package gov.uspto.tasks.service;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
public class AppConfig {

    @Value("${cpc.jdbc.driver}")
    private String driverName;

    @Value("${cpc.jdbc.url}")
    private String url;

    @Value("${cpc.jdbc.user}")
    private String username;

    @Value("${cpc.jdbc.password}")
    private String password;

    @Bean
    public DataSource dataSource() {
        System.out.println("======================================= INIT DATA ===========================================================");
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driverName);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return dataSource;
    }


    @Bean
    public SqlSessionFactory sqlSessionFactory() throws Exception {
        System.out.println("======================================= Ibatis DATA ===========================================================");
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(dataSource());
        return factoryBean.getObject();
    }
}
