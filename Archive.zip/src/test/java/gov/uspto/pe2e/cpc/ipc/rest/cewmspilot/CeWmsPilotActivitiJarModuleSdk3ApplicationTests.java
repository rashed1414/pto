package gov.uspto.pe2e.cpc.ipc.rest.cewmspilot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CeWmsPilotActivitiJarModuleSdk3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
