package gov.uspto.pe2e.cpc.ipc.rest.cewmspilot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CeWmsPilotActivitiJarModuleSdk3Application {

	public static void main(String[] args) {
		SpringApplication.run(CeWmsPilotActivitiJarModuleSdk3Application.class, args);
	}

}
