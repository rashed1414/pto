package gov.uspto.pe2e.cpc.ipc.rest.uspto.listener;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.impl.context.Context;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.annotation.Transient;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.activiti.service.api.GroupService;
import com.activiti.service.api.UserService;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalAssigneeGroup;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalStateTask;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalStateTaskRepository;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.AssignmentGroup;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.OfficeContactType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalStateType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.TaskStateDetails;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalService;
import gov.uspto.tasks.service.Constants;
import gov.uspto.tasks.service.TaskListenerHelper;

/**
 * This is custom listener, responsible to get called at certain tasks, to
 * update CPC database for proposal state, and execute other logics.
 * 
 * @author 2020LLC
 * @release 1.13
 *
 */
@Component("commonTaskProposalUpdateListener")
public class CommonTaskProposalUpdateListener implements TaskListener {

	private static final long serialVersionUID = 1L;
	private static Logger log = LoggerFactory.getLogger(CommonTaskProposalUpdateListener.class);

	@Autowired
	@Transient
	private UserService userService;
	@Autowired
	@Transient
	private GroupService groupService;
	@Autowired
	@Transient
	private IdentityService identityService;
	@Autowired
	@Transient
	private TaskService taskService;
	@Autowired
	@Transient
	private HistoryService historyService;
	@Autowired
	@Transient
	private RuntimeService runtimeService;

	@Autowired
	@Transient
	private ProposalService proposalService;

	public void setProposalService(ProposalService proposalService) {
		this.proposalService = proposalService;
	}

	@Autowired
	@Transient
	private ChangeProposalStateTaskRepository changeProposalStateTaskRepository;

	@Autowired
	@PersistenceContext(name = "cpc")
	private EntityManager entityManager;

	@Autowired
	@Qualifier("transactionManager")
	private PlatformTransactionManager transactionManager;

	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	@Override
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.activiti.engine.delegate.TaskListener#notify(org.activiti.engine.delegate
	 * .DelegateTask)
	 */
	public void notify(final DelegateTask task) {

		log.info(
				"******LISTENER IS GETTING CALLED NOW, for the TASK ID = {} ; and TASK_NAME = {}-{},{} ****************",
				task.getId(), task.getTaskDefinitionKey(), task.getName(), task.getProcessInstanceId());

		if (transactionManager == null) {
			updateProposalState(task, task.getExecutionId(), task.getId());
			return;
		} else {
			TransactionTemplate tmpl = new TransactionTemplate(transactionManager);
			tmpl.execute(new TransactionCallbackWithoutResult() {

				@Override
				protected void doInTransactionWithoutResult(TransactionStatus status) {
					updateProposalState(task, task.getExecutionId(), task.getId());
				}

			});
		}
	}

	public void setTaskService(TaskService taskService) {
		this.taskService = taskService;
	}

	/*
	 * To update the proposal state.
	 * 
	 * @param task
	 * 
	 * @return void
	 */
	private void updateProposalState(DelegateTask task, String executionId, String taskId) {
		taskService = (taskService == null ? taskService = Context.getProcessEngineConfiguration().getTaskService()
				: taskService);
		if (identityService == null)
			identityService = Context.getProcessEngineConfiguration().getIdentityService();
		if (runtimeService == null)
			runtimeService = Context.getProcessEngineConfiguration().getRuntimeService();
		// change state of the proposal and save to CPC database other than activiti DB.
		log.info(" taskService test : " + " ##### " + taskService + " ##### " + task.getId() + " ##### "
				+ task.getExecution().getProcessBusinessKey()+ " ##### "
						+ task.getExecution());
		UUID projectUUID = UUID.fromString(TaskListenerHelper.getProcessName(taskService, task));
		log.info("STARTED_BY {}, actor: {}, office: {}",
				runtimeService.getVariable(executionId, Constants.VAR_TASK_STARTED_BY),
				runtimeService.getVariable(executionId, Constants.VAR_PI_ACTOR),
				runtimeService.getVariable(executionId, Constants.VAR_PI_RAPPORTEUR_OFFICE));
		String actor = (String) runtimeService.getVariable(executionId, Constants.VAR_PI_ACTOR);
		log.debug("Actor  : " + actor);
		actor = TaskListenerHelper.getEmailOfUser(userService, identityService, actor.trim());
		String phase = (String) taskService.getVariable(taskId, Constants.VAR_PI_PHASE);
		runtimeService.setVariable(executionId, Constants.VAR_TASK_TASK_PHASE, phase);

		String subphase = (String) taskService.getVariableLocal(taskId, Constants.VAR_PI_SUB_PHASE);
		runtimeService.setVariable(executionId, Constants.VAR_PI_SUB_PHASE,
				StringUtils.isBlank(subphase) ? null : subphase.trim());

		Date projectStartDate = (Date) runtimeService.getVariable(executionId, Constants.VAR_TASK_PROJECT_START_DATE);
		if (projectStartDate == null) {
			projectStartDate = new Date();
		}
		String assignee = task.getAssignee();
		String email;
		TaskStateDetails details = new TaskStateDetails();
		String newTaskedRole = ""; // By Sheham
		if (assignee != null) {
			email = TaskListenerHelper.getEmailOfUser(userService, identityService, assignee);
			log.info("Set task assignee(CR1): {}->{}", assignee, email);
			details.setAssignee(email);
			runtimeService.setVariable(executionId, Constants.VAR_PI_ACTOR, email);
		} else {
			List<IdentityLink> groups = taskService.getIdentityLinksForTask(taskId);
			// assuming for list of Group since assignee is null.
			for (IdentityLink link : groups) {
				String groupName = (groupService == null
						? TaskListenerHelper.getGroupNameById(identityService, link.getGroupId())
						: groupService.getGroup(Long.parseLong(link.getGroupId())).getName());

				AssignmentGroup assigneeGroup = new AssignmentGroup();
				// group name reads like: US_COORDINATOR
				log.info("groupName : " + groupName);// By Sheham
				if (groupName.contains("_")) {

					newTaskedRole += groupName.replace("_", ":") + ","; // By Sheham

					String officeName = groupName.substring(0, groupName.indexOf("_"));
					if (EnumUtils.isValidEnum(StandardIpOfficeCode.class, officeName)) {
						assigneeGroup.getOffices().add(StandardIpOfficeCode.valueOf(officeName));
						String roleName = groupName.substring(officeName.length() + 1);
						if (EnumUtils.isValidEnum(OfficeContactType.class, roleName))
							assigneeGroup.setRole(OfficeContactType.fromValue(roleName));
					} else {
						// for groups reads like: GROUP1, JOINT_BOARD
						if (EnumUtils.isValidEnum(OfficeContactType.class, groupName))
							assigneeGroup.setRole(OfficeContactType.fromValue(groupName));
					}
				} else {
					newTaskedRole += groupName + ","; // By Sheham
					// for groups reads like: JOINT_BOARD
					if (EnumUtils.isValidEnum(OfficeContactType.class, groupName))
						assigneeGroup.setRole(OfficeContactType.fromValue(groupName));
				}

				details.getAssigneeCandidateGroups().add(assigneeGroup);
			}
		}

		log.info("newTaskedRole : " + newTaskedRole);// By Sheham
		details.setDueTs(task.getDueDate());
		details.setTaskDefinitionKey(task.getTaskDefinitionKey());
		details.setEstimatedDays((Integer) taskService.getVariableLocal(taskId, Constants.VAR_TASK_EXPECTED_DAYS));
		details.setPhase(ProposalPhase.fromValue(phase));
		details.setStartTs(task.getCreateTime());
		details.setSubphase(TaskListenerHelper.getProposalSubphase(subphase));
		details.setTaskId(task.getId());
		details.setTaskName(task.getName());
		// add new fields for office and role
		String office = (String) taskService.getVariableLocal(task.getId(), Constants.VAR_TASK_OFFICE);
		details.setTaskedOffice(StandardIpOfficeCode.fromValue(office));
		String role = (String) taskService.getVariableLocal(task.getId(), Constants.VAR_TASK_ROLE);
		details.setTaskedRole(newTaskedRole);
		// details.setTaskedRole(role);
		// log.info("old role: ", role);
		// log.info("Roles List: ", taskRoleNew);

		// add current task to existing task list
		List<TaskStateDetails> listDetails = new ArrayList<TaskStateDetails>();
		listDetails.add(details);

		if (changeProposalStateTaskRepository != null) {

			log.info("changeProposalStateTaskRepository : ", changeProposalStateTaskRepository);

			List<ChangeProposalStateTask> tasks = changeProposalStateTaskRepository
					.findByProposalGuid(projectUUID.toString());
			// only valid for parallel tasks
			for (ChangeProposalStateTask t : tasks) {
				log.info("task  : ", t.getId());

				HistoricTaskInstance historicTask = historyService.createHistoricTaskInstanceQuery()
						.taskId(t.getTaskId()).singleResult();
				// if the task completed, we need to ignore it.
				if (historicTask != null && historicTask.getEndTime() != null) {
					continue;
				} else {
					// if the existing active task has the same task def ID with current one, ignore
					// it.
					Task activeTask = taskService.createTaskQuery().taskId(t.getTaskId()).singleResult();
					if (activeTask != null && activeTask.getTaskDefinitionKey().equals(task.getTaskDefinitionKey()))
						continue;

					TaskStateDetails td = new TaskStateDetails();
					email = TaskListenerHelper.getEmailOfUser(userService, identityService, t.getAssignee());
					log.info("Set task assignee(CR2): {}->{}", t.getAssignee(), email);
					td.setAssignee(email);
					if (t.getAssignee() == null && t.getAssignmentGroups() != null) {
						Set<ChangeProposalAssigneeGroup> groups = t.getAssignmentGroups();
						for (ChangeProposalAssigneeGroup g : groups) {
							AssignmentGroup group = new AssignmentGroup();
							group.setRole(g.getRole());
							if (g.getIpOfficeCode() != null)
								group.getOffices().add(g.getIpOfficeCode());

							td.getAssigneeCandidateGroups().add(group);
						}
					}
					td.setDueTs(t.getTaskDueTs());

					long diffInMillies = Math.abs(t.getTaskDueTs().getTime() - t.getCreateTs().getTime());
					long days = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS) + 1;

					td.setEstimatedDays((int) days);
					td.setPhase(ProposalPhase.fromValue(phase));
					td.setStartTs(t.getCreateTs());
					td.setTaskDefinitionKey(t.getTaskDefinitionKey());
					td.setSubphase(TaskListenerHelper.getProposalSubphase(subphase));
					td.setTaskId(t.getTaskId());
					td.setTaskName(t.getTaskName());
					// add new fields for office and role
					office = (String) taskService.getVariableLocal(t.getTaskId(), Constants.VAR_TASK_OFFICE);
					td.setTaskedOffice(StandardIpOfficeCode.fromValue(office));
					role = (String) taskService.getVariableLocal(t.getTaskId(), Constants.VAR_TASK_ROLE);
					td.setTaskedRole(newTaskedRole);
					// t.setTaskedRole(newTaskedRole); // By Sheham
					listDetails.add(td);
				}
			}
		}

		TaskStateDetails[] arrayTasks = new TaskStateDetails[listDetails.size()];
		arrayTasks = listDetails.toArray(arrayTasks);

		log.debug("projectStartDate --> " + projectStartDate);
		if (proposalService != null)
			proposalService.updateProposalStatus(projectUUID, task.getProcessInstanceId(),
					task.getProcessDefinitionId(), projectStartDate, null, ProposalPhase.fromValue(phase),
					TaskListenerHelper.getProposalSubphase(subphase), ProposalStateType.ACTIVE, actor, null,
					arrayTasks);
	}

	public void setHistoryService(HistoryService historyService) {
		this.historyService = historyService;
	}

	public void setIdentityService(IdentityService identityService) {
		this.identityService = identityService;
	}

	public void setChangeProposalStateTaskRepository(
			ChangeProposalStateTaskRepository changeProposalStateTaskRepository) {
		this.changeProposalStateTaskRepository = changeProposalStateTaskRepository;
	}

	public void setRuntimeService(RuntimeService runtimeService) {
		this.runtimeService = runtimeService;
	}

}