package org.activiti.test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;

import junit.framework.Assert;




@ContextConfiguration(classes=WmsBypassTest.class)
public class WmsBypassTest {
    private static final Logger log =  LoggerFactory.getLogger(WmsBypassTest.class);
    
    
    @BeforeEach
	public void setUp() throws Exception {
    	log.debug("Nothing to test , bypassing all cases");
	}


    @Test
    public void testDummy() throws Exception {
    	log.debug("Nothing to test , bypassing all cases");
    	Assert.assertTrue(true);
    }
    

 

}
