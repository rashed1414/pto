/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.pm.testing;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.CpcCsdGroupService;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.User;

/**
 * @author myoung3
 *
 */
@Service
public class MockCpcCsdGroupService implements CpcCsdGroupService {

	@Override
	public List<User> getCsdGroupUsersByGrpName(String csdGroup) {
		List<User> users = new ArrayList<>();
		User u = new User();
		u.setEmail("xboopathi@uspto.gov");
		users.add(u);
		return users;
	}

}
