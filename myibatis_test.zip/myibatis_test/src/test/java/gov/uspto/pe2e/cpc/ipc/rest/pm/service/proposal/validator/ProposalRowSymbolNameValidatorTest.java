package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowSymbolNameValidatorTest {
	
	private static final Logger log = LoggerFactory.getLogger(ProposalRowSymbolNameValidatorTest.class);
	
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ProposalRowSymbolNameValidator proposalRowSymbolNameValidator;
    
    @Inject
    private ProposalValidationService proposalValidationService;
    
    @Resource
    private List<ProposalValidator> proposalValidators;
    
    @Test
    public void testConfigCorrectlyIncludesSymbolNameValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator: proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(proposalRowSymbolNameValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }
    
    @Test
    public void testValidate1() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A1", "Section", "Title Text", new String[] {"A01N"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolNameValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        for (RevisionChangeItem row : rows) {
            Assert.assertEquals(1, row.getValidationMessages().size());
            for (ValidationMessage msg : row.getValidationMessages()) {
                Assert.assertEquals(ValidationMessageField.SYMBOL_NAME, msg.getTriggerField());
                log.debug(msg.getMessageText());
                Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
            }
        }
    }
    
    @Test
    public void testValidate2() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01b100", "Section", "Title Text", new String[] {"A01N"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolNameValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        for (RevisionChangeItem row : rows) {
            Assert.assertEquals(1, row.getValidationMessages().size());
            for (ValidationMessage msg : row.getValidationMessages()) {
                Assert.assertEquals(ValidationMessageField.SYMBOL_NAME, msg.getTriggerField());
                log.debug(msg.getMessageText());
                Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
            }
        }
    }
    
    //H04N 9/04559
    @Test
    public void testValidate3() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "HO4N 5/232933", "Section", "Title Text", new String[] {"A01N"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolNameValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        for (RevisionChangeItem row : rows) {
            Assert.assertEquals(1, row.getValidationMessages().size());
            for (ValidationMessage msg : row.getValidationMessages()) {
                Assert.assertEquals(ValidationMessageField.SYMBOL_NAME, msg.getTriggerField());
                log.debug(msg.getMessageText());
                Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
                Assert.assertEquals("Symbol 'HO4N 5/232933' is not well formed and does not meet the required CPC symbol pattern.",msg.getMessageText());
            }
        }
    }
    
    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.LOW, proposalRowSymbolNameValidator.getCost());

    }
    
    @Test 
    public void testGetValidatorType() {
        Assert.assertEquals(ValidationMessageType.RECORD, proposalRowSymbolNameValidator.getValidationType());
        
        
    }

    @Before
    public void setUp() throws Exception {
        datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }

}
