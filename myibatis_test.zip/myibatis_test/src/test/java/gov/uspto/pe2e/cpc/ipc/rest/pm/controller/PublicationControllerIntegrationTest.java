package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.DatabaseUnitException;
import org.dbunit.dataset.DataSetException;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PrivateProposalTreeStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationTreeStatus;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test-oraclelocal.xml" })
@TestPropertySource("classpath:oracle.properties") // this allows the integration test to override oracle properties without affecting spring factory
@NotThreadSafe
@Category(NotThreadSafe.class)
public class PublicationControllerIntegrationTest  {
    private static final Logger log = LoggerFactory.getLogger(PublicationControllerIntegrationTest.class);
   
    @Inject
    private ProposalController proposalController;
   
       
    /**
     * 
     * @throws IOException 
     * @throws DatabaseUnitException 
     * @throws SQLException 
     * @throws FileNotFoundException 
     * @throws DataSetException 
     * @throws BeansException 
     */
    @Transactional
    @Test
    public void testValidatePrivatePublicationTreeStatus() throws BeansException, DataSetException, FileNotFoundException, SQLException, DatabaseUnitException, IOException {        
    	ResponseEntity<PrivateProposalTreeStatus> resp = proposalController.getPublicationTree(UUID.fromString("fa70195c-5334-47e7-833d-dde9833dff36"));
    	assertNotNull(resp);
    	assertNotNull(resp.getBody());
    	assertEquals(PublicationTreeStatus.COMPLETE, resp.getBody().getStatus());
    	
    }
    
    @Before
    public void setUp() throws Exception {
//        IDatabaseConnection conn = datasetTestingService.getConnection();
//        datasetTestingService.emptyTables(conn);
//        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
    			"bkuppusamy", "Boops","Kuppusamy", "US");
    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"boopathi.kuppusamy@uspto.gov", token,
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/proposals/1/twl")));
    }

    
    
}