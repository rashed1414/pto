package gov.uspto.pe2e.cpc.ipc.rest.pm.service;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalLock;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalLockRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import jakarta.inject.Inject;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalLockManagerTest {
    
    private static final Logger log = LoggerFactory.getLogger(ProposalLockManagerTest.class);
    
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private SecurityService securityService;

    @Inject
    private ChangeProposalLockRepository changeProposalLockRepository;

    @Inject
    private ChangeProposalRepository changeProposalRepository;
    
    
    @Test 
    public void testAcquireLock() {
    	
    	ChangeProposalLock existingLock = changeProposalLockRepository
				.findAnyExsitngLock("c960d30a52a847fc8c51b64dfcc0ea85");
    	
    	System.out.println("Test-1"+existingLock);
    	
		/*
		 * UsernamePasswordAuthenticationToken springUser = new
		 * UsernamePasswordAuthenticationToken( "test.user@uspto.gov",
		 * "test.user@uspto.gov", Arrays.asList(new
		 * BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
		 * )); SecurityContextHolder.getContext().setAuthentication(springUser);
		 * 
		 * UsptoAuthenticationToken authToken =
		 * securityService.mapSamlTokenToContractModel(springUser);
		 * 
		 * ProposalMetadataUpdateRequest request = new ProposalMetadataUpdateRequest();
		 * 
		 * request.setId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"
		 * ));//"XX0026"); request.setFamilyCount(4);
		 * request.setSize(ProjectSizeCategory.MEDIUM);
		 * 
		 * request.setRapporteurOffice(StandardIpOfficeCode.US);
		 * 
		 * List<OfficeContact> primaryContacts = new ArrayList<>();
		 * primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,
		 * OfficeContactType.COORDINATOR,"matt.young@uspto.gov"));
		 * primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,
		 * OfficeContactType.EDITORIAL_BOARD,"boops@uspto.gov"));
		 * primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,
		 * OfficeContactType.QN_TECH_EXPERT,"venkat@uspto.gov"));
		 * 
		 * List<OfficeContact> secondaryContacts = new ArrayList<>();
		 * secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,
		 * OfficeContactType.COORDINATOR,"venkat@uspto.gov"));
		 * secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,
		 * OfficeContactType.EDITORIAL_BOARD,"boops@uspto.gov"));
		 * secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,
		 * OfficeContactType.QN_TECH_EXPERT,"matt.young@uspto.gov"));
		 * 
		 * request.getPrimaryOfficeContacts().addAll(primaryContacts);
		 * request.getSecondaryOfficeContacts().addAll(secondaryContacts);
		 * 
		 * request.setCpcAreaText("test 123"); request.setSubject("Test 456");
		 * ProposalSummary p =
		 * proposalService.updateProposalMetadata(GUIDUtils.fromDatabaseFormat(
		 * "d153f9bf804848aa8ba202db9f844db5"), request, authToken);
		 * 
		 * Assert.assertNotNull(p); Assert.assertEquals("XX0026", p.getDisplayName());
		 * 
		 * Assert.assertEquals(3, p.getTechnologies().size()); Assert.assertEquals(2,
		 * p.getPrimaryOfficeContacts().size()); Assert.assertEquals(1,
		 * p.getSecondaryOfficeContacts().size());
		 */
    	
    }
   
    
    
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }

}
