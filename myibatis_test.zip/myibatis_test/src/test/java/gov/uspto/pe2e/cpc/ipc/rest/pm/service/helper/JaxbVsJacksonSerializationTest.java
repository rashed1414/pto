package gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper;


import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.DefinitionSectionTypeDictionary;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.VersionSymbol;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.DurationUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.collections.CollectionScanner;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.pm.job.processor.ProposalDocxImporterTest;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem;
import jakarta.inject.Inject;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class JaxbVsJacksonSerializationTest {
	private static final Logger log = LoggerFactory.getLogger(ProposalDocxImporterTest.class);

	 @Inject
	 private DatasetTestingService datasetTestingService;
	    
	@Inject
	private ProposalImportHelper proposalImportHelper;
	
	
	@Test
	public void testCompareJsonToXML() throws JsonParseException, JsonMappingException, IOException {
		String sctFile = "data/json/proposal/AE_sla_revision_change_items.json";
		
		ObjectMapper mapper = new ObjectMapper();

		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);


		try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(sctFile)) {
			Date now = new Date();
			String username ="test";
			List<RevisionChangeItemRequest> sctItems =	mapper.readValue(is, new TypeReference<List<RevisionChangeItemRequest>>(){});
			
			long start = System.currentTimeMillis();
			for (RevisionChangeItemRequest row: sctItems) {
				VersionSymbol vs = new VersionSymbol();
				vs.setSymbolName(row.getSymbolName());
			   proposalImportHelper.buildAndSetComponentRevisionForDefinition(vs, row, username, now);
			}

			long end = System.currentTimeMillis();
			log.info("{} row took {} as XML", sctItems.size(), DurationUtils.toDuration(end-start));
//			String json = IOUtils.toString(is);
			start = System.currentTimeMillis();
			for (RevisionChangeItemRequest row: sctItems) {
				   if (row != null && CollectionUtils.isNotEmpty(row.getDefinitionItems())) {
			        	DefinitionItem def = new DefinitionItem();
			            for (DefSectionItemEditRequest defEdit : row.getDefinitionItems()) {
			                
			                if (defEdit != null) {
			                	
			                	DefinitionSectionTypeDictionary dict = DefinitionSectionTypeDictionary.valueOf(defEdit.getSectionType().name());
			                	Object content = CollectionScanner.coalesce(defEdit.getDefinitionTitle(), defEdit.getDefinitionStatement(),
			                            defEdit.getRelationship(), defEdit.getInformativeReferences(), defEdit.getLimitingReferences(),
			                            defEdit.getResidualReferences(), defEdit.getApplicationReferences(), defEdit.getGlossaryOfTerms(),
			                            defEdit.getSpecialRules(), defEdit.getSynonymsKeywords());
			               	 	if (defEdit != null && defEdit.getChangeType() != null) {
			               	 		BeanWrapper contentWrapper = PropertyAccessorFactory.forBeanPropertyAccess(content);
			               	 		contentWrapper.setPropertyValue("documentChangeType",defEdit.getChangeType().name());
			               	 	}
			                	   BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(def);
			                	   wrapper.setAutoGrowNestedPaths(true);
			                	   wrapper.setPropertyValue(dict.getFieldPath(),content);
			                	   


			                }
			            }
			            def.setDateRevised(now);
			            String xml = mapper.writeValueAsString(def);
			            
			        }

			}

			end = System.currentTimeMillis();
			log.info("{} row took {} as json", sctItems.size(), DurationUtils.toDuration(end-start));
//			
		}
	}
	
}