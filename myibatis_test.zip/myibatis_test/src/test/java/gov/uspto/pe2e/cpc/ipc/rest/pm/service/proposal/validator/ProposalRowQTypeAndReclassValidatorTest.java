package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowQTypeAndReclassValidatorTest {
	
    private static final Logger log = LoggerFactory.getLogger(ProposalRowQTypeAndReclassValidatorTest.class);

    private static final String EXPECTED_MESSAGE1 ="Q groups should transfer to self and at least one other group.";
    private static final String EXPECTED_MESSAGE2 ="Q groups may not have administrative transfers. Q groups require intellectual reclass.";
    
    @Inject
    private DatasetTestingService datasetTestingService;
    
    
    @Inject
    private  ProposalRowQTypeAndReclassValidator  proposalRowQTypeAndReclassValidator;

    @Resource
    private List<ProposalValidator> proposalValidators;
    
    @Inject
    private ProposalValidationService proposalValidationService;

    @Test
    public void testConfigCorrectlyIncludesGrammarValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(proposalRowQTypeAndReclassValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }
    
    @Test
    public void testValidate1() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A01B5/005", "0", "Bold Error ##BOLD##", new String[] {"A01B 5/005","A01B 5/008"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowQTypeAndReclassValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());        
        Assert.assertEquals(EXPECTED_MESSAGE2, rows.get(0).getValidationMessages().get(0).getMessageText());
        //Assert.assertEquals(EXPECTED_MESSAGE2, rows.get(0).getValidationMessages().get(1).getMessageText());
        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, rows.get(0).getValidationMessages().get(0).getTriggerField());                
        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(0).getLevel());
        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(0).getMessageType());
        Assert.assertTrue(StringUtils.isNotBlank(rows.get(0).getValidationMessages().get(0).getMessageText()));
/*        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, rows.get(0).getValidationMessages().get(1).getTriggerField());                
        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(1).getLevel());
        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(1).getMessageType());
        Assert.assertTrue(StringUtils.isNotBlank(rows.get(0).getValidationMessages().get(1).getMessageText()));
*/        
    }

    @Test
    public void testValidate2() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItemWithIntelluctualReclassCategory("Q", "A01B5/005", "0", "Bold Error ##BOLD##", new String[] {"A01B 5/005","A01B 5/008"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowQTypeAndReclassValidator.validate(proposalValidationContext, rows);
//        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
//        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());        
//        Assert.assertEquals(EXPECTED_MESSAGE2, rows.get(0).getValidationMessages().get(0).getMessageText());
        //Assert.assertEquals(EXPECTED_MESSAGE2, rows.get(0).getValidationMessages().get(1).getMessageText());
//        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, rows.get(0).getValidationMessages().get(0).getTriggerField());                
//        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(0).getLevel());
//        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(0).getMessageType());
//        Assert.assertTrue(StringUtils.isNotBlank(rows.get(0).getValidationMessages().get(0).getMessageText()));
/*        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, rows.get(0).getValidationMessages().get(1).getTriggerField());                
        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(1).getLevel());
        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(1).getMessageType());
        Assert.assertTrue(StringUtils.isNotBlank(rows.get(0).getValidationMessages().get(1).getMessageText()));
*/        
    }
    
    @Test
    public void testValidate3() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A01B5/005", "0", "Bold Error ##BOLD##", new String[] {"A01B 5/005"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowQTypeAndReclassValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertEquals(2, rows.get(0).getValidationMessages().size());
        Assert.assertEquals(EXPECTED_MESSAGE1, rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals(EXPECTED_MESSAGE2, rows.get(0).getValidationMessages().get(1).getMessageText());
        //Assert.assertEquals(EXPECTED_MESSAGE2, rows.get(0).getValidationMessages().get(1).getMessageText());
        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, rows.get(0).getValidationMessages().get(0).getTriggerField());                
        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(0).getLevel());
        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(0).getMessageType());
        Assert.assertTrue(StringUtils.isNotBlank(rows.get(0).getValidationMessages().get(0).getMessageText()));
/*        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, rows.get(0).getValidationMessages().get(1).getTriggerField());                
        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(1).getLevel());
        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(1).getMessageType());
        Assert.assertTrue(StringUtils.isNotBlank(rows.get(0).getValidationMessages().get(1).getMessageText()));
*/        
    }
    
    @Before
    public void setUp() throws Exception {
        datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }

}
