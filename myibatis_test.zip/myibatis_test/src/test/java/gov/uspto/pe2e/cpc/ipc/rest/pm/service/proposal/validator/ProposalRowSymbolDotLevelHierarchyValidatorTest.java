package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.api.parallel.ExecutionMode;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@Execution(ExecutionMode.CONCURRENT)
public class ProposalRowSymbolDotLevelHierarchyValidatorTest {
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ProposalRowSymbolDotLevelHierarchyValidator proposalRowSymbolDotLevelHierarchyValidator;
    
    @Inject
    private ProposalValidationService proposalValidationService;
    
    @Resource
    private List<ProposalValidator> proposalValidators;
    
    @Test
    public void testConfigCorrectlyIncludesDotLevelWithSymbolValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator: proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(proposalRowSymbolDotLevelHierarchyValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    } 
    
    @Test
    public void testValidateSubGroupWithValidIndent() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01F1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01F1/08", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01F1/10", "3", "Title Text", new String[] {"A01N"}));
       
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(2).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals("This symbol 'A01F1/10' with Indent '3' lacks proper preceding row/symbol with Indent '2' in SDCT.", rows.get(2).getValidationMessages().get(0).getMessageText());
        
    }
    
    @Test
    public void testValidateSubGroupWithValidIndentNoError() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01F1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01F1/08", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01F1/10", "1", "Title Text", new String[] {"A01N"}));
       
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
       
    }
    
    @Test
    public void testValidateSubGroupWithValidIndentWithNewSubGroupSymbol() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D", "Subclass", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01D1/08", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D4/11", "1", "Title Text", new String[] {"A01N"}));

        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
        Assert.assertEquals("This symbol 'A01D4/11' with Indent '1' lacks proper preceding row/symbol with Indent '0' in SDCT.", rows.get(3).getValidationMessages().get(0).getMessageText());
    }

    @Test
    public void testValidateSubGroupWithInvalidIndent(){
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "D99Z2/45", "Subclass", "Title Text", new String[] {"A01N"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals("This symbol 'D99Z2/45' is not valid for Indent 'Subclass'", rows.get(0).getValidationMessages().get(0).getMessageText());
    }
    
    @Test
    public void testValidateSubGroupWithValidIndentWithMultiSubGroupSymbol() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D", "Subclass", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01D1/08", "3", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D4/11", "3", "Title Text", new String[] {"A01N"}));
       
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertEquals("This symbol 'A01D1/08' with Indent '3' lacks proper preceding row/symbol with Indent '2' in SDCT.", rows.get(2).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals("This symbol 'A01D4/11' with Indent '3' lacks proper preceding row/symbol with Indent '2' in SDCT.", rows.get(3).getValidationMessages().get(0).getMessageText());
       
    }
    
    @Test
    public void testValidateSubGroupWithValidIndentWithMulti1SubGroupSymbol() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D", "Subclass", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01D1/08", "3", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D4/11", "3", "Title Text", new String[] {"A01N"}));
       
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertEquals("This symbol 'A01D1/08' with Indent '3' lacks proper preceding row/symbol with Indent '2' in SDCT.", rows.get(2).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals("This symbol 'A01D4/11' with Indent '3' lacks proper preceding row/symbol with Indent '2' in SDCT.", rows.get(3).getValidationMessages().get(0).getMessageText());
       
    }
    
    @Test
    public void testValidateSubGroupWithValidIndentWithSubGroupA01B() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01B1/00", "Subclass", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01B1/22", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01B1/222", "2", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01B1/225", "3", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01B1/25", "4", "Title Text", new String[] {"A01N"}));
       
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(3).getValidationMessages().isEmpty());
        Assert.assertEquals("This symbol 'A01B1/25' with Indent '4' lacks proper preceding row/symbol with Indent '3' in SDCT.", rows.get(4).getValidationMessages().get(0).getMessageText());
        
       
    }
    
    
    @Test
    public void testValidateSubGroupWithValidIndentWithMulti1SubGroupSymbolTest() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B 1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B 1/06", "1", "Title Text", new String[] {"A01N"}));
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
       
    }
    
    @Test
    public void testValidateSubGroupWithValidIndentWithMulti1SubGroupSymbolTest1() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("C", "A01B1/22 ", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("C", "A01B1/222", "2", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/225", "3", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/25", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/26", "3", "Title Text", new String[] {"A01N"}));
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals("This symbol 'A01B1/26' with Indent '3' lacks proper preceding row/symbol with Indent '2' in SDCT.", rows.get(5).getValidationMessages().get(0).getMessageText());
       
    }
    
    @Test
    public void testValidateSubGroupWithValidIndentWithMulti1SubGroupSymbolTest2() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("C", "A01B1/02 ", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("C", "A01B1/06", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/065", "2", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/08", "2", "Title Text", new String[] {"A01N"}));
        
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(3).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(4).getValidationMessages().isEmpty());
       
    }
    
    @Test
    public void testValidateSubGroupWithValidIndentWithMulti1SubGroupSymbol1() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D", "Subclass", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01D1/08", "2", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/16", "3", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/26", "5", "Title Text", new String[] {"A01N"}));
       
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
        Assert.assertEquals("This symbol 'A01D1/16' with Indent '3' lacks proper preceding row/symbol with Indent '2' in SDCT.", rows.get(3).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals("This symbol 'A01D1/26' with Indent '5' lacks proper preceding row/symbol with Indent '4' in SDCT.", rows.get(4).getValidationMessages().get(0).getMessageText());
       
    }
    
    
    @Test
    public void testValidateSubGroupWithValidIndentWithMulti1SubGroupSymbol11() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D", "Subclass", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01D1/08", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D11/025", "2", "Title Text", new String[] {"A01N"}));
       
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(3).getValidationMessages().isEmpty());
       
    }
    
    @Test
    public void testValidateSubGroupWithValidIndentWithMulti1SubGroupSymbol12() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D", "Subclass", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01D1/08", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/10", "3", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/13", "6", "Title Text", new String[] {"A01N"}));
       
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
        Assert.assertEquals("This symbol 'A01D1/10' with Indent '3' lacks proper preceding row/symbol with Indent '2' in SDCT.", rows.get(3).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals("This symbol 'A01D1/13' with Indent '6' lacks proper preceding row/symbol with Indent '5' in SDCT.", rows.get(4).getValidationMessages().get(0).getMessageText());
       
    }
    
    @Test
    public void testValidateSubGroupWithValidIndentWithMulti1SubGroupSymbol13() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D", "Subclass", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01D1/08", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/10", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/11", "2", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/20", "1", "Title Text", new String[] {"A01N"}));
       
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(3).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(4).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(5).getValidationMessages().isEmpty());
       
    }
    
    @Test
    public void testValidateSubGroupWithValidIndentWithMulti1SubGroupSymbol14() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D", "Subclass", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D1/00", "0", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01D1/08", "1", "Title Text", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D11/025", "3", "Title Text", new String[] {"A01N"}));
       
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowSymbolDotLevelHierarchyValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
        Assert.assertEquals("This symbol 'A01D11/025' with Indent '3' lacks proper preceding row/symbol with Indent '2' in SDCT.", rows.get(3).getValidationMessages().get(0).getMessageText());      
       
    }
    
    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.LOW, proposalRowSymbolDotLevelHierarchyValidator.getCost());
    }
    
    @Test 
    public void testGetValidatorType() {
        Assert.assertEquals(ValidationMessageType.RECORD, proposalRowSymbolDotLevelHierarchyValidator.getValidationType());        
        
    }

    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();
	        SchemePublicationVersion version = new SchemePublicationVersion();
	        version.setClassificationSchemeId(1L);
	        version.setCpcXsdVersion("1.7");
	        version.setDefinitionXsdVersion("1.0");
	        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
	        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
	        SchemePublicationVersionContextHolder.setContext(version);
	   
    }

}
