package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import javax.xml.stream.XMLStreamReader;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.CloseableUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.TitleConverter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.NamespaceXmlReader;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefinitionSectionType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.LimitingReferences;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.SynonymsKeywords;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowDefinitionLegacySKInGoldCopyValidatorTest {
	

	private static final Logger log = LoggerFactory.getLogger(TitleSymbolRefOrderWithinRefPartValidator.class);

	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private ProposalValidationService proposalValidationService;
	
	@Inject
	private TitleService titleService;

	private DocumentAdapter docAdapter;

	@Resource(name = "proposalConsistencyValidator")
	private List<ProposalValidator> proposalValidators;
	

	@Inject
	private ProposalRowDefinitionLegacySKInGoldCopyValidator  proposalRowDefinitionLegacySKInGoldCopyValidator; 
	
	@Transactional
	@Test
	public void testValidateBasicError() {
		String filename = "data/xml/fragments/definition_limitingreference_with_empty_table2.xml";
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01M1/00", "0", 
				 " test (test 123 ##SYMBOL##B01N##/SYMBOL##; test ##SYMBOL##A01N##/SYMBOL## test ##SYMBOL##A##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
		 DefSectionItemEditRequest req = new DefSectionItemEditRequest();

	        req.setChangeType(SCTComponentChangeType.M);
	        req.setSectionType(DefinitionSectionType.LIMITING_REFERENCES);
 	        LimitingReferences def = null;
	        InputStream is = null;
	        XMLStreamReader xsr = null;
	        NamespaceXmlReader xr = null;
	        try  {
	            is = Thread.currentThread().getContextClassLoader()
	                .getResourceAsStream( filename);
	            log.debug("inputStream is not null {} ", is != null);
	            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
	                +IOUtils.toString(is)+"</references></definition-item>");
	            def = defItem.getReferences().getLimitingReferences();
	        } catch (Exception je) {
	            log.debug("failed to parse xml",je);
	            throw new IllegalArgumentException(je);
	        } finally {
	            CloseableUtils.closeQuietly(xr);
	            CloseableUtils.closeQuietly(xsr);
	            IOUtils.closeQuietly(is);
	        }
	        
	        req.setLimitingReferences(def);
	        assertNotNull(req.getLimitingReferences());

	        
	        item.getDefinitionItems().add(req);
	        
	        List<RevisionChangeItem> rows = new ArrayList<>();

	        rows.add(item);
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        proposalRowDefinitionLegacySKInGoldCopyValidator.validate(proposalValidationContext, rows);
	        assertEquals(1, rows.size());
	        assertEquals(0, rows.get(0).getValidationMessages().size());
			/*
			 * assertEquals("Legacy Synonyms and Keywords section detected. It must be replaced by new-format Synonyms and Keywords subsections or deleted."
			 * , rows.get(0).getValidationMessages().get(0).getMessageText());
			 */
	        
	}
	@Transactional
	@Test
	public void testValidateBasicErrorCondpath2() {
		String filename = "data/xml/fragments/definition/def_snk_a01m1_00.xml";
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01M1/00", "0", 
				 " test (test 123 ##SYMBOL##B01N##/SYMBOL##; test ##SYMBOL##A01N##/SYMBOL## test ##SYMBOL##A##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
		 DefSectionItemEditRequest req = new DefSectionItemEditRequest();

	        req.setChangeType(SCTComponentChangeType.M);
	        req.setSectionType(DefinitionSectionType.SYNONYMS_AND_KEYWORDS);
 	        SynonymsKeywords def = null;
	        InputStream is = null;
	        XMLStreamReader xsr = null;
	        NamespaceXmlReader xr = null;
	        try  {
	            is = Thread.currentThread().getContextClassLoader()
	                .getResourceAsStream( filename);
	            log.debug("inputStream is not null {} ", is != null);
	            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
	                +IOUtils.toString(is)+"</definition-item>");
	            def = defItem.getSynonymsKeywords();
	        } catch (Exception je) {
	            log.debug("failed to parse xml",je);
	            throw new IllegalArgumentException(je);
	        } finally {
	            CloseableUtils.closeQuietly(xr);
	            CloseableUtils.closeQuietly(xsr);
	            IOUtils.closeQuietly(is);
	        }
	        
	        req.setSynonymsKeywords(def);
	        assertNotNull(req.getSynonymsKeywords());

	        
	        item.getDefinitionItems().add(req);
	        
	        List<RevisionChangeItem> rows = new ArrayList<>();

	        rows.add(item);
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        proposalRowDefinitionLegacySKInGoldCopyValidator.validate(proposalValidationContext, rows);
	        assertEquals(1, rows.size());
	        assertEquals(0, rows.get(0).getValidationMessages().size());
	        //assertEquals("Legacy Synonyms and Keywords section detected. It must be replaced by new-format Synonyms and Keywords subsections or deleted.", 
	        			//rows.get(0).getValidationMessages().get(0).getMessageText());
	        
	}

	@Test
	public void testVerifyConfig() {
		  boolean isIncluded = false;
	        for (ProposalValidator validator: proposalValidators) {
	            if (validator.getClass().getCanonicalName().equals(proposalRowDefinitionLegacySKInGoldCopyValidator.getClass().getCanonicalName())) {
	                isIncluded = true;
	                break;
	            }
	        }
	        Assert.assertTrue(isIncluded);

	}


	@Test
	public void testGetValidationType() {
		assertEquals(ValidationMessageType.RECORD,proposalRowDefinitionLegacySKInGoldCopyValidator.getValidationType());
	}

	@Test
	public void testGetCost() {
		assertEquals(ValidationCost.HIGH, proposalRowDefinitionLegacySKInGoldCopyValidator.getCost());
	}

	@Before
	public void setUp() throws Exception {

		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		DateTimeZone.setDefault(DateTimeZone.UTC);
		datasetTestingService.loadOnce();

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(2L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);
		
		 
        Class adapterClass = Class.forName(DocumentAdapter.class.getCanonicalName());
        docAdapter = (DocumentAdapter)adapterClass.newInstance();

		
	}


}
