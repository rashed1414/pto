package gov.uspto.pe2e.cpc.ipc.rest.web.service.handler.lock;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.LocalDateTime;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposal;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalLock;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalLockRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.OfficeContactType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.infrastructure.pessimisticlocking.proposal.ProposalLock;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.OfficeContact;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProjectSizeCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalCreationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalController;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalLockManager;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.handler.lock.ProposalLockAcquireLockHandler;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.handler.lock.ProposalLockAutoExtendLockHandler;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.handler.lock.ProposalLockReleaseNameLocksHandler;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.handler.lock.ProposalLockReleaseThisLockHandler;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.handler.lock.ProposalLockUserLockReportHandler;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalLockHandlersTest {

    private static final Logger log = LoggerFactory.getLogger(ProposalLockHandlersTest.class);
    @Inject
    private DatasetTestingService datasetTestingService;
    @Inject
    private ChangeProposalRepository changeProposalRepository;

    @Inject
    private ProposalController proposalController;
    @Inject
    private ProposalLockManager proposalLockManager;
    @Inject
    private ChangeProposalLockRepository changeProposalLockRepository;
    @Inject 
    private ProposalLockUserLockReportHandler proposalLockUserLockReportHandler;
    @Inject
    private ProposalLockReleaseNameLocksHandler proposalLockReleaseNameLocksHandler;
    @Inject
    private ProposalLockReleaseThisLockHandler proposalLockReleaseThisLockHandler;
    
    @Inject
    private ProposalLockAcquireLockHandler proposalLockAcquireLockHandler;

    @Inject
    private ProposalLockAutoExtendLockHandler proposalLockAutoExtendLockHandler;
    
    
    @Transactional
    @Test
    public void testGetLockListPostHandler() throws Exception {
        createAndSaveLock(1000000001L, "user@user.com", 15);
        createAndSaveLock(1000000002L, "user@user.com", 15);
        HttpServletRequest request = WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposals");
        HttpServletResponse response = WebMocker.mockHttpResponse();
        proposalLockUserLockReportHandler.postHandle(request, response, null, null);
        log.debug("Response {}", response.getHeaderNames());
        String header = response.getHeader(ProposalLockManager.HELD_LOCK_RESPONSE_ATTR_NAME);
        Assert.assertEquals(2, header.split(";").length);
        
    }
    
    @Transactional
    @Test
    public void testReleaseByName() throws Exception {
        createAndSaveLock(1000000001L, "user@user.com", 15);
        createAndSaveLock(1000000002L, "user@user.com", 15);
        HttpServletRequest request = WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposals");
        ((MockHttpServletRequest)request).addHeader(ProposalLockManager.RELEASE_LOCK_GUID_HEADER_NAME, GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85").toString());

        ((MockHttpServletRequest)request).addHeader(ProposalLockManager.RELEASE_LOCK_GUID_HEADER_NAME, GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7").toString());
        HttpServletResponse response = WebMocker.mockHttpResponse();
        proposalLockReleaseNameLocksHandler.postHandle(request, response, null, null);
        long count = changeProposalLockRepository.count();
        
        Assert.assertEquals(0, count);
    }


    @Transactional
    @Test
    public void testReleaseByNameWithUnparsableGuid() throws Exception {
        createAndSaveLock(1000000001L, "user@user.com", 15);
        createAndSaveLock(1000000002L, "user@user.com", 15);
        HttpServletRequest request = WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposals");
        ((MockHttpServletRequest)request).addHeader(ProposalLockManager.RELEASE_LOCK_GUID_HEADER_NAME, GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85").toString());
        ((MockHttpServletRequest)request).addHeader(ProposalLockManager.RELEASE_LOCK_GUID_HEADER_NAME, GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7").toString());
        ((MockHttpServletRequest)request).addHeader(ProposalLockManager.RELEASE_LOCK_GUID_HEADER_NAME, "51614cc00eb");
        HttpServletResponse response = WebMocker.mockHttpResponse();
        proposalLockReleaseNameLocksHandler.postHandle(request, response, null, null);
        long count = changeProposalLockRepository.count();
        Assert.assertEquals(0, count);
    }


    @Transactional
    @Test
    public void testReleaseThisLockHandler() throws Exception {

        HttpServletRequest request = WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposals");
        ((MockHttpServletRequest)request).addHeader(ProposalLockManager.RELEASE_LOCK_HEADER_NAME, Boolean.TRUE.toString());
        HttpServletResponse response = WebMocker.mockHttpResponse();

        RequestContextHolder.setRequestAttributes(
                new ServletRequestAttributes(request));
        proposalLockManager.acquireLock(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),"user@user.com", null);
        proposalLockReleaseThisLockHandler.postHandle(request, response, null, null);
        long count = changeProposalLockRepository.count();
        Assert.assertEquals(0, count);
    }


  

    @Transactional
    @Test
    public void testAcquireByProposalGuidInUrl() throws Exception {

        HttpServletRequest request = WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposals/"+GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
        ((MockHttpServletRequest)request).setMethod(RequestMethod.POST.name());
        HttpServletResponse response = WebMocker.mockHttpResponse();

        RequestContextHolder.setRequestAttributes(
                new ServletRequestAttributes(request));
        proposalLockAcquireLockHandler.preHandle(request, response, null);
        long count = changeProposalLockRepository.count();
        Assert.assertEquals(1, count);
        Assert.assertNotNull(request.getAttribute(ProposalLockManager.THIS_NEW_LOCK_REQUEST_ATTR_NAME));
    }



    @Transactional
    @Test
    public void testExtendLockByProposalGuidInUrl() throws Exception {
        String dbUuid = "c960d30a52a847fc8c51b64dfcc0ea85";
        createAndSaveLock(1000000001L, "user@user.com", 1);
        HttpServletRequest request = WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposals/"
                +GUIDUtils.fromDatabaseFormat(dbUuid));
        ((MockHttpServletRequest)request).setMethod(RequestMethod.POST.name());
        HttpServletResponse response = WebMocker.mockHttpResponse();

        RequestContextHolder.setRequestAttributes(
                new ServletRequestAttributes(request));
        proposalLockAutoExtendLockHandler.postHandle(request, response, null,null);
        ProposalLock lock =proposalLockManager.lookupExistingLock(GUIDUtils.fromDatabaseFormat(dbUuid));
        Assert.assertNotNull(lock);
        Assert.assertTrue(new LocalDateTime().plusHours(2).toDate().before(lock.getLockExpirationTs()));
    }


    @Transactional
    @Test
    public void testExtendLockByProposalGuidNotInUrl() throws Exception {
        HttpServletRequest request = WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposals");
        ((MockHttpServletRequest)request).setMethod(RequestMethod.POST.name());
        HttpServletResponse response = WebMocker.mockHttpResponse();

        RequestContextHolder.setRequestAttributes(
                new ServletRequestAttributes(request));
        proposalLockAutoExtendLockHandler.postHandle(request, response, null,null);
        List<ProposalLock> locks =proposalLockManager.listAllLocks();
        log.debug("proposal lock is null? {}", locks);
        Assert.assertEquals(0, locks.size());
    }


    @Transactional
    @Test
    public void testAcquireLockByProposalGuidNotInUrl() throws Exception {
        HttpServletRequest request = WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposals");
        ((MockHttpServletRequest)request).setMethod(RequestMethod.POST.name());
        HttpServletResponse response = WebMocker.mockHttpResponse();

        RequestContextHolder.setRequestAttributes(
                new ServletRequestAttributes(request));
        proposalLockAcquireLockHandler.preHandle(request, response, null);
        List<ProposalLock> locks =proposalLockManager.listAllLocks();
        log.debug("proposal lock is null? {}", locks);
        Assert.assertEquals(0, locks.size());
    }
    
    @Transactional
    @Test
    public void testExtendLockByRequestAttributeSetDuringCreate() throws Exception {
        
        String dbUuid = "c960d30a52a847fc8c51b64dfcc0ea85";
        HttpServletRequest request = WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposals");
        ((MockHttpServletRequest)request).setMethod(RequestMethod.POST.name());
        HttpServletResponse response = WebMocker.mockHttpResponse();
        RequestContextHolder.setRequestAttributes(
                new ServletRequestAttributes(request));
        ProposalCreationRequest proposalCreateReq = new ProposalCreationRequest();
        proposalCreateReq.setRapporteurOffice(StandardIpOfficeCode.US);
  //      proposalCreateReq.setProjectName("RP4401");
        proposalCreateReq.setProposalTypeCode("RP");
        // TODO: add technology
        proposalCreateReq.setSize(ProjectSizeCategory.SMALL);
        OfficeContact c = new OfficeContact();
        c.setContactType(OfficeContactType.COORDINATOR);
        c.setIpOffice(StandardIpOfficeCode.US);
        c.setEmail("myoung@uspto.gov");

        proposalCreateReq.getPrimaryOfficeContacts().add(c);
        OfficeContact c2 = new OfficeContact();
        c2.setContactType(OfficeContactType.COORDINATOR);
        c2.setIpOffice(StandardIpOfficeCode.EP);
        c2.setEmail("venkat@uspto.gov");
        
        proposalCreateReq.getSecondaryOfficeContacts().add(c2);
        log.debug("proposalController {}", proposalController);
        ResponseEntity<Void> resp= null;
        try {
        	resp = proposalController.createProposal(proposalCreateReq);
        } catch (Exception e) {
        	log.debug("exception ",e);
        }
        Assert.assertNotNull(resp);
        
        log.debug("Headers = {}", resp.getHeaders());
        Assert.assertTrue(resp.getHeaders().containsKey(HttpHeaders.LOCATION));
        
        Assert.assertTrue(resp.getHeaders().containsKey(RestUtils.RESOURCE_ID_HEADER));
        UUID guid = UUID.fromString(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
        Assert.assertEquals(guid, request.getAttribute(ProposalLockManager.THIS_NEW_LOCK_REQUEST_ATTR_NAME));
        
        proposalLockAutoExtendLockHandler.postHandle(request, response, null,null);
        ProposalLock lock =proposalLockManager.lookupExistingLock(guid);
        Assert.assertNotNull(lock);
        Assert.assertTrue(new LocalDateTime().plusHours(2).toDate().before(lock.getLockExpirationTs()));
        
        
    }

    
    private void createAndSaveLock(Long proposalId, String userId, int minToAddToExpiry) {
        Date expiry = new LocalDateTime().plusMinutes(minToAddToExpiry).toDate();
        ChangeProposal p = changeProposalRepository.findById(proposalId).get();
        ChangeProposalLock lock = new ChangeProposalLock();
        lock.setChangeProposal(p);
        lock.setId(p.getId());
        Assert.assertNotNull(lock.getId());
        lock.setCreateTs(new Date());
        lock.setCreateUserId(userId);
        lock.setExpirationTs(expiry);
        lock.setLastModTs(new Date());
        lock.setLastModUserId(userId);
        lock.setLockControl(0);
        lock.setLockedUserId(userId);
        changeProposalLockRepository.save(lock);
     }


    @After
    public void destroy() {
        changeProposalLockRepository.deleteAll();

    }

    @Transactional
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user@user.com", "user@user.com",
                Arrays.asList(new BasicTestingGrantedAuthority("test")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(
                new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposals")));
    }


}
