package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import java.io.IOException;
import java.util.Arrays;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ExternalServiceException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassFamilyCount;
import jakarta.inject.Inject;

/**
 * Test class for External Services process functionality
 * TODO: Find out why this relies on external CSD services and use Mock Rest Template to fix this
 * @author Maximus
 * @date March 02, 2021 12:56:09 PM
 * @version 2.1.0
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
public class ExternalServicesControllerIntegrationTest {
	private static final Logger log = LoggerFactory.getLogger(ExternalServicesControllerIntegrationTest.class);

	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private ProposalExternalInterfaceController proposalExternalInterfaceController;

	@Before
	public void setUp() throws Exception {
		datasetTestingService.loadOnce();

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setPublicationDate(DateUtils.parseDate("2015-09-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamy@uspto.gov", "boopathi.kuppusamy@uspto.gov",
				Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(token);
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(
				WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/resources/images/cpc-sch-A01N-0937.gif")));
	}

	@Test
	public void testReclassPendingFamilyCounts()
			throws ExternalServiceException, JsonGenerationException, JsonMappingException, IOException {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boopathi", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamyy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);
		ResponseEntity<ReclassFamilyCount> resp = proposalExternalInterfaceController
				.getReclassPendingFamilyCount("RP0360");
		Assert.assertNull(resp.getBody());
		log.debug("resp = {} ", JsonUtils.toJson(resp.getBody()));
	}


	@Test
	public void testReclassPendingFamilyCountsWithProjectDoesnotExits()
			throws ExternalServiceException, JsonGenerationException, JsonMappingException, IOException {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boopathi", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamyy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);
		ResponseEntity<ReclassFamilyCount> resp = proposalExternalInterfaceController
				.getReclassPendingFamilyCount("RP03600");
		Assert.assertNull(resp.getBody());
		log.debug("resp = {} ", JsonUtils.toJson(resp.getBody()));
	}

}
