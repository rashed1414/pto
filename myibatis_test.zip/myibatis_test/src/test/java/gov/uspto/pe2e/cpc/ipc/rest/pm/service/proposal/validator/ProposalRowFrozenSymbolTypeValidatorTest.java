package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowFrozenSymbolTypeValidatorTest {
    private static final Logger log = LoggerFactory.getLogger(TitleReferencePartValidatorTest.class);
    
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private  ProposalRowFrozenSymbolTypeValidator  proposalRowFrozenSymbolTypeValidator;

    @Resource
    private List<ProposalValidator> proposalValidators;

    @Test
    public void testConfigCorrectlyIncludesGrammarValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(proposalRowFrozenSymbolTypeValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }

    @Test
    public void testValidate() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N",  "A01B63/00", "0",
                "Testing", new String[]{}));

        ProposalValidationContext proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenSymbolTypeValidator.validate(proposalValidationContext, rows);
        int i = 1;
        for (RevisionChangeItem row : rows) {
            log.debug("line {} has {} validation messages", i++, row.getValidationMessages().size());
        }
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Cannot modify this Frozen symbol. Only Type U or D is allowed.",
                rows.get(0).getValidationMessages().get(0).getMessageText());
        
        
        rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U",  "A01B63/00", "0",
                "Testing", new String[]{}));

        proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenSymbolTypeValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());
        
        

        rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D",  "A01B63/00", "0",
                "Testing", new String[]{}));


        proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenSymbolTypeValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

    }      
    
    @Before
    public void setUp() throws Exception {

        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        DateTimeZone.setDefault(DateTimeZone.UTC);
        datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        // UsernamePasswordAuthenticationToken token = new
        // UsernamePasswordAuthenticationToken("user1", "user@user.com",
        // Arrays.asList(new BasicTestingGrantedAuthority("test")));
        //
        // SecurityContextHolder.getContext().setAuthentication(token);
        //
        // RequestContextHolder.setRequestAttributes(
        // new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
        // "/cpcipcrestweb", "/symbols")));
    }
}
