package gov.uspto.pe2e.cpc.ipc.rest.pm.testingsupport;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.TitleConverter;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import jakarta.inject.Inject;
/**
 * TODO: Move this to PM jar
 * 
 * @author 2020 Development Team (myoung3)
 *
 */
@Service("proposalDatasetTestingService")
public  class ProposalDatasetTestingService {

	private static final Logger log = LoggerFactory.getLogger(ProposalDatasetTestingService.class);
	@Inject 
	private TitleService titleService;
	public void pupulateDefaultsAsIfFromRequest(List<RevisionChangeItem> rows) {
		for (RevisionChangeItem item: rows) {
		try {
            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
            item.setTitle(tree);
            try {
                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
                item.setFlattenedTitle(tree);
            } catch (GrammarParseException gpe2) {
                log.debug("GPE encountered, IPC title will be set to null");
            }
        } catch (GrammarParseException gpe) {
            item.getValidationMessages().addAll(gpe.getValidationMessages());
        }
		}
	}
}
