package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLStreamException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteParagraph;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteRawText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteSuggestionEnd;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteSuggestionStart;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteText;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class NoteRequestParseTest {
	
	public static final JAXBContext TESTCTX = JaxbUtils.initJAXBContext( NoteParagraph.class);

	@Test
	public void test() throws XMLStreamException, FactoryConfigurationError, JAXBException, JsonGenerationException, JsonMappingException, IOException {
//		System.setProperty("jakarta.xml.stream.XMLInputFactory","com.ctc.wstx.stax.WstxInputFactory");
//
//		System.setProperty("jakarta.xml.stream.XMLOutputFactory","com.ctc.wstx.stax.WstxOutputFactory");
//
//		System.setProperty("jakarta.xml.stream.XMLEventFactory","com.ctc.wstx.stax.WstxEventFactory");
        //System.setProperty("jakarta.xml.parsers.DocumentBuilderFactory","com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");

        System.setProperty("illegal-access", "debug");
		InputStream is = Thread.currentThread().getContextClassLoader()
				 .getResourceAsStream("data/xml/note_sample.xml");
		String xml = IOUtils.toString(is);
		log.debug(xml);
		IOUtils.closeQuietly(is);
		
		String[] paragraphs = xml.trim().split("<\\?xml[\\sA-Za-z0-9=\"\\-\\.]*\\?>");
		
		assertEquals((Integer)4, (Integer)paragraphs.length);
		
		for (String paraFrag: paragraphs) {
			log.debug("unmarshalling {}", paraFrag);
			if (StringUtils.isNotEmpty(paraFrag)) {
			NoteParagraph p = (NoteParagraph) TESTCTX.createUnmarshaller().unmarshal(new ByteArrayInputStream(paraFrag.trim().getBytes(StandardCharsets.UTF_8)));
			assertNotNull(p);
			}
		
		}
//		final SAXParserFactory sax = SAXParserFactory.newInstance();
//		sax.setNamespaceAware(false);
//		final XMLReader reader;
//		try {
//		    reader = sax.newSAXParser().getXMLReader();
//		} catch (SAXException | ParserConfigurationException e) {
//		    throw new RuntimeException(e);
//		}
//		SAXSource source = new SAXSource(reader, new InputSource(is));
//		@SuppressWarnings("unchecked")
////		
////		 XMLInputFactory xif = XmlFactoryUtils.newXMLInputFactory(XmlFactoryUtils.XML_FACTORY_IMPL_CLASS);
////		 DefSectionItemEditRequest parsed = (DefSectionItemEditRequest) TESTCTX.createUnmarshaller()
////				 .unmarshal(xif.createXMLStreamReader(Thread.currentThread().getContextClassLoader()
////						 .getResourceAsStream("data/xml/definition_section_edit_request.xml")));
		
//		XMLInputFactory xif = XMLInputFactory.newInstance();
//		xif.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, false); // this is the magic line
//
//		// create xml stream reader using our configured factory
//		StreamSource source = new StreamSource(is);
//		XMLStreamReader xsr = xif.createXMLStreamReader(source);

		// unmarshall, note that it's better to reuse JAXBContext, as newInstance()
		// calls are pretty expensive

		
//		XMLStreamReader xsr = XMLInputFactory.newFactory("jakarta.xml.stream.XMLInputFactory",
//                Thread.currentThread().getContextClassLoader()).createXMLStreamReader(is);
//		NamespaceXmlReader xr = new NamespaceXmlReader(xsr, JaxbUtils.extractNamespace(NotesAndWarnings.class));
//		
//		NotesAndWarnings parsed = (NotesAndWarnings) TESTCTX.createUnmarshaller().unmarshal(xr);
		
//		DefinitionItem parsed = TESTCTX.createUnmarshaller().unmarshal(new StreamSource(is),DefinitionItem.class).getValue();



//		 assertNotNull(parsed.getChildren());
		

	}

	@Test
	public void testNoteSuggestion() throws XMLStreamException, FactoryConfigurationError, JAXBException, JsonGenerationException, JsonMappingException, IOException {
//		System.setProperty("jakarta.xml.stream.XMLInputFactory","com.ctc.wstx.stax.WstxInputFactory");
//
//		System.setProperty("jakarta.xml.stream.XMLOutputFactory","com.ctc.wstx.stax.WstxOutputFactory");
//
//		System.setProperty("jakarta.xml.stream.XMLEventFactory","com.ctc.wstx.stax.WstxEventFactory");
        //System.setProperty("jakarta.xml.parsers.DocumentBuilderFactory","com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");

        System.setProperty("illegal-access", "debug");
        NoteParagraph p = new NoteParagraph();
        NoteSuggestionStart suggestStart = new NoteSuggestionStart();
        suggestStart.setName("deletion:edbf7261c271e9a0d64beb92388ae446a:KEVIN.CONVY@USPTO.GOV");
        p.getChildren().add(suggestStart);
        NoteRawText rawText = new NoteRawText();
        rawText.setContent("Deleted Text");
        NoteText text = new NoteText();
        text.getChildren().add(rawText);
        p.getChildren().add(text);
        
        NoteSuggestionEnd suggestEnd = new NoteSuggestionEnd();
        suggestEnd.setName("deletion:edbf7261c271e9a0d64beb92388ae446a:KEVIN.CONVY@USPTO.GOV");
        p.getChildren().add(suggestEnd);
        
        log.debug("JSON = {}", JsonUtils.toJsonOrStacktrace(p) );
        
        String suggestStartJson = JsonUtils.toJsonOrStacktrace(suggestStart);
        assertEquals("{\"type\":\"NOTESUGGESTIONSTART\",\"id\":null,\"noteOrWarningType\":null,"
        		+"\"sortIndex\":0,\"children\":[],"
        		+"\"name\":\"deletion:edbf7261c271e9a0d64beb92388ae446a:KEVIN.CONVY@USPTO.GOV\"}", 
        		suggestStartJson);
        
        ObjectMapper mapper = new ObjectMapper();
        NoteParagraph fromFile = mapper.readValue(
        			new File("src/test/resources/data/json/proposal/note_paragraph_with_suggestion.json")
        			, NoteParagraph.class);
        
        assertNotNull(fromFile);
        assertEquals(NoteSuggestionStart.class.getCanonicalName() , fromFile.getChildren().get(0).getClass().getCanonicalName());
//		InputStream is = Thread.currentThread().getContextClassLoader()
//				 .getResourceAsStream("data/xml/note_sample.xml");
//		String xml = IOUtils.toString(is);
//		log.debug(xml);
//		IOUtils.closeQuietly(is);
//		
//		String[] paragraphs = xml.trim().split("<\\?xml[\\sA-Za-z0-9=\"\\-\\.]*\\?>");
//		
//		assertEquals((Integer)4, (Integer)paragraphs.length);
//		
//		for (String paraFrag: paragraphs) {
//			log.debug("unmarshalling {}", paraFrag);
//			if (StringUtils.isNotEmpty(paraFrag)) {
//			NoteParagraph p = (NoteParagraph) TESTCTX.createUnmarshaller().unmarshal(new ByteArrayInputStream(paraFrag.trim().getBytes(StandardCharsets.UTF_8)));
//			assertNotNull(p);
//			}
//		
//		}
		

	}

}
