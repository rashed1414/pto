package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLStreamReader;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.jdom2.Element;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.CloseableUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.NamespaceXmlReader;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefinitionSectionType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.ipc.rest.pm.testingsupport.ProposalSCTRowFactory;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.LimitingReferences;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class CpcOnlyNonLimitingReferenceValidatorTest {

    private static final Logger log = LoggerFactory.getLogger(CpcOnlyNonLimitingReferenceValidatorTest.class);

    @Inject
    private DatasetTestingService datasetTestingService;


    @Inject
    private  CpcOnlyNonLimitingReferenceValidator cpcOnlyNonLimitingReferenceValidator;

    @Inject
    private  TitleService titleService;

    @Resource(name="proposalConsistencyValidator")
    private List<ProposalValidator> consistencyValidators;

    @Inject
    private ProposalValidationService proposalValidationService;
    @Inject
    private ProposalSCTRowFactory proposalSCTRowFactory;
    private DocumentAdapter docAdapter;


    @Test
    public void testAppConfiguredInProperValidatorChain() {
        boolean isIncluded = false;
        for (ProposalValidator validator : consistencyValidators) {
            if (validator.getClass().getCanonicalName().equals(cpcOnlyNonLimitingReferenceValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        assertTrue(isIncluded);
    }

    /**
     * This is a single comprehensive test that has multiple null definition, multiple nonnulls (3)
     * 2 sections will have multiple errors each
     */
    @Test
    public void testValidateCpcReferenceSymbolsExistInLimitingReferences() {

    	  List<RevisionChangeItem> rows = new ArrayList<>();
          rows.add(proposalSCTRowFactory.createRevisionChangeItemWithApplicationReferences("U", "A01B1/02", "0", "test;hello {section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##}; Hello ##SYMBOL##A01B1/0261##/SYMBOL## {section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test}", new String[] {"A01B 5/005","A01B 5/008"},
        		  "data/xml/fragments/definition_appref.xml"));

          rows.add(proposalSCTRowFactory.createRevisionChangeItemWithOnlySNKDef("U", "H04N2005/222", "0", "test;hello {section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##}; Hello ##SYMBOL##A01B1/0261##/SYMBOL## {section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test}", new String[] {"A01B 5/005","A01B 5/008"},
        		  "data/xml/fragments/definition_snk_cpconly.xml"));

          rows.add( ProposalValidationHelperTest.createRevisionChangeItem("U", "H04N2/222", "0", "test;hello {section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##}; Hello ##SYMBOL##A01B1/0261##/SYMBOL## {section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test}", new String[] {"A01B 5/005","A01B 5/008"}));

          ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);

          for (RevisionChangeItem row: rows) {
	          try {
	              TitlePartTree tree = titleService.fromGrammar(row.getTitleGrammar());
	              row.setTitle(tree);
	          } catch (GrammarParseException gpe) {
	              row.getValidationMessages().addAll(gpe.getValidationMessages());
	          }
          }

          log.debug("title = {}", JaxbUtils.marshalToString(rows.get(0).getTitle()));

          List<Element> titleSymbolElements = cpcOnlyNonLimitingReferenceValidator.findCpcOnlySymbolReferences(rows.get(0).getTitle());

          assertEquals(3, titleSymbolElements.size());

          List<Element> row2titleSymbols = cpcOnlyNonLimitingReferenceValidator.findCpcOnlySymbolReferences(rows.get(1).getTitle());

          assertEquals(3, row2titleSymbols.size());
          List<Element> row3titleSymbols = cpcOnlyNonLimitingReferenceValidator.findCpcOnlySymbolReferences(rows.get(1).getTitle());

          assertEquals(3, row3titleSymbols.size());

          cpcOnlyNonLimitingReferenceValidator.validate(proposalValidationContext, rows);
          assertEquals(3, rows.get(0).getValidationMessages().size());
          assertEquals("CPC-only limiting references must not be found in references sections of definition other than limiting references section - [A01B1/0241]",
        		  rows.get(0).getValidationMessages().get(0).getMessageText());

          assertEquals("CPC-only limiting references must not be found in references sections of definition other than limiting references section - [A01B1/0247]",
        		  rows.get(0).getValidationMessages().get(1).getMessageText());
          assertEquals("CPC-only limiting references must not be found in references sections of definition other than limiting references section - [A01C63/00]",
        		  rows.get(0).getValidationMessages().get(2).getMessageText());

          assertEquals(ValidationMessageField.APPLICATION_REFERENCES,
        		  rows.get(0).getValidationMessages().get(0).getTriggerField());
          assertEquals(ValidationMessageLevel.CRITICAL,
        		  rows.get(0).getValidationMessages().get(0).getLevel());
          assertEquals(ValidationPhase.CONSISTENCY,
        		  rows.get(0).getValidationMessages().get(0).getPhase());
          // Y series and 2k series symbols don't get validations
          assertEquals(0, rows.get(1).getValidationMessages().size());
          assertEquals(0, rows.get(2).getValidationMessages().size());
           // verify that null informative ref is not a problem
          for (RevisionChangeItem row: rows) {
          for (ValidationMessage msg: row.getValidationMessages()) {
        	  assertTrue(
            		  msg.getMessageText().startsWith(
            				  "CPC-only limiting references must not be found in references sections of definition other than limiting references section - ["));

              assertNotEquals(ValidationMessageField.LIMITING_REFERENCES,
            		  msg.getTriggerField());
              assertEquals(ValidationMessageLevel.CRITICAL,
            		  msg.getLevel());
              assertEquals(ValidationPhase.CONSISTENCY,
            		  msg.getPhase());
          }
          }

    }


    /**
     * This is a single comprehensive test that has multiple null definition, multiple nonnulls (3)
     * 2 sections will have multiple errors each
     */
    @Test
    public void testValidateOtherReferences() {

    	  List<RevisionChangeItem> rows = new ArrayList<>();
          rows.add(proposalSCTRowFactory.createRevisionChangeItemWithApplicationReferences("U", "A01B1/02", "0", "test;hello {section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##}; Hello ##SYMBOL##A01B1/0261##/SYMBOL## {section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test}", new String[] {"A01B 5/005","A01B 5/008"},
        		  "data/xml/fragments/definition_appref.xml"));

          rows.add(proposalSCTRowFactory.createRevisionChangeItemWithOnlySNKDef("U", "H04N2005/222", "0", "test;hello {section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##}; Hello ##SYMBOL##A01B1/0261##/SYMBOL## {section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test}", new String[] {"A01B 5/005","A01B 5/008"},
        		  "data/xml/fragments/definition_snk_cpconly.xml"));

          rows.add(proposalSCTRowFactory.createRevisionChangeItemWithApplicationReferences("U", "A01B1/03", "0", "test;hello {section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##}; Hello ##SYMBOL##A01B1/0261##/SYMBOL## {section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test}", new String[] {"A01B 5/005","A01B 5/008"},
        		  "data/xml/fragments/definition_appref.xml"));


        	//	  ProposalValidationHelperTest.createRevisionChangeItem("U", "H04N2/222", "0", "test;hello {section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##}; Hello ##SYMBOL##A01B1/0261##/SYMBOL## {section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test}", new String[] {"A01B 5/005","A01B 5/008"}));

          ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);

          for (RevisionChangeItem row: rows) {
	          try {
	              TitlePartTree tree = titleService.fromGrammar(row.getTitleGrammar());
	              row.setTitle(tree);
	          } catch (GrammarParseException gpe) {
	              row.getValidationMessages().addAll(gpe.getValidationMessages());
	          }
          }

          log.debug("title = {}", JaxbUtils.marshalToString(rows.get(0).getTitle()));

          List<Element> titleSymbolElements = cpcOnlyNonLimitingReferenceValidator.findCpcOnlySymbolReferences(rows.get(0).getTitle());

          assertEquals(3, titleSymbolElements.size());

          List<Element> row2titleSymbols = cpcOnlyNonLimitingReferenceValidator.findCpcOnlySymbolReferences(rows.get(1).getTitle());

          assertEquals(3, row2titleSymbols.size());
          List<Element> row3titleSymbols = cpcOnlyNonLimitingReferenceValidator.findCpcOnlySymbolReferences(rows.get(1).getTitle());

          assertEquals(3, row3titleSymbols.size());

          cpcOnlyNonLimitingReferenceValidator.validate(proposalValidationContext, rows);
          assertEquals(3, rows.get(0).getValidationMessages().size());
          assertEquals("CPC-only limiting references must not be found in references sections of definition other than limiting references section - [A01B1/0241]",
        		  rows.get(0).getValidationMessages().get(0).getMessageText());

          assertEquals("CPC-only limiting references must not be found in references sections of definition other than limiting references section - [A01B1/0247]",
        		  rows.get(0).getValidationMessages().get(1).getMessageText());
          assertEquals("CPC-only limiting references must not be found in references sections of definition other than limiting references section - [A01C63/00]",
        		  rows.get(0).getValidationMessages().get(2).getMessageText());

          assertEquals(ValidationMessageField.APPLICATION_REFERENCES,
        		  rows.get(0).getValidationMessages().get(0).getTriggerField());
          assertEquals(ValidationMessageLevel.CRITICAL,
        		  rows.get(0).getValidationMessages().get(0).getLevel());
          assertEquals(ValidationPhase.CONSISTENCY,
        		  rows.get(0).getValidationMessages().get(0).getPhase());
          // Y series and 2k series symbols don't get validations
          assertEquals(0, rows.get(1).getValidationMessages().size());
          assertEquals(3, rows.get(2).getValidationMessages().size());
          assertEquals(ValidationMessageField.APPLICATION_REFERENCES,
        		  rows.get(2).getValidationMessages().get(0).getTriggerField());

           // verify that null informative ref is not a problem
          for (RevisionChangeItem row: rows) {
	          for (ValidationMessage msg: row.getValidationMessages()) {
	        	  assertTrue(
	            		  msg.getMessageText().startsWith(
	            				  "CPC-only limiting references must not be found in references sections of definition other than limiting references section - ["));

	              assertNotEquals(ValidationMessageField.LIMITING_REFERENCES,
	            		  msg.getTriggerField());
	              assertEquals(ValidationMessageLevel.CRITICAL,
	            		  msg.getLevel());
	              assertEquals(ValidationPhase.CONSISTENCY,
	            		  msg.getPhase());
	          }
          }

    }

    /**
     * This is a single comprehensive test that has multiple null definition, multiple nonnulls (3)
     * 2 sections will have multiple errors each
     */
    @Test
    public void testValidateParthasCases() {

    	  List<RevisionChangeItem> rows = new ArrayList<>();
          rows.add(proposalSCTRowFactory.createRevisionChangeItemWithOnlySNKDef("U", "H04N", "0", "test;hello {section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##}; Hello ##SYMBOL##A01B1/0261##/SYMBOL## {section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test}", new String[] {"A01B 5/005","A01B 5/008"},
        		  "data/xml/fragments/definition_snk_cpconly.xml"));

          rows.add(proposalSCTRowFactory.createRevisionChangeItemWithApplicationReferences("U", "H04N2005/222", "0", "test;hello {section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##}; Hello ##SYMBOL##A01B1/0261##/SYMBOL## {section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test}", new String[] {"A01B 5/005","A01B 5/008"},
        		  "data/xml/fragments/definition_appref.xml"));

          rows.add(proposalSCTRowFactory.createRevisionChangeItemWithApplicationReferences("U", "A01B5/005", "0", "test;hello {section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##}; Hello ##SYMBOL##A01B1/0261##/SYMBOL## {section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test}", new String[] {"A01B 5/005","A01B 5/008"},
        		  "data/xml/fragments/definition_appref.xml"));


        	//	  ProposalValidationHelperTest.createRevisionChangeItem("U", "H04N2/222", "0", "test;hello {section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##}; Hello ##SYMBOL##A01B1/0261##/SYMBOL## {section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test}", new String[] {"A01B 5/005","A01B 5/008"}));

          ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);

          for (RevisionChangeItem row: rows) {
	          try {
	              TitlePartTree tree = titleService.fromGrammar(row.getTitleGrammar());
	              row.setTitle(tree);
	          } catch (GrammarParseException gpe) {
	              row.getValidationMessages().addAll(gpe.getValidationMessages());
	          }
          }

          log.debug("title = {}", JaxbUtils.marshalToString(rows.get(0).getTitle()));


          cpcOnlyNonLimitingReferenceValidator.validate(proposalValidationContext, rows);
          assertEquals(0, rows.get(0).getValidationMessages().size());
          assertEquals(0, rows.get(1).getValidationMessages().size());
          assertEquals(3, rows.get(2).getValidationMessages().size());

    }


    public RevisionChangeItem createRevisionChangeItemWithDefinitionLimitingRef(String entryType, String symbolName, String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel, titleGrammar, reclassTargets);
        item.getDefinitionItems().add(createDefinitionLimitingRef(SCTComponentChangeType.M));
        return item;
    }


    private DefSectionItemEditRequest createDefinitionLimitingRef(SCTComponentChangeType updateType) {
  		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
  		req.setChangeType(updateType);
  		req.setSectionType(DefinitionSectionType.LIMITING_REFERENCES);
  		LimitingReferences snk = null;
  		InputStream is = null;
  		XMLStreamReader xsr = null;
  		NamespaceXmlReader xr = null;
  		try  {
  			is = Thread.currentThread().getContextClassLoader()
  									  //data/xml/fragments/definition_limitingref_for_cpconly_match.xml
  				.getResourceAsStream("data/xml/fragments/limref.xml");
  			log.debug("inputStream is not null {} ", is != null);
  			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
  				+IOUtils.toString(is)+"</references></definition-item>");
//  			xsr = XMLInputFactory.newFactory("com.sun.xml.internal.stream.XMLInputFactoryImpl",
//  		                Thread.currentThread().getContextClassLoader()).createXMLStreamReader(is);
//  				xr = new NamespaceXmlReader(xsr, JaxbUtils.extractNamespace(DefinitionStatement.class));
//  				Unmarshaller um = STATEMENT_CTX.createUnmarshaller();
//  			statement = (DefinitionStatement)um.unmarshal(xr);
  			snk = defItem.getReferences().getLimitingReferences();
  		} catch (Exception je) {
  			log.debug("failed to parse xml",je);
  			throw new IllegalArgumentException(je);
  		} finally {
  			CloseableUtils.closeQuietly(xr);
  			CloseableUtils.closeQuietly(xsr);
  			IOUtils.closeQuietly(is);
  		}

  		req.setLimitingReferences(snk);
  		assertNotNull(req.getLimitingReferences());
  		return req;
  	}




	@Before
    public void setUp() throws Exception {
        datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        Class adapterClass = Class.forName(DocumentAdapter.class.getCanonicalName());
        docAdapter = (DocumentAdapter)adapterClass.newInstance();

    }

}
