package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.ValidatedList;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposal;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalAlias;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalDetail;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalDetailRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDetail;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDetailCreationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalFormType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalPageDetail;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalDetailsControllerVolatileTest  {
    private static final Logger log = LoggerFactory.getLogger(ProposalDetailsControllerVolatileTest.class);
    
    @Inject
    private ProposalDetailsController proposalDetailsController;
    
    @Inject 
    private ChangeProposalRepository changeProposalRepository;
    
    @Inject
    private ChangeProposalDetailRepository changeProposalDetailRepository;
    
    @Inject
    private DatasetTestingService datasetTestingService;  
    
    @Transactional
    @Test
    public void testFindProposalsWithoutCEAliases() {
    	
    	List<ChangeProposal> list = changeProposalRepository.findProposalsWithNoPDAliases();
    	for (ChangeProposal cp : list) {
    		log.debug("found {}/{}/{}", cp.getId() , cp.getExternalId(), 
    				cp.getAliases().stream().map(ChangeProposalAlias::getName).collect(Collectors.toList()) );
    		
    		ResponseEntity<ProposalPageDetail> resp = proposalDetailsController.getProposalDetailsByExternalId(GUIDUtils.fromDatabaseFormat(cp.getExternalId()), ProposalFormType.PROJECT_DETAIL, true);
    		
    		assertEquals(cp.getId()+" found to have PD aliases when it should not!",0, resp.getBody().getProposalDetails().stream()
    				.filter(it -> it.getItemName().equals(ChangeProposalDetail.CEF_ALIAS_KEY) 
    						|| it.getItemName().equals(ChangeProposalDetail.USERDEFINED_ALIAS_KEY))
    				.count());
    		
    	}
    	
    	
    	
    }
   
    
    /**
     * Failed to find parent record 
     */
    @Transactional
    @Test
    public void testSaveAsUpdate_success() {        
            
        
        Date now = new Date();
        ValidatedList<ProposalDetailCreationRequest> list = new ValidatedList<>();
        ProposalDetailCreationRequest propDetailReq = new ProposalDetailCreationRequest();
        propDetailReq.setDetails("Test 123");
        propDetailReq.setItemName("Test1");
        propDetailReq.setFormType(ProposalFormType.INTERNAL_REQUEST);
        list.add(propDetailReq);
        ResponseEntity<Void> resp = proposalDetailsController.save(
                    GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), 
                    list);
        assertEquals(1,
                    resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).size());
    }
    
    @Test
    public void testUpdateAndNewSaveForInternalRequestForm() {  

        ValidatedList<ProposalDetail> list = new ValidatedList<>();
        ProposalDetail pDetail1 = new ProposalDetail();
        ProposalDetail pDetail2 = new ProposalDetail();

        pDetail1.setId(GUIDUtils.fromDatabaseFormat("af75b85c65ee4bfb969db1dcc923f081"));
        pDetail1.setDetails("update Test 123");
        pDetail1.setItemName("AA TEST");
        pDetail1.setProposalId(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
        pDetail1.setFormType(ProposalFormType.INTERNAL_REQUEST);

        pDetail2.setItemName("BB TEST");
        pDetail2.setDetails("new Test 123");
        pDetail2.setFormType(ProposalFormType.INTERNAL_REQUEST);
        pDetail2.setProposalId(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
        list.add(pDetail1);
        list.add(pDetail2);

        ResponseEntity<List<ProposalDetail>> resp = proposalDetailsController.update(GUIDUtils.fromDatabaseFormat(
                "c960d30a52a847fc8c51b64dfcc0ea85"), list);
        assertEquals(resp.getBody().get(0).getDetails(),"update Test 123");
        assertEquals(resp.getBody().get(1).getDetails(),"new Test 123");
        assertNotNull(resp.getBody().get(1).getId());       
        
        assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());       
        
        assertEquals(2, resp.getBody().size());

    }
    
    @Test
    public void testSaveAndUpdateTogether() {  

        ValidatedList<ProposalDetail> list = new ValidatedList<>();
        ProposalDetail pDetail1 = new ProposalDetail();
        ProposalDetail pDetail2 = new ProposalDetail();

        pDetail1.setId(GUIDUtils.fromDatabaseFormat("af75b85c65ee4bfb969db1dcc923f081"));
        pDetail1.setDetails("update Test 123");
        pDetail1.setItemName("techCenter_IR");
        pDetail1.setProposalId(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
        pDetail1.setFormType(ProposalFormType.INTERNAL_REQUEST);
        
        pDetail2.setItemName("BB TEST - not already existing");
        pDetail2.setDetails("new Test 123");
        pDetail2.setFormType(ProposalFormType.INTERNAL_REQUEST);
        list.add(pDetail1);
        list.add(pDetail2);

        ResponseEntity<Void> resp = proposalDetailsController.saveForFormType(GUIDUtils.fromDatabaseFormat(
                "c960d30a52a847fc8c51b64dfcc0ea85"), ProposalFormType.INTERNAL_REQUEST.INTERNAL_REQUEST,
        		list);
     
        assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());       
        
        assertEquals(2, resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).size());
        
        List<ChangeProposalDetail> details = changeProposalDetailRepository.findProposalItemDetailsByExternalId("c960d30a52a847fc8c51b64dfcc0ea85");
        assertEquals(15, details.size());
    }
    
    @Test
    public void testSaveAndUpdateTogetherWithEmptyDetails() {  

        ValidatedList<ProposalDetail> list = new ValidatedList<>();
        ProposalDetail pDetail1 = new ProposalDetail();
        ProposalDetail pDetail2 = new ProposalDetail();

        pDetail1.setId(GUIDUtils.fromDatabaseFormat("af75b85c65ee4bfb969db1dcc923f081"));
        pDetail1.setDetails("");
        pDetail1.setItemName("techCenter_IR");
        pDetail1.setProposalId(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
        pDetail1.setFormType(ProposalFormType.INTERNAL_REQUEST);
        
        pDetail2.setItemName("BB TEST - not already existing");
        pDetail2.setDetails("new Test 123");
        pDetail2.setFormType(ProposalFormType.INTERNAL_REQUEST);
        list.add(pDetail1);
        list.add(pDetail2);

        ResponseEntity<Void> resp = proposalDetailsController.saveForFormType(GUIDUtils.fromDatabaseFormat(
                "c960d30a52a847fc8c51b64dfcc0ea85"), ProposalFormType.INTERNAL_REQUEST.INTERNAL_REQUEST,
                list);
     
        assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());       
        
        assertEquals(1, resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).size());
        
        List<ChangeProposalDetail> details = changeProposalDetailRepository.findProposalItemDetailsByExternalId("c960d30a52a847fc8c51b64dfcc0ea85");
        assertEquals(14, details.size());
    }
    
    @Test
    public void testUpdateAndNewSaveForProjectDetailForm() {
        ValidatedList<ProposalDetail> list = new ValidatedList<>();
        ProposalDetail pDetail1 = new ProposalDetail();
        ProposalDetail pDetail2 = new ProposalDetail();

        pDetail1.setId(GUIDUtils.fromDatabaseFormat("e3520e28bbdd4a74b02b11ed27097916"));
        pDetail1.setDetails("project detail update Test 123");
        pDetail1.setItemName("PD AA TEST");
        pDetail1.setProposalId(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
        pDetail1.setFormType(ProposalFormType.PROJECT_DETAIL);

        pDetail2.setItemName("PD BB TEST");
        pDetail2.setDetails("Project detail new Test 123");
        pDetail2.setFormType(ProposalFormType.PROJECT_DETAIL);
        pDetail2.setProposalId(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
        list.add(pDetail1);
        list.add(pDetail2);

        ResponseEntity<List<ProposalDetail>> resp = proposalDetailsController.update(GUIDUtils.fromDatabaseFormat(
                "c960d30a52a847fc8c51b64dfcc0ea85"), list);
        assertEquals(resp.getBody().get(0).getDetails(),"project detail update Test 123");
        assertEquals(resp.getBody().get(1).getDetails(),"Project detail new Test 123");
        assertNotNull(resp.getBody().get(1).getId());       
        
        assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());       
        
        assertEquals(2, resp.getBody().size());

    } 
       
    /**
     * Failed to find parent reccord 
     */
    @Test
    public void testMissingParentChangeProposal() {    	
			
        
        
       Date now = new Date();
       ValidatedList<ProposalDetailCreationRequest> list = new ValidatedList<>();
       ProposalDetailCreationRequest propDetailReq = new ProposalDetailCreationRequest();
       propDetailReq.setDetails("Test 123");
       propDetailReq.setItemName("Test1");
       propDetailReq.setFormType(ProposalFormType.INTERNAL_REQUEST);
       list.add(propDetailReq);
      
        try {
            ResponseEntity<Void> resp = proposalDetailsController.save(
                    GUIDUtils.fromDatabaseFormat("aaaaf9bf804848aa8ba202db9f844db5"), 
                    list);
            fail();
        } catch (Exception e) {
            assertEquals("EntityNotFoundException",e.getClass().getSimpleName());
            assertEquals("Proposal "+GUIDUtils.fromDatabaseFormat("aaaaf9bf804848aa8ba202db9f844db5")+" does not exist", e.getMessage());
        }
               
    }
      @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
    			"bkuppusamy", "Boops","Kuppusamy", "US");
    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"boopathi.kuppusamy@uspto.gov", token,
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/proposals/1/twl")));
    }

    
    
}