/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.pm.testing;

import java.io.IOException;

import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.ProposalResourceExportHandler;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.CloudResource;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.KeyValuePairEntry;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.MetadataKey;

/**
 * @author Maximus
 *
 */
@Service
public class MockProposalResourceExportHandler implements ProposalResourceExportHandler {

	@Override
	public CloudResource getDocumentByResourceId(String resourceId) {
		
		CloudResource cr = new CloudResource();		
		cr.setId("1123");
		try {
			cr.setBytes(org.h2.util.IOUtils.readBytesAndClose(Thread.currentThread().getContextClassLoader().getResourceAsStream("cpc-objects/images/cpc-def-A01N-0000.png"), -1));
		} catch (IOException e) {			
			e.printStackTrace();
		}
		KeyValuePairEntry filePairEntry = new KeyValuePairEntry();
        filePairEntry.setKey(MetadataKey.ORIGINAL_FILENAME.name());
        filePairEntry.setValue("cpc-def-A01N-0000.png");
        cr.getMetadata().add(filePairEntry);
		return cr;
	}

   

}
