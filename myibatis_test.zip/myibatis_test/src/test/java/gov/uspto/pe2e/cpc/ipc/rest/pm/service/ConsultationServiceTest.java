package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ExternalSystemCategory;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.I18nMessageKey;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ExternalServiceException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposal;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalAlias;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalDetail;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.StandardWfTaskConfig;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.WfSmeConsultation;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.WfSmeConsultationComment;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.OfficeContactType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import gov.uspto.pe2e.cpc.ipc.rest.contract.smeconsult.v1_0.Consultation;
import gov.uspto.pe2e.cpc.ipc.rest.contract.smeconsult.v1_0.ConsultationRequest;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
public class ConsultationServiceTest {
	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private ConsultationService consultationService;

	@Inject
	private SecurityService securityService;

	@Before
	public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();

		datasetTestingService.loadOnce();

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(2L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

//        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("myoung3@uspto.gov", "myoung3@uspto.gov", Arrays
//                .asList(new BasicTestingGrantedAuthority("test"), 
//                		new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
//
//        SecurityContextHolder.getContext().setAuthentication(token);

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamy@uspto.gov", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(
				WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposaltaskconsultation")));
	}

	@Test
	public void testIsUserSME() {
		ChangeProposalDetail dtl = new ChangeProposalDetail();
		dtl.setItemName("USSCE_PD");
		dtl.setDetails("Jules.Winfield@pulpfiction.com");
		Set<ChangeProposalDetail> details = new HashSet<>(Arrays.asList(dtl));
		assertTrue(consultationService.isUserSME(dtl.getDetails(), details));

		dtl.setItemName("backupUSSCE_PD");
		assertTrue(consultationService.isUserSME(dtl.getDetails(), details));

		dtl.setItemName("USSCESPE_PD");
		assertTrue(consultationService.isUserSME(dtl.getDetails(), details));

		dtl.setItemName("EPQN_PD");
		assertTrue(consultationService.isUserSME(dtl.getDetails(), details));

		dtl.setItemName("EPGERANT_PD");
		assertTrue(consultationService.isUserSME(dtl.getDetails(), details));

		dtl.setItemName("NOT_SME_PD");
		assertFalse(consultationService.isUserSME(dtl.getDetails(), details));

	}

	@Test
	public void testBuildSMERecipientList() {
		ChangeProposalDetail dtl = new ChangeProposalDetail();
		dtl.setItemName("USSCE_PD");
		dtl.setDetails("Jules.Winfield@pulpfiction.com");

		ChangeProposalDetail dtl2 = new ChangeProposalDetail();
		dtl2.setItemName("EPGERANT_PD");
		dtl2.setDetails("Winston.Wolfe@pulpfiction.com");

		ChangeProposalDetail dtl3 = new ChangeProposalDetail();
		dtl3.setItemName("NOT_SME_PD");
		dtl3.setDetails("Butch.Coolidge@pulpfiction.com");

		Set<ChangeProposalDetail> details = new HashSet<>(Arrays.asList(dtl, dtl2, dtl3));

		List<String> emails = consultationService.buildSMERecipientList(details, StandardIpOfficeCode.US);
		assertEquals(1, emails.size());
		assertEquals(dtl.getDetails(), emails.get(0));

		emails = consultationService.buildSMERecipientList(details, StandardIpOfficeCode.EP);
		assertEquals(1, emails.size());
		assertEquals(dtl2.getDetails(), emails.get(0));
	}

	@Test
	public void testNotifyUsptoAuthenticationTokenChangeProposalStringI18nMessageKeyWfSmeConsultationComment() {
		Date now = new Date();
		ChangeProposalDetail dtl = new ChangeProposalDetail();
		dtl.setItemName("USSCE_PD");
		dtl.setDetails("Jules.Winfield@pulpfiction.com");

		ChangeProposalDetail dtl2 = new ChangeProposalDetail();
		dtl2.setItemName("EPGERANT_PD");
		dtl2.setDetails("Winston.Wolfe@pulpfiction.com");

		ChangeProposalDetail dtl3 = new ChangeProposalDetail();
		dtl3.setItemName("NOT_SME_PD");
		dtl3.setDetails("Butch.Coolidge@pulpfiction.com");

		Set<ChangeProposalDetail> details = new HashSet<>(Arrays.asList(dtl, dtl2, dtl3));
		ChangeProposalAlias alias = new ChangeProposalAlias();
		alias.setCreateTs(now);
		alias.setLastModifiedTs(now);
		alias.setSystemCategory(ExternalSystemCategory.CE);
		alias.setName("TESTALIAS");
		ChangeProposal cp = new ChangeProposal();
		cp.setExternalId(GUIDUtils.toDatabaseFormat(UUID.randomUUID()));
		cp.getAliases().add(alias);
		cp.getChangeProposalDetail().addAll(details);

		StandardWfTaskConfig taskConfig = new StandardWfTaskConfig();
		taskConfig.setId("test_task_def_key");
		
		WfSmeConsultationComment comment = new WfSmeConsultationComment();
		comment.setComment("This is a test comment");
		comment.setApproverRole(OfficeContactType.COORDINATOR);
		comment.setCreateUserId("Vincent.Vega@pulpfiction.com");
		
		WfSmeConsultation consultation = new WfSmeConsultation();
		consultation.setStandardIpOfficeCode(StandardIpOfficeCode.US);
		consultation.setChangeProposal(cp);
		consultation.setCoordinator(comment.getCreateUserId());
		consultation.setCreateTs(now);
		consultation.setTaskConfig(taskConfig);
		
		consultation.getComments().add(comment);
		
		comment.setConsultation(consultation);
		

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("CPCCollaborationSupport@USPTO.GOV", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"CPCCollaborationSupport@USPTO.GOV", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		 UsptoAuthenticationToken authToken = securityService
	                .mapSamlTokenToContractModel(springUser);

		try {
			consultationService.notify(authToken, cp, taskConfig.getId(),
					I18nMessageKey.CONSULTATION_NOTIFICATION_SUBJECT, comment);
			
		} catch (Exception e) {
			log.warn("Notify failed ", e);
			fail("notifySme() failed");
		}
	}
	
	@Test
	public void testEndOpenConsultationByProposalAndTaskId() {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("xboopathi@uspto.gov", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"xboopathi@uspto.gov", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);
		UsptoAuthenticationToken authToken = securityService
				.mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());

		UUID proposalGuid = GUIDUtils.fromDatabaseFormat("df82473cf682452e82d79048609a548f");
		String taskId = "IRT04";

		ConsultationRequest req = new ConsultationRequest();
		req.setWorkflowTaskInstanceId(999L);
		req.setComment("This is a test comment");

		consultationService.startConsultation(proposalGuid, taskId, req, authToken);

		List<Consultation> consult = consultationService.listConsulationsByProposalAndTaskId(proposalGuid, taskId, null, null);
		

		assertNotNull(consult);
		assertEquals(1, consult.size());
		assertNull(consult.get(0).getEndTs());

		consultationService.endOpenConsultationByProposalAndTask(proposalGuid, taskId);
		consult = consultationService.listConsulationsByProposalAndTaskId(proposalGuid, taskId, null, null);

		assertNotNull(consult);
		assertEquals(1, consult.size());
		assertNotNull(consult.get(0).getEndTs());
	}

	@Test
	public void testCalculateTotalConsultDays() {
		
		//Consult started on same day as task day and consult ended next day
		Date consultEndTs =  new Date();
		Date consultStartTs = new DateTime(consultEndTs).minusDays(1).toDate();
		Date taskStartDate = consultStartTs;
		
		int consultDays = consultationService.calculateTotalConsultDays(consultStartTs, consultEndTs, taskStartDate);
		assertEquals(1, consultDays);
		
		// Consult started on same day as task day and consult ended on same day
		consultStartTs = new Date();
		taskStartDate = consultStartTs;

		consultDays = consultationService.calculateTotalConsultDays(consultStartTs, consultEndTs, taskStartDate);
		assertEquals(0, consultDays);
		
		// Consult started on next day of task day and consult ended day after
		consultEndTs = new Date();
		consultStartTs = new DateTime(consultEndTs).minusDays(1).toDate();
		taskStartDate = new DateTime(consultEndTs).minusDays(2).toDate();

		consultDays = consultationService.calculateTotalConsultDays(consultStartTs, consultEndTs, taskStartDate);
		assertEquals(2, consultDays);
	}
	
	@Test
	@Transactional
	public void testExportConsultationHistoryDataIntoXlsx_file() throws IOException, ExternalServiceException {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("xboopathi@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("xboopathi@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		UsptoAuthenticationToken authToken = securityService
				.mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());

		UUID proposalID = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		byte[] exportData = consultationService.getConsultationHistoryDataExport(proposalID, authToken);

		assertNotNull(exportData);
		IOUtils.write(exportData, new FileOutputStream(new File("target/export_consultations.xlsx.xml")));
	}

	@Test
	@Transactional
	public void testExportConsultationHistoryFileName() {

		String exportFileName = consultationService
				.getExportConsultationsXlsxFileName(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
		
		assertTrue(exportFileName.contains("DP0026_ConsultationHistory_"));
	}
}
