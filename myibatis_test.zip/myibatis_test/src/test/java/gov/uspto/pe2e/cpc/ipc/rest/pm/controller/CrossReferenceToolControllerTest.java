package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.NAWItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.crt.v1_0.CrossProjectReferenceSummary;
import gov.uspto.pe2e.cpc.ipc.rest.contract.crt.v1_0.OtherProjectsSdct;
import gov.uspto.pe2e.cpc.ipc.rest.contract.crt.v1_0.RefLocation;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.pm.util.CrossRefLocationComparator;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml"})
@NotThreadSafe
@Category(NotThreadSafe.class)
public class CrossReferenceToolControllerTest {
    private static final Logger log = LoggerFactory.getLogger(CrossReferenceToolControllerTest.class);
    @Inject
    private CrossReferenceToolController crossReferenceToolController;
    @Inject
    private DatasetTestingService datasetTestingService;

    @Test
    @Transactional
    public void testGetCrossProjectReferenceSummary() {

        ResponseEntity<List<CrossProjectReferenceSummary>> resp = crossReferenceToolController
                .getCrossProjectReferenceSummary(GUIDUtils.fromDatabaseFormat("b8610e87e24544a0af98c901b6e4877f"), null,
                        null);

        assertNotNull(resp.getBody());
        assertEquals(resp.getBody().size(), 2);

        CrossProjectReferenceSummary crps = resp.getBody().get(0);
        assertEquals("C", crps.getChangeType());
        assertEquals(1, crps.getSortOrderNumber());
        assertEquals(1, crps.getVersionNumber());
        assertEquals("b8610e87-e245-44a0-af98-c901b6e4877f", crps.getVersionSymbolGuidId());
        assertEquals("A61M5/00", crps.getReferenceSymbol());
        assertEquals("A61M5/00,A61M5/009,A61M5/0091", crps.getTransferToSymbols());
        assertEquals("Title", crps.getRefLocation().get(0).getRefLocationName());
        assertEquals("Limiting References", crps.getRefLocation().get(0).getRefSubsectionLocationName());
        assertEquals("A61B5/14", crps.getRefLocation().get(0).getRefLocationTobeChanged());
        assertEquals("Definition", crps.getRefLocation().get(1).getRefLocationName());
        assertEquals("Limiting References", crps.getRefLocation().get(1).getRefSubsectionLocationName());
        assertEquals("A61B5/14532", crps.getRefLocation().get(1).getRefLocationTobeChanged());

        assertEquals("RP11657", crps.getOtherProjectCrlOverlap().get(0).getProjectAlias());
        assertEquals("RP11745", crps.getOtherProjectCrlOverlap().get(1).getProjectAlias());
        assertEquals("XX11909", crps.getOtherProjectCrlOverlap().get(2).getProjectAlias());

        assertEquals("XX11961", crps.getOtherProjectSdctOverlap().get(0).getProjectAlias());
        assertEquals("XX12148", crps.getOtherProjectSdctOverlap().get(1).getProjectAlias());
        assertEquals("XX12149", crps.getOtherProjectSdctOverlap().get(2).getProjectAlias());


        assertEquals("DP10005", crps.getRefLocation().get(0).getOtherProjectsCrl().get(0).getProjectAlias());
        assertEquals("RP10453", crps.getRefLocation().get(0).getOtherProjectsCrl().get(1).getProjectAlias());
        assertEquals("XX11506", crps.getRefLocation().get(0).getOtherProjectsCrl().get(2).getProjectAlias());


        assertEquals("RP10402", crps.getRefLocation().get(0).getOtherProjectsSdct().get(0).getProjectAlias());
        assertEquals("RP10403", crps.getRefLocation().get(0).getOtherProjectsSdct().get(1).getProjectAlias());
        assertEquals("RP10404", crps.getRefLocation().get(0).getOtherProjectsSdct().get(2).getProjectAlias());
    }

    @Test
    public void testCrossRefLocationComparator() {
        List<RefLocation> refList = new ArrayList<>();
        RefLocation r1 = new RefLocation();
        r1.setRefLocationTobeChanged("B65G");
        RefLocation r2 = new RefLocation();
        r2.setRefLocationTobeChanged("A01N 5/20");
        RefLocation r3 = new RefLocation();
        r3.setRefLocationTobeChanged("A01B 2/01");
        RefLocation r4 = new RefLocation();
        r4.setRefLocationTobeChanged("B65C");

        refList.add(r1);
        refList.add(r2);
        refList.add(r3);
        refList.add(r4);

        refList.sort(new CrossRefLocationComparator());

        assertEquals("A01B 2/01", refList.get(0).getRefLocationTobeChanged());
        assertEquals("A01N 5/20", refList.get(1).getRefLocationTobeChanged());

    }

    @Test
    public void testDuplicateOtherSdct() {
        RefLocation refLocation = new RefLocation();
        OtherProjectsSdct sd = new OtherProjectsSdct();
        sd.setComponentPartType("Warning");
        sd.setGuid("12312313213");
        sd.setProjectAlias("RP10011");
        sd.setSymbol("A01B 02/112");
        refLocation.getOtherProjectsSdct().add(sd);
        OtherProjectsSdct sd1 = new OtherProjectsSdct();
        sd1.setComponentPartType("Warning");
        sd1.setGuid("12312313213");
        sd1.setProjectAlias("RP10011");
        sd1.setSymbol("A01B 02/112");
        refLocation.getOtherProjectsSdct().add(sd1);
        OtherProjectsSdct sd2 = new OtherProjectsSdct();
        sd2.setComponentPartType("Warning");
        sd2.setGuid("12312313213");
        sd2.setProjectAlias("DP10011");
        sd2.setSymbol("A01B 02/112");
        refLocation.getOtherProjectsSdct().add(sd2);


        List<OtherProjectsSdct> before = refLocation.getOtherProjectsSdct();
        List<OtherProjectsSdct> after = before.stream()
                .filter(distinctBy(OtherProjectsSdct::getProjectAlias)).collect(Collectors.toList());

        assertEquals(3, before.size());
        refLocation.getOtherProjectsSdct().removeAll(before);
        assertEquals(0, refLocation.getOtherProjectsSdct().size());
        refLocation.getOtherProjectsSdct().addAll(after);
        assertEquals(2, refLocation.getOtherProjectsSdct().size());


    }

    /**
     * Filter duplicate records by property
     *
     * @param <T>
     * @param f
     * @return
     */
    private static <T> Predicate<T> distinctBy(Function<? super T, ?> f) {
        Set<Object> objects = new HashSet<>();
        return t -> objects.add(f.apply(t));
    }

    @Test
    @Transactional
    public void testSearchByScheme() {

        ResponseEntity<List<CrossProjectReferenceSummary>> resp = crossReferenceToolController
                .getCrossProjectReferenceSummary(GUIDUtils.fromDatabaseFormat("b8610e87e24544a0af98c901b6e4877f"), "May 2021",
                        null);
        assertEquals(resp.getBody().size(), 2);

        CrossProjectReferenceSummary crps = resp.getBody().get(0);
        assertEquals(1, crps.getOtherProjectCrlOverlap().size());
        assertEquals(1, crps.getOtherProjectSdctOverlap().size());
        assertNotNull(crps.getRefLocation());
        assertEquals(1, crps.getRefLocation().get(0).getOtherProjectsCrl().size());
        assertEquals(1, crps.getRefLocation().get(0).getOtherProjectsSdct().size());

    }

    @Test
    @Transactional
    public void testSearchByProjectType() {

		List<String> projectTypes = new ArrayList<>();
		projectTypes.add("DP");
		projectTypes.add("RP");
		
		ResponseEntity<List<CrossProjectReferenceSummary>> resp = crossReferenceToolController
				.getCrossProjectReferenceSummary(GUIDUtils.fromDatabaseFormat("b8610e87e24544a0af98c901b6e4877f"),null,
						projectTypes  );

		assertEquals(resp.getBody().size(), 2);
		
		CrossProjectReferenceSummary crps = resp.getBody().get(0);
		assertEquals(3, crps.getOtherProjectCrlOverlap().size());
		assertEquals(2, crps.getOtherProjectSdctOverlap().size());
		assertNotNull(crps.getRefLocation());
		assertEquals(3, crps.getRefLocation().get(0).getOtherProjectsCrl().size());
		assertEquals(3, crps.getRefLocation().get(0).getOtherProjectsSdct().size());
	}
	
	@Test
	@Transactional
	public void testSearchByProjectType1() {
		List<String> projectTypes = new ArrayList<>();
		projectTypes.add("DP");
		 
		ResponseEntity<List<CrossProjectReferenceSummary>> resp = crossReferenceToolController
				.getCrossProjectReferenceSummary(GUIDUtils.fromDatabaseFormat("b8610e87e24544a0af98c901b6e4877f"), null,
						projectTypes);
		assertEquals(resp.getBody().size(), 2);
		
		CrossProjectReferenceSummary crps = resp.getBody().get(0);
		assertEquals(0, crps.getOtherProjectCrlOverlap().size());
		assertEquals(1, crps.getOtherProjectSdctOverlap().size());
		assertNotNull(crps.getRefLocation());
		assertEquals(3, crps.getRefLocation().get(0).getOtherProjectsCrl().size());
		assertEquals(0, crps.getRefLocation().get(0).getOtherProjectsSdct().size());
	}
	
	@Test
	@Transactional
	public void testSearchByProjectType2() {
		List<String> projectTypes = new ArrayList<>();
		projectTypes.add("RP");
		 
		ResponseEntity<List<CrossProjectReferenceSummary>> resp = crossReferenceToolController
				.getCrossProjectReferenceSummary(GUIDUtils.fromDatabaseFormat("b8610e87e24544a0af98c901b6e4877f"), "May 2021",
						projectTypes);
		assertEquals(resp.getBody().size(), 2);
		
		CrossProjectReferenceSummary crps = resp.getBody().get(0);
		assertEquals(1, crps.getOtherProjectCrlOverlap().size());
		assertEquals(1, crps.getOtherProjectSdctOverlap().size());
		assertNotNull(crps.getRefLocation());
		assertEquals(1, crps.getRefLocation().get(0).getOtherProjectsCrl().size());
		assertEquals(1, crps.getRefLocation().get(0).getOtherProjectsSdct().size());
  	}

    @Test
    @Transactional
    public void testSearchByProjectType_refLoc_status_true() {
        List<String> projectTypes = new ArrayList<>();
        projectTypes.add("RP");
        projectTypes.add("MP");

        ResponseEntity<List<CrossProjectReferenceSummary>> resp = crossReferenceToolController
                .getCrossProjectReferenceSummary(GUIDUtils.fromDatabaseFormat("b8610e87e24544a0af98c901b6e4877a"), "May 2023",
                        projectTypes);
        System.out.print("Resp" + resp.getBody());
        assertEquals(resp.getBody().size(), 2);

        /* CrossProjectReferenceSummary 1 */
        CrossProjectReferenceSummary crps0 = resp.getBody().get(0);
        assertEquals(0, crps0.getOtherProjectCrlOverlap().size());
        assertEquals(0, crps0.getOtherProjectSdctOverlap().size());
        assertNotNull(crps0.getRefLocation());

        /* CrossProjectReferenceSummary 1: RefLocation 1*/
        assertEquals(0, crps0.getRefLocation().get(0).getOtherProjectsCrl().size());
        assertEquals(0, crps0.getRefLocation().get(0).getOtherProjectsSdct().size());
        assertEquals("A61M5/21", crps0.getReferenceSymbol());
        assertEquals("A61B5/14", crps0.getRefLocation().get(0).getRefLocationTobeChanged());
        assertEquals("Title", crps0.getRefLocation().get(0).getRefLocationName());
        assertEquals(true, crps0.getRefLocation().get(0).isStatus());

        /* CrossProjectReferenceSummary 1: RefLocation 2*/
        assertEquals(0, crps0.getRefLocation().get(1).getOtherProjectsCrl().size());
        assertEquals(0, crps0.getRefLocation().get(1).getOtherProjectsSdct().size());
        assertEquals("A61M5/21", crps0.getReferenceSymbol());
        assertEquals("A61B5/14", crps0.getRefLocation().get(1).getRefLocationTobeChanged());
        assertEquals("Notes", crps0.getRefLocation().get(1).getRefLocationName());
        assertEquals(false, crps0.getRefLocation().get(1).isStatus());

        /* CrossProjectReferenceSummary 1: RefLocation 3*/
        assertEquals(0, crps0.getRefLocation().get(2).getOtherProjectsCrl().size());
        assertEquals(0, crps0.getRefLocation().get(2).getOtherProjectsSdct().size());
        assertEquals("A61M5/21", crps0.getReferenceSymbol());
        assertEquals("A61B5/14", crps0.getRefLocation().get(2).getRefLocationTobeChanged());
        assertEquals("Warning", crps0.getRefLocation().get(2).getRefLocationName());
        assertEquals(true, crps0.getRefLocation().get(2).isStatus());

        /* CrossProjectReferenceSummary 1: RefLocation 4*/
        assertEquals(0, crps0.getRefLocation().get(3).getOtherProjectsCrl().size());
        assertEquals(0, crps0.getRefLocation().get(3).getOtherProjectsSdct().size());
        assertEquals("A61M5/21", crps0.getReferenceSymbol());
        assertEquals("A61B5/14", crps0.getRefLocation().get(3).getRefLocationTobeChanged());
        assertEquals("Definition", crps0.getRefLocation().get(3).getRefLocationName());
        assertEquals(true, crps0.getRefLocation().get(3).isStatus());

        /* CrossProjectReferenceSummary 2 */
        CrossProjectReferenceSummary crps1 = resp.getBody().get(1);
        assertEquals(0, crps1.getOtherProjectCrlOverlap().size());
        assertEquals(0, crps1.getOtherProjectSdctOverlap().size());
        assertNotNull(crps1.getRefLocation());

        /* CrossProjectReferenceSummary 2: RefLocation 1*/
        assertEquals(0, crps1.getRefLocation().get(0).getOtherProjectsCrl().size());
        assertEquals(0, crps1.getRefLocation().get(0).getOtherProjectsSdct().size());
        assertEquals("A61M5/22", crps1.getReferenceSymbol());
        assertEquals("A61B5/18", crps1.getRefLocation().get(0).getRefLocationTobeChanged());
        assertEquals("Title", crps1.getRefLocation().get(0).getRefLocationName());
        assertEquals(true, crps1.getRefLocation().get(0).isStatus());

        /* CrossProjectReferenceSummary 2: RefLocation 2*/
        assertEquals(0, crps1.getRefLocation().get(1).getOtherProjectsCrl().size());
        assertEquals(0, crps1.getRefLocation().get(1).getOtherProjectsSdct().size());
        assertEquals("A61M5/22", crps1.getReferenceSymbol());
        assertEquals("A61B5/18", crps1.getRefLocation().get(1).getRefLocationTobeChanged());
        assertEquals("Notes", crps1.getRefLocation().get(1).getRefLocationName());
        assertEquals(true, crps1.getRefLocation().get(1).isStatus());

        /* CrossProjectReferenceSummary 2: RefLocation 3*/
        assertEquals(0, crps1.getRefLocation().get(2).getOtherProjectsCrl().size());
        assertEquals(0, crps1.getRefLocation().get(2).getOtherProjectsSdct().size());
        assertEquals("A61M5/22", crps1.getReferenceSymbol());
        assertEquals("A61B5/18", crps1.getRefLocation().get(2).getRefLocationTobeChanged());
        assertEquals("Warning", crps1.getRefLocation().get(2).getRefLocationName());
        assertEquals(true, crps1.getRefLocation().get(2).isStatus());

        /* CrossProjectReferenceSummary 2: RefLocation 4*/
        assertEquals(0, crps1.getRefLocation().get(3).getOtherProjectsCrl().size());
        assertEquals(0, crps1.getRefLocation().get(3).getOtherProjectsSdct().size());
        assertEquals("A61M5/22", crps1.getReferenceSymbol());
        assertEquals("A61B5/18", crps1.getRefLocation().get(3).getRefLocationTobeChanged());
        assertEquals("Definition", crps1.getRefLocation().get(3).getRefLocationName());
        assertEquals(true, crps1.getRefLocation().get(3).isStatus());

    }


    @Test
    @Transactional
    public void testSearchByProjectType3_status_False() {
        List<String> projectTypes = new ArrayList<>();
        projectTypes.add("MP");

        ResponseEntity<List<CrossProjectReferenceSummary>> resp = crossReferenceToolController
                .getCrossProjectReferenceSummary(GUIDUtils.fromDatabaseFormat("b8610e87e24544a0af98c901b6e4877f"), "May 2021",
                        null);
        assertEquals(resp.getBody().size(), 2);

        CrossProjectReferenceSummary crps = resp.getBody().get(0);
        assertNotNull(crps.getRefLocation());
        assertEquals(false, crps.getRefLocation().get(1).isStatus());
    }

    @Test
    @Transactional
    public void testGetCrossProjectReferenceSummary_NoTransferToSymbols() {

        ResponseEntity<List<CrossProjectReferenceSummary>> resp = crossReferenceToolController
                .getCrossProjectReferenceSummary(GUIDUtils.fromDatabaseFormat("b8610e87e24544a0af99c901b6e4877f"), null,
                        null);

        assertNotNull(resp.getBody());
        assertEquals(resp.getBody().size(), 1);

        CrossProjectReferenceSummary crps = resp.getBody().get(0);
        assertEquals("C", crps.getChangeType());
        assertEquals(1, crps.getSortOrderNumber());
        assertEquals(1, crps.getVersionNumber());
        assertEquals("b8810e87-e245-44a0-af98-c901b6e4877f", crps.getVersionSymbolGuidId());
        assertEquals("A61M5/002", crps.getReferenceSymbol());
        assertEquals(null, crps.getTransferToSymbols());
    }

    @Test
    @Transactional
    public void testGetCrlSymbolContentsForRTE() {
        UUID sourceProposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        //UUID otherProposalId = GUIDUtils.fromDatabaseFormat(null);
        UUID versionSymbolId = GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56");
        SymbolName crlSymbol = null;

        SymbolName sourceSymbol = new SymbolName("A01B1/00");

        ResponseEntity<RevisionChangeItem> resp = crossReferenceToolController
                .getCrlSymbolContentsForRTE(sourceProposalId, null, versionSymbolId, sourceSymbol, crlSymbol);

        RevisionChangeItem crps = resp.getBody();
        assertNotNull(crps);
        assertEquals(sourceSymbol.getClassificationSymbolCd(), crps.getSymbolName());
        assertTrue(crps.getTitleGrammar().contains("Hand tools"));
    }

    @Test
    @Transactional
    public void testGetCrlSymbolContentsForRTE_PencilIcon_ModifiedTitle() {
        UUID sourceProposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        //UUID otherProposalId = GUIDUtils.fromDatabaseFormat(null);
        UUID versionSymbolId = GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56");
        SymbolName crlSymbol = new SymbolName("A01");

        SymbolName sourceSymbol = new SymbolName("A61K35/02");

        ResponseEntity<RevisionChangeItem> resp = crossReferenceToolController
                .getCrlSymbolContentsForRTE(sourceProposalId, null, versionSymbolId, sourceSymbol, crlSymbol);

        RevisionChangeItem crps = resp.getBody();
        assertNotNull(crps);
        assertEquals(crlSymbol.getClassificationSymbolCd(), crps.getSymbolName());
        assertTrue(crps.getTitleGrammar().contains("Modified title saved in CRL"));
    }

    @Test
    @Transactional
    public void testGetCrlSymbolContentsForRTE_ProposalNameLink_ModifiedTitle() {
        UUID sourceProposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        UUID otherProposalId = GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7");
        UUID versionSymbolId = GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56");
        SymbolName crlSymbol = new SymbolName("A01");

        SymbolName sourceSymbol = new SymbolName("A61K35/02");

        ResponseEntity<RevisionChangeItem> resp = crossReferenceToolController
                .getCrlSymbolContentsForRTE(sourceProposalId, otherProposalId, versionSymbolId, sourceSymbol, crlSymbol);

        RevisionChangeItem crps = resp.getBody();
        assertNotNull(crps);
        assertEquals(crlSymbol.getClassificationSymbolCd(), crps.getSymbolName());
        assertEquals(
                "Methods of preparing ammonium salts in general##SUGGESTIONSTART####SUGGESTIONNAME##insertion:eceb7d6ed5cc6d9b3c63344bdfa0ae073:MANPREET.SINGH@USPTO.GOV##/SUGGESTIONNAME####/SUGGESTIONSTART##test##SUGGESTIONEND####SUGGESTIONNAME##insertion:eceb7d6ed5cc6d9b3c63344bdfa0ae073:MANPREET.SINGH@USPTO.GOV##/SUGGESTIONNAME####/SUGGESTIONEND##",
                crps.getTitleGrammar());
    }

    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1@uspto.gov", "myoung3@uspto.gov", Arrays
                .asList(new BasicTestingGrantedAuthority("test@uspto.gov")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }

    @Test
    @Transactional
    public void testGetCrlSymbolContentsForRTE_NoteItems() {
        UUID sourceProposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        //UUID otherProposalId = GUIDUtils.fromDatabaseFormat(null);
        UUID versionSymbolId = GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56");
        SymbolName crlSymbol = new SymbolName("A01B1/00");

        SymbolName sourceSymbol = new SymbolName("A01B1/00");

        ResponseEntity<RevisionChangeItem> resp = crossReferenceToolController
                .getCrlSymbolContentsForRTE(sourceProposalId, null, versionSymbolId, sourceSymbol, crlSymbol);

        RevisionChangeItem crps = resp.getBody();
        assertNotNull(crps);
        assertEquals(sourceSymbol.getClassificationSymbolCd(), crps.getSymbolName());
        assertTrue(crps.getTitleGrammar().contains("Modified title saved in CRL"));
        /*
        DE69281 unit test assertions:
            Revision Change Item(Gold Copy): noteItems (1 note 1 warning)
            CRL Current project: noteItems (2 notes and 1 warning)
            Expected: Revision Change Item(Gold Copy) noteItems were removed and appended 2 notes and 1 warning from current project url */
        assertEquals(crps.getNoteItems().size() , 3);
        List<NAWItemEditRequest> crptNotes = crps.getNoteItems().stream().filter(item -> item.getNoteCategory().value().equals(NoteType.NOTE.value())).collect(Collectors.toList());
        List<NAWItemEditRequest> crptWarnings = crps.getNoteItems().stream().filter(item -> item.getNoteCategory().value().equals(NoteType.WARNING.value())).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(crptNotes)) {
            log.info("inside");
            assertEquals(crptNotes.size() , 2);
            assertEquals(crptNotes.get(0).getNoteCategory().value() , NoteType.NOTE.value());
            assertEquals(crptNotes.get(0).getChangeType().value() , SCTComponentChangeType.M.value());
            assertEquals(crptNotes.get(1).getNoteCategory().value() , NoteType.NOTE.value());
            assertEquals(crptNotes.get(1).getChangeType().value() , SCTComponentChangeType.U.value());
        }
        if (CollectionUtils.isNotEmpty(crptWarnings)) {
            log.info("inside warning");
            assertEquals(crptWarnings.size() , 1);
            assertEquals(crptWarnings.get(0).getNoteCategory().value() , NoteType.WARNING.value());
            assertEquals(crptWarnings.get(0).getChangeType().value() , SCTComponentChangeType.M.value());
        }
    }

}
