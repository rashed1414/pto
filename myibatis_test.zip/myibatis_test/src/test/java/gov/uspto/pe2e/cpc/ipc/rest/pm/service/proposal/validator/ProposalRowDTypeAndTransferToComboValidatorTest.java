package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowDTypeAndTransferToComboValidatorTest {
    
    private static final Logger log = LoggerFactory.getLogger(ProposalRowDTypeAndTransferToComboValidatorTest.class);    
    
    private static final String EXPECTED_MESSAGE = "Deleted additional-only symbol with no transfer. Confirm!";
    
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalRowDTypeAndTransferToComboValidator proposalRowDTypeAndTransferToComboValidator;

    @Inject
    private ProposalValidationService proposalValidationService;

    @Resource
    private List<ProposalValidator> proposalValidators;


    @Test
    public void testValidate() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A01N27/99", "0", "Bold Error ##BOLD##", null));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("", "A01N27/99", "0", "Bold Error ##BOLD##", null));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowDTypeAndTransferToComboValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
    }
    
    
    @Test
    public void testValidateTypeDWithYSeriesAndIndexSymbols() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "Y01N27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "Y01N27", "0", "Bold Error ##BOLD##", null));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A01N2700/99", "0", "Bold Error ##BOLD##", new String[] {}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "Y01N27/99", "0", "Bold Error ##BOLD##", new String[] {}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowDTypeAndTransferToComboValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty()); 
        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, rows.get(2).getValidationMessages().get(0).getTriggerField());
        Assert.assertEquals(EXPECTED_MESSAGE, rows.get(2).getValidationMessages().get(0).getMessageText());  
        Assert.assertEquals(EXPECTED_MESSAGE, rows.get(3).getValidationMessages().get(0).getMessageText());
        log.debug("Expected Message:: {}", rows.get(3).getValidationMessages().get(0).getMessageText());
    }  
    
    @Test
    public void testEmptyRows() {
        List<RevisionChangeItem> rows = new ArrayList<>();      
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowDTypeAndTransferToComboValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.size());
    }   

    @Test
    public void testConfigCorrectlyIncludesGrammarValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(proposalRowDTypeAndTransferToComboValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }

    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.LOW, proposalRowDTypeAndTransferToComboValidator.getCost());

    }

    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }

}
