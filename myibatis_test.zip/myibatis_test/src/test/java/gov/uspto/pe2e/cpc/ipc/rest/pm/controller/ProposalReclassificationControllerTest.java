package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ExternalServiceException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassFamilyCount;
import jakarta.inject.Inject;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalReclassificationControllerTest {
	private static final Logger log = LoggerFactory.getLogger(ProposalReclassificationControllerTest.class);

	@Inject
	private ProposalReclassificationController proposalReclassificationController;

	@Inject
	private DatasetTestingService datasetTestingService;
	
	
	//This test class directly calling CPC DB service so it is failing when that service is down
	//Refactor this test case to utilize mocking external service.
	/*
	 * @Transactional
	 * 
	 * @Test public void testSaveProposalFamilyCountDetails() throws
	 * ExternalServiceException, JsonGenerationException, JsonMappingException,
	 * IOException {
	 * 
	 * log.info("inside testGetProposalFamilyCountDetails"); UUID uuid =
	 * GUIDUtils.fromDatabaseFormat("df82444cf682452e82d79048609a548f");
	 * 
	 * ResponseEntity<Void> resp =
	 * proposalReclassificationController.saveFamilyCount(uuid);
	 * 
	 * Assert.assertNotNull(resp); Assert.assertNull(resp.getBody()); }
	 */

	@Transactional
	@Test
	public void testGetProposalFamilyCountDetails() throws ExternalServiceException, JsonGenerationException, JsonMappingException, IOException  {

		log.info("inside testGetProposalFamilyCountDetails");
		UUID uuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		
		ResponseEntity<List<ReclassFamilyCount>> resp = proposalReclassificationController.getFamilyCount(uuid);

		Assert.assertNotNull(resp);
		Assert.assertNotNull(resp.getBody());
		Assert.assertNotNull(resp.getBody().get(0).getReclassProgressId());
		log.debug("resp = {} ", JsonUtils.toJson(resp.getBody()));
	}

	
	@Transactional
	@Test
	public void testDeleteProposalFamilyCountDetails() throws ExternalServiceException, JsonGenerationException, JsonMappingException, IOException  {

		log.info("inside testDeleteProposalFamilyCountDetails");
		UUID uuid = GUIDUtils.fromDatabaseFormat("b640501396034fa6aa07317eaf74c9cb");
		 proposalReclassificationController.deleteFamilyCount(uuid);
        
		 UUID uuid2 = GUIDUtils.fromDatabaseFormat("b740501396034fa6aa07317eaf74c9cb");
		 Exception exception = assertThrows(Exception.class, () -> proposalReclassificationController.deleteFamilyCount(uuid2));
		 assertEquals("Reclassification family count with id 'b7405013-9603-4fa6-aa07-317eaf74c9cb' not found.", exception.getMessage());
		 
	}

	
	@Before
	public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.emptyTables(conn);
		datasetTestingService.loadAllDatasets(conn);

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamy@uspto.gov", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
	}

}