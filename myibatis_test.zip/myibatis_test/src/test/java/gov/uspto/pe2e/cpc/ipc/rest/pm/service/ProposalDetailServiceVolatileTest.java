package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalDetail;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalDetailRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDetailCreationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalFormType;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalDetailServiceVolatileTest {
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ChangeProposalDetailRepository changeProposalDetailRepository;
    
    @Inject
    private ChangeProposalRepository changeProposalRepository;
    
    @Inject
    private ProposalDetailsService proposalDetailsService;
    
	@Transactional
	@Test
	public void testReclassOfficeByItemName() {

		String reclassOffice = proposalDetailsService.getReclassOfficeFromPDForm("d153f9bf804848aa8ba202db9f944db5",
				"reclassificationOffice_PD");

		if (StringUtils.isNotBlank(reclassOffice)) {
			assertEquals("US", reclassOffice);
		}

	}

       
    @Transactional
    @Test
    public void testSaveAsNew() throws JsonGenerationException, JsonMappingException, IOException {
        Date now = new Date();
        List<ProposalDetailCreationRequest> list = new ArrayList<>();
        ProposalDetailCreationRequest req = new ProposalDetailCreationRequest();
        req.setDetails("Test 123");
        req.setItemName("Test1");
        req.setFormType(ProposalFormType.INTERNAL_REQUEST);
        list.add(req);
        assertNotNull(proposalDetailsService);
        
        List<UUID> twlId = proposalDetailsService.save(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), 
                list, "myoung@uspto.gov");
        ChangeProposalDetail dbTWL = changeProposalDetailRepository.findByExternalId(
                GUIDUtils.toDatabaseFormat(twlId.get(0)));
        assertNotNull(dbTWL);
        assertEquals(ProposalPhase.I, dbTWL.getProposalPhaseCode());
    }
    

    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
                "bkuppusamy", "Boops","Kuppusamy", "US");
            UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "boopathi.kuppusamy@uspto.gov", token,
                Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
                        new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
                        new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
        SecurityContextHolder.getContext().setAuthentication(springUser);  

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/proposals/xxx/twl")));
    }

}
