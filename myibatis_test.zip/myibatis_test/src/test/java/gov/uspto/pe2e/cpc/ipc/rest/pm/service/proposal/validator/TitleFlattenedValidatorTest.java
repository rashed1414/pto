package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.TitleConverter;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class TitleFlattenedValidatorTest {
    private static final Logger log = LoggerFactory.getLogger(TitleFlattenedValidatorTest.class);

    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private TitleReferencePartFltValidator titleReferencePartFltValidator;
    

    @Inject
    private TitleReference0Or1AndAtEndFltValidator titleReference0Or1AndAtEndFltValidator;

    @Inject
    private TitleHasNonReferenceFltValidator titleHasNonReferenceFltValidator;

    @Inject
    private TitleDanglingSemicolonFltValidator titleDanglingSemicolonFltValidator;
    

    @Inject
    private TitleValidTitleButInvalidFltValidator titleValidTitleButInvalidFltValidator;
    
    @Inject
    private ProposalValidationService proposalValidationService;

    @Inject
    private TitleService titleService;

    @Resource(name="proposalCompletenessValidator")
    private List<ProposalValidator> proposalValidators;

    @Test
    public void testConfigCorrectlyIncludesRefPartValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(titleReferencePartFltValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }

    @Test
    public void testConfigCorrectlyIncludes0or1Validator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(titleReference0Or1AndAtEndFltValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }
    
    @Test
    public void testConfigCorrectlyIncludesHasNonRefValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(titleHasNonReferenceFltValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }
 
    @Test
    public void testConfigCorrectlyIncludesValidTitleButInvalidFlattenedValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(titleValidTitleButInvalidFltValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }
 
    @Test
    public void testConfigCorrectlyIncludesDanglingSemicolonValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(titleDanglingSemicolonFltValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }

    @Test
    public void testValidateReferencePartVaidator() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateIpcTitleGrammar("M", "A01N27/99", "0",
                "Testing (Handy for {; Takes precedence for sewerage ##SYMBOL##E02B 7/18##/SYMBOL##} siphon)", null));

        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartFltValidator.validate(proposalValidationContext, rows);
        int i = 1;
        for (RevisionChangeItem row : rows) {
            log.debug("line {} has {} validation messages", i++, row.getValidationMessages().size());
        }
        Assert.assertEquals(2, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Non-precedence reference parts must have reference text followed by one or more symbols",
                rows.get(0).getValidationMessages().get(0).getMessageText());

        Assert.assertEquals("Precedence reference must appear as first reference part and have reference symbol",
                rows.get(0).getValidationMessages().get(1).getMessageText());

    }
    
    @Test
    public void testValidateDanglingSemicolonValidator() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateIpcTitleGrammar("M", "A01N27/99", "0",
                "tp1;tp2 (section refp1{;})", null));
        
        Assert.assertNotNull(rows.get(0).getFlattenedTitle());
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleDanglingSemicolonFltValidator.validate(proposalValidationContext, rows);
        int i = 1;
        for (RevisionChangeItem row : rows) {
            log.debug("line {} has {} validation messages", i++, row.getValidationMessages().size());
        }
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Title-parts or reference-parts can not be empty.",
                rows.get(0).getValidationMessages().get(0).getMessageText());

    }
 
    @Test
    public void testValidateHasNonReferenceValidator() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateIpcTitleGrammar("M", "A01N27/99", "0",
                "Test{;(class)}", null));
        
        Assert.assertNotNull(rows.get(0).getFlattenedTitle());
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleHasNonReferenceFltValidator.validate(proposalValidationContext, rows);
        int i = 1;
        for (RevisionChangeItem row : rows) {
            log.debug("line {} has {} validation messages", i++, row.getValidationMessages().size());
        }
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Title part must have title part text that is not within the Reference.",
                rows.get(0).getValidationMessages().get(0).getMessageText());

    }

    @Test
    public void testValidate0Or1RefValidator() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateIpcTitleGrammar("M", "A01N27/99", "0",
                "Test{(class)(section)}", null));
        
        Assert.assertNotNull(rows.get(0).getFlattenedTitle());
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReference0Or1AndAtEndFltValidator.validate(proposalValidationContext, rows);
        int i = 1;
        for (RevisionChangeItem row : rows) {
            log.debug("line {} has {} validation messages", i++, row.getValidationMessages().size());
        }
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Title part cannot have more than one reference.",
                rows.get(0).getValidationMessages().get(0).getMessageText());

    }

    @Test
    public void testValidateIPCTitleParsed() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        
        rows.add(createRevisionChangeItemAndValidateIpcTitleGrammar("M", "A01N27/99", "0",
                "{;}Test", null));
        Assert.assertNotNull(rows.get(0).getTitle());
        
        Assert.assertNull(rows.get(0).getFlattenedTitle());
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleValidTitleButInvalidFltValidator.validate(proposalValidationContext, rows);
        int i = 1;
        for (RevisionChangeItem row : rows) {
            log.debug("line {} has {} validation messages", i++, row.getValidationMessages().size());
        }
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Modifications to the IPC title are improper, (check curly bracket placement).",
                rows.get(0).getValidationMessages().get(0).getMessageText());

    }

    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.MEDIUM, titleReferencePartFltValidator.getCost());
    }

    @Test
    public void testGetValidatorType() {
        Assert.assertEquals(ValidationMessageType.RECORD, titleReferencePartFltValidator.getValidationType());

    }

    public RevisionChangeItem createRevisionChangeItemAndValidateTitleGrammar(String entryType, String symbolName,
            String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel,
                titleGrammar, reclassTargets);
        try {
            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
            item.setTitle(tree);
        } catch (GrammarParseException gpe) {
            item.getValidationMessages().addAll(gpe.getValidationMessages());
        }
        return item;
    }
    public RevisionChangeItem createRevisionChangeItemAndValidateIpcTitleGrammar(String entryType, String symbolName,
            String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel,
                titleGrammar, reclassTargets);
        try {
            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
            item.setTitle(tree);
            try {
                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
                item.setFlattenedTitle(tree);
            } catch (GrammarParseException gpe2) {
                log.debug("GPE encountered, IPC title will be set to null");
            }
        } catch (GrammarParseException gpe) {
            item.getValidationMessages().addAll(gpe.getValidationMessages());
        }
        return item;
    }

    @Before
    public void setUp() throws Exception {

        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        DateTimeZone.setDefault(DateTimeZone.UTC);
        
        datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        // UsernamePasswordAuthenticationToken token = new
        // UsernamePasswordAuthenticationToken("user1", "user@user.com",
        // Arrays.asList(new BasicTestingGrantedAuthority("test")));
        //
        // SecurityContextHolder.getContext().setAuthentication(token);
        //
        // RequestContextHolder.setRequestAttributes(
        // new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
        // "/cpcipcrestweb", "/symbols")));
    }

      @Test
        public void testConfigCorrectlyIncludesGrammarValidator() {
            boolean isIncluded = false;
            for (ProposalValidator validator : proposalValidators) {
                if (validator.getClass().getCanonicalName().equals(titleReferencePartFltValidator.getClass().getCanonicalName())) {
                    isIncluded = true;
                    break;
                }
            }
            Assert.assertTrue(isIncluded);
        }
    

}
