package gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.DotLevelType;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.DefinitionHierarchy;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.SchemeHierarchy;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.SchemeHierarchyRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.AdapterUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.SymbolStatusCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PrivateProposalTreeStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationTreeStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SchemeChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePart;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartRawText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalService;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.ApplicationReferences;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalPublicationHelperTest {

	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private ProposalService proposalService;

	@Inject
	private ProposalPublicationHelper proposalPublicationHelper;

	@Inject
	private SchemeHierarchyRepository schemeHierarchyRepository;
	
	@Inject
	private EntityManager entityManager;

	@Resource(name = "documentAdapterConfig")
	private Map<String, String> documentAdapterConfig;

	@BeforeClass
	public static void setupClass() {
		System.setProperty("com.sun.xml.internal.stream.XMLInputFactoryImpl",
				"com.sun.xml.internal.stream.XMLInputFactoryImpl");
		System.setProperty("jakarta.xml.parsers.DocumentBuilderFactory",
				"com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");

	}

	@Before
	public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.emptyTables(conn);
		datasetTestingService.loadAllDatasets(conn);
		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

	}

	@Test
	public void testBuildPublicationAndVerifyAllSymbolsAreIncluded(){
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		sctItems.add(createSctItem("A01B1/00", DotLevelType.MAINGROUP, SchemeChangeType.U));

		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), 3L,
				sctItems, "test", new Date());

		SchemeHierarchy s1 = schemeHierarchyRepository.findByCompositeId(3L, "A01B19/00",6);
		Assert.assertNotNull(s1);
	}

	@Test
	@Transactional
	public void testBuildPublication() {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		sctItems.add(createSctItem("A01N65/26", DotLevelType.fromIndentLevel(9), SchemeChangeType.C));
		sctItems.add(createSctItem("A01N65/99", DotLevelType.fromIndentLevel(9), SchemeChangeType.C));
		sctItems.add(createSctItem("A01N65/99", DotLevelType.fromIndentLevel(9), SchemeChangeType.D));
		//sctItems.add(createSctItem("A01B1/02", DotLevelType.fromIndentLevel(8), SchemeChangeType.M));

		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), 3L,
				sctItems, "test", new Date());
		
		
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		assertNotEquals(count, afterCount);
		assertEquals(5950, afterCount);
		entityManager.flush();
		entityManager.clear();
		List<SchemeHierarchy> symbols = new ArrayList<SchemeHierarchy>();
//		schemeHierarchyRepository.findAll().forEach(symbols::add);
//		Collections.sort(symbols, new BeanComparator<>("createTs"));
//		Collections.reverse(symbols);
//		List<SchemeHierarchy> symbols = schemeHierarchyRepository.findByName(3L,  "A01N65/99");
		SchemeHierarchy s1 = schemeHierarchyRepository.findByCompositeId(3L, "A01N65/99",9);
		symbols.add(s1);
		assertTrue(symbols.size() > 0);
		int i = 0;
		for (SchemeHierarchy symbol: symbols) {
			log.debug("id = {} name = {} status = {} scheme = {} indent = {}", symbol.getId(), 
					symbol.getClassificationSymbolCode(), symbol.getStatusCode(), 
					symbol.getClassificationScheme().getId(), symbol.getIndentLevel());
			i++;
			if (i > 30) {
				break;
			}
		}
		SchemeHierarchy symbol = symbols.get(0);
//		log.debug("definition content = {}", 
//				symbol.getDefinitionHierarchies().iterator().next().getDefinition());
		assertEquals(SymbolStatusCode.PROPOSED_DELETED, symbol.getStatusCode());
		
		PrivateProposalTreeStatus treeStatus =  proposalService.getPublicationTreeStatus(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
		assertNotNull(treeStatus);
		assertEquals(PublicationTreeStatus.COMPLETE, treeStatus.getStatus());
	}

	
	@Test
	@Transactional
	public void testBuildPublication2() {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		sctItems.add(createSctItem("A01B1/00", DotLevelType.fromIndentLevel(8), SchemeChangeType.M));

		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), 3L,
				sctItems, "test", new Date());
		
		
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		assertNotEquals(count, afterCount);
		assertEquals(6031, afterCount);
		entityManager.flush();
		entityManager.clear();
	}

	@Test
	@Transactional
	public void testBuildPublication_withsiblings() {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		sctItems.add(createSctItem("A01N65/26", DotLevelType.fromIndentLevel(9), SchemeChangeType.C));
		//sctItems.add(createSctItem("A01B1/02", DotLevelType.fromIndentLevel(8), SchemeChangeType.M));

		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), 3L,
				sctItems, "test", new Date());
		
		
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		entityManager.flush();
		entityManager.clear();
		List<SchemeHierarchy> symbols = new ArrayList<SchemeHierarchy>();

		SchemeHierarchy sibling = schemeHierarchyRepository.findByCompositeId(3L, "A01N65/28",9);
		assertNotNull(sibling);
		assertEquals("A01N65/28", sibling.getClassificationSymbolCode());
	}

	
	@Test
	@Transactional
	public void testInitializeSchemeForSave() {
		Long id = proposalPublicationHelper.initializeClassificationScheme(
				GUIDUtils.fromDatabaseFormat("5615a330b8994a96af7df8d2d8589606"), 
				DateTime.now().toDate(), "unit@testing.com");
		assertNotNull(id);
	}	
	
	private RevisionChangeItemRequest createSctItem(String symbolName, DotLevelType dotLevel, SchemeChangeType changeType) {
		RevisionChangeItemRequest item = new RevisionChangeItemRequest();
		item.setSymbolName(SymbolName.normalize(symbolName));
		String titleXmlFile = "data/xml/fragments/A01D_title_fragment.xml";
		TitlePartTree title = null;
		try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(titleXmlFile)) {
			assertNotNull("failed to find " + titleXmlFile+" for symbol "+symbolName, is);
			String baseTitle = IOUtils.toString(is);

			SchemeHierarchy dbSymbol = schemeHierarchyRepository
					.findByNameFromLatestSchemeNotIncludingHeadingSymbols(symbolName);

			if (dbSymbol != null) {
				String xml = dbSymbol.getTitle();
				title = (TitlePartTree) AdapterUtils.latest(documentAdapterConfig).mapTitleXmlDocument(xml);

			} else {
				title = (TitlePartTree) AdapterUtils.latest(documentAdapterConfig).mapTitleXmlDocument(baseTitle);
			}
			TitlePartRawText raw = new TitlePartRawText();
			raw.setContent("This is a minor edit forcing difference in case of testing publication");

			TitlePartText txt = new TitlePartText();
			txt.getChildren().add(raw);
			title.getChildren().add((TitlePart)txt);
		} catch (Exception e) {
			log.debug("exc = ", e);
		}
		item.setTitle(title);
		item.setDotLevel(dotLevel.getDisplayValue());
		item.setEntryType(changeType.name());
		DefSectionItemEditRequest def =  new DefSectionItemEditRequest();
		def.setApplicationReferences(new ApplicationReferences());
		def.getApplicationReferences().setSuggestionStart("123");

		def.getApplicationReferences().setSuggestionEnd("123");
		item.getDefinitionItems().add(def);
		return item;
	}
	
	@Test
	public void testLevelMapping() {
		RevisionChangeItem sctItem = new RevisionChangeItem();
		sctItem.setDotLevel("Subclass");
		try {
			DotLevelType dot = DotLevelType.fromDisplay(sctItem.getDotLevel());
			assertNotNull(dot);
			assertEquals(5, dot.getIndentLevel());
		} catch (Exception e) {
			fail();
		}
	}
	
	@Test
	@Transactional
	public void testDetermineParent() {
		SchemeHierarchy parent = null;
		parent = proposalPublicationHelper.determineParentForNewSymbol("A01P", 
				DotLevelType.SUBCLASS.getIndentLevel(),2L, 3L);
		assertEquals("A01", parent.getClassificationSymbolCode());
		assertEquals((Integer)4, (Integer)parent.getIndentLevel());

		parent = proposalPublicationHelper.determineParentForNewSymbol("A01", 
				DotLevelType.CLASS.getIndentLevel(),2L, 3L);
		assertEquals("A01", parent.getClassificationSymbolCode());
		assertEquals((Integer)3, (Integer)parent.getIndentLevel());

		parent = proposalPublicationHelper.determineParentForNewSymbol("A01", 
		DotLevelType.SUBSECTION.getIndentLevel(),2L, 3L);
		assertEquals("A", parent.getClassificationSymbolCode());
		assertEquals((Integer)2, (Integer)parent.getIndentLevel());	

		parent = proposalPublicationHelper.determineParentForNewSymbol("A01N1/1012", 
				DotLevelType.SUBGROUP.getIndentLevel(),2L, 3L);
		assertEquals("A01N1/00", parent.getClassificationSymbolCode());
		assertEquals((Integer)7, (Integer)parent.getIndentLevel());

		
		parent = proposalPublicationHelper.determineParentForNewSymbol("A01N1/00", 
				DotLevelType.GUIDANCEHEADING.getIndentLevel(),2L, 3L);
		assertEquals("A01N", parent.getClassificationSymbolCode());
		assertEquals((Integer)5, (Integer)parent.getIndentLevel());

		parent = proposalPublicationHelper.determineParentForNewSymbol("A01B3/188", 
				DotLevelType.FOUR.getIndentLevel(),2L, 3L);
		assertEquals("A01B3/18", parent.getClassificationSymbolCode());
		assertEquals((Integer)10, (Integer)parent.getIndentLevel());

		try {
			// There is no parent at dot level 3 that could possibly match this symbol, fail test if it is null because it should be exception
			parent = proposalPublicationHelper.determineParentForNewSymbol("A01B66/5088",
					DotLevelType.FOUR.getIndentLevel(),2L, 3L);
			assertNotNull(parent);
		} catch (Exception e) {
			// Expecting an exception
		}

		parent = proposalPublicationHelper.determineParentForNewSymbol("A01B63/004", 
				DotLevelType.TWO.getIndentLevel(),2L, 3L);
		assertEquals("A01B63/002", parent.getClassificationSymbolCode());
		assertEquals((Integer)8, (Integer)parent.getIndentLevel());

		
		
	}
	
	@Test
	@Transactional
	public void testDetermineParentMaingroupWithParent() {
		SchemeHierarchy parent = proposalPublicationHelper.determineParentForNewSymbol("A01B22/00", 
				DotLevelType.MAINGROUP.getIndentLevel(),2L, 3L);
		assertNotNull(parent);
		
		assertEquals("A01B19/00", parent.getClassificationSymbolCode());
		assertEquals((Integer)6, (Integer)parent.getIndentLevel());		
		
	}

	@Test
	@Transactional
	public void testDetermineParentSubgroupWithNewParent() {
//		SchemeHierarchy parent = proposalPublicationHelper.determineParentForNewSymbol("A01B6/001", 
//				DotLevelType.SUBGROUP.getIndentLevel(),2L, 3L);
//		assertNotNull(parent);
//		
//		assertEquals("A01B19/00", parent.getClassificationSymbolCode());
//		assertEquals((Integer)6, (Integer)parent.getIndentLevel());		
//		
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		sctItems.add(createSctItem("A01B6/00", DotLevelType.fromIndentLevel(7), SchemeChangeType.N));
		sctItems.add(createSctItem("A01B6/001", DotLevelType.fromIndentLevel(8), SchemeChangeType.N));

		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), 3L,
				sctItems, "test", new Date());
//		SchemeHierarchy level6Symbol = schemeHierarchyRepository.findById(1000004L).get();
//		assertNotNull(level6Symbol);
//		assertNotNull(level6Symbol.getClassificationScheme());
//		log.debug("name = {}, schemeId = {}, indent level = {}", level6Symbol.getClassificationSymbolCode(),
//				level6Symbol.getClassificationScheme().getId(), 
//				level6Symbol.getIndentLevel());
		
		SchemeHierarchy sym = schemeHierarchyRepository.findByCompositeId(3L, "A01B6/00",7);
		assertNotNull(sym);
		log.debug("{} {} {}", sym.getClassificationScheme().getId(),
				sym.getClassificationSymbolCode(), sym.getIndentLevel());
		assertEquals("A01B3/00", sym.getParent().getClassificationSymbolCode());
		assertEquals((Integer)6, sym.getParent().getIndentLevel());

		
		sym = schemeHierarchyRepository.findByCompositeId(3L, "A01B6/001",8);
		assertNotNull(sym);
		assertEquals((Integer)7, sym.getParent().getIndentLevel());
		assertEquals("A01B6/00", sym.getParent().getClassificationSymbolCode());
		

	}

	
	@Test
	@Transactional
	public void testBuildPublicationWithSelfParent() {
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		sctItems.add(createSctItem("A01B22/00", DotLevelType.fromIndentLevel(6), SchemeChangeType.M));
		sctItems.add(createSctItem("A01B22/00", DotLevelType.fromIndentLevel(7), SchemeChangeType.M));

		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), 3L,
				sctItems, "test", new Date());
//		SchemeHierarchy level6Symbol = schemeHierarchyRepository.findOne(1000004L);
//		assertNotNull(level6Symbol);
//		assertNotNull(level6Symbol.getClassificationScheme());
//		log.debug("name = {}, schemeId = {}, indent level = {}", level6Symbol.getClassificationSymbolCode(),
//				level6Symbol.getClassificationScheme().getId(), 
//				level6Symbol.getIndentLevel());
		
		SchemeHierarchy sym = schemeHierarchyRepository.findByCompositeId(3L, "A01B22/00",6);
		assertNotNull(sym);
		assertEquals((Integer)5, sym.getParent().getIndentLevel());
		assertEquals("A01B", sym.getParent().getClassificationSymbolCode());

		
		sym = schemeHierarchyRepository.findByCompositeId(3L, "A01B22/00",7);
		assertNotNull(sym);
		assertEquals((Integer)6, sym.getParent().getIndentLevel());
		assertEquals("A01B22/00", sym.getParent().getClassificationSymbolCode());
		
	}

	
	@Test
	public void testDetermineChildrenOfA01B() {
		List<SchemeHierarchy> children = schemeHierarchyRepository.findDirectChildSymbolsByParentSymbolName(1047964L, 2L);
		for (SchemeHierarchy child: children) {
			log.debug("{}", child.getClassificationSymbolCode());
			List<SchemeHierarchy> subchildren = schemeHierarchyRepository.findDirectChildSymbolsByParentSymbolName(child.getId(), 2L);
			for (SchemeHierarchy level7: subchildren) {
				log.debug("-- {} {}", child.getClassificationSymbolCode(), level7.getClassificationSymbolCode());
				
			}
			
		}
	}

	
	@Test
	public void testMapDefinitionsToGoldCopy() throws IOException {
		try (InputStream is = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("data/xml/fragments/definition/collab_definition_sample.xml")) {
			String dirty = IOUtils.toString(is);
			String goldDefinition = proposalPublicationHelper.mapDefinitionsToGoldCopy(dirty);
			assertEquals("<definition-item date-revised=\"2023-07-15\"><classification-symbol>A61K2035/11</classification-symbol><definition-title>Test</definition-title><references/></definition-item>",
					goldDefinition);
			
		}
	}
	
	@Test
	public void testMapTextContainingSymbolsToGoldCopy() throws IOException {
		String dirty = "<definition-title>Electrotherapy;Circuits therefor (##SYMBOL####SCHEME##cpc##/SCHEME##A61N2/00##/SYMBOL## takes precedence; irradiation apparatus ##SYMBOL####SCHEME##cpc##/SCHEME##A61N5/00##/SYMBOL##)</definition-title>";
		String goldDefinition = proposalPublicationHelper.mapTextContainingSymbolsToGoldCopy(dirty);
		assertEquals(
				"<definition-title>Electrotherapy;Circuits therefor (<class-ref scheme=\"cpc\">A61N2/00</class-ref> takes precedence; irradiation apparatus <class-ref scheme=\"cpc\">A61N5/00</class-ref>)</definition-title>",
				goldDefinition);
	}
	
	//TODO: Check with Matt why this is failing
	//@Test
	@Transactional
	public void testBuildPublication_withuberproject() {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		sctItems.add(createSctItem("A01N65/26", DotLevelType.fromIndentLevel(9), SchemeChangeType.C));
		//sctItems.add(createSctItem("A01B1/02", DotLevelType.fromIndentLevel(8), SchemeChangeType.M));

//		proposalPublicationHelper.initializeClassificationScheme(null, null, null)
		
		proposalPublicationHelper.buildGlobalPublicationPreview(
				GUIDUtils.fromDatabaseFormat("5615a330b8994a96af7df8d2d8589606"),
				3L,
				sctItems, "test", new Date());
		
		
//		(null,
//				null,
//				GUIDUtils.fromDatabaseFormat("5615a330b8994a96af7df8d2d8589606"), 3L,
//				sctItems, "test", new Date());
//		
		
	}

	
	@Test
	@Transactional
	public void testBuildPublication_newdefs() throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//		TypeFactory typeFactory = objectMapper.getTypeFactory();		
		try (InputStream is = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("data/json/de67965.json")) {
			String sctJson = IOUtils.toString(is);
			List<RevisionChangeItemRequest> sct = objectMapper.readValue(sctJson, new TypeReference<List<RevisionChangeItemRequest>>() {});
			
			proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("5615a330b8994a96af7df8d2d8589606"),
					3L,
					sct, "test", new Date());
		
			SchemeHierarchy symbol = schemeHierarchyRepository.findByCompositeId(3L, 
					"A01N1/0215", DotLevelType.FOUR.getIndentLevel());
			assertNotNull(symbol);
			assertEquals("A01N1/0215", symbol.getClassificationSymbolCode());
			assertEquals(true, symbol.getDefinitionExists());
			List<DefinitionHierarchy> defs = new ArrayList<>(symbol.getDefinitionHierarchies());
			
			log.debug("def xml =  {} ", defs.get(0).getDefinition());
			
			assertTrue(defs.get(0).getDefinition().contains("A01N1/0215"));
			
			
		}
	}
	
	


}
