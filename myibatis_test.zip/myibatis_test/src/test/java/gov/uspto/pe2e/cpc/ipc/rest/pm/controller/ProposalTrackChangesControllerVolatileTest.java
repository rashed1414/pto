package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalTrackChangesControllerVolatileTest {
	 
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ProposalTrackChangesController controller;
    

    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
    			"bkuppusamy", "Boops","Kuppusamy", "US");
    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"boopathi.kuppusamy@uspto.gov", token,
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);        


        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/proposaltaskconsultation")));
    }

    @Transactional
	@Test
	public void testSave() throws Exception {
		String json = " {\r\n"
				+ "            \"id\": \"suggestion-3\",\r\n"
				+ "            \"type\": \"formatInline:886cqig6g8rf\",\r\n"
				+ "            \"authorId\": \"user-1\",\r\n"
				+ "            \"createdAt\": \"2019-01-14T18:43:19.938-04:00\",\r\n"
				+ "            \"data\": {\r\n"
				+ "                \"commandName\": \"bold\",\r\n"
				+ "                \"commandParams\": [ { \"forceValue\": true } ]\r\n"
				+ "            },\r\n"
				+ "            \"attributes\": {}\r\n"
				+ "        }";
		ResponseEntity<Void> resp = controller.save(
				GUIDUtils.fromDatabaseFormat("44c4f7b8b78e4c07aa5d37432db56260"), json);
		assertNotNull(resp);
		assertNotNull(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER));
		assertEquals("suggestion-3", resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
		
		ResponseEntity<String> getResp = controller.findById("suggestion-3");
		assertNotNull(getResp);
		assertEquals(HttpStatus.OK, getResp.getStatusCode());
		assertNotNull(getResp.getBody());
		
		assertEquals("suggestion-3", controller.trackChangesService.extractPayloadId(getResp.getBody()));
	}

    
    @Transactional
	@Test
	public void testDelete() throws Exception {
		
		ResponseEntity<Void> resp = controller.deleteById("suggestion-1");
		assertNotNull(resp);
		assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
		
		try {
			ResponseEntity<String> getResp = controller.findById("suggestion-1");
			fail("Should not get this far since suggestion-1 was deleted above");
		} catch (Exception e) {
			assertEquals("Track Changes document 'suggestion-1' Not Found", e.getMessage());
		}
	}
    
    @Transactional
	@Test
	public void testUpdate() throws Exception {
		String json = "{"
				+ "\"id\": \"075909bd-f152-4e2b-b568-4e20b3c92f4f\","
				+ "\"data\": \"nothing\""
				+ "}";
		ResponseEntity<Void> resp = controller.updateById("075909bd-f152-4e2b-b568-4e20b3c92f4f",
				json);
		assertNotNull(resp);
		assertNotNull(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER));
		assertEquals("075909bd-f152-4e2b-b568-4e20b3c92f4f", resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
		
		ResponseEntity<String> getResp = controller.findById("075909bd-f152-4e2b-b568-4e20b3c92f4f");
		assertNotNull(getResp);
		assertEquals(HttpStatus.OK, getResp.getStatusCode());
		assertNotNull(getResp.getBody());
		assertEquals(json, getResp.getBody());
	}


}
