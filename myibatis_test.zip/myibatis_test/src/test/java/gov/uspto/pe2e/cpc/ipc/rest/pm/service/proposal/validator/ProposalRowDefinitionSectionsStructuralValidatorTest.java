package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import static org.junit.Assert.assertNotNull;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLStreamReader;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.CloseableUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.NamespaceXmlReader;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefinitionSectionType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionStatement;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })

public class ProposalRowDefinitionSectionsStructuralValidatorTest {

    private static final Logger log = LoggerFactory.getLogger(ProposalRowDefinitionSectionsStructuralValidatorTest.class);

    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalRowDefinitionSectionsStructuralValidator proposalRowDefinitionSectionsStructuralValidator;

    @Resource(name = "proposalConsistencyValidator")
    private List<ProposalValidator> consistencyValidators;

    @Inject
    private ProposalValidationService proposalValidationService;

    private DocumentAdapter docAdapter;

    @Test
    public void testConfigCorrectlyIncludesDefinitionSectionsValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : consistencyValidators) {
            if (validator.getClass().getCanonicalName()
                    .equals(proposalRowDefinitionSectionsStructuralValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }


    @Test
    public void testProposalRowDefinitionSectionsStructural() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRow("definition_definitionstatement_wrong_structral.xml"));
        rows.add(createRow("definition_definitionstatement_good_structural_list.xml"));
        rows.add(createRow("definition_definitionstatement_good_structural_table.xml"));
        rows.add(createRow("definition_definitionstatement_good_structural_paragraph.xml"));

        ProposalValidationContext proposalValidationContext = proposalValidationService
                .createProposalValidationContext(rows);
        proposalRowDefinitionSectionsStructuralValidator.validate(proposalValidationContext, rows);
        
        
        Assert.assertEquals("Definition section does not contain a paragraph, list or table.",
                rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertTrue(CollectionUtils.isEmpty(rows.get(1).getValidationMessages()));
        Assert.assertTrue(CollectionUtils.isEmpty(rows.get(2).getValidationMessages()));
        Assert.assertTrue(CollectionUtils.isEmpty(rows.get(3).getValidationMessages()));

    }

    public RevisionChangeItem createRow(String fileName) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0", "test;hello",
                new String[] { "A01B 5/005", "A01B 5/008" });

        DefSectionItemEditRequest req = new DefSectionItemEditRequest();

        req.setChangeType(SCTComponentChangeType.M);
        req.setSectionType(DefinitionSectionType.DEFINITION_STATEMENT);
        DefinitionStatement def = null;
        InputStream is = null;
        XMLStreamReader xsr = null;
        NamespaceXmlReader xr = null;
        try  {
            is = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/" + fileName);
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
                +IOUtils.toString(is)+"</definition-item>");
            def = defItem.getDefinitionStatement();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        } finally {
            CloseableUtils.closeQuietly(xr);
            CloseableUtils.closeQuietly(xsr);
            IOUtils.closeQuietly(is);
        }

        req.setDefinitionStatement(def);
        assertNotNull(req.getDefinitionStatement());

        item.getDefinitionItems().add(req);
        return item;
    }
    
    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        Class adapterClass = Class.forName(DocumentAdapter.class.getCanonicalName());
        docAdapter = (DocumentAdapter) adapterClass.newInstance();

    }


}
