package gov.uspto.pe2e.cpc.ipc.rest.pm.job;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.amazonaws.util.AwsHostNameUtils;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ClassificationScheme;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ClassificationSchemeStatus;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ClassificationSchemeRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ClassificationSchemeStatusRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationTreeStatus;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.scheduler.PublicationThreadNanny;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@EnableAsync
@EnableScheduling
public class PublicationThreadNannyTest {
    @Resource(name = "runningThreadsByProposalUuid")
    private Map<Long, UUID> runningThreadsByProposalUuid;

    @Inject
    private TaskExecutor taskExecutor;

    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ClassificationSchemeRepository classificationSchemeRepository;

    @Inject
    private ClassificationSchemeStatusRepository classificationSchemeStatusRepository;

    @Inject
    private PublicationThreadNanny publicationThreadNanny;

    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
    }

    @Test
    public void testClassificationSchemeRepository() {
		Instant twoHoursAgo = Instant.now().minus(2, ChronoUnit.HOURS);
		List<ClassificationScheme> classificationSchemeList = classificationSchemeRepository
				.findLongRunningProcessesByStatus(PublicationTreeStatus.INPROGRESS, Date.from(twoHoursAgo));

        Assert.assertNotNull(classificationSchemeList);
        Assert.assertNotEquals(classificationSchemeList.size(), 0);

        ClassificationSchemeStatus classificationSchemeStatus = classificationSchemeList.get(0).getClassificationSchemeStatus();
        Assert.assertNotNull(classificationSchemeStatus);

        Instant now = Instant.now();
        // Verifies there are no results that return less than 2 hours
        Assert.assertFalse(classificationSchemeList.stream().anyMatch(cs ->
                !cs.getLastModTs().toInstant().isBefore(now.minus(2, ChronoUnit.HOURS))
        ));
    }

    @Test
    @Transactional
    public void testUpdateClassificationSchemeStatusByNameAndThreadId(){
        classificationSchemeStatusRepository.updateClassificationSchemeStatusByServerNameAndThreadId("b5487892475111eebe560242ac120002",
                "testingUpdate", 1234L, "justin.smith1@uspto.gov", new Date());

        ClassificationScheme classificationSchemeUpdated = classificationSchemeRepository.findPrivate("b5487892475111eebe560242ac120002");
        Assert.assertNotNull(classificationSchemeUpdated);
        Assert.assertNotNull(classificationSchemeUpdated.getClassificationSchemeStatus());

        ClassificationSchemeStatus classificationSchemeStatus = classificationSchemeUpdated.getClassificationSchemeStatus();
        Assert.assertNotNull(classificationSchemeStatus);
        Assert.assertEquals(classificationSchemeStatus.getServerNameText(), "testingUpdate");
        Assert.assertEquals(classificationSchemeStatus.getThreadIdNumber().longValue(), 1234L);
    }

    @Test
    @Transactional
    public void testThreadNannyCleanupTask() throws NoSuchFieldException, IllegalAccessException, InterruptedException {
        AtomicBoolean interrupted = new AtomicBoolean(false);
        AtomicLong threadId = new AtomicLong();
        taskExecutor.execute((new Thread(() -> {
            try {
                threadId.set(Thread.currentThread().getId());
                runningThreadsByProposalUuid.put(Thread.currentThread().getId(), GUIDUtils.fromDatabaseFormat("b5487892475111eebe560242ac120002"));
                // Only last 500ms to allow for an interrupt, if longer than that then it should fail.
                // Threads will not be interrupted while they are sleeping, so make sure the interval is fast.
                for(int i = 0; i < 50; i++){
                    Thread.sleep(10);
                }
            } catch (InterruptedException e) {
                interrupted.set(true);
            }
        })));

        int updated = classificationSchemeStatusRepository.updateClassificationSchemeStatusByServerNameAndThreadId("b5487892475111eebe560242ac120002",
                AwsHostNameUtils.localHostName(), threadId.longValue(), "justin.smith1@uspto.gov", new Date(0));
        Assert.assertEquals(updated, 1);
        publicationThreadNanny.executeTask();
        // Have to wait for interrupt to execute.
        Thread.sleep(100);
        Assert.assertTrue(interrupted.get());
    }
}
