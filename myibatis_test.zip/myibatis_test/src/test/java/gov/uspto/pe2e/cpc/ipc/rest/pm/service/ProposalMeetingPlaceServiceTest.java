package gov.uspto.pe2e.cpc.ipc.rest.pm.service;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import biweekly.Biweekly;
import biweekly.ICalendar;
import biweekly.component.VEvent;
import biweekly.property.DateStart;
import biweekly.property.Summary;
import biweekly.util.Duration;
import biweekly.util.Frequency;
import biweekly.util.Recurrence;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@Slf4j
public class ProposalMeetingPlaceServiceTest {

    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalMeetingPlaceService proposalMeetingPlaceService;

	@Test
	public void testGetMeetingAsICALDocument() throws IOException {
		String icalDoc = proposalMeetingPlaceService.getMeetingAsICALDocument(
				GUIDUtils.fromDatabaseFormat("b5441ef0cac7455ba651be1fe7c9890e"), 
				new MockHttpServletRequest().getServletContext());
		FileUtils.writeStringToFile(new File("target/icaltest.ics"), icalDoc);
		
		assertIndex(5, icalDoc, "UID:b5441ef0-cac7-455b-a651-be1fe7c9890e");
		assertIndex(6, icalDoc, "SUMMARY;LANGUAGE=en-us:GET/POST Service Requirements JAD");
		
		assertIndex(8, icalDoc, "DURATION:PT1H");
		//assertIndex(9, icalDoc, "RRULE:FREQ=DAILY;COUNT=1");
		assertIndex(9, icalDoc, "DESCRIPTION:Title:      GET/POST Service Requirements JAD\\nAgenda:     PMP ");
		
		
	}
	
	@Test
	public void testICALMeetingWithRecurringSeries() throws IOException {
		  ICalendar ical = new ICalendar();
	        ical.setProductId("CPC/IPC Meeting Place");
	        VEvent event = new VEvent();
	        event.setUid(UUID.randomUUID().toString());
	          Summary summary = event.setSummary("Meeting to discuss Recurring Series datamodel");
	          summary.setLanguage("en-us");

	          DateStart start = new DateStart(new DateTime().plusHours(8).toDate());
	          event.setDateStart(start);
	          

	          Duration duration = new Duration.Builder().hours(1).build();
	          event.setDuration(duration);

	          // TODO: figure out how to make this something sane
	          Recurrence recur = new Recurrence.Builder(Frequency.DAILY).until(new DateTime().plusDays(30).toDate()).build();
	          event.setRecurrenceRule(recur);
//	          
	          
	          event.setDescription(
	        		  "Title:      Test 123\n"
	          		+ "Agenda:     Test Agenda"
	          		);

	        ical.addEvent(event);
	       
//	        		"Meeting info: \n------------------------\n"
//	        		+"Meeting Link: "+latestMeetingResp.get("webLink")+"\n"
//	        		+"Phone Number: "+((List<Map<String, Map<String,Object>>>)((Map<String,Map<String,Object>>)latestMeetingResp.get("telephony")).get("callInNumbers")).get(0).get("callInNumber")+"\n"
//	        		+"Access Code: "+((Map<String,Map<String,Object>>)latestMeetingResp.get("telephony")).get("accessCode")+"\n"
//	        		+"Meeting Password: "+this.webexMeeting.getPassword());

	      String icsString = Biweekly.write(ical).go();
	      log.debug("ICS String= {}", icsString);
		  FileUtils.writeStringToFile(new File("target/icaltest_recurring.ics"), icsString);

	      
		
	}
	
	  
    private void assertIndex(int expectedIndex, String lines, String searchString) {
    	List<String> linesList = Arrays.asList(lines.split("\\r?\\n"));
    	int j = 0;
    	for (String line: linesList) {
    		log.debug("{} - {}", j++, line );
    	}
    	assertTrue(searchString+" could not be found in "+linesList, linesList.contains(searchString));
    	int index = linesList.indexOf(searchString);
    	log.debug("found {} at {}", searchString, index);
		assertEquals(expectedIndex, index);
	}


	@Before
    public void setUp() throws Exception {
		System.setProperty("illegal-access", "debug");
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.loadOnce();

//        SchemePublicationVersion version = new SchemePublicationVersion();
//        version.setClassificationSchemeId(1L);
//        version.setCpcXsdVersion("1.6");
//        version.setDefinitionXsdVersion("0.9");
//        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
//        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
//        SchemePublicationVersionContextHolder.setContext(version);
//        

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("matt.young@uspto.gov", "matt.young@uspto.gov",
                Arrays.asList(new BasicTestingGrantedAuthority("test")));

        SecurityContextHolder.getContext().setAuthentication(token);


    }

}
