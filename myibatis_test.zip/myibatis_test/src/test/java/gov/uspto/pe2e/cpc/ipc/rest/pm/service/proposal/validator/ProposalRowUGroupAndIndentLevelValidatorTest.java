package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowUGroupAndIndentLevelValidatorTest {
	
	private static final Logger log = LoggerFactory.getLogger(ProposalRowUGroupAndIndentLevelValidatorTest.class);
	
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ProposalRowUGroupAndIndentLevelValidator proposalRowUGroupAndIndentLevelValidator;
    
    @Inject
    private ProposalValidationService proposalValidationService;
    
    @Resource
    private List<ProposalValidator> proposalValidators;  

    private static final String message = "Indent does not match indent from gold copy. U groups cannot have an indent change.";
    
    private static final String ENTRY_TYPE_F_MSG = "Indent does not match indent from gold copy. F groups cannot have an indent change.";
    
    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.HIGH, proposalRowUGroupAndIndentLevelValidator.getCost());

    }
    
    @Test
    public void testGetValidationType() {
        Assert.assertEquals(ValidationMessageType.RECORD, proposalRowUGroupAndIndentLevelValidator.getValidationType());

    }

    @Before
    public void setUp() throws Exception {
        
        datasetTestingService.loadOnce();
        
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
    }
    
    @Test
    @Transactional //A01N27/90
    public void testValidateTypeUSymbolNotExitInGold() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "B01B63/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
/*        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        Assert.assertEquals(ValidationMessageField.DOT_LEVEL, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
        Assert.assertEquals(message,msg.getMessageText());
*/    }
    
    @Test
    @Transactional //A01N27/90
    public void testValidateTypeUSymbolExitInGoldDoleLevelDontMatch() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/00", "10", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        Assert.assertEquals(ValidationMessageField.DOT_LEVEL, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
        Assert.assertEquals(message,msg.getMessageText());
    }
    
    @Test
    @Transactional //A01N27/90
    public void testValidateTypeFSymbolExitInGoldDoleLevelDontMatch() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("F", "A01B1/00", "10", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        Assert.assertEquals(ValidationMessageField.DOT_LEVEL, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
        Assert.assertEquals(ENTRY_TYPE_F_MSG,msg.getMessageText());
    }
    
    @Test
    @Transactional //A01N27/90
    public void testValidateTypeFSymbolExitInGoldDoleLevelMatch() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("F", "A01B1/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);      
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    @Transactional //
    public void testValidateTypeUSymbolExitInGold() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/99"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    @Transactional //
    public void testValidateTypeUSymbolEmpty() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", null, "0", "Bold Error ##BOLD##", new String[] {"A01B1/99"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    @Transactional //
    public void testValidateTypeUSymbolEmpty1() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", " ", "0", "Bold Error ##BOLD##", new String[] {"A01B1/99"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    @Transactional //
    public void testValidateTypeUSymbolEmpty2() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "", "0", "Bold Error ##BOLD##", new String[] {"A01B1/99"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    @Transactional //
    public void testValidateTypeUEmpty() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem(null, "A01b1/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/99"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    @Transactional //
    public void testValidateTypeUEmpty3() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("", "A01b1/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/99"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    @Test
    @Transactional //
    public void testValidateTypeUEmpty2() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem(" ", "A01b1/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/99"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    @Test
    @Transactional //
    public void testValidateTypeUEmpty1() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("E", "A01b1/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/99"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowUGroupAndIndentLevelValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
}
