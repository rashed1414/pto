package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.TitleConverter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator.BaseTitleValidator.TitleClassificationUtils;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator.TitleSymbolRefOrderWithinReferencesValidator.RefpartClassification;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class TitleSymbolRefOrderWithinReferemcesValidatorTest {
	
	private static final Logger log = LoggerFactory.getLogger(TitleSymbolRefOrderWithinRefPartValidatorTest.class);

	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private TitleSymbolRefOrderWithinReferencesValidator titleSymbolRefOrderWithinReferencesValidator;

	@Inject
	private ProposalValidationService proposalValidationService;

	@Inject
	private TitleService titleService;

	@Resource(name = "proposalConsistencyValidator")
	private List<ProposalValidator> proposalValidators;
	
	@Test
	public void testVerifyConfig() {
		  boolean isIncluded = false;
	        for (ProposalValidator validator: proposalValidators) {
	            if (validator.getClass().getCanonicalName().equals(titleSymbolRefOrderWithinReferencesValidator.getClass().getCanonicalName())) {
	                isIncluded = true;
	                break;
	            }
	        }
	        Assert.assertTrue(isIncluded);
	}
	
	@Test
	public void testValidate() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N27/99", "0", 
				 " test (test 123 ##SYMBOL##B01N##/SYMBOL##; test ##SYMBOL##A01N##/SYMBOL## test ##SYMBOL##A##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

//	        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "##SYMBOL##A01N01T/3002##/SYMBOL## This symbol should exist ##SYMBOL##A01N##/SYMBOL##", null));
//	        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "Test ##SYMBOL##D01N01/2001##/SYMBOL##", null));
//	        

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleSymbolRefOrderWithinReferencesValidator.validate(proposalValidationContext, rows);
	        assertEquals(1, rows.get(0).getValidationMessages().size());
	        assertEquals("References in title must be presented in sort key order corresponding to policy", 
	        		rows.get(0).getValidationMessages().get(0).getMessageText());
	        
	        assertEquals(ValidationMessageField.TITLE, 
	        		rows.get(0).getValidationMessages().get(0).getTriggerField());
	        
	        assertEquals(ValidationMessageLevel.WARNING, 
	        		rows.get(0).getValidationMessages().get(0).getLevel());
	        
	        assertEquals(ValidationPhase.CONSISTENCY, 
	        		rows.get(0).getValidationMessages().get(0).getPhase());
	        assertEquals(ValidationMessageType.RECORD, 
	        		rows.get(0).getValidationMessages().get(0).getMessageType());
	        
	}

	@Test
	public void testValidateNoError() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N27/99", "0", 
				 " test (test 123 ##SYMBOL##B01N##/SYMBOL##; test ##SYMBOL##C01N##/SYMBOL## test ##SYMBOL##C02N##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleSymbolRefOrderWithinReferencesValidator.validate(proposalValidationContext, rows);
	        assertEquals(0, rows.get(0).getValidationMessages().size());
	}
	@Test
	public void testValidateOuterBuckets() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N27/99", "0", 
				 " test (test 123 ##SYMBOL##B01N##/SYMBOL##; test takes precedence ##SYMBOL##C01N##/SYMBOL## test ##SYMBOL##C02N##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleSymbolRefOrderWithinReferencesValidator.validate(proposalValidationContext, rows);
	        assertEquals(1, rows.get(0).getValidationMessages().size());
	}

	@Test
	public void testValidateSecondaryBuckets() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N27/99", "0", 
				 " test (takes precedence ##SYMBOL##D01N1/00##/SYMBOL##; this is not part of the same subclass ##SYMBOL##A01B1/21##/SYMBOL##; test ##SYMBOL##A01N1/21##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleSymbolRefOrderWithinReferencesValidator.validate(proposalValidationContext, rows);
	        assertEquals(1, rows.get(0).getValidationMessages().size());
	}

	@Test
	public void testValidateSecondaryBucketsNoError() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N27/99", "0", 
				 " test (takes precedence ##SYMBOL##D01N1/00##/SYMBOL##; this is not part of the same subclass ##SYMBOL##A01N1/21##/SYMBOL##; test ##SYMBOL##A01B1/21##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleSymbolRefOrderWithinReferencesValidator.validate(proposalValidationContext, rows);
	        assertEquals(0, rows.get(0).getValidationMessages().size());
	}

	
	@Test
	public void testValidateNoRowsNoError() {
		 List<RevisionChangeItem> rows = new ArrayList<>();

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleSymbolRefOrderWithinReferencesValidator.validate(proposalValidationContext, rows);
	        assertEquals(0, rows.size());
	}

	@Test
	public void testValidate2000SeriesNoError() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N27/99", "0", 
				 " test (test 123 ##SYMBOL##B01N##/SYMBOL##; test ##SYMBOL##C01N2005/00##/SYMBOL## test ##SYMBOL##C01N4/00##/SYMBOL##; test ##SYMBOL##C01N7/00##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

//	        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "##SYMBOL##A01N01T/3002##/SYMBOL## This symbol should exist ##SYMBOL##A01N##/SYMBOL##", null));
//	        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "Test ##SYMBOL##D01N01/2001##/SYMBOL##", null));
//	        

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleSymbolRefOrderWithinReferencesValidator.validate(proposalValidationContext, rows);
	        assertEquals(0, rows.get(0).getValidationMessages().size());
	        
	}

	
	@Test
	public void testGetCost() {
		assertEquals(ValidationCost.MEDIUM, titleSymbolRefOrderWithinReferencesValidator.getCost());
	}
	
	@Test
	public void testValidateSecondaryBucketsNoErrorWithSpaces() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N 27/99", "0", 
				 " test (takes precedence ##SYMBOL##D01N 1/00##/SYMBOL##; this is not part of the same subclass ##SYMBOL##A01N 1/21##/SYMBOL##; test ##SYMBOL##A01B1/21##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleSymbolRefOrderWithinReferencesValidator.validate(proposalValidationContext, rows);
	        assertEquals(0, rows.get(0).getValidationMessages().size());
	}

	
	@Test
	public void testWithSpacesInSymbolName() {
		String title = "this should faile for consituent order (test ##SYMBOL##A01N1/00##/SYMBOL##; test ##SYMBOL##H04N 1/20##/SYMBOL##)";
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "H04N 1/00", "0", 
				 title, null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleSymbolRefOrderWithinReferencesValidator.validate(proposalValidationContext, rows);
	        assertEquals(1, rows.get(0).getValidationMessages().size());
	        assertEquals("References in title must be presented in sort key order corresponding to policy", rows.get(0).getValidationMessages().get(0).getMessageText());
	
	}
	
	@Test
	public void testSort() throws GrammarParseException {
		String title = "this should faile for consituent order (test ##SYMBOL##A01N1/00##/SYMBOL##; test ##SYMBOL##H04N 1/20##/SYMBOL##)";
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "H04N 1/00", "0", 
				 title, null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        TitlePartTree tree = titleSymbolRefOrderWithinReferencesValidator.getTitle(item);
	        log.debug("{}", JaxbUtils.marshalToString(tree));
	        String fullReference = TitleClassificationUtils.classifyNodeContent(tree.getChildren().get(0).getChildren().get(1));
	        log.debug("Full ref=[{}]",fullReference);
	        String xml = TitleConverter.toXmlString(fullReference);
	        log.debug("Xml={}", xml);
	        RefpartClassification sortMe = titleSymbolRefOrderWithinReferencesValidator.classifyRefPartForSort(xml, item.getSymbolName());
	      
	        assertNotNull(sortMe);
	}

	
//   /**
//    * recursively walks the title tree searching for reference objects. It validates each one in series
//    * @param context
//    * @param node
//    * @param msgs
//    */
//   @SuppressWarnings("unchecked")
//   private void searchForReferenceText(ProposalValidationContext context, Object node, 
//   		List<ValidationMessage> msgs, String rowSymbol) {
//       if (node.getClass().getName().equalsIgnoreCase(TitlePartReference.class.getName())) {
//       	String xml = null; // defined here instead inside for-loop so it can be logged in catch
//       	String fullReference = TitleClassificationUtils.classifyNodeContent(node);
//           log.debug("Checking text [{}]",fullReference);
//           String [] refPartTexts = StringUtils.split(fullReference,";");
//           List<RefpartClassification> refParts = new ArrayList<>();
//           for (String refPart: refPartTexts) {
//           	try {
//           		
//           		xml = TitleConverter.toXmlString(refPart);
//           		RefpartClassification rpClassification = classifyRefPartForSort(xml, rowSymbol);
//           		refParts.add(rpClassification);
//           		
//           		
//              	} catch (Exception e) {
//           		log.warn("failed to execute xpath expression {} on {} because {}",
//           				NODE_XPATH, xml, e.getMessage());
//           	}
//           }
//           if (!refParts.stream()
//   				.sorted(new ComparatorChain(
//   						Arrays.asList(new BeanComparator<>("precedenceClassification"), 
//   						new ReverseComparator<>( new BeanComparator<>("subclassMatches")),
//   						new ModelSymbolNameComparator<>("sortKey"))))
//   				.collect(Collectors.toList())
//   				.equals(refParts)) {
//   			msgs.add(createValidationMessage(ValidationMessageLevel.WARNING, 
//   					ValidationMessageType.RECORD, ValidationPhase.CONSISTENCY,
//   					I18nMessageKey.PROPOSAL_TITLE_REFPART_NOT_IN_PRECEDENCE_SYMBOL_BUCKET_ORDER.name(),
//   	                ValidationMessageField.TITLE, I18nMessageKey.PROPOSAL_TITLE_REFPART_NOT_IN_PRECEDENCE_SYMBOL_BUCKET_ORDER.name(), new Object[] {}));
//   		}
//
//       } 
//       else {
//           try {
//               List<Object> children = (List<Object>) PropertyUtils.getProperty(node,
//                       AdapterUtils.TREE_CHILD_COLLECTION_PROPERTY_NAME);
//               for (Object newNode : children) {
//                   searchForReferenceText(context, newNode, msgs, rowSymbol);
//               }
//           } catch (Exception e) {
//               log.error("Error navigating title tree", e);
//           }
//       }
//
//   }
	@Before
	public void setUp() throws Exception {

		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		DateTimeZone.setDefault(DateTimeZone.UTC);
		datasetTestingService.loadOnce();

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(2L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		
	}

}
