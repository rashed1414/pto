package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.LocalDateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalTWL;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalTWLRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.AllocationAgreementCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.NonRequestingOfficeAllocationAgreementCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalTwlStatistics;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RequestingOfficeTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.TWLDetail;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.TWLDocument;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.TWLDocumentStatus;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalTWLControllerVolatileTest  {
    private static final Logger log = LoggerFactory.getLogger(ProposalTWLControllerVolatileTest.class);
    
    @Inject
    private ProposalTWLController proposalTWLController;
    
    @Inject
    private ChangeProposalTWLRepository changeProposalTWLRepository;
    
    @Inject
    private DatasetTestingService datasetTestingService;  
   
    
    /**
     * happy path success test
     */
    @Transactional
    @Test
    public void testSaveAsUpdate_success() {        
            
        
        Date now = new Date();
        TWLDocument twl = new TWLDocument();
        twl.setId(GUIDUtils.fromDatabaseFormat("eb04002f08694152b6f2083b4df825c2"));
        twl.setComment("test 123");
        twl.setCreateTs(now);
        twl.setCreateUserId("myoung@uspto.gov");
        twl.setUpdateTs(now);
        twl.setUpdateUserId("myoung@uspto.gov");
        twl.setPatentDocumentId("10001");
        twl.setProposalId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));
        twl.setPublishedKindCode("A");
        twl.setStandardIpOffice(StandardIpOfficeCode.US);
        TWLDetail detail1 = createTWLDetail(null,
                twl.getId(),
                AllocationAgreementCategory.AGREE, 
                "Final comment 1", "AA", 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 1",
                "Notes 1", RequestingOfficeTypeCode.A,
                 "Requesting office comment 1",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId());
        twl.getDetails().add(detail1);
        TWLDetail detail2 = createTWLDetail(null,
                twl.getId(),
                AllocationAgreementCategory.AGREE, 
                "Final comment 2", "AA", 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 2",
                "Notes 2", RequestingOfficeTypeCode.A,
                 "Requesting office comment 2",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId());
        assertFalse(detail1.equals(detail2));
        
        twl.getDetails().add(detail2);

        
            ResponseEntity<Void> resp = proposalTWLController.save(twl.getProposalId(), Arrays.asList(twl));
            assertNotEquals(GUIDUtils.fromDatabaseFormat("eb04002f08694152b6f2083b4df825c2").toString(),
                    resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
            assertEquals(1,  resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).size());
            String dbguid = StringUtils.remove(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0), "-");
            log.info("looking up by external id = {}", dbguid);
            ChangeProposalTWL dbTwl = changeProposalTWLRepository.findByExternalId(dbguid);
            assertNotNull(dbTwl);
            assertEquals(TWLDocumentStatus.PENDING, dbTwl.getStatus());
    }

    
    /**
     * happy path success test
     */
    @Transactional
    @Test
    public void testSaveNew() {        
        
    	UUID proposalId = UUID.fromString("df82473c-f682-452e-82d7-9048609a548d");
    	
    	try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("data/json/twl/twl_savefirst.json")) {
        
        Date now = new Date();
        TWLDocument twl = JsonUtils.fromJson(is, TWLDocument.class);
        		
        
        
            ResponseEntity<Void> resp = proposalTWLController.save(twl.getProposalId(), Arrays.asList(twl));
            assertNotEquals(GUIDUtils.fromDatabaseFormat("eb04002f08694152b6f2083b4df825c2").toString(),
                    resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
            assertEquals(1,  resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).size());
            String dbguid = StringUtils.remove(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0), "-");
            log.info("looking up by external id = {}", dbguid);
            ChangeProposalTWL dbTwl = changeProposalTWLRepository.findByExternalId(dbguid);
            assertNotNull(dbTwl);
            assertEquals(TWLDocumentStatus.PENDING, dbTwl.getStatus());
            assertEquals(3, dbTwl.getDetails().size());
    	} catch (Exception e) {
    		log.error("Exception ", e);
    	}
    	
    	
    }

    
    /**
     * happy path success with null NEXTACTION
     */
    @Transactional
    @Test
    public void testSaveAsUpdate_success_withnullnextaction() {        
            
        
        Date now = new Date();
        TWLDocument twl = new TWLDocument();
        twl.setId(GUIDUtils.fromDatabaseFormat("eb04002f08694152b6f2083b4df825c2"));
        twl.setComment("test 123");
        twl.setCreateTs(now);
        twl.setCreateUserId("myoung@uspto.gov");
        twl.setUpdateTs(now);
        twl.setUpdateUserId("myoung@uspto.gov");
        twl.setPatentDocumentId("10001");
        twl.setProposalId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));
        twl.setPublishedKindCode("A");
        twl.setStandardIpOffice(StandardIpOfficeCode.US);

        twl.setStatus(TWLDocumentStatus.COMPLETED);
        TWLDetail detail1 = createTWLDetail(null,
                twl.getId(),
                AllocationAgreementCategory.AGREE, 
                "Final comment 1", null, 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 1",
                "Notes 1", RequestingOfficeTypeCode.A,
                 "Requesting office comment 1",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId());
        twl.getDetails().add(detail1);
        
        ResponseEntity<Void> resp = proposalTWLController.save(twl.getProposalId(), Arrays.asList(twl));
        assertNotEquals(GUIDUtils.fromDatabaseFormat("eb04002f08694152b6f2083b4df825c2").toString(),
                    resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
        assertEquals(1,  resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).size());
        String dbguid = StringUtils.remove(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0), "-");
        ChangeProposalTWL dbTwl = changeProposalTWLRepository.findByExternalId(dbguid);
        assertEquals(TWLDocumentStatus.COMPLETED, dbTwl.getStatus());
            
    }
    

    /**
     * Failed to find parent record 
     */
    @Test
    public void testSaveAsUpdate_DUP_withinpayload() {        
            
        

        Date now = new Date();
        TWLDocument twl = new TWLDocument();
        twl.setId(GUIDUtils.fromDatabaseFormat("eb04002f08694152b6f2083b4df825c2"));
        twl.setComment("test 123");
        twl.setCreateTs(now);
        twl.setCreateUserId("myoung@uspto.gov");
        twl.setUpdateTs(now);
        twl.setUpdateUserId("myoung@uspto.gov");
        twl.setPatentDocumentId("10001");
        twl.setProposalId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));
        twl.setPublishedKindCode("A");
        twl.setStandardIpOffice(StandardIpOfficeCode.US);
        TWLDetail detail1 = createTWLDetail(null,
                twl.getId(),
                AllocationAgreementCategory.AGREE, 
                "Final comment 1", "AA", 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 1",
                "Notes 1", RequestingOfficeTypeCode.A,
                 "Requesting office comment 1",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId());
        twl.getDetails().add(detail1); // making dups
        

        try {
            proposalTWLController.save(twl.getProposalId(), Arrays.asList(twl, twl));
            fail();
        } catch (Exception e) {
        	e.printStackTrace();
            assertEquals("IllegalArgumentException", e.getClass().getSimpleName());
            assertEquals("Patent Document [US10001] is a duplicate value",e.getMessage());
        }
    }


      
    
    /**
     * Failed to find parent record 
     */
    @Test
    public void testSaveAsUpdate_NEXTACTION_notfound() {        
            
        
        Date now = new Date();
        TWLDocument twl = new TWLDocument();
        twl.setId(GUIDUtils.fromDatabaseFormat("eb04002f08694152b6f2083b4df825c2"));
        twl.setComment("test 123");
        twl.setCreateTs(now);
        twl.setCreateUserId("myoung@uspto.gov");
        twl.setUpdateTs(now);
        twl.setUpdateUserId("myoung@uspto.gov");
        twl.setPatentDocumentId("10001");
        twl.setProposalId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));
        twl.setPublishedKindCode("A");
        twl.setStandardIpOffice(StandardIpOfficeCode.US);
        TWLDetail detail1 = createTWLDetail(null,
                twl.getId(),
                AllocationAgreementCategory.AGREE, 
                "Final comment 1", "INVALIDACTION", 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 1",
                "Notes 1", RequestingOfficeTypeCode.A,
                 "Requesting office comment 1",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId());
        twl.getDetails().add(detail1);

        try {
            proposalTWLController.save(twl.getProposalId(), Arrays.asList(twl));
            fail();
        } catch (Exception e) {
        	e.printStackTrace();
            assertEquals("EntityNotFoundException", e.getClass().getSimpleName());
            assertEquals("TWL Next Action INVALIDACTION does not exist",e.getMessage());
        }
    }
    
    /**
     * Failed to find parent reccord 
     */
    @Test
    @Transactional
    public void testMissingParentTWL() {    	
			
        
        Date now = new Date();
        TWLDocument twl = new TWLDocument();
        twl.setId(GUIDUtils.fromDatabaseFormat("eb04002f08694152b6f2083b4df825c2"));
        twl.setComment("test 123");
        twl.setCreateTs(now);
        twl.setCreateUserId("myoung@uspto.gov");
        twl.setUpdateTs(now);
        twl.setUpdateUserId("myoung@uspto.gov");
        twl.setPatentDocumentId("10001");
        twl.setProposalId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844dbb"));
        twl.setPublishedKindCode("A");
        twl.setStandardIpOffice(StandardIpOfficeCode.US);
        TWLDetail detail1 = createTWLDetail(null,
                twl.getId(),
                AllocationAgreementCategory.AGREE, 
                "Final comment 1", "AA", 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 1",
                "Notes 1", RequestingOfficeTypeCode.A,
                 "Requesting office comment 1",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId());
        twl.getDetails().add(detail1);
        TWLDetail detail2 = createTWLDetail(null,
                twl.getId(),
                AllocationAgreementCategory.AGREE, 
                "Final comment 2", "AA", 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 2",
                "Notes 2", RequestingOfficeTypeCode.A,
                 "Requesting office comment 2",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId());
        assertFalse(detail1.equals(detail2));
        
        twl.getDetails().add(detail2);

        try {
            ResponseEntity<Void> resp = proposalTWLController.save(twl.getProposalId(), Arrays.asList(twl));
            fail();
        } catch (Exception e) {
            assertEquals("EntityNotFoundException",e.getClass().getSimpleName());
            assertEquals("Proposal "+GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844dbb")+" does not exist", e.getMessage());
        }
               
    }
    
    @Test
    @Transactional
    public void testGetTwl() {
        String cpExternalId = "51614cc00eb74436a33dca859119eeb7";
        ResponseEntity<List<TWLDocument>> entityResponse = proposalTWLController.getAllTwl(GUIDUtils.fromDatabaseFormat(
                cpExternalId));
        List<TWLDocument> twlResponses = entityResponse.getBody();
        Assert.assertNotNull(twlResponses);
        assertEquals(2, twlResponses.size());
        Assert.assertNotNull(twlResponses.get(0).getDetails());
        assertEquals(1, twlResponses.get(0).getDetails().size());
    }
    
    @Test
    public void testDelete() {
    	String cpID = "c960d30a52a847fc8c51b64dfcc0ea85";
        String twlID = "eb04002f08694152b6f2083b4df825c2";
        ResponseEntity<Void> entityResponse = proposalTWLController.delete(GUIDUtils.fromDatabaseFormat(cpID), 
        		GUIDUtils.fromDatabaseFormat(twlID));
        Assert.assertNotNull(entityResponse);
        assertEquals(1, entityResponse.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).size());

        assertEquals(GUIDUtils.fromDatabaseFormat(twlID).toString(), 
        		entityResponse.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
        
        ChangeProposalTWL twl = changeProposalTWLRepository.findByExternalId(twlID);
        assertNull(twl);
       
    }
   
//    
//    @Test
//    public void testListDocumentsPagingCase1() {       
//            
//        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
//                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
//                null, 
//                null, false);
//        assertNotNull(resp);
//        assertEquals(HttpStatus.OK, resp.getStatusCode());
//               
//    }
//    
//    @Test
//    public void testListDocumentsPagingCase2() {       
//            
//        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
//                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
//                ProposalDocumentTypeCode.TWL, 
//                ProposalDocumentVersionClassificationCode.Initial, false);
//        assertNotNull(resp);
//        assertEquals(HttpStatus.OK, resp.getStatusCode());
//        assertTrue(resp.getBody().getList().size() >=2);
//               
//    }
//    
//    
//    @Test
//    public void testGetDocumentApprovals() {       
//            
//        ResponseEntity<List<ProposalDocumentApproval>> resp = proposalDocumentController.listDocumentApprovalsById(
//                GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), 
//                GUIDUtils.fromDatabaseFormat("c960d30a52a852fc8c51b64dfcc0ea85"));
//        assertNotNull(resp);
//        assertEquals(HttpStatus.OK, resp.getStatusCode());
//        assertTrue(resp.getBody().size()>= 2);          
//    }
//    
//    @Test
//    public void testGetDocumentApprovals_mismatchedProposalAndDoc() {       
//            
//        try {
//        ResponseEntity<List<ProposalDocumentApproval>> resp = proposalDocumentController.listDocumentApprovalsById(
//                GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), 
//                GUIDUtils.fromDatabaseFormat("c960d30a52a852fc8c51b64dfcc0ea85"));
//            fail(); // if you get this far, the mismatched pro/doc relationship is not being detected
//        } catch (Exception e) {
//            assertEquals(IllegalArgumentException.class, e.getClass());
//            assertEquals("Document c960d30a-52a8-52fc-8c51-b64dfcc0ea85 does not belong to proposal d153f9bf-8048-48aa-8ba2-02db9f844db5", e.getMessage());
//        }
//    }
//    
//    @Test
//    public void testGetDocumentApprovals_entitynotfound() {       
//            
//        try {
//        ResponseEntity<List<ProposalDocumentApproval>> resp = proposalDocumentController.listDocumentApprovalsById(
//                GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), 
//                UUID.fromString("7af7219c-b604-4359-a2fc-5996484f4672")); // this doc does not exist
//            fail(); // if you get this far, the mismatched pro/doc relationship is not being detected
//        } catch (Exception e) {
//            assertEquals(EntityNotFoundException.class, e.getClass());
//            assertEquals("Document 7af7219c-b604-4359-a2fc-5996484f4672 does not exist", e.getMessage());
//        }
//    }
//    
//    
//    @Test
//    public void testListDocumentsPagingCase3() {       
//            
//        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
//                0,25,GUIDUtils.fromDatabaseFormat("5578f1c578d64e2887af1a27bb789ff2"),
//                ProposalDocumentTypeCode.TWL, 
//                ProposalDocumentVersionClassificationCode.Initial, true);
//        assertNotNull(resp);
//        assertEquals(HttpStatus.NO_CONTENT, resp.getStatusCode());
//               
//    }
    
    @Transactional
    @Test
    public void testAdd() {        
            
        
        Date now = new Date();
        TWLDocument twl = new TWLDocument();
        twl.setId(GUIDUtils.fromDatabaseFormat("eb04002f08694152b6f2083b4df825c2"));
        twl.setComment("test 123");
        twl.setCreateTs(now);
        twl.setCreateUserId("bkuppusamy@uspto.gov");
        twl.setUpdateTs(now);
        twl.setUpdateUserId("bkuppusamy@uspto.gov");
        twl.setPatentDocumentId("10001");
        twl.setProposalId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));
        twl.setPublishedKindCode("A");
        twl.setStandardIpOffice(StandardIpOfficeCode.US);
        ResponseEntity<Void> resp = proposalTWLController.add(twl.getProposalId(), twl);        
        assertNotEquals(GUIDUtils.fromDatabaseFormat("eb04002f08694152b6f2083b4df825c2").toString(),
                resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
        assertEquals(1,
                resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).size());

        
    }
    @Transactional
    @Test
    public void testExportTWLData() throws IOException {  
    	
    	UUID proposalID=GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7");
    	UUID proposalRevisionUUID=GUIDUtils.fromDatabaseFormat("0a940f78a42a41cbae5f9dd37450034b");
    	
    	HttpServletResponse resp = WebMocker.mockHttpResponse();
    	proposalTWLController.exportTWLData(proposalID, proposalRevisionUUID, true, resp);
    	
    	assertEquals("application/vnd.ms-excel", resp.getContentType());
    	assertTrue(resp.getHeader("Content-Disposition").contains("attachment; filename=TWL_DP0027_"+new LocalDateTime().toString("MMddyy")+".xlsx"));
    }
    
    @Transactional
    @Test
    public void testGlobalTWLStatus() throws IOException {  
    	
    	String cpExternalId = "51614cc00eb74436a33dca859119eeb7";
        ResponseEntity<String> entityResponse = proposalTWLController.getTWLGlobalStatus(GUIDUtils.fromDatabaseFormat(
                cpExternalId));      
        Assert.assertNotNull(entityResponse.getBody());
        assertEquals("Pending", entityResponse.getBody());
    	
    }
    
    private TWLDetail createTWLDetail(UUID id, UUID parentTWLId,  
            AllocationAgreementCategory allocAggrCat, 
            String finalComment,
            String nextActionName, 
            NonRequestingOfficeAllocationAgreementCategory nonRequestingOfficeAllocAgreement, 
            String nonRequestingOfficeComment,
            String notes,
            RequestingOfficeTypeCode requestingIpOffceCode,
            String reqestingOfficeComment,
            String sourceSymbol,
            String targetSymbol,
            Date now, 
            String userId) {
        TWLDetail dtl = new TWLDetail();
        dtl.setCreateTs(now);
        dtl.setCreateUserId(userId);
        dtl.setFinalAllocationAgreement(allocAggrCat);
        dtl.setFinalComment(finalComment);
        dtl.setId(id); 
        dtl.setNextActionName(nextActionName);
        dtl.setNonRequestingOfficeComment(nonRequestingOfficeComment);
        dtl.setNonRequestingOfficeAllocationAgreement(nonRequestingOfficeAllocAgreement);
        dtl.setNotes(notes);
        dtl.setParentId(parentTWLId);
        dtl.setRequestingIpOfficeCode(requestingIpOffceCode);
        dtl.setRequestingIpOfficeComment(reqestingOfficeComment);
        dtl.setSourceSymbolName(sourceSymbol);
        dtl.setTargetSymbolName(targetSymbol);
        dtl.setUpdateTs(now);
        dtl.setUpdateUserId(userId);
        return dtl;
    } 
    
    @Transactional
    @Test
    public void testTWLStatistics() throws IOException {  
    	
    	String cpExternalId = "51614cc00eb74436a33dca859119eeb7";
        ResponseEntity<ProposalTwlStatistics> entityResponse = proposalTWLController.getTWLStatistics(GUIDUtils.fromDatabaseFormat(cpExternalId));      
        Assert.assertNotNull(entityResponse.getBody());
    	
    }
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
    			"bkuppusamy", "Boops","Kuppusamy", "US");
    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"boopathi.kuppusamy@uspto.gov", token,
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/proposals/1/twl")));
    }

    
    
}