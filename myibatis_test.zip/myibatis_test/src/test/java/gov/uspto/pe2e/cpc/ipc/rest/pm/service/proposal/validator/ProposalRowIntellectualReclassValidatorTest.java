package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowIntellectualReclassValidatorTest {
	
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ProposalRowIntellectualReclassValidator proposalRowIntellectualReclassValidator;
    
    @Inject
    private ProposalValidationService proposalValidationService;
    
    @Resource
    private List<ProposalValidator> proposalValidators;
    
    @Test
    public void testConfigCorrectlyIncludesReclassTransferDuplicateValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator: proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(proposalRowIntellectualReclassValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }
    
    @Test
    public void testValidate1() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItemWithIntelluctualReclassCategory("C", "A01N", "0", "Bold Error ##BOLD##", new String[] {"A01N1/00"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowIntellectualReclassValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        for (RevisionChangeItem row : rows) {
            Assert.assertEquals(1, row.getValidationMessages().size());
            for (ValidationMessage msg : row.getValidationMessages()) {
                Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, msg.getTriggerField());                
                Assert.assertEquals(ValidationMessageLevel.CRITICAL, msg.getLevel());
                Assert.assertEquals(ValidationMessageType.RECORD, msg.getMessageType());
                Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
                Assert.assertEquals("Intellectual reclassification requires more than one destination symbol", msg.getMessageText());
            }
        }
    }
    
    
    @Test
    public void testValidate4() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItemWithIntelluctualReclassCategory("C", "A01N", "0", "Bold Error ##BOLD##", null));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowIntellectualReclassValidator.validate(proposalValidationContext, rows);        
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    public void testValidate2() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("C", "A01N", "0", "Bold Error ##BOLD##", new String[] {"A01N1/00"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowIntellectualReclassValidator.validate(proposalValidationContext, rows);        
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    public void testValidate3() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItemWithIntelluctualReclassCategory("C", "A01N", "0", "Bold Error ##BOLD##", new String[] {"A01N1/00","A01N2/00"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowIntellectualReclassValidator.validate(proposalValidationContext, rows);        
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.MEDIUM, proposalRowIntellectualReclassValidator.getCost());

    }

    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }

}
