package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowNorQTypeAndSortKeyValidatorTest {
	
	private static final Logger log = LoggerFactory.getLogger(ProposalRowNorQTypeAndSortKeyValidatorTest.class);
	
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ProposalRowNorQTypeAndSortKeyValidator proposalRowNorQTypeAndSortKeyValidator;
    
    @Inject
    private ProposalValidationService proposalValidationService;
    
    @Resource
    private List<ProposalValidator> proposalValidators;    
    
    private static final String message = "Hierarchy problem: Cannot insert this main group because proper parent subclass cannot be found (Hint: double check symbols).";
    
    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.HIGH, proposalRowNorQTypeAndSortKeyValidator.getCost());

    }
    
    @Test
    public void testGetValidationType() {
        Assert.assertEquals(ValidationMessageType.GLOBAL, proposalRowNorQTypeAndSortKeyValidator.getValidationType());

    }

    @Before
    public void setUp() throws Exception {
        datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }
    
    /**
     * Determine the query symbol - which is, if AE have 2000 series, query symbol would be sort key.
     * And, if it is non-2000, get 2000 series symbol.
     * @param symbolName
     * @return query symbol
     */
    private String determineQuerySymbol(String symbolName) {
    	SymbolName cpcSymbolName = new SymbolName(symbolName);
    	String querySymbol = new String();
    	
    	
    	if(cpcSymbolName.isThis2000SeriesSymbol()){
    		// Minus 2000, to get query symbol which is nothing but sort key
    		querySymbol = cpcSymbolName.getSortKey();
    	}else{
    		// Add 2000, to get 2000 series symbol
    		
            String[] parts = symbolName.split("/");
            String symbolWithMainGroup = parts[0];
            String subGroup = parts[1];
            String mainGroup = symbolWithMainGroup.substring(4);
            int twoThousandNumber = Integer.parseInt(mainGroup) + 2000;
            // full symbol = Concatenate Subclass + sort key + forward slash
            // + sub group
            querySymbol = symbolWithMainGroup.substring(0, 4).concat(Integer.toString(twoThousandNumber))
                    .concat("/").concat(subGroup);
                    
    	}

    	return querySymbol;
	}
    
    @Test
    @Transactional
    public void testValidateTypeNorQSymbolExitInGoldCopy() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01D46/262", "0", "Bold Error ##BOLD##", new String[] {"A01N27/90"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A05B", "0", "Bold Error ##BOLD##", new String[] {"A01N27/90"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNorQTypeAndSortKeyValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        Assert.assertEquals(ValidationMessageField.SYMBOL_NAME, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));       
        Assert.assertEquals("Sort key conflicts with existing symbol: "+determineQuerySymbol("A01D46/262"),msg.getMessageText()); //A05A2001/00 A01D2046/262
        
    }
    
    @Test
    @Transactional
    public void testValidateTypeNorQSymbolExitInSCT() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01B2001/00", "0", "Bold Error ##BOLD##", new String[] {"A01N27/90"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A05A2001/00", "0", "Bold Error ##BOLD##", new String[] {"A01N27/90"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNorQTypeAndSortKeyValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        Assert.assertEquals(ValidationMessageField.SYMBOL_NAME, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));       
        Assert.assertEquals("Sort key conflicts with existing symbol: "+determineQuerySymbol("A01B2001/00"),msg.getMessageText()); //A05A2001/00
        
    }
    
    @Test
    @Transactional
    public void testValidateTypeNorQSymbolNotInInGoldCopyAndNotInSCTasDType() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A05A1/00", "0", "Bold Error ##BOLD##", new String[] {"A01N27/90"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A01N", "0", "Bold Error ##BOLD##", new String[] {"A01N27/90"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNorQTypeAndSortKeyValidator.validate(proposalValidationContext, rows);
        for(int i =0; i < rows.size(); i++) {
            Assert.assertTrue(rows.get(i).getValidationMessages().isEmpty());
        }
    }

}
