package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.junit.Assert.assertNull;

import java.util.Arrays;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalDocument;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalDocumentRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentApprovalRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentApproverRole;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentVersionClassificationCode;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalDocumentServiceTest {

	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private ProposalDocumentService proposalDocumentService;

	@Inject
	private ChangeProposalDocumentRepository changeProposalDocumentRepository;
	
	 
	@Test
	@Transactional
	public void testSaveAsNew() {

		ChangeProposalDocument firstDoc = changeProposalDocumentRepository
				.findByChangeProposalUUIDAndANX("a960b30c52a172ac8c37b64dfcc0ea21", 1);
		assertNull(firstDoc);
		String userid = "user@testing.com";
		ProposalDocumentRequest doc = new ProposalDocumentRequest();
		doc.setComment("First Doc");
		doc.setDocumentType(ProposalDocumentTypeCode.TWL);
		doc.setIpOfficeCode(StandardIpOfficeCode.US);
		doc.setName("TEST.TWL");
		doc.setResourceId("proposal/documents/RP12096_1_F_title_image (5)_01302023 200141.png");
		doc.setVersion(ProposalDocumentVersionClassificationCode.Final);
		doc.getApprovals().add(createApproval(StandardIpOfficeCode.US, ProposalDocumentApproverRole.PC, true, "test"));
		doc.getApprovals()
				.add(createApproval(StandardIpOfficeCode.US, ProposalDocumentApproverRole.EB, true, "test 2"));
//		UUID docId = proposalDocumentService.saveAsNew(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"),
//				doc, userid);
//		ChangeProposalDocument dbdoc = changeProposalDocumentRepository
//				.findByExternalId(GUIDUtils.toDatabaseFormat(docId));
//		assertNotNull(dbdoc);
//		assertNotNull(dbdoc.getApprovals());
//		assertEquals(2, dbdoc.getApprovals().size());

	}

	private ProposalDocumentApprovalRequest createApproval(StandardIpOfficeCode ipOffice,
			ProposalDocumentApproverRole roleCode, Boolean approved, String comment) {
		ProposalDocumentApprovalRequest appr = new ProposalDocumentApprovalRequest();
		appr.setApproved(approved);
		appr.setComment(comment);
		appr.setIpOfficeCode(ipOffice);
		appr.setProposerRoleCode(roleCode);
		return appr;
	}

	@Before
	public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.emptyTables(conn);
		datasetTestingService.loadAllDatasets(conn);

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamy@uspto.gov", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
	}

}
