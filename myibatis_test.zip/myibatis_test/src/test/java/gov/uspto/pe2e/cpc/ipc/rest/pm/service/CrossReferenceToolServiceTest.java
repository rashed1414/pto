package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CrptCurrentProjectCrl;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CrptOtherProjectCrl;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
public class CrossReferenceToolServiceTest {
	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private CrossReferenceToolService crossReferenceToolService;

	@Before
	public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.loadOnce();
	}
	@Test
	public void mapChangeTypes_currentProject_test() throws IOException {
		CrptCurrentProjectCrl currentProjectCrl = new CrptCurrentProjectCrl();
		RevisionChangeItemRequest revisionChangeItemRequest = mapJsonStringToRevisionChangeItemRequest("data/json/crt/CrossReferenceToolServiceMapChangeType.json");
		crossReferenceToolService.mapChangeTypes(currentProjectCrl, null, revisionChangeItemRequest);
		log.debug("currentProjectCrl: {}"+currentProjectCrl);
		assertEquals(currentProjectCrl.getTitleChangeIndicator().value(), SCTComponentChangeType.M.value());
		assertEquals(currentProjectCrl.getNotesChangeIndicator().value(), SCTComponentChangeType.M.value());
		assertEquals(currentProjectCrl.getWarnChangeIndicator().value(), SCTComponentChangeType.M.value());
		assertEquals(currentProjectCrl.getDefinitionChangeIndicator().value(), SCTComponentChangeType.M.value());
	}

	@Test
	public void mapChangeTypes_crptOtherProjectCrl_test() throws IOException {
		CrptOtherProjectCrl crptOtherProjectCrl = new CrptOtherProjectCrl();
		RevisionChangeItemRequest revisionChangeItemRequest = mapJsonStringToRevisionChangeItemRequest("data/json/crt/CrossReferenceToolServiceMapChangeType.json");
		crossReferenceToolService.mapChangeTypes(null, crptOtherProjectCrl, revisionChangeItemRequest);
		log.debug("crptOtherProjectCrl: {}", crptOtherProjectCrl);
		assertEquals(crptOtherProjectCrl.getTitleChangeIndicator().value(), SCTComponentChangeType.M.value());
		assertEquals(crptOtherProjectCrl.getNotesChangeIndicator().value(), SCTComponentChangeType.M.value());
		assertEquals(crptOtherProjectCrl.getWarnChangeIndicator().value(), SCTComponentChangeType.M.value());
		assertEquals(crptOtherProjectCrl.getDefinitionChangeIndicator().value(), SCTComponentChangeType.M.value());
	}

	private RevisionChangeItemRequest mapJsonStringToRevisionChangeItemRequest(String filePath) throws IOException {
		InputStream is = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream(filePath);
		String jsonString =  IOUtils.toString(is);
		return new ObjectMapper().readValue(jsonString, RevisionChangeItemRequest.class);
	}
}
