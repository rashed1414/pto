package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.DatabaseUnitException;
import org.dbunit.dataset.DataSetException;
import org.joda.time.DateTimeZone;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.beans.BeansException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.StandardSchemeReleaseRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PagableProposalSummary;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PrivateProposalTreeStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalSummary;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationTreeStatus;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

/**
 * This is the tests for Proposal controller that are non-volatile/Idempotent
 * 
 * @author myoung3
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalControllerTest {

	@Inject
	private StandardSchemeReleaseRepository standardSchemeReleaseRepository;

	@Inject
	private ProposalController proposalController;

	@Inject
	private DatasetTestingService datasetTestingService;

	@Test
	public void testSearchBy_mytasks() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("venkat@uspto.gov", "venkat", "kommareddy",
				"kommareddy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("venkat@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));

		ResponseEntity<PagableProposalSummary> resp = proposalController.listProposalSummaries(null, null, null, null,
				null, null, null, null, null, null, null, null, null, null, null, null, null, null, true, null, null,
				null, null, null, null, null, null, null, false, false, null, null, null);

		assertEquals(3, resp.getBody().getList().size());

	}

	@Test
	public void testShareProposalBetweenEPandUS() {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		// Check proposals before sharing
		ResponseEntity<PagableProposalSummary> summaryResp = proposalController.listProposalSummaries(null, null, null,
				null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, null,
				null, null, null, null, null, null, null, null, false, false, null, null, null);
		assertEquals(15, summaryResp.getBody().getList().size());

		// Share a EPO proposal with USPTO
		ResponseEntity<Void> postResp = proposalController
				.shareProposal(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844d41"), true);
		assertEquals(HttpStatus.OK, postResp.getStatusCode());

		// Check proposals list after sharing a proposal with USPTO
		summaryResp = proposalController.listProposalSummaries(null, null, null, null, null, null, null, null, null,
				null, null, null, null, null, null, null, null, null, false, null, null, null, null, null, null, null,
				null, null, false, false, null, null, null);
		assertEquals(16, summaryResp.getBody().getList().size());

		ProposalSummary sharedProposal = summaryResp.getBody().getList().stream()
				.filter(ps -> ps.getId().equals(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844d41")))
				.findFirst().get();

		assertTrue(sharedProposal.isShared());

	}

	@Transactional
	@Test
	public void testValidatePrivatePublicationTreeStatus() throws BeansException, DataSetException,
			FileNotFoundException, SQLException, DatabaseUnitException, IOException {
		ResponseEntity<PrivateProposalTreeStatus> resp = proposalController
				.getPublicationTree(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
		assertNotNull(resp);
		assertNotNull(resp.getBody());
		assertEquals(PublicationTreeStatus.COMPLETE, resp.getBody().getStatus());

	}

	@Before
	public void setUp() throws Exception {
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		DateTimeZone.setDefault(DateTimeZone.UTC);
		datasetTestingService.loadOnce();

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(2L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2021-09-27", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamy@uspto.gov", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
	}

}
