package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.stream.Collectors;

import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.*;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.CrossReferenceToolService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalVersion;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CrptCrlOverlapCrlV;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalVersionRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CrptCrlOverlapCrlViewRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.crt.v1_0.CrossProjectReferenceSummary;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalRevisionService;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test-oraclelocal.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class CrossReferenceToolControllerIntegrationTest {
	private static final Logger log = LoggerFactory.getLogger(CrossReferenceToolControllerIntegrationTest.class);
	@Inject
	private CrossReferenceToolController crossReferenceToolController;
	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private ChangeProposalVersionRepository changeProposalVersionRepository;

	@Inject
	private ProposalRevisionService proposalRevisionService;

	@Inject
	private CrptCrlOverlapCrlViewRepository crptCrlOverlapCrlViewRepository;
	@Inject
	private SecurityService securityService;

	@Inject
	private CrossReferenceToolService crossReferenceToolService;

	@Test
	@Transactional
	public void testGetCrlSymbolContentsForRTE() {

		UUID sourceProposalId = GUIDUtils.fromDatabaseFormat("d743774194f64f1ebc4244bdd145686d");
		// UUID otherProposalId = GUIDUtils.fromDatabaseFormat(null);
		UUID versionSymbolId =  GUIDUtils.fromDatabaseFormat("5b4bd2138a1d4c5dba70e2ba11191b7b");

		SymbolName sourceSymbol = new SymbolName("B64G1");
		SymbolName crlSymbol = new SymbolName("B64G1/46");

		ResponseEntity<RevisionChangeItem> resp = crossReferenceToolController
				.getCrlSymbolContentsForRTE(sourceProposalId, null, versionSymbolId, sourceSymbol, crlSymbol);

		RevisionChangeItem rcItem = resp.getBody();
		log.info("rcItem.getNoteItems()", rcItem.getNoteItems());
		assertNotNull(rcItem);
		assertEquals("B64G1/46", rcItem.getSymbolName());
		assertNotNull(rcItem.getTitleGrammar());
	}

	@Before
	public void setUp() throws Exception {

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1@uspto.gov",
				"myoung3@uspto.gov", Arrays.asList(new BasicTestingGrantedAuthority("test@uspto.gov")));

		SecurityContextHolder.getContext().setAuthentication(token);

		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
	}

	@Test
	@Transactional
	public void testDefinitions() {
		UUID sourceProposalId = GUIDUtils.fromDatabaseFormat("11ca1b69e11c4106b2e731cbc447fc9d");
		ChangeProposalVersion ver = changeProposalVersionRepository
				.findByExternalId(GUIDUtils.toDatabaseFormat(sourceProposalId));

		ProposalRevisionDetail proposalRevisionDetail = proposalRevisionService
				.getRevisionDetailByRevisionId(sourceProposalId, false);
		List<RevisionChangeItem> revisionChangeItems = proposalRevisionDetail.getRevisionChangeItems();
		List<SCTComponentChangeType> uniqueDefinitionTypes = new ArrayList<>();
		for (RevisionChangeItem item : revisionChangeItems) {
			log.debug("===========================================================================");
			log.debug("SIZE OF DEFINITION ITEMS :: == " + item.getDefinitionItems().size());
			if (item.getDefinitionItems().size() > 0) {
				if (item.getDefinitionItems() != null) {
					System.out.println(item.getDefinitionItems().get(0));
				}
			}

			log.debug("===========================================================================");
			if (CollectionUtils.isNotEmpty(item.getDefinitionItems())) {
				// Prepare array of Definition type
				Set<DefinitionSectionType> validDefinitionSectionTypes = EnumSet.of(DefinitionSectionType.RELATIONSHIP,
						DefinitionSectionType.LIMITING_REFERENCES, DefinitionSectionType.APPLICATION_REFERENCES,
						DefinitionSectionType.RESIDUAL_REFERENCES, DefinitionSectionType.INFORMATIVE_REFERENCES,
						DefinitionSectionType.SPECIAL_RULES, DefinitionSectionType.GLOSSARY_OF_TERMS,
						DefinitionSectionType.SYNONYMS_AND_KEYWORDS);
				Arrays.asList(DefinitionSectionType.values());
				Set<String> validDefinitionSectionTypeNames = validDefinitionSectionTypes.stream()
						.map(DefinitionSectionType::name).collect(Collectors.toSet());

				List<SCTComponentChangeType> definitionTypes = (List<SCTComponentChangeType>) item.getDefinitionItems()
						.stream().filter(Objects::nonNull)
						.filter(definitionItem -> definitionItem.getChangeType() != null
								&& validDefinitionSectionTypeNames.contains(definitionItem.getSectionType().name()))
						.map(definitionItem -> definitionItem.getChangeType()).collect(Collectors.toList());

				log.debug(" validDefinitionSectionTypes " + validDefinitionSectionTypes);
				log.debug(" definitionTypes ##==> " + definitionTypes);

				// Prepare unique definition sequences out of prepared array
				List<SCTComponentChangeType> uniqueDefinitionTypes1 = definitionTypes.stream().filter(Objects::nonNull)
						.collect(Collectors.toList());
				log.debug(" Unique Defintion Types ==> " + uniqueDefinitionTypes1);
				if (uniqueDefinitionTypes1.size() > 0) {
					for (SCTComponentChangeType udt : uniqueDefinitionTypes1) {
						uniqueDefinitionTypes.add(udt);
					}
				}

			}

		}

		log.debug(" UNIQUE DEFINITION TYPES ::== " + uniqueDefinitionTypes);
	}

	// We shouldn't random tests to just any class, they should be added to the right place.
//	@Test
//	@Transactional
//	public void testImpactedGroupDefinitions() {
//		Map<String, List<String>> definitions = globalSubclassDashBoardService.getImpactedMainGroupByDefinitions("A01B");
//		ResponseEntity<GlobalSubclassImpactedMaingroupsResponse> response = gsubController.findAllImpactedMainGroups("A01B");
//		log.debug(" ===>> TEST Impacted Group Definitions ===> " +definitions.get("Definitions") );
//		if (response.getBody() != null) {
//			log.debug(" ===>> TEST Impacted Group Scheme ===> " + response.getBody());
//			assertNotNull(response.getBody());
//		}
//	}

	
	@Test
	@Transactional
	public void testGetCrlOverLapCrl() {
		Long sourceProposalId = 1000009475l;
		String sourceGuidId = "a6fbbd8f81bd49d388d613884984ef92";
		String schemeVersion = "May 2023";
		List<CrptCrlOverlapCrlV> testList = new ArrayList<>();

		List<CrptCrlOverlapCrlV> otherProjectCrlOverlapCrlvsRows1 = crptCrlOverlapCrlViewRepository
				.findBySourceProposalIdAndSchemeRelease(sourceProposalId, schemeVersion);

		log.debug("SIZE OF THE First LIST >> " + otherProjectCrlOverlapCrlvsRows1.size());
		for (Object crl : otherProjectCrlOverlapCrlvsRows1) {
			 Object[] obj= (Object[]) crl;
			 Set<CrptCrlOverlapCrlV> unique = new TreeSet<>();
			List<CrptCrlOverlapCrlV> crptCrlOverLap = crptCrlOverlapCrlViewRepository
						.findByProposalIdandSourceCtlSymbol(sourceProposalId, schemeVersion, (String)obj[2] , (String)obj[1]);
			if(crptCrlOverLap.size()>1)
			{
				unique.addAll(crptCrlOverLap);
				testList.addAll(unique);
			}else {
			    testList.addAll(crptCrlOverLap);
			}
		}
		 
		log.debug(" ================================================ ");
		log.debug("  ==> Final RESULT " + testList.size());
		log.debug(" ================================================ ");
		 
		int index=1;
		for (CrptCrlOverlapCrlV crl : testList) {
			log.debug("Index " + index + " CRL --" + crl.getSourceProjectCd() + "<==>"+crl.getSourceCrlSymbolTx() + " <===> "+ crl.getSourceSymbolTx() +" <==> " + crl.getCrlOverlapSdctProjectCd());
			  index++;
		}
		 

	}
	
	@Test
	@Transactional
	public void testGetCrossProjectReferenceSummary() {

		UUID sourceProposalId = GUIDUtils.fromDatabaseFormat("e154ccf1324c4b38ad8adb97e70aefd3");
		String schemeRelease = "May 2022";
       
		ResponseEntity<List<CrossProjectReferenceSummary>> resp = crossReferenceToolController
				.getCrossProjectReferenceSummary(sourceProposalId, schemeRelease, null);

		List<CrossProjectReferenceSummary> rcItem = resp.getBody();
		assertTrue(CollectionUtils.isNotEmpty(rcItem));
	}
	@Test
	@Transactional
	public void testSaveProjectCrlSymbols() {

		UUID sourceProposalId = GUIDUtils.fromDatabaseFormat("d743774194f64f1ebc4244bdd145686d");
		// UUID otherProposalId = GUIDUtils.fromDatabaseFormat(null);
		UUID versionSymbolId =  GUIDUtils.fromDatabaseFormat("9e052f7e266e4408a7d137bc09815470");


		SymbolName sourceSymbol = new SymbolName("B64G");
		SymbolName crlSymbol = new SymbolName("F16C2326/47");

		RevisionChangeItemRequest revisionChangeItem = new RevisionChangeItemRequest();
		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(SecurityContextHolder.getContext()

				.getAuthentication());


		crossReferenceToolService.saveProjectCrlSymbols(
				sourceProposalId, null, versionSymbolId, "B64G", "F16C2326/47", revisionChangeItem, authToken);

//		RevisionChangeItem rcItem = resp.getBody();
//		log.info("rcItem.getNoteItems()", rcItem.getNoteItems());
//		assertNotNull(rcItem);
//		assertEquals("B64G1/46", rcItem.getSymbolName());
//		assertNotNull(rcItem.getTitleGrammar());
	}
	
	
}
