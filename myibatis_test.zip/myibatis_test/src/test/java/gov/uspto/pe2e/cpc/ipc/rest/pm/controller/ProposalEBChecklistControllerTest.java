package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposerAction;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposerTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.CheckListItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.CheckListItemDecision;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.ChecklistName;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.EbCheckList;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.EbclApproverRole;
import jakarta.inject.Inject;


/**
 * Test for class ProposalEBChecklistController
 * @author msingh4
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalEBChecklistControllerTest {
    private static final Logger log = LoggerFactory.getLogger(ProposalEBChecklistControllerTest.class);
    
    @Inject
    private DatasetTestingService datasetTestingService;    
    
    @Inject
    private ProposalEBChecklistController proposalEBChecklistController;
          
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);
        
		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1000L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setPublicationDate(DateUtils.parseDate("2015-09-01", 
				DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);
        
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("boopathi.kuppusamy@uspto.gov", "boopathi.kuppusamy@uspto.gov", 
                Arrays.asList(new BasicTestingGrantedAuthority("test")));
        SecurityContextHolder.getContext().setAuthentication(token);        
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/resources/images/cpc-sch-A01N-0937.gif")));
    }

    @Test
    public void saveChecklistItems_NewItem_RO_EB() { 
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
                "bkuppusamy", "Boopathi","Kuppusamy", "US");
            UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "boopathi.kuppusamyy@uspto.gov", token,
                Arrays.asList(new BasicTestingGrantedAuthority("test")));
                SecurityContextHolder.getContext().setAuthentication(springUser);  
        
                List<EbCheckList> requestList= new ArrayList<>();
                EbCheckList request= new EbCheckList();
                request.setType("IPC");
                request.setChecklistName(ChecklistName.PUB_INITIAL);
                CheckListItem item= new CheckListItem();
                item.setItemId(1000L);
                
                CheckListItemDecision decision = new CheckListItemDecision();
                decision.setRole(EbclApproverRole.EDITORIAL_BOARD);
                decision.setDecisionType(ProposerAction.YES);
                decision.setOfficeType(ProposerTypeCode.RO);
                decision.setOfficeCode(StandardIpOfficeCode.US);
                decision.setDecisionComments("Test Comments - RO EB");
                item.getDecisions().add(decision);
                request.getItems().add(item);
                requestList.add(request);
                
                UUID cpGuid= GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
                
                ResponseEntity<Void> response = proposalEBChecklistController.saveChecklistItems(cpGuid, requestList);
                
                assertNotNull(response);
                assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }
    @Test
    public void saveChecklistItems_NewItem_NR_EB() { 
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
                "bkuppusamy", "Boopathi","Kuppusamy", "US");
            UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "boopathi.kuppusamyy@uspto.gov", token,
                Arrays.asList(new BasicTestingGrantedAuthority("test")));
                SecurityContextHolder.getContext().setAuthentication(springUser);  
        
                List<EbCheckList> requestList= new ArrayList<>();
                EbCheckList request= new EbCheckList();
                request.setType("IPC");
                request.setChecklistName(ChecklistName.PUB_INITIAL);
                CheckListItem item= new CheckListItem();
                item.setItemId(1000L);
                
                CheckListItemDecision decision = new CheckListItemDecision();
                decision.setRole(EbclApproverRole.EDITORIAL_BOARD);
                decision.setDecisionType(ProposerAction.YES);
                decision.setOfficeType(ProposerTypeCode.NR);
                decision.setDecisionComments("Test Comments - NR EB");
                decision.setOfficeCode(StandardIpOfficeCode.US);
                item.getDecisions().add(decision);
                request.getItems().add(item);
                requestList.add(request);
                
                UUID cpGuid= GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
                
                ResponseEntity<Void> response = proposalEBChecklistController.saveChecklistItems(cpGuid, requestList);
                
                assertNotNull(response);
                assertEquals(HttpStatus.CREATED, response.getStatusCode());           
    }
    @Test
    public void saveChecklistItems_UpdateExisting() { 
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
                "bkuppusamy", "Boopathi","Kuppusamy", "US");
            UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "boopathi.kuppusamyy@uspto.gov", token,
                Arrays.asList(new BasicTestingGrantedAuthority("test")));
                SecurityContextHolder.getContext().setAuthentication(springUser);  
        
                List<EbCheckList> requestList= new ArrayList<>();
                EbCheckList request= new EbCheckList();
                request.setType("IPC");
                request.setChecklistName(ChecklistName.PUB_INITIAL);
                CheckListItem item= new CheckListItem();
                item.setItemId(1000L);
                
                CheckListItemDecision decision = new CheckListItemDecision();
                decision.setRole(EbclApproverRole.COORDINATOR);
                decision.setDecisionType(ProposerAction.YES);
                decision.setOfficeType(ProposerTypeCode.RO);
                decision.setDecisionComments("Test Comments - Updated");
                decision.setOfficeCode(StandardIpOfficeCode.US);
                item.getDecisions().add(decision);
                request.getItems().add(item);
                requestList.add(request);
                
                UUID cpGuid= GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
                
                ResponseEntity<Void> response = proposalEBChecklistController.saveChecklistItems(cpGuid, requestList);
                
                assertNotNull(response);
                assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }
    
    @Test
    public void saveChecklistItems_UpdateExisting_AddNew() { 
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
                "bkuppusamy", "Boopathi","Kuppusamy", "US");
            UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "boopathi.kuppusamyy@uspto.gov", token,
                Arrays.asList(new BasicTestingGrantedAuthority("test")));
                SecurityContextHolder.getContext().setAuthentication(springUser);  
        
                List<EbCheckList> requestList= new ArrayList<>();
                EbCheckList request= new EbCheckList();
                request.setType("IPC");
                request.setChecklistName(ChecklistName.PUB_INITIAL);
                CheckListItem item= new CheckListItem();
                item.setItemId(1000L);
                
                CheckListItemDecision decision = new CheckListItemDecision();
                decision.setRole(EbclApproverRole.COORDINATOR);
                decision.setDecisionType(ProposerAction.YES);
                decision.setOfficeType(ProposerTypeCode.RO);
                decision.setDecisionComments("Test Comments - Updated");
                decision.setOfficeCode(StandardIpOfficeCode.US);
                item.getDecisions().add(decision);
                request.getItems().add(item);
                requestList.add(request);
                
                EbCheckList request2= new EbCheckList();
                request2.setType("IPC");
                request2.setChecklistName(ChecklistName.PUB_INITIAL);
                CheckListItem item2= new CheckListItem();
                item2.setItemId(1000L);
                
                CheckListItemDecision decision2 = new CheckListItemDecision();
                decision2.setRole(EbclApproverRole.COORDINATOR);
                decision2.setDecisionType(ProposerAction.YES);
                decision2.setOfficeType(ProposerTypeCode.NR);
                decision2.setDecisionComments("Test Comments - NEW");
                decision2.setOfficeCode(StandardIpOfficeCode.US);
                item2.getDecisions().add(decision2);
                request2.getItems().add(item2);
                requestList.add(request2);
                
                UUID cpGuid= GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
                
                ResponseEntity<Void> response = proposalEBChecklistController.saveChecklistItems(cpGuid, requestList);
                
                assertNotNull(response);
                assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }
    
	@Test
	public void testGetAllCheckList_Pub_Initial() {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boopathi", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamyy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		UUID cpGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");

		ResponseEntity<List<EbCheckList>> response = proposalEBChecklistController.getChecklistItems(cpGuid, ChecklistName.PUB_INITIAL);
		assertNotNull(response);
		assertNotNull(response.getBody().get(0).getChecklistName().equals(ChecklistName.PUB_INITIAL));
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGetAllCheckList_Pub_Final() {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boopathi", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamyy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		UUID cpGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");

		ResponseEntity<List<EbCheckList>> response = proposalEBChecklistController.getChecklistItems(cpGuid, ChecklistName.PUB_FINAL);
		assertNotNull(response);
		assertNotNull(response.getBody().get(0).getChecklistName().equals(ChecklistName.PUB_FINAL));
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGetAllCheckList_EBJB_REVIEW() {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boopathi", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamyy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		UUID cpGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");

		ResponseEntity<List<EbCheckList>> response = proposalEBChecklistController.getChecklistItems(cpGuid, ChecklistName.EBJB_REVIEW);
		assertNotNull(response);
		assertNotNull(response.getBody().get(0).getChecklistName().equals(ChecklistName.EBJB_REVIEW));
		assertNotNull(response.getBody().get(0).getProposalStatus().equals(ProposalStatus.ACTIVE));
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGetAllCheckList_saveNew_EBJB_REVIEW() {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boopathi", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamyy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		UUID cpGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");

		List<EbCheckList> requestList= new ArrayList<>();
        EbCheckList request= new EbCheckList();
        request.setType("EBJB_REVIEW");
        request.setChecklistName(ChecklistName.EBJB_REVIEW);
        CheckListItem item= new CheckListItem();
        item.setItemId(1003L);
        
        CheckListItemDecision decision = new CheckListItemDecision();
        decision.setRole(EbclApproverRole.EDITORIAL_BOARD);
        decision.setDecisionType(ProposerAction.APPROVED);
        decision.setDecisionComments("Approved by US EB");
        decision.setOfficeCode(StandardIpOfficeCode.US);
        
        CheckListItemDecision decision2 = new CheckListItemDecision();
        decision2.setRole(EbclApproverRole.EDITORIAL_BOARD);
        decision2.setDecisionType(ProposerAction.APPROVED);
        decision2.setDecisionComments("Approved by EP EB");
        decision2.setOfficeCode(StandardIpOfficeCode.EP);
        
        item.getDecisions().addAll(Arrays.asList(decision, decision2));
        request.getItems().add(item);
        requestList.add(request);
        
        ResponseEntity<Void> response = proposalEBChecklistController.saveChecklistItems(cpGuid, requestList);
        
        assertNotNull(response);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        
        ResponseEntity<List<EbCheckList>> getResp = proposalEBChecklistController.getChecklistItems(cpGuid, ChecklistName.EBJB_REVIEW);
		assertNotNull(getResp);
		
		CheckListItem savedItem = getResp.getBody().get(0).getItems()
				.stream().filter(cl -> cl.getItemId() == 1003L)
				.findFirst().get();
		
		assertEquals(2, savedItem.getDecisions().size());
	}

	@Test(expected = AccessDeniedException.class)
	public void suspendProject_noApprovals() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boopathi", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamyy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		ResponseEntity<Void> response = proposalEBChecklistController
				.suspendProject(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
	}	

	@Test(expected = AccessDeniedException.class)
	public void suspendProject_usebApproved_epebRejected() {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boopathi", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamyy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		UUID cpGuid = GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7");

		List<EbCheckList> requestList = new ArrayList<>();
		EbCheckList request = new EbCheckList();
		request.setType("EBJB_REVIEW");
		request.setChecklistName(ChecklistName.EBJB_REVIEW);
		CheckListItem item = new CheckListItem();
		item.setItemId(1007L);

		CheckListItemDecision decision = new CheckListItemDecision();
		decision.setRole(EbclApproverRole.EDITORIAL_BOARD);
		decision.setDecisionType(ProposerAction.APPROVED);
		decision.setDecisionComments("Approved by US EB");
		decision.setOfficeCode(StandardIpOfficeCode.US);

		CheckListItemDecision decision2 = new CheckListItemDecision();
		decision2.setRole(EbclApproverRole.EDITORIAL_BOARD);
		decision2.setDecisionType(ProposerAction.REJECTED);
		decision2.setDecisionComments("Rejected by EP EB");
		decision2.setOfficeCode(StandardIpOfficeCode.EP);

		item.getDecisions().addAll(Arrays.asList(decision, decision2));
		request.getItems().add(item);
		requestList.add(request);

		proposalEBChecklistController.saveChecklistItems(cpGuid, requestList);

		proposalEBChecklistController.suspendProject(GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7"));
	}
	@Test
	public void suspendProject_usebApproved_epebApproved() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boopathi", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamyy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		UUID cpGuid = GUIDUtils.fromDatabaseFormat("405cfba610d54d05a25db281d335214d");

		List<EbCheckList> requestList= new ArrayList<>();
        EbCheckList request= new EbCheckList();
        request.setType("EBJB_REVIEW");
        request.setChecklistName(ChecklistName.EBJB_REVIEW);
        CheckListItem item= new CheckListItem();
        item.setItemId(1007L);
        item.setItemName("Family Count above 5000");
        
        CheckListItemDecision decision = new CheckListItemDecision();
        decision.setRole(EbclApproverRole.EDITORIAL_BOARD);
        decision.setDecisionType(ProposerAction.APPROVED);
        decision.setDecisionComments("Approved by US EB");
        decision.setOfficeCode(StandardIpOfficeCode.US);
        
        CheckListItemDecision decision2 = new CheckListItemDecision();
        decision2.setRole(EbclApproverRole.EDITORIAL_BOARD);
        decision2.setDecisionType(ProposerAction.APPROVED);
        decision2.setDecisionComments("Approved by EP EB");
        decision2.setOfficeCode(StandardIpOfficeCode.EP);
        
        item.getDecisions().addAll(Arrays.asList(decision, decision2));
        request.getItems().add(item);
        requestList.add(request);
        
        proposalEBChecklistController.saveChecklistItems(cpGuid, requestList);
		
		ResponseEntity<Void> response = proposalEBChecklistController
				.suspendProject(GUIDUtils.fromDatabaseFormat("405cfba610d54d05a25db281d335214d"));
		
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
}
