package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating.TemplateConfigurationLocator;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassTransferView;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalRevisionService;
import jakarta.inject.Inject;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalRevisionControllerVolatileTest  {
    private static final Logger log = LoggerFactory.getLogger(ProposalRevisionControllerVolatileTest.class);
    
    
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ProposalRevisionController controller;

    
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

//        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("myoung3@uspto.gov", "myoung3@uspto.gov", Arrays
//                .asList(new BasicTestingGrantedAuthority("test"), 
//                		new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
//
//        SecurityContextHolder.getContext().setAuthentication(token);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
    			"bkuppusamy", "Boops","Kuppusamy", "US");
    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"boopathi.kuppusamy@uspto.gov", token,
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);        


        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }

    @Test
    @Transactional
    public void testUploadToRST() throws Exception {
        log.info("setting up RST mocks");
        
        ProposalRevisionService mockRevisionSvc =  mock(ProposalRevisionService.class);
        when(mockRevisionSvc.uploadToRST(any(), any())).thenReturn(UUID.fromString("0987e6b6-4925-4e09-a97e-79e12771aff2"));
        when(mockRevisionSvc.createRSTLocation(any())).thenReturn("http://mocklocation/id=0987e6b6-4925-4e09-a97e-79e12771aff2");
        
        SecurityService mockSecurityService = mock( SecurityService.class);
        
        ProposalRevisionController controller = new ProposalRevisionController(mockRevisionSvc, mockSecurityService  );
             UUID guid = GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56");
        Assert.assertNotNull(new TemplateConfigurationLocator().getUiBaseUrl());
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(
                   WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposalrevisions/080f8146bd4e4e349350c1b184db1b56/sct.docx")));
        
//        byte[] dataForDisplay = proposalRevisionService.exportProposalRevisionInfoIntoDocx(GUIDUtils.fromDatabaseFormat(guid), ExportDocxReportType.SCT.name(), null);
//        Assert.assertNotNull(dataForDisplay);
        ResponseEntity<Void> resp = controller.uploadToRST(guid, null);
        
        log.info("RST returned {}", resp.getHeaders().get(HttpHeaders.LOCATION).get(0));
        assertNotNull(resp.getHeaders().get(HttpHeaders.LOCATION).get(0));
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals("http://mocklocation/id=0987e6b6-4925-4e09-a97e-79e12771aff2", 
                resp.getHeaders().get(HttpHeaders.LOCATION).get(0));
        
    }
   

    @Test
    @Transactional
    public void testFetchReclassTransfers() throws Exception {
    	
    	ResponseEntity<List<ReclassTransferView>> resp = controller.getReclassTransfers(GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56"));
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertNotNull(resp.getBody());
        assertNotEquals(0, resp.getBody().size());
        for (ReclassTransferView rcls: resp.getBody()) {
            log.info("id= {}, source = {}, target = {}, changeType = {}, reclass Type = {}", 
            		rcls.getId(), rcls.getSourceSymbolName(), rcls.getTargetSymbolName(), 
            		rcls.getChangeType(), rcls.getReclassificationTypeCategory());
        	assertNotNull(rcls.getReclassificationTypeCategory());
        }
        assertEquals(9, resp.getBody().size());
        
    }
    
    @Test
    @Transactional
    public void testFetchReclassTransfers_Notfound() throws Exception {
    	try {
    	
    		controller.getReclassTransfers(GUIDUtils.fromDatabaseFormat("bbbb8146bd4e4e349350c1b184db1b56"));
    		fail();
    	} catch (Exception e) {
    		assertEquals(EntityNotFoundException.class, e.getClass());
    		assertEquals("Proposal Revision bbbb8146-bd4e-4e34-9350-c1b184db1b56 not found.", e.getMessage());
    	}
        
    }
    
}