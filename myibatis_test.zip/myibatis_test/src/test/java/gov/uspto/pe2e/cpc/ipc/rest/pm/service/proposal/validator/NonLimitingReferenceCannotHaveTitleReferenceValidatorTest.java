package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.jdom2.Element;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.I18nMessageKey;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.ipc.rest.pm.testingsupport.ProposalSCTRowFactory;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
public class NonLimitingReferenceCannotHaveTitleReferenceValidatorTest {

	private static final Logger log = LoggerFactory
			.getLogger(NonLimitingReferenceCannotHaveTitleReferenceValidatorTest.class);

	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private NonLimitingReferenceCannotHaveTitleReferenceValidator nonLimitingReferenceCannotHaveTitleReferenceValidator;

	@Inject
	private TitleService titleService;

	@Resource(name = "proposalCompletenessValidator")
	private List<ProposalValidator> completenessValidators;

	@Resource(name = "proposalConsistencyValidator")
	private List<ProposalValidator> consistencyValidators;

	@Inject
	private ProposalValidationService proposalValidationService;

	@Inject
	private ProposalSCTRowFactory proposalSCTRowFactory;

	private DocumentAdapter docAdapter;

	@Test
	public void testAppConfiguredInProperValidatorChain() {
		boolean isIncluded = false;
		for (ProposalValidator validator : consistencyValidators) {
			if (validator.getClass().getCanonicalName()
					.equals(nonLimitingReferenceCannotHaveTitleReferenceValidator.getClass().getCanonicalName())) {
				isIncluded = true;
				break;
			}
		}
		assertTrue(isIncluded);
	}

	/**
	 * This is a single comprehensive test that has multiple null definition,
	 * multiple nonnulls (3) 2 sections will have multiple errors each
	 */
	@Test
	public void testValidateDennissCases() {

		List<RevisionChangeItem> rows = new ArrayList<>();
		// TEST CASE 1 (No definition sections at all)
		rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0",
				"text (viewfinders for cameras ##SYMBOL##G03B1/00##/SYMBOL##)",
				new String[] { "A01B 5/005", "A01B 5/008" }));
		// Test Case 2 (other def sections but not the ones we look at)
		RevisionChangeItem row = ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0",
				"text (viewfinders for cameras ##SYMBOL##G03B1/00##/SYMBOL##)",
				new String[] { "A01B 5/005", "A01B 5/008" });
		row.getDefinitionItems().add(proposalSCTRowFactory.createDefinitionSnKSection(SCTComponentChangeType.M,
				"data/xml/fragments/definition_snk_G03B1-00.xml"));
		assertEquals(1, row.getDefinitionItems().size());
		assertNull(row.getDefinitionItems().get(0).getLimitingReferences());
		assertNotNull(row.getDefinitionItems().get(0).getSynonymsKeywords());
		rows.add(row);

		// TEST case 3 (App ref, Residual, ref or informative exist but no symbols)
		row = ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0",
				"text (viewfinders for cameras ##SYMBOL##G03B1/00##/SYMBOL##)",
				new String[] { "A01B 5/005", "A01B 5/008" });
		row.getDefinitionItems().add(proposalSCTRowFactory.createApplicationReference(SCTComponentChangeType.M,
				"data/xml/fragments/appref_no_symbols.xml"));
		row.getDefinitionItems().add(proposalSCTRowFactory.createResidualReference(SCTComponentChangeType.M,
				"data/xml/fragments/resref_no_symbols.xml"));
		row.getDefinitionItems().add(proposalSCTRowFactory.createInformativeReference(SCTComponentChangeType.M,
				"data/xml/fragments/inforef_no_symbols.xml"));
		assertEquals(3, row.getDefinitionItems().size());
		assertNull(row.getDefinitionItems().get(0).getLimitingReferences());
		rows.add(row);

		// Test Case 4 (Symbol in res ref but NOT in title ref) - No error
		row = ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0",
				"text (viewfinders for cameras)", new String[] { "A01B 5/005", "A01B 5/008" });
		row.getDefinitionItems().add(proposalSCTRowFactory.createApplicationReference(SCTComponentChangeType.M,
				"data/xml/fragments/appref_G03B1-00.xml"));
		assertEquals(1, row.getDefinitionItems().size());
		assertNull(row.getDefinitionItems().get(0).getLimitingReferences());
		rows.add(row);

		// Test Case 5 (Symbol in res ref and title ref) - error
		row = ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0",
				"text (viewfinders for cameras ##SYMBOL##G03B1/00##/SYMBOL##)",
				new String[] { "A01B 5/005", "A01B 5/008" });
		row.getDefinitionItems().add(proposalSCTRowFactory.createApplicationReference(SCTComponentChangeType.M,
				"data/xml/fragments/appref_G03B1-00.xml"));
		assertEquals(1, row.getDefinitionItems().size());
		assertNull(row.getDefinitionItems().get(0).getLimitingReferences());
		rows.add(row);
		// Test case 6 - (symbol in info ref but not refed in title) - no error
		row = ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0",
				"text (viewfinders for cameras ##SYMBOL##A03B1/00##/SYMBOL##)",
				new String[] { "A01B 5/005", "A01B 5/008" });
		row.getDefinitionItems().add(proposalSCTRowFactory.createApplicationReference(SCTComponentChangeType.M,
				"data/xml/fragments/appref_G03B1-00.xml"));
		assertEquals(1, row.getDefinitionItems().size());
		assertNull(row.getDefinitionItems().get(0).getLimitingReferences());
		rows.add(row);


		// Test Case 7 ommitted (covered in above test)
		// Test Case 8
		row = ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0",
				"text {(viewfinders for cameras ##SYMBOL##G03B1/00##/SYMBOL## ##SYMBOL##A01c69/00##/SYMBOL##)}",
				new String[] { "A01B 5/005", "A01B 5/008" });
		row.getDefinitionItems().add(proposalSCTRowFactory.createApplicationReference(SCTComponentChangeType.M,
				"data/xml/fragments/appref_G03B1-00.xml"));
		row.getDefinitionItems().add(proposalSCTRowFactory.createInformativeReference(SCTComponentChangeType.M,
				"data/xml/fragments/inforef_G03B1-00.xml"));
		assertEquals(2, row.getDefinitionItems().size());
		assertNull(row.getDefinitionItems().get(0).getLimitingReferences());
		rows.add(row);

		rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "H04N2/222", "0",
				"test;hello (section ##SYMBOL##A01B1/0241##/SYMBOL## test ##SYMBOL##A01B1/0247##/SYMBOL##); Hello ##SYMBOL##A01B1/0261##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## ##SYMBOL##A01C65/00##/SYMBOL## ##SYMBOL##A01C69/00##/SYMBOL## test)",
				new String[] { "A01B 5/005", "A01B 5/008" }));

		ProposalValidationContext proposalValidationContext = proposalValidationService
				.createProposalValidationContext(rows);
		for (int i = 0; i < rows.size(); i++) {
			try {
				TitlePartTree tree = titleService.fromGrammar(rows.get(i).getTitleGrammar());
				rows.get(i).setTitle(tree);
			} catch (GrammarParseException gpe) {
				rows.get(i).getValidationMessages().addAll(gpe.getValidationMessages());
			}
		}

		log.debug("title = {}", JaxbUtils.marshalToString(rows.get(0).getTitle()));

		List<Element> titleSymbolElements = nonLimitingReferenceCannotHaveTitleReferenceValidator
				.findReferenceSymbols(rows.get(0).getTitle());
		assertEquals(1, titleSymbolElements.size());

		titleSymbolElements = nonLimitingReferenceCannotHaveTitleReferenceValidator
				.findReferenceSymbols(rows.get(1).getTitle());
		assertEquals(1, titleSymbolElements.size());

		titleSymbolElements = nonLimitingReferenceCannotHaveTitleReferenceValidator
				.findReferenceSymbols(rows.get(2).getTitle());
		assertEquals(1, titleSymbolElements.size());

		titleSymbolElements = nonLimitingReferenceCannotHaveTitleReferenceValidator
				.findReferenceSymbols(rows.get(3).getTitle());
		assertEquals(0, titleSymbolElements.size());

		titleSymbolElements = nonLimitingReferenceCannotHaveTitleReferenceValidator
				.findReferenceSymbols(rows.get(4).getTitle());
		assertEquals(1, titleSymbolElements.size());

		nonLimitingReferenceCannotHaveTitleReferenceValidator.validate(proposalValidationContext, rows);
		// test case 1
		assertEquals(0, rows.get(0).getValidationMessages().size());
		// test case 2
		assertEquals(0, rows.get(1).getValidationMessages().size());
		// test case 3
		assertEquals(0, rows.get(2).getValidationMessages().size());
		// test case 4
		assertEquals(0, rows.get(3).getValidationMessages().size());
		// test case 5
		assertEquals(1, rows.get(4).getValidationMessages().size());
		assertEquals(
				"References in non-limiting reference sections of definition [APPLICATION_REFERENCES] must not be found in title - [G03B1/00]",
				rows.get(4).getValidationMessages().get(0).getMessageText());
		assertEquals(ValidationMessageLevel.ERROR,
				rows.get(4).getValidationMessages().get(0).getLevel());
		assertEquals(ValidationMessageField.TITLE,
				rows.get(4).getValidationMessages().get(0).getTriggerField());
		// test case 6
		assertEquals(0, rows.get(5).getValidationMessages().size());

		assertEquals(2, rows.get(6).getValidationMessages().size());
		assertEquals(
				"References in non-limiting reference sections of definition [APPLICATION_REFERENCES] must not be found in title - [G03B1/00]",
				rows.get(6).getValidationMessages().get(0).getMessageText());
		assertEquals(
				"References in non-limiting reference sections of definition [INFORMATIVE_REFERENCES] must not be found in title - [G03B1/00]",
				rows.get(6).getValidationMessages().get(1).getMessageText());
		assertEquals(ValidationMessageLevel.ERROR,
				rows.get(6).getValidationMessages().get(0).getLevel());
		assertEquals(
				ValidationMessageLevel.ERROR,
				rows.get(6).getValidationMessages().get(1).getLevel());
		assertEquals(
				ValidationMessageField.TITLE,
				rows.get(6).getValidationMessages().get(0).getTriggerField());
		assertEquals(
				ValidationMessageField.TITLE,
				rows.get(6).getValidationMessages().get(1).getTriggerField());

		assertEquals(
				I18nMessageKey.PROPOSAL_VALIDATION_NONLIMITING_REF_IN_TITLE_REF.name(),
				rows.get(6).getValidationMessages().get(0).getErrorEventKey());
		assertEquals(I18nMessageKey.PROPOSAL_VALIDATION_NONLIMITING_REF_IN_TITLE_REF.name(),
				rows.get(6).getValidationMessages().get(1).getErrorEventKey());


	}

	@Test
	public void testExtraCasesDennisDidNotSpecify() {

		List<RevisionChangeItem> rows = new ArrayList<>();
		// Y series 
		RevisionChangeItem row =  ProposalValidationHelperTest.createRevisionChangeItem("U", 
				"Y10T", "0",
				"text (viewfinders for cameras ##SYMBOL##G03B1/00##/SYMBOL##)",
				new String[] { "A01B 5/005", "A01B 5/008" });
		row.getDefinitionItems().add(proposalSCTRowFactory.createApplicationReference(SCTComponentChangeType.M,
				"data/xml/fragments/appref_G03B1-00.xml"));
		assertEquals(1, row.getDefinitionItems().size());
		assertNull(row.getDefinitionItems().get(0).getLimitingReferences());
		rows.add(row);
		// 2000-series
		assertTrue(SymbolName.parse("A45B2023/0093").isYSeriesOrTwoThousandSeries());
		row =  ProposalValidationHelperTest.createRevisionChangeItem("U", 
				"A45B2023/0093", "0",
				"text (viewfinders for cameras ##SYMBOL##G03B1/00##/SYMBOL##)",
				new String[] { "A01B 5/005", "A01B 5/008" });
		row.getDefinitionItems().add(proposalSCTRowFactory.createApplicationReference(SCTComponentChangeType.M,
				"data/xml/fragments/appref_G03B1-00.xml"));
		assertEquals(1, row.getDefinitionItems().size());
		assertNull(row.getDefinitionItems().get(0).getLimitingReferences());
		rows.add(row);
		
		ProposalValidationContext proposalValidationContext = proposalValidationService
				.createProposalValidationContext(rows);
		for (int i = 0; i < rows.size(); i++) {
			try {
				TitlePartTree tree = titleService.fromGrammar(rows.get(i).getTitleGrammar());
				rows.get(i).setTitle(tree);
			} catch (GrammarParseException gpe) {
				rows.get(i).getValidationMessages().addAll(gpe.getValidationMessages());
			}
		}


		nonLimitingReferenceCannotHaveTitleReferenceValidator.validate(proposalValidationContext, rows);
		// Y Series
		assertEquals(0, rows.get(0).getValidationMessages().size());
		// 2000 series
		assertEquals(0, rows.get(1).getValidationMessages().size());
	}
	
	@Test
	public void testDefSectionSetup() {
		List<RevisionChangeItem> rows = new ArrayList<>();
		// Test Case 8
		RevisionChangeItem row = ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0",
				"text {(viewfinders for cameras ##SYMBOL##G03B1/00##/SYMBOL## ##SYMBOL##A01c69/00##/SYMBOL##)}",
				new String[] { "A01B 5/005", "A01B 5/008" });
		row.getDefinitionItems().add(proposalSCTRowFactory.createApplicationReference(SCTComponentChangeType.M,
				"data/xml/fragments/appref_G03B1-00.xml"));
		row.getDefinitionItems().add(proposalSCTRowFactory.createInformativeReference(SCTComponentChangeType.M,
				"data/xml/fragments/inforef_G03B1-00.xml"));
		assertEquals(2, row.getDefinitionItems().size());
		assertNull(row.getDefinitionItems().get(0).getLimitingReferences());
		rows.add(row);


	}
	
	public RevisionChangeItem createRevisionChangeItemWithDefinitionLimitingRef(String entryType, String symbolName,
			String dotLevel, String titleGrammar, String[] reclassTargets) {
		RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel,
				titleGrammar, reclassTargets);
		item.getDefinitionItems().add(proposalSCTRowFactory.createDefinitionLimitingRef(SCTComponentChangeType.M,
				"data/xml/fragments/limref2.xml"));
		return item;
	}

	@Before
	public void setUp() throws Exception {
		datasetTestingService.loadOnce();
		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		Class adapterClass = Class.forName(DocumentAdapter.class.getCanonicalName());
		docAdapter = (DocumentAdapter) adapterClass.newInstance();

	}

}