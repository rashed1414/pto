package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.format.PeriodFormatter;
import org.joda.time.format.PeriodFormatterBuilder;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalVersion;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.VersionSymbol;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalVersionRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.VersionSymbolRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.TitleConverter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcConcordanceMapping;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcSymbol;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalRevisionDetail;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalSummary;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassTransfer;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassificationTypeCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePart;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartRawText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalImportHelper;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalControllerVolatileDE55585Test {
	
    public static final PeriodFormatter DEFAULT_PERIOD_FORMATTER =  new PeriodFormatterBuilder().appendHours()
                    .appendSuffix("h").appendLiteral(" ").appendMinutes().appendSuffix("m")
                    .appendLiteral(" ").appendSecondsWithOptionalMillis().appendSuffix("s").toFormatter();


	@Inject
	private ProposalController proposalController;

	@Inject
	private ProposalRevisionController proposalRevisionController;

	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private ChangeProposalVersionRepository changeProposalVersionRepository;

	@Inject
	private ChangeProposalRepository changeProposalRepository;

	@Inject
	private VersionSymbolRepository versionSymbolRepository;

	@Inject
	private ProposalValidationService proposalValidationService;

	@Inject
	private ProposalService proposalService;

	@Inject
	private TitleService titleService;


	@Transactional 
	@Test
	public void testSaveSCT_DE55585() throws IOException, GrammarParseException {
		
		ChangeProposalVersion revision = changeProposalVersionRepository.findByExternalId("87930a9328da43559f902f284d1e96d8");
		assertNotNull(revision);
		assertEquals(1, revision.getSctItems().size());
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		sctItems.add(createSctRequestItem("M", "A01N 1/00", "subclass", "test Title 1", 
				Arrays.asList(createReclassTransfer("A01B 1/00", ReclassificationTypeCategory.ADMIN))));

		ResponseEntity<ProposalRevisionDetail> resp = proposalController
				.overwriteExistingLatestRevision(GUIDUtils.fromDatabaseFormat("405cfba610d54d05a25db281d335214d"), sctItems);
		String uuidStr = resp.getHeaders().getFirst(RestUtils.RESOURCE_ID_HEADER);

		revision = changeProposalVersionRepository.findByExternalId("87930a9328da43559f902f284d1e96d8");
		assertNotNull(revision);
		
		int realVsCount = 0;
		int systemGenCount = 0;
		for (VersionSymbol vs: revision.getSctItems()) {
			log.debug("DE55585 {} {} {}", vs.getSymbolName(), 
					vs.getSystemCreated(), vs.getTitleXml());
			if (vs.getSystemCreated()) {
				systemGenCount++;
			} else {
				realVsCount++;
			}
		}
		assertEquals(1, realVsCount);
		assertEquals(0, systemGenCount);
		
		ResponseEntity<ProposalRevisionDetail> byIdResp = proposalRevisionController.getRevisionDetailByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat("87930a9328da43559f902f284d1e96d8"), true);

		assertNotNull(byIdResp.getBody());
		for (RevisionChangeItem item: byIdResp.getBody().getRevisionChangeItems()) {
			log.debug("DE55585 {} {}", item.getSymbolName(), TitleConverter.toGrammar( item.getTitle()));
			
		}
		assertEquals(1, byIdResp.getBody().getRevisionChangeItems().size());
	

	}
	
	

	@Transactional 
	@Test
	public void testSaveSCT_DE55668() throws IOException, GrammarParseException {
		
		RevisionChangeItemRequest row = new RevisionChangeItemRequest();
		row.setEntryType("M");
		row.setSymbolName("A01N 1/00");
		row.setDotLevel("subclass");
		
		ChangeProposalVersion revision = changeProposalVersionRepository.findByExternalId("87930a9328da43559f902f284d1e96d8");
		assertNotNull(revision);
		assertEquals(1, revision.getSctItems().size());
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
	//	RevisionChangeItemRequest row = createSctRequestItem("M", "A01N 1/00", "subclass", "test Title 1", 
	//			Arrays.asList(createReclassTransfer("A01B 1/00", ReclassificationTypeCategory.ADMIN)));
		row.setTitleGrammar("{containing within the molecule the substructure ##IMG####ALT##null##/ALT##cpc-sch-C07K-1009.gif##/IMG## with m, n  0 and mn  0, A, B, D, E being heteroatoms X being a bond or a chain, e.g. muramylpeptides}"
//				"{containing within the molecule the substructure ##IMG##cpc-sch-C07K-1009.gif##/IMG## with m, n > 0 and m+n > 0, A, B, D, E being heteroatoms; X being a bond or a chain, e.g. muramylpeptides}"
				);
	//	row.setTitle(titleService.fromGrammar(row.getTitleGrammar()));
		sctItems.add(row);

		log.debug(StringUtils.substring(row.getTitleGrammar(), 188));
		TitlePartTree tree =  titleService.fromGrammar(row.getTitleGrammar());
	    FileUtils.writeStringToFile(new File("target/c07k9-005.xml"),  
	    		JaxbUtils.marshalToString(ProposalImportHelper.JAXB_TITLE_CTX, tree));
		assertNotNull(tree);
		assertEquals("gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartText", tree.getChildren().get(0).getChildren().get(0).getClass().getName());
		
		ResponseEntity<ProposalRevisionDetail> resp = proposalController
				.overwriteExistingLatestRevision(GUIDUtils.fromDatabaseFormat("405cfba610d54d05a25db281d335214d"), sctItems);
		String uuidStr = resp.getHeaders().getFirst(RestUtils.RESOURCE_ID_HEADER);

		revision = changeProposalVersionRepository.findByExternalId("87930a9328da43559f902f284d1e96d8");
		assertNotNull(revision);
		
		int realVsCount = 0;
		int systemGenCount = 0;
		for (VersionSymbol vs: revision.getSctItems()) {
			log.debug("DE55668 {} {} {}", vs.getSymbolName(), 
					vs.getSystemCreated(), vs.getTitleXml());
			assertTrue(StringUtils.isNotEmpty(vs.getTitleXml()));
			assertEquals("<", StringUtils.substring( vs.getTitleXml(), 0, 1)); // verifies that the grammar was parsable as a titlepart tree and correctly stored

			// unparsable grammars
		}

	}

	@Transactional 
	@Test
	public void testSaveSCT_roundtrip_reclass() throws IOException, GrammarParseException {
		
		RevisionChangeItemRequest row = new RevisionChangeItemRequest();
		row.setEntryType("M");
		row.setSymbolName("A01N 1/00");
		row.setDotLevel("subclass");
		
		row.getReclassTransfers().add(createReclassTransfer("A01N01/29", ReclassificationTypeCategory.INTELLECTUAL));
		
		ChangeProposalVersion revision = changeProposalVersionRepository.findByExternalId("87930a9328da43559f902f284d1e96d8");
		assertNotNull(revision);
		assertEquals(1, revision.getSctItems().size());
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
	//	RevisionChangeItemRequest row = createSctRequestItem("M", "A01N 1/00", "subclass", "test Title 1", 
	//			Arrays.asList(createReclassTransfer("A01B 1/00", ReclassificationTypeCategory.ADMIN)));
		row.setTitleGrammar("{containing within the molecule the substructure ##IMG####ALT##null##/ALT##cpc-sch-C07K-1009.gif##/IMG## with m, n  0 and mn  0, A, B, D, E being heteroatoms X being a bond or a chain, e.g. muramylpeptides}"
//				"{containing within the molecule the substructure ##IMG##cpc-sch-C07K-1009.gif##/IMG## with m, n > 0 and m+n > 0, A, B, D, E being heteroatoms; X being a bond or a chain, e.g. muramylpeptides}"
				);
	//	row.setTitle(titleService.fromGrammar(row.getTitleGrammar()));
		sctItems.add(row);

		log.debug(StringUtils.substring(row.getTitleGrammar(), 188));
		ResponseEntity<ProposalRevisionDetail> resp = proposalController
				.overwriteExistingLatestRevision(GUIDUtils.fromDatabaseFormat("405cfba610d54d05a25db281d335214d"), sctItems);
		String uuidStr = resp.getHeaders().getFirst(RestUtils.RESOURCE_ID_HEADER);

		revision = changeProposalVersionRepository.findByExternalId("87930a9328da43559f902f284d1e96d8");
		assertNotNull(revision);
		
		
		
		for (VersionSymbol vs: revision.getSctItems()) {
			log.debug("DExxxxxx {} {} {}", vs.getSymbolName(), 
					vs.getSystemCreated(), vs.getTitleXml());
			if (vs.getSymbolName().equals("A01N1/00")) {
				log.debug("{} {} ", vs.getReclassTransferItems().size(), vs.getReclassTransferItems());
				assertEquals(1, vs.getReclassTransferItems().size());
			} else {
				log.debug("{}", vs.getSymbolName());
			}
			if (CollectionUtils.isNotEmpty(vs.getReclassTransferItems())) {
				for (gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ReclassTransfer dbReclass: vs.getReclassTransferItems()) {
					assertNotNull(dbReclass.getReclassificationTypeCategory());
					assertNotNull(dbReclass.getTargetSymbolName());
				}
			}
		}
		
		ResponseEntity<ProposalRevisionDetail> getResp = proposalRevisionController.getRevisionDetailByChangeProposalVersionId(
				GUIDUtils.fromDatabaseFormat("87930a9328da43559f902f284d1e96d8"), true);
		assertNotNull(getResp);
		assertNotNull(getResp.getBody());
		assertEquals(1, CollectionUtils.size(getResp.getBody().getRevisionChangeItems()));
		assertNotNull(getResp.getBody().getRevisionChangeItems().get(0));
		assertEquals(ReclassificationTypeCategory.INTELLECTUAL,getResp.getBody().getRevisionChangeItems().get(0)
				.getReclassTransfers().get(0).getReclassificationTypeCategory());
		assertEquals("A01N01/29", getResp.getBody().getRevisionChangeItems().get(0)
				.getReclassTransfers().get(0).getTargetSymbolName());

		ResponseEntity<ProposalSummary> proposalGetResp = proposalController.getProposalSummaryById(
				GUIDUtils.fromDatabaseFormat("405cfba610d54d05a25db281d335214d"));
		assertNotNull(proposalGetResp);
		assertNotNull(proposalGetResp.getBody());
		// Removed, new code relies on view
		//assertEquals(22, CollectionUtils.size(proposalGetResp.getBody().getScopeSymbols()));
							

	}


//	@Transactional
//	@Test
//	public void testSaveAfterImageDelete_DE55689() {
//		RevisionChangeItemRequest row = new RevisionChangeItemRequest();
//		row.setEntryType("M");
//		row.setSymbolName("A01N 1/00");
//		row.setDotLevel("subclass");
//		
//		ChangeProposalVersion revision = changeProposalVersionRepository.findByExternalId("87930a9328da43559f902f284d1e96d8");
//		assertNotNull(revision);
//		assertEquals(1, revision.getSctItems().size());
//		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
//	//	RevisionChangeItemRequest row = createSctRequestItem("M", "A01N 1/00", "subclass", "test Title 1", 
//	//			Arrays.asList(createReclassTransfer("A01B 1/00", ReclassificationTypeCategory.ADMIN)));
//		row.setTitleGrammar("{containing within the molecule the substructure ##IMG####ALT##null##/ALT##cpc-sch-C07K-1009.gif##/IMG## with m, n  0 and mn  0, A, B, D, E being heteroatoms X being a bond or a chain, e.g. muramylpeptides}"
////				"{containing within the molecule the substructure ##IMG##cpc-sch-C07K-1009.gif##/IMG## with m, n > 0 and m+n > 0, A, B, D, E being heteroatoms; X being a bond or a chain, e.g. muramylpeptides}"
//				);
//	//	row.setTitle(titleService.fromGrammar(row.getTitleGrammar()));
//		sctItems.add(row);
//	}
	
	private ReclassTransfer createReclassTransfer(String symbolName, ReclassificationTypeCategory reclassType) {
		ReclassTransfer reclass = new ReclassTransfer();
		reclass.setReclassificationTypeCategory(reclassType);
		reclass.setTargetSymbolName(symbolName);
		return reclass;
	}


	public static RevisionChangeItemRequest createSctRequestItem(String entryType, String symbolName, String dotLevel,
			String simpleTitleText, List<ReclassTransfer> reclasses) {
		RevisionChangeItemRequest req = new RevisionChangeItemRequest();
		req.setEntryType(entryType);
		req.setSymbolName(symbolName);
		req.setDotLevel(dotLevel);
		if (StringUtils.isNotBlank(simpleTitleText)) {
			TitlePartTree tree = new TitlePartTree();
			TitlePartText tpText = new TitlePartText();
			TitlePartRawText raw = new TitlePartRawText();
			tpText.getChildren().add((TitlePart) raw);

			tree.getChildren().add(tpText);
			req.setTitle(tree);
		}
		req.getReclassTransfers().addAll(reclasses);
		return req;

	}

	public static RevisionChangeItemRequest createSctRequestItemWithGrammarTitle(String entryType, String symbolName,
			String dotLevel, String simpleTitleText, String reclassExpression) {
		RevisionChangeItemRequest req = new RevisionChangeItemRequest();
		req.setEntryType(entryType);
		req.setSymbolName(symbolName);
		req.setDotLevel(dotLevel);
		if (StringUtils.isNotBlank(simpleTitleText)) {
			req.setTitleGrammar(simpleTitleText);
		}
		req.setReclassTransferExpression(reclassExpression);
		return req;

	}

	
	public static RevisionChangeItemRequest createSctRequestItemWithGrammarTitle(String entryType, String symbolName,
			String dotLevel, String simpleTitleText, String reclassExpression, Boolean cpcOnly,
			String generatedIpcSymbolName, String overrideIpcSymbolName) {
		RevisionChangeItemRequest req = createSctRequestItemWithGrammarTitle(entryType, symbolName, dotLevel,
				simpleTitleText, reclassExpression);
		if ((cpcOnly != null && cpcOnly.equals(Boolean.TRUE) || (StringUtils.isNotBlank(generatedIpcSymbolName)
				|| (StringUtils.isNoneBlank(overrideIpcSymbolName))))) {
			IpcConcordanceMapping mapping = new IpcConcordanceMapping();
			mapping.setCpcOnly(false);
			if (cpcOnly != null) {
				mapping.setCpcOnly(cpcOnly);
			}
			if (StringUtils.isNotBlank(generatedIpcSymbolName)) {
				IpcSymbol generated = new IpcSymbol();
				generated.setIpcSymbolName(generatedIpcSymbolName);
				mapping.setGeneratedIpcSymbol(generated);
			}

			if (StringUtils.isNotBlank(overrideIpcSymbolName)) {
				IpcSymbol overrideSymbol = new IpcSymbol();
				overrideSymbol.setIpcSymbolName(overrideIpcSymbolName);
				mapping.setOverrideIpcSymbol(overrideSymbol);
			}
			req.setIpcSymbol(mapping);
		}
		return req;

	}




	@BeforeClass
	public static void setupClass() {
		System.setProperty("com.sun.xml.internal.stream.XMLInputFactoryImpl",
				"com.sun.xml.internal.stream.XMLInputFactoryImpl");
		 System.setProperty("jakarta.xml.parsers.DocumentBuilderFactory","com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");

	}

	@Before
	public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.emptyTables(conn);
		datasetTestingService.loadAllDatasets(conn);

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(2L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2021-09-27", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

//	        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("myoung3@uspto.gov", "myoung3@uspto.gov", Arrays
//	                .asList(new BasicTestingGrantedAuthority("test"), 
//	                		new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
		//
//	        SecurityContextHolder.getContext().setAuthentication(token);

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamy@uspto.gov", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
	}

}