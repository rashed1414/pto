package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.tree.ParseTree;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.TitleConverter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.ScriptOrientation;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartClassRef;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartRawText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import jakarta.inject.Inject;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class TitleServiceTest {
    public static Logger log = LoggerFactory.getLogger(TitleServiceTest.class);
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private TitleService titleService;
    
    
    @Before
    public void setup() {
	    System.setProperty("com.sun.xml.internal.stream.XMLInputFactoryImpl", "com.sun.xml.internal.stream.XMLInputFactoryImpl");
        System.setProperty("jakarta.xml.parsers.DocumentBuilderFactory","com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");

    }


    @Test 
    public void test1() throws RecognitionException, IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, GrammarParseException {
        TitlePartTree tree = titleService.fromGrammar("this is title part 1; title parts 2 ##BOLD## this is bold ##/BOLD## more text; Here isa a Symbol Ref A01N3/27;  I hope that works");
        Assert.assertNotNull(tree);
        Assert.assertFalse(tree.getChildren().isEmpty());
        log.debug("First Child {}", tree.getChildren());
        Assert.assertEquals(4, tree.getChildren().size());
        log.debug("HEre is first text object [{}]", tree.getChildren().get(0).getChildren().get(0).getChildren().get(0));
        Assert.assertTrue(TitlePartText.class.isAssignableFrom(tree.getChildren().get(0).getChildren().get(0).getClass()));
        Assert.assertEquals("this is title part 1",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
        Assert.assertEquals(" title parts 2 ",((TitlePartRawText)tree.getChildren().get(1).getChildren().get(0).getChildren().get(0)).getContent());
        log.debug("json {}",JsonUtils.toJson(tree));
        
        Assert.assertEquals(" this is bold ",((TitlePartRawText)tree.getChildren().get(1).getChildren().get(1).getChildren().get(0)).getContent());
        Assert.assertTrue(((TitlePartText)tree.getChildren().get(1).getChildren().get(1)).isBold());

    }


    @Test 
    public void test1SymbolRecognition() throws RecognitionException, IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, GrammarParseException {
        TitlePartTree tree = titleService.fromGrammar("Test##SYMBOL##A01N01/27##/SYMBOL##");
        Assert.assertNotNull(tree);
        Assert.assertFalse(tree.getChildren().isEmpty());
        Assert.assertEquals(1, tree.getChildren().size());
        log.debug("HEre is first text object [{}]", tree.getChildren().get(0).getChildren().get(0).getChildren().get(0));
        Assert.assertEquals("Test",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
        Assert.assertEquals("A01N01/27",((TitlePartClassRef)tree.getChildren().get(0).getChildren().get(1)).getSymbolName());
        log.debug("json {}",JsonUtils.toJson(tree));

    }

    @Test 
    public void test1SymbolRecognitionWithScheme() throws RecognitionException, IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, GrammarParseException {
        String grammarInp = "Test##SYMBOL####SCHEME##cpc##/SCHEME##A01N01/27##/SYMBOL##";
    	TitlePartTree tree = titleService.fromGrammar(grammarInp);
        Assert.assertNotNull(tree);
        Assert.assertFalse(tree.getChildren().isEmpty());
        Assert.assertEquals(1, tree.getChildren().size());
        Assert.assertEquals("Test",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
        Assert.assertEquals("A01N01/27",((TitlePartClassRef)tree.getChildren().get(0).getChildren().get(1)).getSymbolName());
        Assert.assertEquals("cpc",((TitlePartClassRef)tree.getChildren().get(0).getChildren().get(1)).getScheme());
        
        assertRoundTripSuccess(grammarInp);

    }

    @Test 
    public void testSuggestion() throws RecognitionException, IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, GrammarParseException {
        String grammarInp = "Test##SUGGESTIONSTART####SUGGESTIONSTARTNAME##cpc##/SUGGESTIONSTARTNAME####/SUGGESTIONSTART##Hello##SUGGESTIONEND####SUGGESTIONENDNAME##xxx123##/SUGGESTIONENDNAME####/SUGGESTIONEND##  Test##SYMBOL####SCHEME##cpc##/SCHEME##A01N01/27##/SYMBOL##";
    	TitlePartTree tree = titleService.fromGrammar(grammarInp);
        Assert.assertNotNull(tree);
        Assert.assertFalse(tree.getChildren().isEmpty());
        Assert.assertEquals(1, tree.getChildren().size());
        Assert.assertEquals("Test",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
//        Assert.assertEquals("A01N01/27",((TitleSuggestionStart)tree.getChildren().get(0).getChildren().get(1)).getChildren().get(0)+"");
//        Assert.assertEquals("cpc",((TitleSuggestionStart)tree.getChildren().get(0).getChildren().get(1)).getName());
//        
       // log.debug("xml={}", Xml);
        assertRoundTripSuccess(grammarInp);

    }

    
    @Test 
    public void test1AmpWithRoundtrip() throws RecognitionException, IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, GrammarParseException {
        String grammarInp = "Test & ";
    	TitlePartTree tree = titleService.fromGrammar(grammarInp);
        Assert.assertNotNull(tree);
        Assert.assertFalse(tree.getChildren().isEmpty());
        
        assertRoundTripSuccess(grammarInp);

    }

    @Test 
    public void test1SymbolRecognitionWithIPCScheme() throws RecognitionException, IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, GrammarParseException {
        String grammarInp = "Test##SYMBOL####SCHEME##ipc##/SCHEME##A01N01/27##/SYMBOL##";
    	TitlePartTree tree = titleService.fromGrammar(grammarInp);
        Assert.assertNotNull(tree);
        Assert.assertFalse(tree.getChildren().isEmpty());
        Assert.assertEquals(1, tree.getChildren().size());
        Assert.assertEquals("Test",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
        Assert.assertEquals("A01N01/27",((TitlePartClassRef)tree.getChildren().get(0).getChildren().get(1)).getSymbolName());
        Assert.assertEquals("ipc",((TitlePartClassRef)tree.getChildren().get(0).getChildren().get(1)).getScheme());
        
        assertRoundTripSuccess(grammarInp);

    }
    
    
    @Test
    public void test1SymbolRecognitionWithNotMappedScheme() throws RecognitionException, IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, GrammarParseException {
        String grammarInp = "Test##SYMBOL####SCHEME##not-mapped##/SCHEME##A01N01/27##/SYMBOL##";
    	TitlePartTree tree = titleService.fromGrammar(grammarInp);
        Assert.assertNotNull(tree);
        Assert.assertFalse(tree.getChildren().isEmpty());
        Assert.assertEquals(1, tree.getChildren().size());
        Assert.assertEquals("Test",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
        Assert.assertEquals("A01N01/27",((TitlePartClassRef)tree.getChildren().get(0).getChildren().get(1)).getSymbolName());
        Assert.assertEquals("not-mapped",((TitlePartClassRef)tree.getChildren().get(0).getChildren().get(1)).getScheme());
        
        assertRoundTripSuccess(grammarInp);

    }
    
    @Test(expected=GrammarParseException.class)
    public void test1SymbolRecognitionWithNotMappedSchemeInvalidOrder() throws RecognitionException, IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, GrammarParseException {
        String grammarInp = "Test##SYMBOL##A01N01/27##SCHEME##not-mapped##/SCHEME####/SYMBOL##";
    	titleService.fromGrammar(grammarInp);
        // This should throw an exception because the order of the attributes/sub elements matters
    	// the reason we require a certain order is so we can effectively round trip grammar to tree 
    	// and back
    }

    


//    @Test 
//    public void test1SymbolInvalidTPSep() throws RecognitionException, IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, GrammarParseException {
//        TitlePartTree tree = titleService.fromGrammar("Hand tool Testing ( this is a test ;test 2)");
//        Assert.assertNotNull(tree);
//        Assert.assertTrue(!tree.getChildren().isEmpty());
//        Assert.assertEquals(1, tree.getChildren().size());
//        log.debug("HEre is first text object [{}]", tree.getChildren().get(0).getChildren().get(0));
//        Assert.assertEquals("A01N01/27",((TitlePartClassRef)tree.getChildren().get(0).getChildren().get(0)).getSymbolName());
//        log.debug("json {}",JsonUtils.toJson(tree));
//
//    }

    @Test 
    public void test1ValidSuperScript() throws RecognitionException, IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, GrammarParseException {
        TitlePartTree tree = titleService.fromGrammar("Formula z##SUPERSCRIPT##2##/SUPERSCRIPT##");
        Assert.assertNotNull(tree);
        Assert.assertFalse(tree.getChildren().isEmpty());
        log.debug("json {}",JsonUtils.toJson(tree));
        Assert.assertEquals(1, tree.getChildren().size());
        Assert.assertEquals(2, tree.getChildren().get(0).getChildren().size());
        
        log.debug("HEre is first text object [{}]", tree.getChildren().get(0).getChildren().get(0));
        Assert.assertEquals("Formula z",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
        Assert.assertNull(((TitlePartText)tree.getChildren().get(0).getChildren().get(0)).getScriptOrientation());
        Assert.assertEquals("2",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0)).getContent());
        Assert.assertEquals(ScriptOrientation.SUPERSCRIPT,((TitlePartText)tree.getChildren().get(0).getChildren().get(1)).getScriptOrientation());
        log.debug("json {}",JsonUtils.toJson(tree));

    }


    @Test 
    public void test1SymbolRecognitionOnlyClassRef() throws RecognitionException, IOException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, GrammarParseException {
        TitlePartTree tree = titleService.fromGrammar("##SYMBOL##A01N01/27##/SYMBOL##");
        Assert.assertNotNull(tree);
        Assert.assertFalse(tree.getChildren().isEmpty());
        Assert.assertEquals(1, tree.getChildren().size());
        log.debug("HEre is first text object [{}]", tree.getChildren().get(0).getChildren().get(0));
        Assert.assertEquals("A01N01/27",((TitlePartClassRef)tree.getChildren().get(0).getChildren().get(0)).getSymbolName());
        log.debug("json {}",JsonUtils.toJson(tree));

    }

    @Test
    public void testToEarlyExitException() throws GrammarParseException {
            List<ValidationMessage> msgs = titleService.validateGrammar(") hi");
            Assert.assertEquals(1, msgs.size());
            Assert.assertEquals("Unexpected text ')' found", msgs.get(0).getMessageText());
    }

    @Test(expected= GrammarParseException.class)
    public void testGenerateExceptionForClearlyBadTitle() throws GrammarParseException, InterruptedException {
        String badTitle = "Here is titlepart 1;(reference text with no ending parenthesis";
        TitlePartTree xml = titleService.fromGrammar(badTitle);
    }

    @Test
    public void testNoTokenMismatch() {
        List<ValidationMessage> msgs = titleService.validateGrammar("Test (##UNDERLINE##Test)##/UNDERLINE##");
        Assert.assertEquals("Expected '##/UNDERLINE##' but found ')'", msgs.get(0).getMessageText());
        Assert.assertEquals(1, msgs.size());
        

    }
    
    @Test
    public void testFromGrammar() throws JsonGenerationException, JsonMappingException, IOException, GrammarParseException {
        TitlePartTree tree = titleService.fromGrammar("this is title part 1; title parts 2 ##BOLD## this is bold ##/BOLD## more text; Here isa a Symbol Ref A01N3/27;  I hope that works");
        Assert.assertNotNull(tree);
        Assert.assertFalse(tree.getChildren().isEmpty());
        //log.debug("First Child {}", tree.getChildren());
        Assert.assertEquals(4, tree.getChildren().size());
      //  log.debug("HEre is first text object [{}]", tree.getChildren().get(0).getChildren().get(0).getChildren().get(0));
        Assert.assertTrue(TitlePartText.class.isAssignableFrom(tree.getChildren().get(0).getChildren().get(0).getClass()));
        Assert.assertEquals("this is title part 1",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
        Assert.assertEquals(" title parts 2 ",((TitlePartRawText)tree.getChildren().get(1).getChildren().get(0).getChildren().get(0)).getContent());
        /**
         * 
         * 
         * <?xml version="1.0" encoding="UTF-8"?><class-title><title-part><text>this is title part 1</text>
         *      </title-part><title-part><text> title parts 2 </text>
         *          <b> this is bold </b><text> more text</text></title-part>
         *          <title-part><text> Here isa a Symbol Ref A01N3/27</text>
         *          </title-part><title-part><text>  I hope that works</text></title-part>
         * </class-title>
         * 
         * <?xml version="1.0" encoding="UTF-8"?><class-title><title-part><text>this is title part 1</text>
         *      </title-part><title-part><text> title parts 2 </text>
         *      <b><text> this is bold </text></b><text> more text</text></title-part><title-part><text> Here isa a Symbol Ref A01N3/27</text></title-part><title-part><text>  I hope that works</text></title-part></class-title>

         * 

         */
        
        //Assert.assertEquals(" this is bold ",((TitlePartRawText)tree.getChildren().get(1).getChildren().get(1).getChildren().get(0)).getContent());
        log.debug("Element Type: {}",tree.getChildren().get(1).getChildren().get(1).getClass());
        log.debug("Content: {}",(tree.getChildren().get(2).getChildren().get(0)));
        Assert.assertTrue(((TitlePartText)tree.getChildren().get(1).getChildren().get(1)).isBold());
        Assert.assertEquals(" this is bold ",((TitlePartRawText)tree.getChildren().get(1).getChildren().get(1).getChildren().get(0)).getContent());
        Assert.assertEquals(" more text",((TitlePartRawText)tree.getChildren().get(1).getChildren().get(2).getChildren().get(0)).getContent());
        
        Assert.assertEquals(" Here isa a Symbol Ref A01N3/27",((TitlePartRawText)tree.getChildren().get(2).getChildren().get(0).getChildren().get(0)).getContent());

        Assert.assertEquals("  I hope that works",((TitlePartRawText)tree.getChildren().get(3).getChildren().get(0).getChildren().get(0)).getContent());
          
        ObjectMapper mapper = new ObjectMapper();
        mapper.writer().writeValue(System.out, tree);
        
    }

    
    @Test
    public void testFromGrammarNestedBold() throws JsonGenerationException, JsonMappingException, IOException, GrammarParseException {
        TitlePartTree tree = titleService.fromGrammar("this is title part 1##BOLD## This is ##UNDERLINE## underlined text##/UNDERLINE## H##SUBSCRIPT##2##/SUBSCRIPT##O##/BOLD##");
        Assert.assertNotNull(tree);
        Assert.assertFalse(tree.getChildren().isEmpty());
        

        ObjectMapper mapper = new ObjectMapper();
        mapper.writer().writeValue(System.out, tree);
        
        //log.debug("First Child {}", tree.getChildren());
        Assert.assertEquals(1, tree.getChildren().size());
      //  log.debug("HEre is first text object [{}]", tree.getChildren().get(0).getChildren().get(0).getChildren().get(0));
        Assert.assertTrue(TitlePartText.class.isAssignableFrom(tree.getChildren().get(0).getChildren().get(0).getClass()));
        Assert.assertEquals("this is title part 1",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
        Assert.assertEquals(" This is ",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0)).getContent());
        Assert.assertTrue(((TitlePartText)tree.getChildren().get(0).getChildren().get(1)).isBold());
        
        Assert.assertEquals(" underlined text",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(1).getChildren().get(0)).getContent());

    }
    
    
    @Test
    public void testSemiColonInReferenceFromGrammar() throws GrammarParseException{
		TitlePartTree tree = titleService.fromGrammar(
				"PLANTING;SOWING;FERTILISING (combined with general working of soil A01B49/04; parts, details or accessories of agricultural machines or implements, in general A01B51/00 - A01B75/00; {apparatus for spreading sand or salt E01C; sowing and fertilising with aircraft B64D1/16 - B64D1/20})");
    	Assert.assertNotNull(tree);
    	Assert.assertFalse(tree.getChildren().isEmpty());
    	Assert.assertEquals(3, tree.getChildren().size());
    	Assert.assertTrue(TitlePartText.class.isAssignableFrom(tree.getChildren().get(0).getChildren().get(0).getClass()));
    	Assert.assertEquals("PLANTING",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
    }

    @Test
    public void testRoundTrip() throws GrammarParseException {
    	String titleGrammar = "PLANTING;SOWING;FERTILISING (combined with general working of soil A01B49/04; parts, details or accessories of agricultural machines or implements, in general A01B51/00 - A01B75/00; {apparatus for spreading sand or salt E01C; sowing and fertilising with aircraft B64D1/16 - B64D1/20})";
    	assertRoundTripSuccess(titleGrammar);    	
    	Assert.assertTrue(Boolean.TRUE); // Added because sonar is too stupid to see asserts called in other methods.
    }

    
    private void assertRoundTripSuccess(String titleGrammar) throws GrammarParseException {
    	ParseTree antlrTree = TitleConverter.parseTree(titleGrammar);
		String xml = TitleConverter.toTree(antlrTree, null); // parent is always null for root
		Assert.assertNotEquals(titleGrammar, xml);
		TitlePartTree tree = titleService.fromGrammar(titleGrammar);
		Assert.assertNotNull(tree);
		String derivedGrammar = TitleConverter.toGrammar(tree);
		log.debug("derived grammar {}", derivedGrammar);
		Assert.assertEquals(titleGrammar, derivedGrammar);
	}
    
    @Test
    public void testValidSeriialization() throws JsonGenerationException, JsonMappingException, IOException, GrammarParseException, JAXBException {
    	TitlePartTree tree = titleService.fromGrammar(
				"PLANTING;SOWING;FERTILISING (combined with general working of soil A01B49/04; parts, details or accessories of agricultural machines or implements, in general A01B51/00 - A01B75/00; {apparatus for spreading sand or salt E01C; sowing and fertilising with aircraft B64D1/16 - B64D1/20})");

//        ObjectMapper mapper = new ObjectMapper();
//        mapper.writer().writeValue(System.out, tree);
//        
        JAXBContext ctx = JaxbUtils.initJAXBContext(tree.getClass());
        Assert.assertNotNull(ctx);
        Marshaller m =ctx.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        m.marshal(tree, System.out);
    	
    }

}
