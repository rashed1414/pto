package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.Arrays;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.ValidatedList;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentApprovalRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentApproverRole;
import jakarta.inject.Inject;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalDocumentControllerVolatileTest  {
    private static final Logger log = LoggerFactory.getLogger(ProposalDocumentControllerVolatileTest.class);
    
    @Inject
    private ProposalDocumentController proposalDocumentController;
    
    @Inject
    private DatasetTestingService datasetTestingService;  
   
    
    
//    @Test
//    public void testSaveAsNew() {
//        
//        ProposalDocument doc = new ProposalDocument();
//        doc.setComment("First Doc");
//        doc.setDocumentType(ProposalDocumentTypeCode.EBL);
//        doc.setIpOfficeCode(StandardIpOfficeCode.US);
//        doc.setName("TEST.TWL");
//        doc.setResourceId(UUID.randomUUID());
//        doc.setVersion(ProposalDocumentVersionClassificationCode.Final);
//        
//      
//
//        ResponseEntity<Void> resp =proposalDocumentController.saveAsNew(GUIDUtils.fromDatabaseFormat("5578f1c578d64e2887af1a27bb789ff2"), doc);
//        assertEquals(HttpStatus.CREATED, resp.getStatusCode());
//        assertNotNull(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER));
//
//        assertNotNull(resp.getHeaders().get(HttpHeaders.LOCATION));
//    }

    @Test
    @Transactional
    public void testSaveOrUpdateApproval_new() {
        
        ProposalDocumentApprovalRequest approval = new ProposalDocumentApprovalRequest();
        approval.setComment("new approval");
        approval.setApproved(true);
        approval.setIpOfficeCode(StandardIpOfficeCode.EP);
        approval.setProposerRoleCode(ProposalDocumentApproverRole.PC);


        ValidatedList approvals =  new ValidatedList<>();
        approvals.add(approval);
        
        ResponseEntity<Void> resp =proposalDocumentController.saveOrUpdateApproval(
                GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7"),
                GUIDUtils.fromDatabaseFormat("a960b30c52a172ac8c37b64dfcc0ea21"),approvals);
        assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
        assertNotNull(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER));

        assertNotNull(resp.getHeaders().get(HttpHeaders.LOCATION));
    }
    
    @Test
    @Transactional
    public void testSaveOrUpdateApproval_newPB() {
        
        ProposalDocumentApprovalRequest approval = new ProposalDocumentApprovalRequest();
        approval.setComment("new approval");
        approval.setApproved(true);
        approval.setIpOfficeCode(StandardIpOfficeCode.EP);
        approval.setProposerRoleCode(ProposalDocumentApproverRole.PB);


        ValidatedList approvals =  new ValidatedList<>();
        approvals.add(approval);
        
        ResponseEntity<Void> resp =proposalDocumentController.saveOrUpdateApproval(
                GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7"),
                GUIDUtils.fromDatabaseFormat("a960b30c52a172ac8c37b64dfcc0ea21"),approvals);
        assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
        assertNotNull(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER));

        assertNotNull(resp.getHeaders().get(HttpHeaders.LOCATION));
    }
    
    @Test
    @Transactional
    public void testSaveOrUpdateApproval_newPB_emptyComment() {
        
        ProposalDocumentApprovalRequest approval = new ProposalDocumentApprovalRequest();
       
        approval.setApproved(true);
        approval.setIpOfficeCode(StandardIpOfficeCode.EP);
        approval.setProposerRoleCode(ProposalDocumentApproverRole.PB);


        ValidatedList approvals =  new ValidatedList<>();
        approvals.add(approval);
        
        ResponseEntity<Void> resp =proposalDocumentController.saveOrUpdateApproval(
                GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7"),
                GUIDUtils.fromDatabaseFormat("a960b30c52a172ac8c37b64dfcc0ea21"),approvals);
        assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
        assertNotNull(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER));

        assertNotNull(resp.getHeaders().get(HttpHeaders.LOCATION));
    }
    
    @Test
    @Transactional
    public void testSaveOrUpdateApproval_newPM() {
        
        ProposalDocumentApprovalRequest approval = new ProposalDocumentApprovalRequest();
        approval.setComment("new approval");
        approval.setApproved(true);
        approval.setIpOfficeCode(StandardIpOfficeCode.US);
        approval.setProposerRoleCode(ProposalDocumentApproverRole.PM);


        ValidatedList approvals =  new ValidatedList<>();
        approvals.add(approval);
        
        ResponseEntity<Void> resp =proposalDocumentController.saveOrUpdateApproval(
                GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7"),
                GUIDUtils.fromDatabaseFormat("a960b30c52a172ac8c37b64dfcc0ea21"),approvals);
        assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
        assertNotNull(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER));

        assertNotNull(resp.getHeaders().get(HttpHeaders.LOCATION));
    }

    @Test
    @Transactional
    public void testSaveOrUpdateApproval_update() {
        
        ProposalDocumentApprovalRequest approval = new ProposalDocumentApprovalRequest();
        approval.setId(GUIDUtils.fromDatabaseFormat("baac7faa26c048ab9c47aedf02f0ad3b"));
        approval.setComment("changed it");
        approval.setApproved(false);
        approval.setIpOfficeCode(StandardIpOfficeCode.EP);
        approval.setProposerRoleCode(ProposalDocumentApproverRole.EB);

        ValidatedList approvals =  new ValidatedList<>();
        approvals.add(approval);
        
        ResponseEntity<Void> resp =proposalDocumentController.saveOrUpdateApproval(
                GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                GUIDUtils.fromDatabaseFormat("c960d30a52a852ac8c51b64dfcc0ea41"),approvals);
        assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
        assertNotNull(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER));

        assertEquals(approval.getId().toString(),
                resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
        assertEquals("http://localhost:8080/cpcipcrestweb/proposals/c960d30a-52a8-47fc-8c51-b64dfcc0ea85/documents/c960d30a-52a8-52ac-8c51-b64dfcc0ea41/approvals",
                resp.getHeaders().get(HttpHeaders.LOCATION).get(0));
    }
    
    @Test
    @Transactional
    public void testSaveOrUpdateApproval_updatefail_wrongid() {
        
        ProposalDocumentApprovalRequest approval = new ProposalDocumentApprovalRequest();
        approval.setId(GUIDUtils.fromDatabaseFormat("aaaa7faa26c048ab9c47aedf02f0ad3b"));
        approval.setComment("changed it");
        approval.setApproved(false);
        approval.setIpOfficeCode(StandardIpOfficeCode.EP);
        approval.setProposerRoleCode(ProposalDocumentApproverRole.EB);


        ValidatedList approvals =  new ValidatedList<>();
        approvals.add(approval);
        
        try {
            proposalDocumentController.saveOrUpdateApproval(
                GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                GUIDUtils.fromDatabaseFormat("c960d30a52a852ac8c51b64dfcc0ea41"),approvals);
            fail();
        } catch (Exception e) {
            assertEquals(IllegalArgumentException.class, e.getClass());
            assertEquals("Office EP and Proposer Role EB already exists with a different GUID (baac7faa-26c0-48ab-9c47-aedf02f0ad3b)", e.getMessage());
        }
    }

    @Test
    @Transactional
    public void testSaveOrUpdateApproval_updatefail_mismatchedkey() {
        
        ProposalDocumentApprovalRequest approval = new ProposalDocumentApprovalRequest();
        approval.setId(GUIDUtils.fromDatabaseFormat("baac7faa26c048ab9c47aedf02f0ad3b"));
        approval.setComment("changed it");
        approval.setApproved(false);
        approval.setIpOfficeCode(StandardIpOfficeCode.EP);
        approval.setProposerRoleCode(ProposalDocumentApproverRole.PC);


        ValidatedList approvals =  new ValidatedList<>();
        approvals.add(approval);
        
        try {
            proposalDocumentController.saveOrUpdateApproval(
                GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                GUIDUtils.fromDatabaseFormat("c960d30a52a852ac8c51b64dfcc0ea41"),approvals);
            fail();
        } catch (Exception e) {
            assertEquals(EntityNotFoundException.class, e.getClass());
            assertEquals("Approval ID baac7faa-26c0-48ab-9c47-aedf02f0ad3b does not exist to modify with the IP office EP and Proposer Role PC", e.getMessage());
        }
    }
    
    @Test
    public void testArchiveDocument() {       
            
        ResponseEntity<Void> resp = proposalDocumentController.updateExistingDocument(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
        		GUIDUtils.fromDatabaseFormat("c960d30a52a852fc8c51b64dfcc0ea85"), true);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
               
    }
    
    
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
    			"bkuppusamy", "Boops","Kuppusamy", "US");
    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"boopathi.kuppusamy@uspto.gov", token,
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }

    
    
}