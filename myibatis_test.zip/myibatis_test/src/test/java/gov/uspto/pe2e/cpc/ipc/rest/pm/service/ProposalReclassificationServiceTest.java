package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposal;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ReclassProgress;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ReclassProgressRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassFamilyCount;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalReclassificationServiceTest {
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ReclassProgressRepository reclassProgressRepository;
    
    @Inject
    private ChangeProposalRepository changeProposalRepository;
    
    @Inject
    private ProposalReclassificationService proposalReclassificationService;
    
    @Inject
    public SecurityService securityService;
    

    @Test
    @Transactional
    public void testSaveFamilyCountToDB() {
    	
    	HttpHeaders headers = RestUtils.buildErrorHttpHeaders();
		UsptoAuthenticationToken authToken = securityService
				.mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());
		
		ChangeProposal cp = changeProposalRepository.findById((long) 1000000001).get();
		
		ReclassFamilyCount familyCount = new ReclassFamilyCount();
		
		familyCount.setTotalAdminFamilies(1000);
		familyCount.setTotalIntelFamilies(2000);
		familyCount.setUsAdminFamilies(1000);
		familyCount.setEpAdminFamilies(2000);
		familyCount.setNoAdminFamilies(3000);
		
		familyCount.setUsIntelFamilies(1000);
		familyCount.setEpIntelFamilies(2000);
		familyCount.setNoIntelFamilies(3000);
		
    	proposalReclassificationService.saveFamilyCountToDb(cp, familyCount, authToken);
    	
    	List<ReclassProgress> reclassProgress = reclassProgressRepository.findAllByCreateUserId(authToken.getEmail());
    	
    	assertNotNull(reclassProgress);
    }
  
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
                "bkuppusamy", "Boops","Kuppusamy", "US");
            UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "boopathi.kuppusamy@uspto.gov", token,
                Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
                        new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
                        new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
        SecurityContextHolder.getContext().setAuthentication(springUser);  

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/proposals/xxx/twl")));
    }

}
