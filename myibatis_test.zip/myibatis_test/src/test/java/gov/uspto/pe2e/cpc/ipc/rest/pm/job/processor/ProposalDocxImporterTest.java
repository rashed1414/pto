package gov.uspto.pe2e.cpc.ipc.rest.pm.job.processor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.docx4j.openpackaging.exceptions.Docx4JException;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.wml.Tbl;
import org.docx4j.wml.Tc;
import org.docx4j.wml.Tr;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DirectoryUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.DocxUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartRawText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalImportHelper;
import jakarta.inject.Inject;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalDocxImporterTest {
	private static final Logger log = LoggerFactory.getLogger(ProposalDocxImporterTest.class);
	private static final JAXBContext CTX = JaxbUtils.initJAXBContext(TitlePartTree.class);
	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private ProposalImportHelper proposalImportHelper;
	
	//Commented this test due to jenkin environment problem, revert when issue resolved.
	/*@Test
	public void testParseTitle() throws Docx4JException, JAXBException, JsonGenerationException, JsonMappingException, IOException {
		String filepath = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader()
				.getResource("data/docx/sct_basic_parsetitle.docx").getFile());
		log.debug("using {}", filepath);
		WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new java.io.File(filepath));
		MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
		int rowIdx = 0;
		List<Tbl> tables = DocxUtils.search(documentPart, Tbl.class);
		
		List<Tr> rows = DocxUtils.search(tables.get(0), Tr.class);
		TitlePartTree tree = proposalImportHelper.parseTitle(DocxUtils.search(rows.get(1), Tc.class).get(ValidationMessageField.TITLE.ordinal()));
		log.debug(JsonUtils.toJson(tree));
		Assert.assertNotNull(tree);
		Assert.assertEquals("Hello This is a Chemical symbol (H", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
        Assert.assertNull(((TitlePartText)tree.getChildren().get(0).getChildren().get(0)).getScriptOrientation());

		log.debug(((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(1).getChildren().get(0)).getContent());
		Assert.assertEquals("2", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(1).getChildren().get(0)).getContent());
	    Assert.assertEquals(ScriptOrientation.SUBSCRIPT, ((TitlePartText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(1)).getScriptOrientation());
	    Assert.assertEquals("O) ", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(2)).getContent());
		
		Assert.assertEquals(" cpc text got trimmed ", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(2).getChildren().get(0)).getContent());
        Assert.assertEquals("this text is CPC-only. I have a symbol ", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0).getChildren().get(0)).getContent());
        Assert.assertEquals("A01N01/1751", ((TitlePartClassRef)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0).getChildren().get(1)).getSymbolName());
        Assert.assertEquals(" and a formula CO", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0).getChildren().get(2)).getContent());
        Assert.assertEquals("2", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0).getChildren().get(3).getChildren().get(0)).getContent());
        Assert.assertEquals(ScriptOrientation.SUBSCRIPT, ((TitlePartText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0).getChildren().get(3)).getScriptOrientation());
		Assert.assertEquals(" There is N", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0).getChildren().get(4)).getContent());
		Assert.assertEquals("19", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0).getChildren().get(5).getChildren().get(0)).getContent());
		Assert.assertEquals(" value", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0).getChildren().get(6)).getContent());
		Assert.assertEquals("cpc", ((TitlePartText)tree.getChildren().get(0).getChildren().get(1)).getScheme());
		Assert.assertEquals(" cpc text got trimmed ", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(2).getChildren().get(0)).getContent());

		Assert.assertEquals("Test12 67010120 hello",((TitlePartRawText)tree.getChildren().get(0).getChildren().get(2).getChildren().get(1).getChildren().get(0)).getContent());
        Assert.assertEquals(ScriptOrientation.SUBSCRIPT,((TitlePartText)tree.getChildren().get(0).getChildren().get(2).getChildren().get(1)).getScriptOrientation());

//		Assert.assertEquals("This is a Paragraph",  ((TitlePartRawText)tree.getChildren().get(1).getChildren().get(0).getChildren().get(0)).getContent());
//		Assert.assertEquals("This is another P",  ((TitlePartRawText)tree.getChildren().get(2).getChildren().get(0).getChildren().get(0)).getContent());

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Marshaller m =CTX.createMarshaller();
		m.marshal(tree, baos);
		log.debug("{}",baos.toString());
		
		ObjectMapper mapper = new ObjectMapper();
		baos = new ByteArrayOutputStream();
		mapper.writeValue(baos, tree);
		log.debug("{}",baos.toString());
	}*/

	   @Test
	   public void testParseTitleCpcTitles() throws Docx4JException, JAXBException, JsonGenerationException, JsonMappingException, IOException {
	        String filepath = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader()
	                .getResource("data/docx/sct_basic_parsetitle_cpconlytext.docx").getFile());
	        log.debug("using {}", filepath);
	        WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new java.io.File(filepath));
	        MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
	        int rowIdx = 0;
	        List<Tbl> tables = DocxUtils.search(documentPart, Tbl.class);
	        
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();
	        List<Tr> rows = DocxUtils.search(tables.get(0), Tr.class);
	        TitlePartTree tree = proposalImportHelper.parseTitle(DocxUtils.search(rows.get(1), Tc.class).get(ValidationMessageField.TITLE.ordinal()));
	        Assert.assertNotNull(tree);

            ObjectMapper mapper = new ObjectMapper();
            baos = new ByteArrayOutputStream();
            mapper.writeValue(baos, tree);
            log.debug("{}",baos.toString());
	        Assert.assertEquals("Hello ", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());

//	        Assert.assertEquals("Hello ", ((TitlePartRawText)tree.getChildren().get(1).getChildren().get(1).getChildren().get(0)).getContent());

//	        Assert.assertEquals(" ", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0)).getContent());

	        //TODO fix these after whitespace has been corrected
	        //Assert.assertEquals("this text is CPC-only", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0).getChildren().get(0)).getContent());
	      
	        baos = new ByteArrayOutputStream();
	        Marshaller m =CTX.createMarshaller();
	        m.marshal(tree, baos);
	        log.debug("{}",baos.toString());
   	    }


	   @Test
	   public void testParseTitleCpcTitles2() throws Docx4JException, JAXBException, JsonGenerationException, JsonMappingException, IOException {
	        String filepath = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader()
	                .getResource("data/docx/sct_basic_parsetitle_cpconlytext2.docx").getFile());
	        log.debug("using {}", filepath);
	        WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new java.io.File(filepath));
	        MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
	        int rowIdx = 0;
	        List<Tbl> tables = DocxUtils.search(documentPart, Tbl.class);
	        
	        List<Tr> rows = DocxUtils.search(tables.get(0), Tr.class);
	        TitlePartTree tree = proposalImportHelper.parseTitle(DocxUtils.search(rows.get(3), Tc.class).get(ValidationMessageField.TITLE.ordinal()));
	        Assert.assertNotNull(tree);
	        
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();
	        ObjectMapper mapper = new ObjectMapper();
	        baos = new ByteArrayOutputStream();
            mapper.writeValue(baos, tree);
            log.debug("{}",baos.toString());
            //TODO: Fix these when whitespace have been fixed
//	        Assert.assertEquals("based on BaTiO3 perovskite phase", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());

//	        Assert.assertEquals(" ", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0)).getContent());

          //  Assert.assertEquals(" perovskite phase", ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(3).getChildren().get(0)).getContent());
	      
//	        ByteArrayOutputStream baos = new ByteArrayOutputStream();
	        Marshaller m =CTX.createMarshaller();
	        m.marshal(tree, baos);
	        log.debug("{}",baos.toString());
	        
	        baos = new ByteArrayOutputStream();
	        mapper.writeValue(baos, tree);
	        log.debug("{}",baos.toString());
	    }

	   /*
	   @Test
	   public void test(){
		   
		   try{
		        
		            String filepath = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader()
		                    .getResource("data/docx/track_changes.docx").getFile());
		            WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new java.io.File(filepath));
		            MainDocumentPart mainDocumentPart = wordMLPackage.getMainDocumentPart();

		            List<?> revisionInsList = mainDocumentPart.getJAXBNodesViaXPath("//w:ins", true);
		            
		            for (Object obj : revisionInsList) {
		               System.out.println("--------------INSERT----------");
		               RunIns ins = (org.docx4j.wml.RunIns) obj;
		               System.out.println("Author:" + ins.getAuthor());
		               System.out.println("id(position):" + ins.getId());
		               System.out.println("Date:" + ins.getDate());
		               List<Object> listR = ins.getCustomXmlOrSmartTagOrSdt();
		               for (Object aListR : listR) {
		                  R r = ((R) aListR);
		                  //System.out.println(r);
		                  printRevision(r);
		               }
		            }
		             
		            List<?> revisionDelList = mainDocumentPart.getJAXBNodesViaXPath("//w:del", false);
		             
		            for (Object obj : revisionDelList) {
		               System.out.println("--------------DELETE----------");
		               RunDel del = (org.docx4j.wml.RunDel) obj;
		               System.out.println("Author:" + del.getAuthor());
		               System.out.println("id(position):" + del.getId());
		               System.out.println("Date:" + del.getDate());
		             
		               List<Object> listR = del.getCustomXmlOrSmartTagOrSdt();
		               for (Object aListR : listR) {
		                  R r = ((R) aListR);
		                 // System.out.println(r);
		                  printRevision(r);
		               }
		            }
				}catch(Exception e){
					e.printStackTrace();
				}
		   
	   }
	   
	   public static void printRevision(R r){
		    Object objInternal = r.getContent();
		    if(objInternal instanceof JAXBElement){
		        System.out.println(((JAXBElement) objInternal).getValue());
		    } else if (objInternal instanceof ArrayList){
		        for (int j = 0; j < ((ArrayList) objInternal).size() ; j++) {
		            Object objDeleteInternal = ((ArrayList) objInternal).get(j);
		            if(objDeleteInternal instanceof Text){
		                System.out.println(((Text)objDeleteInternal).getValue());
		            } else if(objDeleteInternal instanceof DelText) {
		                System.out.println(((DelText)objDeleteInternal).getValue());
		            } else {
		                JAXBElement jab = (JAXBElement) ((ArrayList) objInternal).get(j);
		                Text t = (Text)jab.getValue();
		                System.out.println(t.getValue());
		            }
		        }
		    }
		}
		
		*/
	   
    @Test
    public void testParseTitleCpcTextNoLinebreaks()
            throws Docx4JException, JAXBException, JsonGenerationException, JsonMappingException, IOException {
        String filepath = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader()
                .getResource("data/docx/sct_basic_parsetitle_cpctext_nobreaks.docx").getFile());
        log.debug("using {}", filepath);
        WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new java.io.File(filepath));
        MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
        int rowIdx = 0;
        List<Tbl> tables = DocxUtils.search(documentPart, Tbl.class);

        List<Tr> rows = DocxUtils.search(tables.get(0), Tr.class);
        TitlePartTree tree = proposalImportHelper
                .parseTitle(DocxUtils.search(rows.get(1), Tc.class).get(ValidationMessageField.TITLE.ordinal()));
        Assert.assertNotNull(tree);
        Assert.assertEquals("This is not CPC text ({this is})",
                ((TitlePartRawText) tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());
//        Assert.assertEquals("This is not CPC text ({this is})",
//                ((TitlePartRawText)tree.getChildren().get(1).getChildren().get(1).getChildren().get(0)).getContent());
       
        // Assert.assertEquals(" ",
        // ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0)).getContent());

        // Assert.assertEquals(" perovskite phase",
        // ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(3).getChildren().get(0)).getContent());

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Marshaller m = CTX.createMarshaller();
        m.marshal(tree, baos);
        log.debug("{}", baos.toString());

        ObjectMapper mapper = new ObjectMapper();
        baos = new ByteArrayOutputStream();
        mapper.writeValue(baos, tree);
        log.debug("{}", baos.toString());
        

        tree = proposalImportHelper
                .parseTitle(DocxUtils.search(rows.get(2), Tc.class).get(ValidationMessageField.TITLE.ordinal()));
        Assert.assertNotNull(tree);
        Assert.assertEquals("Junk ({H",
                ((TitlePartRawText) tree.getChildren().get(0).getChildren().get(0).getChildren().get(0)).getContent());

//        Assert.assertEquals("Junk ({H",
//                ((TitlePartRawText) tree.getChildren().get(1).getChildren().get(1).getChildren().get(0)).getContent());
//        Assert.assertEquals("(",
//                ((TitlePartRawText) tree.getChildren().get(0).getChildren().get(1).getChildren().get(0)).getContent());
//        Assert.assertEquals("2",
//                ((TitlePartRawText) tree.getChildren().get(0).getChildren().get(2).getChildren().get(0)).getContent());
//        Assert.assertEquals("O",
//                ((TitlePartRawText) tree.getChildren().get(0).getChildren().get(3).getChildren().get(0)).getContent());
//        Assert.assertEquals(")",
//                ((TitlePartRawText) tree.getChildren().get(0).getChildren().get(4).getChildren().get(0)).getContent());
//        Assert.assertEquals(" junk",
//                ((TitlePartRawText) tree.getChildren().get(0).getChildren().get(5).getChildren().get(0)).getContent());

        // Assert.assertEquals(" ",
        // ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(1).getChildren().get(0)).getContent());

        // Assert.assertEquals(" perovskite phase",
        // ((TitlePartRawText)tree.getChildren().get(0).getChildren().get(3).getChildren().get(0)).getContent());

        baos = new ByteArrayOutputStream();
        m.marshal(tree, baos);
        log.debug("{}", baos.toString());

        baos = new ByteArrayOutputStream();
        mapper.writeValue(baos, tree);
        log.debug("{}", baos.toString());

    }   
	   
	   
	@Before
	public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.emptyTables(conn);
		datasetTestingService.loadAllDatasets(conn);

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

	}
	
  

}
