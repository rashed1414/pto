package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNot.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.WmsPhases;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.StandardSchemeRelease;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.StandardSchemeReleaseRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.publication.v1_0.GlobalPublication;
import gov.uspto.pe2e.cpc.ipc.rest.contract.publication.v1_0.PageableGlobalPublication;
import gov.uspto.pe2e.cpc.ipc.rest.contract.publication.v1_0.PublicationDocument;
import gov.uspto.pe2e.cpc.ipc.rest.contract.publication.v1_0.PublicationUserRole;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.GlobalPublicationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalService;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class GlobalPublicationControllerTest {

	@Inject
	private StandardSchemeReleaseRepository standardSchemeReleaseRepository;

	@Inject
	private GlobalPublicationController globalPublicationController;

	@Inject
	private DatasetTestingService datasetTestingService;
		
	private List<StandardSchemeRelease> generateDateList() {
		Date since = new DateTime("2022-08-01").toDate();
		return standardSchemeReleaseRepository.findSchemeReleasesSince(since);
	}


	@Transactional
	@Test
	public void testGetGlobalPubList() {

		ResponseEntity<PageableGlobalPublication> response = globalPublicationController.getGlobalPubList(null, null, null, null, null, null,
				null, null);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		List<GlobalPublication> globalPubList = response.getBody().getList();
		assertEquals(4, globalPubList.size());
		List<PublicationDocument> pubDocs = globalPubList.get(0).getPublicationDocuments();
		assertFalse(CollectionUtils.isEmpty(pubDocs));
		assertEquals(2, pubDocs.get(0).getDocAnx().intValue());
		assertEquals("TestFile.xlsx", pubDocs.get(0).getDocName());
		assertEquals("Test comment", pubDocs.get(0).getComments());
		assertEquals("CICL", pubDocs.get(0).getDocType());
		assertEquals("Final", pubDocs.get(0).getDocVersion());
		assertEquals("US", pubDocs.get(0).getIpOfficeCode().name());
		assertEquals("PI", pubDocs.get(0).getPubPhase());
		assertNotNull(pubDocs.get(0).getCreateTs());
		assertEquals("Y", pubDocs.get(0).getEpebApprovalIndicator());
		assertEquals("Y", pubDocs.get(0).getEppcApprovalIndicator());
		assertEquals("Y", pubDocs.get(0).getUspcApprovalIndicator());
		assertEquals("Y", pubDocs.get(0).getUsebApprovalIndicator());
		assertEquals("N", pubDocs.get(0).getUspubApprovalIndicator());
		
	}
	
	@Test
	public void testFindReleaseDatesByType() {
		
		StandardSchemeReleaseRepository repository  = spy(StandardSchemeReleaseRepository.class);
		    	when(repository.findSchemeReleasesSince(any()))
		    	.thenReturn(generateDateList());

		GlobalPublicationService service = new GlobalPublicationService(repository, 
				mock(ChangeProposalRepository.class),
				mock(ProposalService.class));
		
		GlobalPublicationController mockProposalController = new GlobalPublicationController(
				mock(ProposalService.class), 
				service, 
				mock(SecurityService.class));
		
		ResponseEntity<List<Date>> resp =  mockProposalController.findReleaseDates();
		assertNotNull(resp);
		assertEquals(HttpStatus.OK, resp.getStatusCode());
		assertThat(resp.getBody(), is(not(empty())));
		assertEquals(13, resp.getBody().size());

		
	}

	
	
	@Transactional
	@Test
	public void testGetGlobalPubList_byPublicationDate() {
      
		ResponseEntity<PageableGlobalPublication> response = globalPublicationController.getGlobalPubList(null, null, null, null, null, null,
				null, Arrays.asList(new DateTime("2023-01-01").toDate()));
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		List<GlobalPublication> globalPubList = response.getBody().getList();
		assertEquals(3, globalPubList.size());
		
		
	}
	
	@Transactional
	@Test
	public void testGetGlobalPubListPIPhase() {

		ResponseEntity<PageableGlobalPublication> response = globalPublicationController.getGlobalPubList(null, null, null, null, ProposalPhase.PI, null,
				null, null);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		List<GlobalPublication> globalPubList = response.getBody().getList();
		assertEquals(ProposalPhase.PI.name() ,globalPubList.get(0).getPhase().name());
		assertEquals(WmsPhases.PI.getPhaseName() ,globalPubList.get(0).getPhaseName());
		assertNotNull(globalPubList.get(0).getProposalStatus());
		assertEquals(2, globalPubList.size());		
	}
	
	@Transactional
	@Test
	public void testGetGlobalPubListPFPhase() {

		ResponseEntity<PageableGlobalPublication> response = globalPublicationController.getGlobalPubList(null, null, null, null, ProposalPhase.PF, null,
				null, null);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		List<GlobalPublication> globalPubList = response.getBody().getList();
		assertEquals(2, globalPubList.size());
		assertEquals(ProposalPhase.PF.name() ,globalPubList.get(0).getPhase().name());
		assertEquals(WmsPhases.PF.getPhaseName()  ,globalPubList.get(0).getPhaseName());
		
	}
	
	@Transactional
	@Test
	public void testGetGlobalPubListPubWriter() {

		ResponseEntity<PageableGlobalPublication> response = globalPublicationController.getGlobalPubList(null, null, null, null, null, PublicationUserRole.PUB_WRITER_EDITOR,
				"msingh@uspto.gov", null);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		List<GlobalPublication> globalPubList = response.getBody().getList();
		assertEquals(2, globalPubList.size());
		
	}
	@Transactional
	@Test
	public void testGetGlobalPubListPubSpecialist() {

		ResponseEntity<PageableGlobalPublication> response = globalPublicationController.getGlobalPubList(null, null, null, null, null, PublicationUserRole.PUB_SPECIALIST,
				"msingh@uspto.gov", null);
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		List<GlobalPublication> globalPubList = response.getBody().getList();
		assertEquals(1, globalPubList.size());
		
	}

	@Before
	public void setUp() throws Exception {
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		DateTimeZone.setDefault(DateTimeZone.UTC);

		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.emptyTables(conn);
		datasetTestingService.loadAllDatasets(conn);

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamy@uspto.gov", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
	}
}