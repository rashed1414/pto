package gov.uspto.pe2e.cpc.ipc.rest.pm.service;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.dbunit.database.IDatabaseConnection;
import org.docx4j.XmlUtils;
import org.docx4j.openpackaging.exceptions.Docx4JException;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.wml.Tbl;
import org.docx4j.wml.Tc;
import org.docx4j.wml.Tr;
import org.jdom2.Element;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ExportDocxReportType;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.DefinitionReportDisplayRow;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalVersion;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.DescriptionNote;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.VersionSymbol;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalVersionRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.VersionSymbolRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.PTOEmailService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.LocalTestCloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.UnifiedCloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.DocxUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.business.ModelSymbolNameComparator;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating.TemplateConfigurationLocator;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.XmlDomUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.Comment;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalRevisionDetail;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalRevisionUpdateRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SchemeChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionTitle;
import jakarta.inject.Inject;
import jakarta.persistence.EntityNotFoundException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.xml.bind.JAXBElement;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalRevisionServiceTest {
	
	private static final Logger log = LoggerFactory.getLogger(ProposalRevisionServiceTest.class);
    
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject 
    private LocalTestCloudResourcePersistenceService localTestCloudResourcePersistenceService;
    
    @Inject
    private UnifiedCloudResourcePersistenceService unifiedCloudResourcePersistenceService;
    
    @Inject
    private ProposalRevisionService proposalRevisionService;
    
    @Inject
	private ChangeProposalVersionRepository changeProposalVersionRepository;  
    
    @Inject
    private VersionSymbolRepository versionSymbolRepository;
    
    @Inject
    private TitleService titleService;
    
    @Inject
    private PTOEmailService emailService;
    
    @Test(expected=EntityNotFoundException.class)
    public void testExportProposalRevisionInfoIntoDocx() {
    	proposalRevisionService.exportProposalRevisionInfoIntoDocx(UUID.randomUUID(), 
    			"docx", 
    			SCTComponentChangeType.N);
    }
    @Transactional 
    @Test
    public void testGetRevisionDetailByRevisionIdWithoutSystemCreated(){
        
        String dbUid = "080f8146bd4e4e349350c1b184db1b56";
        
        ProposalRevisionDetail p = proposalRevisionService.getRevisionDetailByRevisionId(GUIDUtils.fromDatabaseFormat(dbUid), false);
        log.debug(p.toString());
        Assert.assertNotNull(p);
        Assert.assertEquals(9,p.getRevisionChangeItems().size());
    }
    
    @Transactional 
    @Test
    public void testGetRevisionDetailByRevisionIdIncludingSystemCreated(){
        
        String dbUid = "080f8146bd4e4e349350c1b184db1b56";
        
        ProposalRevisionDetail p = proposalRevisionService.getRevisionDetailByRevisionId(GUIDUtils.fromDatabaseFormat(dbUid), false);
        log.debug(p.toString());
        Assert.assertNotNull(p);
        Assert.assertEquals(9,p.getRevisionChangeItems().size());
    }
    @BeforeClass
	public static void setupClass() {
		System.setProperty("com.sun.xml.internal.stream.XMLInputFactoryImpl",
				"com.sun.xml.internal.stream.XMLInputFactoryImpl");
		 System.setProperty("jakarta.xml.parsers.DocumentBuilderFactory","com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");

	}
    @Before
    public void setUp() throws Exception {
		System.setProperty("illegal-access", "debug");
		
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);
        
	    unifiedCloudResourcePersistenceService.setPersistenceServices(Arrays.asList(localTestCloudResourcePersistenceService));

	    proposalRevisionService.setCloudResourcePersistenceService(unifiedCloudResourcePersistenceService);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("matt.young@uspto.gov", "matt.young@uspto.gov",
                Arrays.asList(new BasicTestingGrantedAuthority("test")));

        SecurityContextHolder.getContext().setAuthentication(token);

        

    }
    
    @Transactional 
    @Test
    public void testGetExportSCTDocxFileName(){
    	String guid = "080f8146bd4e4e349350c1b184db1b56";
        String fileName = proposalRevisionService.getExportSCTDocxFileName(GUIDUtils.fromDatabaseFormat(guid));
        Assert.assertNotNull(fileName);
        Assert.assertTrue(fileName.contains("DP0026"));
        Assert.assertTrue(fileName.endsWith(".docx"));
        
    }
    
    @Transactional 
    @Test
    public void testSCTExportProposalRevisionInfoIntoDocx() throws Exception {
        
    	String filename = "target/sct_pm.docx";
    	String guid = "080f8146bd4e4e349350c1b184db1b56";
    	Assert.assertNotNull(new TemplateConfigurationLocator().getUiBaseUrl());
    	RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(
                   WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposalrevisions/080f8146bd4e4e349350c1b184db1b56/sct.docx")));
        
    	byte[] dataForDisplay = proposalRevisionService.exportProposalRevisionInfoIntoDocx(GUIDUtils.fromDatabaseFormat(guid), ExportDocxReportType.SCT.name(), null);
        Assert.assertNotNull(dataForDisplay);
        Map<String, byte[]> attachments =  new HashMap<>();
        attachments.put("SCT.docx", dataForDisplay);
        emailService.sendEmail(Arrays.asList("matthew.young@uspto.gov"), 
        		"unit test SCT export", "Here is the data from the proposal SCT export", attachments );
        
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(filename);
            fos.write(dataForDisplay);
            fos.flush();
        } finally {
            IOUtils.closeQuietly(fos);
        }
        WordprocessingMLPackage doc = WordprocessingMLPackage.load(new File(filename));
        List<Object> contents = doc.getMainDocumentPart().getContent();
       int countNaw = 0;
        for (Object o : contents) {
            if (o != null && JAXBElement.class.isAssignableFrom(o.getClass())) {
            	if ( Tbl.class.isAssignableFrom(((JAXBElement)o).getValue().getClass())) {
            		String xml = XmlUtils.marshaltoString(((Tbl)((JAXBElement)o).getValue()));
            		if (xml.contains("<w:t>New/Modified Warning</w:t>") 
            				|| xml.contains(" <w:t>New/Modified Note</w:t>")) {
            			countNaw++;
            		}
            		
            		log.debug("table element={}",xml);

            	} else {
            		log.debug("jaxb element={}", ((JAXBElement)o).getValue().getClass());
            	}
            } else {

                log.debug("part={}", o);
            }
            
        }
        // TODO: Find out why after US329671 this assert count dropped from 56 to 28
        Assert.assertEquals(72, contents.size());
       // Assert.assertEquals(28, contents.size());
        //Assert.assertEquals("CPC NOTICE OF CHANGES XXX", contents.get(0).toString().trim());
        //Assert.assertEquals("PROJECT DP0026", contents.get(2).toString().trim());
        //TODO: US329671 uncomment the following
        //Assert.assertEquals(4, countNaw);
    }
    
    
//    @Transactional 
//    @Test
//    public void testSCTExportProposalRevisionInfoIntoDocxWithEmptyNAWTables() throws Exception {
//        
//    	String filename = "target/sct_pm_no_NAW.docx";
//    	String guid = "080f8146bd4e4e349350c1b184db1b56";
//    	RevisionChangeItemRequest req = new RevisionChangeItemRequest();
//    	req.setSymbolName("A01F");
//
//    	req.setEntryType("M");
//    	
//    	UUID revisionGuid = proposalRevisionService.createNewRevsion(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), 
//    		UUID.randomUUID(), Arrays.asList(req), "matt@uspto.gov", "917", new Date(), "No naw");
//    	Assert.assertNotNull(new TemplateConfigurationLocator().getUiBaseUrl());
//    	RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(
//                   WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposalrevisions/080f8146bd4e4e349350c1b184db1b56/sct.docx")));
//        
//    	byte[] dataForDisplay = proposalRevisionService.exportProposalRevisionInfoIntoDocx(revisionGuid, ExportDocxReportType.SCT.name(), null);
//        Assert.assertNotNull(dataForDisplay);
//        
//        FileOutputStream fos = null;
//        try {
//            fos = new FileOutputStream(filename);
//            fos.write(dataForDisplay);
//            fos.flush();
//        } finally {
//            IOUtils.closeQuietly(fos);
//        }
//        WordprocessingMLPackage doc = WordprocessingMLPackage.load(new File(filename));
//        List<Object> contents = doc.getMainDocumentPart().getContent();
//        int countNaw = 0;
//        for (Object o : contents) {
//            if (o != null && JAXBElement.class.isAssignableFrom(o.getClass())) {
//            	if ( Tbl.class.isAssignableFrom(((JAXBElement)o).getValue().getClass())) {
//            		String xml = XmlUtils.marshaltoString(((Tbl)((JAXBElement)o).getValue()));
//            		if (xml.contains("<w:t>New/Modified Warning</w:t>") 
//            				|| xml.contains(" <w:t>New/Modified Note</w:t>")) {
//            			countNaw++;
//            		}
//            		
//            		log.debug("table element={}",xml);
//
//            	} else {
//            		log.debug("jaxb element={}", ((JAXBElement)o).getValue().getClass());
//            	}
//            } else {
//
//                log.debug("part={}", o);
//            }
//            
//        }
//                    Assert.assertEquals(24, contents.size());
//        //Assert.assertEquals("CPC NOTICE OF CHANGES XXX", contents.get(0).toString().trim());
//        //Assert.assertEquals("PROJECT XX0026", contents.get(2).toString().trim());
//        Assert.assertEquals(0, countNaw);
//    }
 
    @Transactional 
    @Test
    public void testCICLExportProposalRevisionInfoIntoDocx() throws Exception {
        
    	String filename = "target/cicl_pm.docx";
    	String guid = "080f8146bd4e4e349350c1b184db1b56";
    	Assert.assertNotNull(new TemplateConfigurationLocator().getUiBaseUrl());
    	RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(
                   WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposalrevisions/080f8146bd4e4e349350c1b184db1b56/cicl.docx")));
        
    	byte[] dataForDisplay = proposalRevisionService.exportProposalRevisionInfoIntoDocx(GUIDUtils.fromDatabaseFormat(guid), ExportDocxReportType.CICL.name(), null);
        Assert.assertNotNull(dataForDisplay);
        
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(filename);
            fos.write(dataForDisplay);
            fos.flush();
        } finally {
            IOUtils.closeQuietly(fos);
        }
        WordprocessingMLPackage doc = WordprocessingMLPackage.load(new File(filename));
        List<Object> contents = doc.getMainDocumentPart().getContent();
        for (Object o : contents) {
            log.debug("part=" + o);
        }
        Assert.assertEquals(15, contents.size());
        //Assert.assertEquals("CPC NOTICE OF CHANGES XXX", contents.get(0).toString().trim());
        //Assert.assertEquals("PROJECT DP0026", contents.get(2).toString().trim());
    }
    
    @Transactional 
    @Test
    public void testGetExportCICLDocxFileName(){
    	String guid = "080f8146bd4e4e349350c1b184db1b56";
        String fileName = proposalRevisionService.getExportCICLDocxFileName(GUIDUtils.fromDatabaseFormat(guid));
        Assert.assertNotNull(fileName);
        Assert.assertTrue(fileName.contains("DP0026"));
        Assert.assertTrue(fileName.endsWith(".docx"));
    }
    
    @Transactional
    @Test(expected=EntityNotFoundException.class)
    public void testExportProposalRevisionInfoIntoDocxENFException() {
    	String guid = "080f8146bd4e4e349350c1b184db1b59";
    	Assert.assertNotNull(new TemplateConfigurationLocator().getUiBaseUrl());
    	RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(
                   WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposalrevisions/080f8146bd4e4e349350c1b184db1b56/cicl.docx")));
        
    	proposalRevisionService.exportProposalRevisionInfoIntoDocx(GUIDUtils.fromDatabaseFormat(guid), ExportDocxReportType.CICL.name(), null);
    }
    
    
	@Test
	@Transactional
	public void testUpdateRevisionMetaData() {
		String dbUid = "080f8146bd4e4e349350c1b184db1b56";
	    UUID uuid = proposalRevisionService.updateRevisionMetaData(GUIDUtils.fromDatabaseFormat(dbUid), "5511", null, "Update Meta Data", "test@uspto.gov");
	    Assert.assertNotNull(uuid);
    	Assert.assertEquals("080f8146-bd4e-4e34-9350-c1b184db1b56",uuid.toString());
	}
	
	@Test
	@Transactional
	public void testUpdateRevisionMetaDataEmptyComment() {
		String dbUid = "080f8146bd4e4e349350c1b184db1b56";
		ProposalRevisionUpdateRequest request = new ProposalRevisionUpdateRequest();
		request.setCefAnx(new Integer(5511));
		request.setCefPostDt(new Date());
		Comment cmt = new Comment();
		cmt.setCommentText("");
		request.setComment(cmt);
		
	    UUID uuid = proposalRevisionService.updateRevisionMetaData(GUIDUtils.fromDatabaseFormat(dbUid), "5511", null, "", "test@uspto.gov");
	    Assert.assertNotNull(uuid);
    	Assert.assertEquals("080f8146-bd4e-4e34-9350-c1b184db1b56",uuid.toString());
    	ChangeProposalVersion revisionEntity = changeProposalVersionRepository
				.findByExternalId(GUIDUtils.toDatabaseFormat(uuid));
    	
    	Iterator<DescriptionNote> itr = revisionEntity.getDescriptionNotes().iterator();
    	DescriptionNote lastNote = itr.next();
    	while(itr.hasNext()) {
    		lastNote=itr.next();
        }
    	Assert.assertEquals(" ",lastNote.getDescriptionNoteText());
    	
	}
	
	@Test
	public void testCreateDocumentAdapter() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		Assert.assertNotNull(proposalRevisionService.createDocumentAdapter());
    }

    @Test
    public void testCreateRSTLocation() throws Exception {
        UUID guid = UUID.fromString("0987e6b6-4925-4e09-a97e-79e12771aff2");
        String location = proposalRevisionService.createRSTLocation(guid);
        log.info("location {}", location);
        assertNotNull(location);
        assertEquals("https://pilot.cpc-ce.org/rst/project/0987e6b6-4925-4e09-a97e-79e12771aff2",
                location);
    }
    
	@Test
	@Transactional
	public void testUploadToRST() throws Exception {
	    log.info("setting up RST mocks");
	    CloseableHttpClient mockHttpClient = Mockito.mock(CloseableHttpClient.class);
	    HttpEntity mockedEntity = Mockito.mock(HttpEntity.class);
	    HttpClientBuilder mockClientBuilder = mock(HttpClientBuilder.class);
	    
	    when(mockedEntity.getContent()).thenReturn(new ByteArrayInputStream("{\"guid\":\"0987e6b6-4925-4e09-a97e-79e12771aff2\"}".getBytes(StandardCharsets.UTF_8)));
	    MockedStatic<HttpClients> mockedFactory = Mockito.mockStatic(HttpClients.class);
	    mockedFactory.when(HttpClients::custom).thenReturn(mockClientBuilder);
	    when(mockClientBuilder.setSSLSocketFactory(any())).thenReturn(mockClientBuilder);
	    when(mockClientBuilder.build()).thenReturn(mockHttpClient);
	    
	    CloseableHttpResponse mockHttpResponse = Mockito.mock(CloseableHttpResponse.class);
	    when(mockHttpResponse.getEntity()).thenReturn(mockedEntity);
	    
	   
	    when(mockHttpClient.execute(any(HttpPost.class))).thenReturn(mockHttpResponse);

        UUID guid = GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56");
        Assert.assertNotNull(new TemplateConfigurationLocator().getUiBaseUrl());
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(
                   WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposalrevisions/080f8146bd4e4e349350c1b184db1b56/sct.docx")));
        
//        byte[] dataForDisplay = proposalRevisionService.exportProposalRevisionInfoIntoDocx(GUIDUtils.fromDatabaseFormat(guid), ExportDocxReportType.SCT.name(), null);
//        Assert.assertNotNull(dataForDisplay);
        UUID rstId = proposalRevisionService.uploadToRST(guid, null);
        log.info("RST returned {}", rstId);
        assertNotNull(rstId);
        assertEquals(UUID.fromString("0987e6b6-4925-4e09-a97e-79e12771aff2"), rstId);
        
	}

	@Test
	@Transactional
	public void testUploadCrosscheckToRST() throws Exception {
	    log.info("setting up RST mocks");
	    File f = new File("target/rst_upload_with_crosscheck_recs.docx");
        UUID guid = GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56");
        Assert.assertNotNull(new TemplateConfigurationLocator().getUiBaseUrl());
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(
                   WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposalrevisions/080f8146bd4e4e349350c1b184db1b56/sct.docx")));
        
//        UUID rstId = proposalRevisionService.uploadToRST(guid, Arrays.asList(
//        			GUIDUtils.fromDatabaseFormat("44c4f7b8b78e4c07aa5d37432db56260"),
//        			GUIDUtils.fromDatabaseFormat("0f234aa1ca8c4d01b91aafe6fb9a0c40")
//        		));
        
        byte[] bytes = proposalRevisionService.exportProposalRevisionWithSCTsToDocx(guid,Arrays.
        				asList(
            			GUIDUtils.fromDatabaseFormat("44c4f7b8b78e4c07aa5d37432db56260"),
            			GUIDUtils.fromDatabaseFormat("0f234aa1ca8c4d01b91aafe6fb9a0c40")
            		));

        IOUtils.write(bytes, new FileOutputStream(f));
        assertTrue(f.exists());
		
	    WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(f);
	    
	    List<Pair<String,String>> entries =  readSCTEntries(wordMLPackage);
	    log.debug("Here is the consolidated entries {}", entries);
	    //A01B63/114 from 080f8146bd4e4e349350c1b184db1b56
	    // H04B3/58 from 44c4f7b8b78e4c07aa5d37432db56260

	    assertTrue(entries.contains(Pair.of("N","A01B3/462")));
	    assertTrue(entries.contains(Pair.of("N","H04B3/58")));
//	    assertEquals(Pair.of("D","A01N1/2011"), entries.get(1));

        
	}
	
	 private List<Pair<String, String>> readSCTEntries(WordprocessingMLPackage wordMLPackage) {
   	  List<Pair<String,String>> foundRows = new ArrayList<>();
		  MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
         List<Tbl> tables = DocxUtils.search(documentPart, Tbl.class);
         for (Tbl docPart : tables) {
  //           if (docPart.getTblGrid().getGridCol().size() == SCT_COLUMN_COUNT) {
                 List<Tr> rows = DocxUtils.search(docPart, Tr.class);
                 for (Tr row : rows) {
                     List<Tc> cells = DocxUtils.search(row, Tc.class);
                     
                     String changeType = DocxUtils.coalesceText(cells.get(0));
                     log.debug("changeType text = {} ", changeType);
                     String symbolName = DocxUtils.coalesceText(cells.get(1));
                     log.debug("Found in column 1 (zero based) = {}", symbolName);
                      	
                     foundRows.add(Pair.of(changeType, symbolName));
                 } // end row for loop
//             }
         }

			return foundRows;
	}

	

	
	@Test
	@Transactional
	public void testMapDefinition() {
		VersionSymbol sctRow = versionSymbolRepository.findByExternalId("2d4593f6909e40cdb52473836238a72c");
		
		assertNotNull(sctRow.getDefinitionXml());
		assertNotEquals("", sctRow.getDefinitionXml());
		RevisionChangeItem revChangeItem = new RevisionChangeItem();
		proposalRevisionService.mapDefinition(revChangeItem, sctRow);
		assertNotNull(revChangeItem.getDefinitionItems());
		assertNotEquals(0, revChangeItem.getDefinitionItems().size());
		assertEquals(2, revChangeItem.getDefinitionItems().size());
	}
	
	@Test
	@Transactional
	public void testMapNotes() {
		VersionSymbol sctRow = versionSymbolRepository.findByExternalId("8b97aa7f0bde4aa191b76a48158a9e61");
		
		assertNotNull(sctRow.getWarningXml());
		assertNotEquals("", sctRow.getWarningXml());
		RevisionChangeItem revChangeItem = new RevisionChangeItem();
		proposalRevisionService.mapNotesAndWarnings(revChangeItem, sctRow);
		assertNotNull(revChangeItem.getNoteItems());
		assertNotEquals(0, revChangeItem.getNoteItems().size());
		assertEquals(3, revChangeItem.getNoteItems().size());
	}
	
	@Test
	@Transactional
	public void testCleanDefinition() throws IOException {
		assertTrue(Pattern.matches("^[A-Za-z0-9]+\\-references$", "informative-references"));
		InputStream is = Thread.currentThread().getContextClassLoader()
				 .getResourceAsStream("data/xml/definition_section_edit_request_withmisplacedreferences.xml");
		String dirtyXml = IOUtils.toString(is);
		String clean = proposalRevisionService.cleanDefinition(dirtyXml);
		log.debug("XXXclean = {}",clean);
		List<Element> nodes = XmlDomUtils.findNodesByXpathExpression(clean, "/definition-item/informative-references");
		assertEquals(0, nodes.size());
		nodes = XmlDomUtils.findNodesByXpathExpression(clean, "/definition-item/references/informative-references");
		
		log.debug("clean {}", clean);
		//assertEquals(1, nodes.size());
		//TODO: Move this out to a volatile test class
	}
	
	@Test
	@Transactional
	public void testDbDefinitionParser_US338801() throws IOException {
		String classpathFilePath = "data/xml/definition_error_US338801.xml";
		try  (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(classpathFilePath)) {
			String defXml =  IOUtils.toString(is);
			RevisionChangeItem rev = new RevisionChangeItem();
			VersionSymbol verSym = new VersionSymbol();
			verSym.setDefinitionXml(defXml);
			proposalRevisionService.mapDefinition(rev, verSym);
			
			assertNotNull(rev.getDefinitionItems());
			assertEquals(3, rev.getDefinitionItems().size());
		} 
	}
	
	// This throws "namespace strings must be interned" error
	@Test
	@Transactional
	public void testDbDefinitionParser_DE55414() throws IOException {
		String classpathFilePath = "data/xml/devinition_intern_error_DE55414.xml";
		try  (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(classpathFilePath)) {
			String defXml =  IOUtils.toString(is);
			RevisionChangeItem rev = new RevisionChangeItem();
			VersionSymbol verSym = new VersionSymbol();
			verSym.setDefinitionXml(defXml);
			proposalRevisionService.mapDefinition(rev, verSym);
			
			assertNotNull(rev.getDefinitionItems());
			assertEquals(1, rev.getDefinitionItems().size());
		} 
	}
	
	  @Test
	    @Transactional
	    public void testMapDefinition_extranull() throws Exception {        
//	        String guid = "0f234aa1ca8c4d01b91aafe6fb9a0c40";
//	        HttpServletResponse resp = WebMocker.mockHttpResponse();
	//
//	        proposalRevisionController.exportDefinitionPartsByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
//	        File f = new File("target/Definitions.zip");
//	        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
//	        Assert.assertTrue(f != null && f.exists() && f.length() >10);
	        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("data/xml/definition_DE55688.xml")) {
	        RevisionChangeItem sctItem = new RevisionChangeItem();
	        VersionSymbol vs = new VersionSymbol();
	        vs.setDefinitionXml(IOUtils.toString(is));
	        proposalRevisionService.mapDefinition(sctItem, vs);
	        assertEquals(3, sctItem.getDefinitionItems().size());
	        }
	    }
	  
	  	@Test
	    @Transactional
	    public void testUpdateXmlResourceIds() throws Exception { 
		  
		  // Create Resource for testing
		  try (InputStream is = Thread.currentThread().getContextClassLoader()
				  .getResourceAsStream("data/xml/db_title_with_image.xml");
				  InputStream imgIs = Thread.currentThread().getContextClassLoader()
						  .getResourceAsStream("cpc-objects/images/cpc-def-A01N-0000.png") ) {
			  String xml = IOUtils.toString(is);
			  assertNotNull(imgIs);
			  
			  Map<String, String> metadata = new HashMap<>();
			  metadata.put("test","123");
			  localTestCloudResourcePersistenceService.persist("9c5d4d7a-1178-413d-9a76-1d5f642e136b", IOUtils.toByteArray(imgIs), metadata, true);
			  xml = proposalRevisionService.updateXmlResourceIdsForTitle(xml);
			  List<Element> nodes  = XmlDomUtils.findNodesByXpathExpression(xml, "//*[@xsi:type=\"ns2:TitlePartMedia\"]/filename");

			  assertNotNull(nodes);
			  assertEquals(1,nodes.size());
			  assertTrue(StringUtils.isNotEmpty(nodes.get(0).getText()));
			  assertNotEquals("9c5d4d7a-1178-413d-9a76-1d5f642e136b",nodes.get(0).getText());
//	        assertEquals(3, sctItem.getDefinitionItems().size());
		  } catch (Exception e) {}
		  
	    }
	  	
	  	@Test
	  	@Transactional
	  	public void testSplitDefinitionItemsBySubclassAndType() {
	  		ProposalRevisionDetail detail = new ProposalRevisionDetail();
	  		detail.getRevisionChangeItems().add(
	  				applyDefinitionChange(
	  						createRevisionChangeItem("M", "A01N01/00", "test 1"), 
	  						SCTComponentChangeType.M));
	  		detail.getRevisionChangeItems().add(
	  				applyDefinitionChange(
	  						createRevisionChangeItem("M", "A01N27/00", "test 1"), 
	  						SCTComponentChangeType.M));
	  		detail.getRevisionChangeItems().add(
	  				applyDefinitionChange(
	  						createRevisionChangeItem("M", "A01N10/99", "test 1"), 
	  						SCTComponentChangeType.M));
	  		detail.getRevisionChangeItems().add(
	  				applyDefinitionChange(
	  						createRevisionChangeItem("M", "A01B10/99", "test 1"), 
	  						SCTComponentChangeType.M));
	  		
	  		List<DefinitionReportDisplayRow> rows = proposalRevisionService.splitDefinitionItemsBySubclassAndType(detail, SCTComponentChangeType.M);
	  		assertTrue(CollectionUtils.isNotEmpty(rows));
	  		assertEquals(3,rows.get(0).getRevisionChangeItems().size());
	  		
	  	}

	 	@Test
	  	@Transactional
	  	public void testSplitDefinitionItemsBySubclassAndType_A61N() {
	  		ProposalRevisionDetail detail = new ProposalRevisionDetail();
	  		detail.getRevisionChangeItems().add(
	  				applyDefinitionChange(
	  						createRevisionChangeItem("U", "A61N", "test 1"), 
	  						SCTComponentChangeType.M));
	  		
	  		
	  		List<DefinitionReportDisplayRow> rows = proposalRevisionService.splitDefinitionItemsBySubclassAndType(detail, SCTComponentChangeType.M);
	  		assertTrue(CollectionUtils.isNotEmpty(rows));
	  		assertEquals(1,rows.get(0).getRevisionChangeItems().size());
	  		
	  	}

	  	
		private RevisionChangeItem applyDefinitionChange(RevisionChangeItem sctItem,
				SCTComponentChangeType changeType) {
			if (changeType != null) {
				DefSectionItemEditRequest req = new DefSectionItemEditRequest();
				req.setChangeType(changeType);
				req.setDefinitionTitle(new DefinitionTitle());
				sctItem.getDefinitionItems().add(req);
			}
			return sctItem;
		}
		
		@Test
	    @Transactional
	    public void testUpdateNoteXmlResourceIds() throws Exception { 
		  
		  // Create Resource for testing
		  try (InputStream is = Thread.currentThread().getContextClassLoader()
				  .getResourceAsStream("data/xml/db_notes_with_image.xml");
				  InputStream imgIs = Thread.currentThread().getContextClassLoader()
						  .getResourceAsStream("cpc-objects/images/cpc-def-A01N-0000.png") ) {
			  String xml = IOUtils.toString(is);
			  assertNotNull(imgIs);
			  
			  Map<String, String> metadata = new HashMap<>();
			  metadata.put("test","123");
			  localTestCloudResourcePersistenceService.persist("3cafab6b-e487-47bd-b344-af53cc3aa385", IOUtils.toByteArray(imgIs), metadata, true);
			  xml = proposalRevisionService.updateXmlResourceIdsForNotes(xml);
			  List<Element> nodes  = XmlDomUtils.findNodesByXpathExpression(xml, "//*[@xsi:type=\"ns2:NoteMedia\"]/filename");

			  assertNotNull(nodes);
			  assertEquals(1,nodes.size());
			  assertTrue(StringUtils.isNotEmpty(nodes.get(0).getText()));
			  assertNotEquals("3cafab6b-e487-47bd-b344-af53cc3aa385",nodes.get(0).getText());
//	        assertEquals(3, sctItem.getDefinitionItems().size());
		  } catch (Exception e) {}
		  
	    }
		@Test
	    @Transactional
	    public void testUpdateDefinitionXmlResourceIds() throws Exception { 
		  
		  // Create Resource for testing
		  try (InputStream is = Thread.currentThread().getContextClassLoader()
				  .getResourceAsStream("data/xml/db_definitions_with_image.xml");
				  InputStream imgIs = Thread.currentThread().getContextClassLoader()
						  .getResourceAsStream("cpc-objects/images/cpc-def-A01N-0000.png") ) {
			  String xml = IOUtils.toString(is);
			  assertNotNull(imgIs);
			  
			  Map<String, String> metadata = new HashMap<>();
			  metadata.put("test","123");
			  localTestCloudResourcePersistenceService.persist("8cbfb927-f4ee-49ec-8b66-011d46fac50f", IOUtils.toByteArray(imgIs), metadata, true);
			  xml = proposalRevisionService.updateXmlResourceIdsForDefinition(xml);
			  List<Element> nodes  = XmlDomUtils.findNodesByXpathExpression(xml, "//*[local-name() = 'media']");

			  assertNotNull(nodes);
			  assertEquals(1,nodes.size());
			  assertTrue(StringUtils.isNotEmpty(nodes.get(0).getAttributeValue("file-name")));
			  assertNotEquals("8cbfb927-f4ee-49ec-8b66-011d46fac50f",nodes.get(0).getAttributeValue("file-name"));
//	        assertEquals(3, sctItem.getDefinitionItems().size());
		  } catch (Exception e) {}
		  
	    }
		
		@Test
		public void testPrepareProposalRevisionInfoIntoDocx_ciclsort() {
			ProposalRevisionDetail detail = new ProposalRevisionDetail();
			detail.getRevisionChangeItems().add(createRevisionChangeItem("N", "B82B5/460", "test 1"));
			detail.getRevisionChangeItems().add(createRevisionChangeItem("N", "B82B5/470", "test 1"));
			detail.getRevisionChangeItems().add(createRevisionChangeItem("N", "B82B5/00", "test 1"));
			detail.getRevisionChangeItems().add(createRevisionChangeItem("N", "B82B5/10", "test 1"));
			detail.getRevisionChangeItems().add(createRevisionChangeItem("N", "B82B5/101", "test 1"));
			detail.getRevisionChangeItems().add(createRevisionChangeItem("N", "B82B5/102", "test 1"));
			proposalRevisionService.prepareProposalRevisionInfoIntoDocx("CICL",SCTComponentChangeType.N,detail);	
			
			assertEquals("B82B5/00", detail.getRevisionChangeItems().get(0).getSymbolName());

			assertEquals("B82B5/10", detail.getRevisionChangeItems().get(1).getSymbolName());

			assertEquals("B82B5/101", detail.getRevisionChangeItems().get(2).getSymbolName());
			assertEquals("B82B5/102", detail.getRevisionChangeItems().get(3).getSymbolName());
			assertEquals("B82B5/460", detail.getRevisionChangeItems().get(4).getSymbolName());
			assertEquals("B82B5/470", detail.getRevisionChangeItems().get(5).getSymbolName());
		}
		
		
		@Test
		@Transactional
		public void testExportAndSortSCTDocx() throws IOException {
	        HttpServletRequest request = WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/proposals");
	        ((MockHttpServletRequest)request).setMethod(RequestMethod.POST.name());
	        HttpServletResponse response = WebMocker.mockHttpResponse();
	        RequestContextHolder.setRequestAttributes(
	                new ServletRequestAttributes(request));
	        
			ProposalRevisionDetail detail = new ProposalRevisionDetail();
			detail.setProposalId(GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7"));
			detail.getRevisionChangeItems().add(
					createRevisionChangeItemWithSortKey("N","B82B5/460", "B82B5/460", "test 1" ));
			detail.getRevisionChangeItems().add(
					createRevisionChangeItemWithSortKey("N","B82B5/470", "B82B5/470", "test 1" ));
			detail.getRevisionChangeItems().add(
					createRevisionChangeItemWithSortKey("N","B82B5/00", "B82B5/00", "test 1" ));
			detail.getRevisionChangeItems().add(
					createRevisionChangeItemWithSortKey("N","B82B5/10", "B82B5/10", "test 1" ));
			detail.getRevisionChangeItems().add(
					createRevisionChangeItemWithSortKey("N","B82B5/101", "B82B5/101", "test 1" ));
			detail.getRevisionChangeItems().add(
					createRevisionChangeItemWithSortKey("N","B82B5/102", "B82B5/102", "test 1" ));
			
            detail.getRevisionChangeItems()
            .sort(new ModelSymbolNameComparator<>("symbolSortKey"));            


			
			byte[] bytes = proposalRevisionService.prepareProposalRevisionInfoIntoDocx("SCT", SCTComponentChangeType.N, detail );
			assertNotNull(bytes);
			boolean loopEnded = false;
			FileUtils.writeByteArrayToFile(new File("target/validating_order.docx"), bytes);
			  try {
		            WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new File("target/validating_order.docx"));
		            MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
		            List<Tbl> tables = DocxUtils.search(documentPart, Tbl.class);
		            int i = 0;
		            for (Tbl docPart : tables) {
		                if (docPart.getTblGrid().getGridCol().size() == 5) {
		                    List<Tr> rows = DocxUtils.search(docPart, Tr.class);
		                    for (Tr row : rows) {

		            			List<Tc> cells = DocxUtils.search(row, Tc.class);
		                        if (!isSctHeader(row) && cells.size() == 5) {
		                        	
		                        	if (i == 0 ) {
		                        		assertEquals("B82B5/00", DocxUtils.coalesceText(cells.get(1)));
		                        	}
		                        	if (i == 1 ) {
		                        		assertEquals("B82B5/10", DocxUtils.coalesceText(cells.get(1)));
		                        	}
		                        	if (i == 2 ) {
		                        		assertEquals("B82B5/101", DocxUtils.coalesceText(cells.get(1)));
		                        	}
		                        	if (i == 3 ) {
		                        		assertEquals("B82B5/102", DocxUtils.coalesceText(cells.get(1)));
		                        	}
		                        	if (i == 4 ) {
		                        		assertEquals("B82B5/460", DocxUtils.coalesceText(cells.get(1)));
		                        	}

		                        	if (i == 5 ) {
		                        		assertEquals("B82B5/470", DocxUtils.coalesceText(cells.get(1)));
		                        	}



		                        	i++;
		                        }
		                    } // end row for loop
		                }
		            }
		            loopEnded = true;

		        } catch (Docx4JException ex) {
		            throw new IllegalArgumentException(
		                    "Docx4j exception, Something is wrong with the docx file.  It  could not be properly read.", ex);

		        } 
			  assertTrue(loopEnded);
		}
		

		@Test
		public void testExportAndSortSCTDocxSpaceIssue() throws IOException, Docx4JException {

			String filename = "target/sct_pm_space_issue.docx";

			Assert.assertNotNull(new TemplateConfigurationLocator().getUiBaseUrl());
			RequestContextHolder
					.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
							"/cpcipcrestweb", "/proposalrevisions/080f8146bd4e4e349350c1b184db1b56/sct.docx")));

			File testDataFile = new File("src/test/resources/data/json/sct/sct_test_data.json");

			ProposalRevisionDetail ProposalRevisionDetail = new ObjectMapper().readValue(testDataFile,
					ProposalRevisionDetail.class);

			byte[] dataForDisplay = proposalRevisionService.prepareProposalRevisionInfoIntoDocx(ExportDocxReportType.SCT.name(), null,
					ProposalRevisionDetail);
			Assert.assertNotNull(dataForDisplay);

			FileOutputStream fos = null;
			try {
				fos = new FileOutputStream(filename);
				fos.write(dataForDisplay);
				fos.flush();
			} finally {
				IOUtils.closeQuietly(fos);
			}
			 String xml = "";
			 WordprocessingMLPackage doc = WordprocessingMLPackage.load(new File(filename));
		        List<Object> contents = doc.getMainDocumentPart().getContent();
		        for (Object o : contents) {
		            if (o != null && JAXBElement.class.isAssignableFrom(o.getClass())) {
		            	if ( Tbl.class.isAssignableFrom(((JAXBElement)o).getValue().getClass())) {
		            		xml = xml + XmlUtils.marshaltoString(((Tbl)((JAXBElement)o).getValue()));
		            	} 
		            }  
		        }
		        log.debug(xml);
		    	Assert.assertNotNull(xml);
		}
		
		@Test
		public void testExportAndSortDefDocxSpaceIssue() throws IOException, Docx4JException {

			String filename = "target/sct_def_space_issue.docx";

			Assert.assertNotNull(new TemplateConfigurationLocator().getUiBaseUrl());
			RequestContextHolder
					.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
							"/cpcipcrestweb", "/proposalrevisions/080f8146bd4e4e349350c1b184db1b56/definitions.docx")));

			File testDataFile = new File("src/test/resources/data/json/sct/sct_test_data.json");

			ProposalRevisionDetail ProposalRevisionDetail = new ObjectMapper().readValue(testDataFile,
					ProposalRevisionDetail.class);

			byte[] dataForDisplay = proposalRevisionService.prepareProposalRevisionInfoIntoDocx(ExportDocxReportType.DEF.name(), null,
					ProposalRevisionDetail);
			Assert.assertNotNull(dataForDisplay);

			FileOutputStream fos = null;
			try {
				fos = new FileOutputStream(filename);
				fos.write(dataForDisplay);
				fos.flush();
			} finally {
				IOUtils.closeQuietly(fos);
			}
			 String xml = "";
			 WordprocessingMLPackage doc = WordprocessingMLPackage.load(new File(filename));
		        List<Object> contents = doc.getMainDocumentPart().getContent();
		        for (Object o : contents) {
		            if (o != null && JAXBElement.class.isAssignableFrom(o.getClass())) {
		            	if ( Tbl.class.isAssignableFrom(((JAXBElement)o).getValue().getClass())) {
		            		xml = xml + XmlUtils.marshaltoString(((Tbl)((JAXBElement)o).getValue()));
		            	} 
		            }  
		        }
		        log.debug(xml);
		    	Assert.assertNotNull(xml);
		}


		private boolean isSctHeader(Tr row) {
			boolean isHeader = false;
			List<Tc> cells = DocxUtils.search(row, Tc.class);
			if (CollectionUtils.isNotEmpty(cells)) {
			   if (DocxUtils.coalesceText(cells.get(0)).equalsIgnoreCase("Type*")  
					   && DocxUtils.coalesceText(cells.get(1)).equalsIgnoreCase("Symbol")) {
				  isHeader = true;   
			   }
			}
			return isHeader;
		}
		private RevisionChangeItem createRevisionChangeItem(String entryType, String symbol, String title) {
			RevisionChangeItem item = new RevisionChangeItem();
			item.setEntryType(entryType);
			item.setSymbolName(symbol);
			try {
				TitlePartTree tree = titleService.fromGrammar(title);
				item.setTitle(tree);
			} catch (GrammarParseException gpe) {
				log.error("ex = ", gpe);
			}
			return item;
		}
		
		
		private RevisionChangeItem createRevisionChangeItemWithSortKey(String entryType, String symbol, String symbolSortKey, String title) {
			RevisionChangeItem item = new RevisionChangeItem();
			item.setEntryType(entryType);
			item.setSymbolName(symbol);
			item.setSymbolSortKey(symbolSortKey);
			try {
				TitlePartTree tree = titleService.fromGrammar(title);
				item.setTitle(tree);
			} catch (GrammarParseException gpe) {
				log.error("ex = ", gpe);
			}
			return item;
		}

		/**
		 * Added this test to debug issue with export template not showing correct count
		 * in the exported data.
		 * 
		 * @throws IOException
		 * @throws Docx4JException
		 */
		@Test
		@Transactional
		public void testExportProposalStatisticsByChangeProposalVersionId() throws IOException, Docx4JException {
			String fileName = "target/sct_statistics.docx";

			Assert.assertNotNull(new TemplateConfigurationLocator().getUiBaseUrl());
			RequestContextHolder
					.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
							"/cpcipcrestweb", "/proposalrevisions/44c4f7b8b78e4c07aa5d37432db56260/statistics.docx")));

			byte[] data = proposalRevisionService.exportProposalRevisionInfoIntoDocx(
					GUIDUtils.fromDatabaseFormat("44c4f7b8b78e4c07aa5d37432db56260"),
					ExportDocxReportType.STATISTICS.name(), null);

			FileOutputStream fos = null;
			try {
				fos = new FileOutputStream(fileName);
				fos.write(data);
				fos.flush();
			} finally {
				IOUtils.closeQuietly(fos);
			}

		}
		
		/**
		 * US412743
		 * @TODO: Add asserts
		 */
		@Test
		@Transactional
		public void testExportProposalCoversheetByChangeProposalVersionId() throws IOException, Docx4JException {
			String fileName = "target/sct_coverheet.docx";

			Assert.assertNotNull(new TemplateConfigurationLocator().getUiBaseUrl());
			RequestContextHolder
					.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
							"/cpcipcrestweb", "/proposalrevisions/44c4f7b8b78e4c07aa5d37432db56260/statistics.docx")));

			byte[] data = proposalRevisionService.exportProposalRevisionInfoIntoDocx(
					GUIDUtils.fromDatabaseFormat("44c4f7b8b78e4c07aa5d37432db56260"),
					ExportDocxReportType.PCS.name(), null);

			FileOutputStream fos = null;
			try {
				fos = new FileOutputStream(fileName);
				fos.write(data);
				fos.flush();
			} finally {
				IOUtils.closeQuietly(fos);
			}

		    WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new java.io.File(fileName));
		    int titlesFound = findCoversheetEntries(wordMLPackage, "Titles Changed:", "H03F");
		    assertEquals("0", String.valueOf(titlesFound));
		    int indentsFound = findCoversheetEntries(wordMLPackage, "Indents Changed:", "H03F");
		    assertEquals("0", String.valueOf(indentsFound));
		}
		
		private int findCoversheetEntries(WordprocessingMLPackage wordMLPackage, String columnLabel, String expectedSymbolClassName) {
            int foundRows = 0;
			MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
            List<Tbl> tables = DocxUtils.search(documentPart, Tbl.class);
            for (Tbl docPart : tables) {
     //           if (docPart.getTblGrid().getGridCol().size() == SCT_COLUMN_COUNT) {
                    List<Tr> rows = DocxUtils.search(docPart, Tr.class);
                    for (Tr row : rows) {
                        List<Tc> cells = DocxUtils.search(row, Tc.class);
                        
                        String label = DocxUtils.coalesceText(cells.get(0));
                        log.debug("label column text = {}", label);
                        if (StringUtils.equals(label, columnLabel)) {
                        	String symbolClassName = DocxUtils.coalesceText(cells.get(1));
                        	log.debug("Found in column 1 (zero based) = {}", symbolClassName);
                        	if (StringUtils.equals(symbolClassName, expectedSymbolClassName )) {
                        		foundRows ++;
                        	}
                        	
                        }
                    } // end row for loop
//                }
            }

			return foundRows;
		}
		
		@Test
		@Transactional
		public void testExportGoldCopyDefinitions()
		{
			ProposalRevisionDetail proposalRevisionDetail = buildProposalRevisionDetail();
			try {
				System.out.println(" TEST EXPORT GOLD COPY DEFNITIONS ");
			 byte[]	goldCopy = proposalRevisionService.exportGoldCopyDefinitions(proposalRevisionDetail);
			 System.out.println(" TEST EXPORT GOLD COPY DEFNITIONS "+ goldCopy.toString());
			 assertNotNull(goldCopy);
			} catch (Exception e) {
				e.printStackTrace();
			} 
		}
		
		private ProposalRevisionDetail buildProposalRevisionDetail() {
			ProposalRevisionDetail rev = new ProposalRevisionDetail();
			rev.setId(GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56"));
			
			rev.setProposalId(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
			rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.C,"A01N1/2011"));
			rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.M,"A01N1/2011"));
			rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.N,"A01N1/11"));
			rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.M,"A01N1/111"));
			rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.D,"A01N1/111"));

			rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.D,"A01N1/2011"));
			return rev;
		}
		
		private RevisionChangeItem createRevisionChangeItem(SchemeChangeType changeType, String symbolName) {
			RevisionChangeItem item =  new RevisionChangeItem();
			item.setEntryType(changeType.name());
			item.setSymbolName(symbolName);
			item.setSymbolSortKey(convert2KSymbolIfNecessary(symbolName));
			return item;
		}
		
		private String convert2KSymbolIfNecessary(String symbolName) {
			String sortKey = symbolName;
			if (StringUtils.indexOf(symbolName,"/") >= 0) {
				String twoThouPart = StringUtils.trim(StringUtils.substringAfterLast(symbolName, "/"));
				if (Integer.parseInt(twoThouPart) >= 2000) {
					twoThouPart = (Integer.parseInt(twoThouPart) - 2000)+"";
				}
				sortKey = StringUtils.substring(symbolName,0, StringUtils.indexOf(symbolName, "/"))+ "/"+twoThouPart;
				log.debug("symbolName ={} -> sorkey = {}", symbolName, sortKey);
			}
			return sortKey;
		}

}
