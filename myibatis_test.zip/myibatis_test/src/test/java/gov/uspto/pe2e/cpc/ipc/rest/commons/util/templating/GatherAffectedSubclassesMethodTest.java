package gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeMap;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import freemarker.template.Configuration;
import freemarker.template.DefaultListAdapter;
import freemarker.template.DefaultObjectWrapperBuilder;
import freemarker.template.TemplateModelException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.SchemeHierarchyRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.templating.model.SubclassOrganizedRow;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;
/**
 * NOTE: cannot be moved into commons where it belongs because this
 * test is dependant on TitleService which is not in commons
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class GatherAffectedSubclassesMethodTest {
	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private SchemeHierarchyRepository schemeHierarchyRepository;
	
	@Inject
	private TitleService titleService;

	@Test
	public void testExec() throws TemplateModelException {
		try {
		List<RevisionChangeItem> items = new ArrayList<>();
		items.add(createRevisionChangeItem("N", "B82B5/460", "B82B5/460", "test 1"));
		items.add(createRevisionChangeItem("N", "B82B5/470", "B82B5/470", "test 1"));
		items.add(createRevisionChangeItem("N", "B82B5/00", "B82B5/00", "test 1"));
		items.add(createRevisionChangeItem("N", "B82B5/10", "B82B5/10", "test 1"));
		items.add(createRevisionChangeItem("N", "B82B5/101", "B82B5/101", "test 1"));
		items.add(createRevisionChangeItem("N", "B82B5/102", "B82B5/102", "test 1"));
//
//		items.sort(new ModelSymbolNameComparator<>("symbolSortKey"));

		
		GatherAffectedSubclassesMethod method = new GatherAffectedSubclassesMethod(schemeHierarchyRepository);
		DefaultListAdapter adapter = DefaultListAdapter.adapt(items, new DefaultObjectWrapperBuilder(Configuration.VERSION_2_3_23).build() 
				);
		Object o= method.exec(Arrays.asList(adapter));
		assertNotNull(o);
		TreeMap<String, SubclassOrganizedRow> sorted = (TreeMap<String, SubclassOrganizedRow>)o;
		assertEquals("B82B5/00", sorted.get("B82B").getRevisionChangeItems().get(0).getSymbolName());

		assertEquals("B82B5/10", sorted.get("B82B").getRevisionChangeItems().get(1).getSymbolName());

		assertEquals("B82B5/101", sorted.get("B82B").getRevisionChangeItems().get(2).getSymbolName());
		assertEquals("B82B5/102", sorted.get("B82B").getRevisionChangeItems().get(3).getSymbolName());
		assertEquals("B82B5/460", sorted.get("B82B").getRevisionChangeItems().get(4).getSymbolName());
		assertEquals("B82B5/470", sorted.get("B82B").getRevisionChangeItems().get(5).getSymbolName());
		} catch (Exception e) {
			log.debug("exc=", e);
			fail();
		}
	}

	private RevisionChangeItem createRevisionChangeItem(String entryType, String symbol, String sortKey, String title) {
		RevisionChangeItem item = new RevisionChangeItem();
		item.setEntryType(entryType);
		item.setSymbolName(symbol);
		item.setSymbolSortKey(sortKey);
		try {
		TitlePartTree tree = titleService.fromGrammar(title);
		item.setTitle(tree);
		} catch (GrammarParseException gpe) {}
		return item;
	}

	@BeforeClass
	public static void setupClass() {
		System.setProperty("com.sun.xml.internal.stream.XMLInputFactoryImpl",
				"com.sun.xml.internal.stream.XMLInputFactoryImpl");
		System.setProperty("javax.xml.parsers.DocumentBuilderFactory",
				"com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");

	}

	@Before
	public void setUp() throws Exception {
		System.setProperty("illegal-access", "debug");

		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.emptyTables(conn);
		datasetTestingService.loadAllDatasets(conn);

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("matt.young@uspto.gov",
				"matt.young@uspto.gov", Arrays.asList(new BasicTestingGrantedAuthority("test")));

		SecurityContextHolder.getContext().setAuthentication(token);

	}

}
