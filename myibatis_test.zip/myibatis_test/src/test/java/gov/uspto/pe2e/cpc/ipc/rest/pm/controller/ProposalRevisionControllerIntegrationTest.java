package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import java.io.File;
import java.util.Arrays;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalVersionRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.IpcConcordanceRevisionRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletResponse;
import net.jcip.annotations.NotThreadSafe;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test-oraclelocal.xml"})
@NotThreadSafe
@Category(NotThreadSafe.class)
@TestPropertySource("classpath:oracle.properties") // this allows the integration test to override oracle properties without affecting spring factory
public class ProposalRevisionControllerIntegrationTest {
    private static final Logger log = LoggerFactory.getLogger(ProposalRevisionControllerIntegrationTest.class);
    @Inject
    private ProposalRevisionController proposalRevisionController;
    @Inject
    private ProposalController proposalController;
    @Inject
    private DatasetTestingService datasetTestingService;
    @Inject
	private ChangeProposalVersionRepository changeProposalVersionRepository;
    @Inject
    private IpcConcordanceRevisionRepository ipcConcordanceRevisionRepository;
    
    
  
    @Before
    public void setUp() throws Exception {
        //IDatabaseConnection conn = datasetTestingService.getConnection();
       // datasetTestingService.emptyTables(conn);
       // datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1@uspto.gov", "myoung3@uspto.gov", Arrays
                .asList(new BasicTestingGrantedAuthority("test@uspto.gov")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }
    
    @Test
    @Transactional
    public void testExportCoverSheetByChangeProposalVersionId_debug_prod_issue() throws Exception {
        
        String guid = "236654456cde4b4996984abf7c2a02fa";
        HttpServletResponse resp = WebMocker.mockHttpResponse();

        proposalRevisionController.exportCoverSheetDetailsByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
        File f = new File("target/CoverSheet.docx");
        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
        Assert.assertTrue(f != null && f.exists() && f.length() >10);
    }

	@Test
    @Transactional
    public void testExportCoverSheetByChangeProposalVersionId_DE67509() throws Exception {
        
        String guid = "423c7a3c40884a6086a778f2bd045000";
        HttpServletResponse resp = WebMocker.mockHttpResponse();

        proposalRevisionController.exportCoverSheetDetailsByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
        File f = new File("target/CoverSheet.docx");
        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
        Assert.assertTrue(f != null && f.exists() && f.length() >10);
    }
	
	@Test
	@Transactional
	public void testExportRevisionDetailByChangeProposalVersionId() throws Exception {
		
		String guid = "afa806ba5afe44408c42fe6706c34bc4";
		HttpServletResponse resp = WebMocker.mockHttpResponse();

		proposalRevisionController.exportRevisionDetailByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
		File f = new File("target/SCTIntegration.docx");
		FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
		Assert.assertTrue(f != null && f.exists() && f.length() >10);
	}
	
	
	@Test
	@Transactional
	public void testExportDefinitionPartsByChangeProposalVersionId() throws Exception {
		String guid = "c207386c2c844368aa4c6f5077cdfa9b";   
		HttpServletResponse resp = WebMocker.mockHttpResponse();
		proposalRevisionController.exportDefinitionPartsByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
		File f = new File("target/definitions.docx"); // Validated Definitions DOcument-
		FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
		Assert.assertTrue(f != null && f.exists() && f.length() >10);
	}
}
