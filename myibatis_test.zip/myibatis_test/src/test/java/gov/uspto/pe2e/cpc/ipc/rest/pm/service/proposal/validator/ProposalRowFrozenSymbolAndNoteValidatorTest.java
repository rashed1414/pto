package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import static org.junit.Assert.assertNotNull;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.NAWItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteParagraph;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NotesAndWarnings;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowFrozenSymbolAndNoteValidatorTest {

    private static final Logger log = LoggerFactory.getLogger(ProposalRowFrozenSymbolAndNoteValidatorTest.class);
    
    private static final String VALIDATION_MESSAGE = "Cannot reference already frozen symbol(s) [A01B63/00, A01B63/026] in Note.";

    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalRowFrozenSymbolAndNoteValidator proposalRowFrozenSymbolAndNoteValidator;

    @Resource(name = "proposalConsistencyValidator")
    private List<ProposalValidator> consistencyValidators;

    @Inject
    private ProposalValidationService proposalValidationService;

    private DocumentAdapter docAdapter;

    @Test
    public void testConfigCorrectlyIncludesDefinitionSymbolReferenceValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : consistencyValidators) {
            if (validator.getClass().getCanonicalName()
                    .equals(proposalRowFrozenSymbolAndNoteValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }

    @Test
    public void testValidateMultipleSectionsWithFrozenSymbols() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemWithNote("U", "A02B1/02", "0",
                "test;hello)",
                new String[] { "A01B 5/005", "A01B 5/008" }, "data/xml/fragments/warning_with_frozen_symbols.xml", NoteType.NOTE));        

        ProposalValidationContext proposalValidationContext = proposalValidationService
                .createProposalValidationContext(rows);
        proposalRowFrozenSymbolAndNoteValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(2, rows.get(0).getValidationMessages().size());
        Assert.assertEquals(VALIDATION_MESSAGE, 
                rows.get(0).getValidationMessages().get(0).getMessageText()); 
        Assert.assertEquals(VALIDATION_MESSAGE, 
                rows.get(0).getValidationMessages().get(1).getMessageText()); 
        Assert.assertEquals(ValidationPhase.CONSISTENCY, rows.get(0).getValidationMessages().get(0).getPhase());                
        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(0).getLevel());
        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(0).getMessageType());
    }

    public RevisionChangeItem createRevisionChangeItemWithNote(String entryType, String symbolName, String dotLevel,
            String titleGrammar, String[] reclassTargets, String nawFile, NoteType noteType) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel,
                titleGrammar, reclassTargets);
        item.getNoteItems().add(createNawItem(SCTComponentChangeType.M,
                        noteType, nawFile));
        item.getNoteItems().add(createNawItem(SCTComponentChangeType.M,
                noteType, nawFile));
        item.getNoteItems().add(createNawItem(SCTComponentChangeType.M,
                NoteType.WARNING, "data/xml/fragments/note_with_invalid_symbols.xml"));
        return item;
    }

    private NAWItemEditRequest createNawItem(SCTComponentChangeType updateType, NoteType noteType, String nawFile) {
        NAWItemEditRequest req = new NAWItemEditRequest();
        req.setChangeType(updateType);
        req.setNoteCategory(noteType);
        NoteParagraph noteP = null;
   
        try(InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(nawFile);) {            
            NotesAndWarnings defItem = docAdapter.mapNotesAndWarningsXmlDocument(
                    "<notes-and-warnings><note>" + IOUtils.toString(is) + "</note></notes-and-warnings>");
            noteP = (NoteParagraph) defItem.getChildren().get(0).getChildren().get(0);
        } catch (Exception je) {
            throw new IllegalArgumentException(je);
        } 

        req.setNoteItem(noteP);
        assertNotNull(req.getNoteItem());
        return req;
    }
    
    @Test
    public void testEmptyRows() {
        List<RevisionChangeItem> rows = new ArrayList<>();      
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowFrozenSymbolAndNoteValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.size());
    } 
    
    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.MEDIUM, proposalRowFrozenSymbolAndNoteValidator.getCost());
    }
    
    @Test
    public void testGetValidationType() {
        Assert.assertEquals(ValidationMessageType.RECORD, proposalRowFrozenSymbolAndNoteValidator.getValidationType());
    }

    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        Class adapterClass = Class.forName(DocumentAdapter.class.getCanonicalName());
        docAdapter = (DocumentAdapter) adapterClass.newInstance();

    }
   
}
