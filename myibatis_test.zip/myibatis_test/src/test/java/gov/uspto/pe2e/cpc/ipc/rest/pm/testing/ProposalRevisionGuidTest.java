package gov.uspto.pe2e.cpc.ipc.rest.pm.testing;

import org.junit.BeforeClass;
import org.junit.Test;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ProposalRevisionGuidTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Test
	public void test() {
		// This GUID is the revision in sit with the most rows (1900+)
		log.info("quid = {}", GUIDUtils.fromDatabaseFormat("84d98e984b994b188b41701fd092da90"));
	}

}
