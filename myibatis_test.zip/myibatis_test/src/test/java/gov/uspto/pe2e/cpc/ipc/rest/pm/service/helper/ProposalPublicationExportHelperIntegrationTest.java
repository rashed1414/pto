package gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.DotLevelType;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.SchemeHierarchy;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.SchemeHierarchyRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.LocalTestCloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.UnifiedCloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.AdapterUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcConcordanceMapping;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SchemeChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePart;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartRawText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.ApplicationReferences;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.ThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test-oraclelocal.xml" } )
@TestPropertySource("classpath:oracle.properties") // this allows the integration test to override oracle properties without affecting spring factory
@ThreadSafe
@Category(ThreadSafe.class)
@Slf4j
public class ProposalPublicationExportHelperIntegrationTest {
	
	@Inject
	private UnifiedCloudResourcePersistenceService unifiedCloudResourcePersistenceService;
	
	@Inject
	private LocalTestCloudResourcePersistenceService localTestCloudResourcePersistenceService;

	@Inject
	private DatasetTestingService datasetTestingService;
	
	@Inject
	private SchemeHierarchyRepository schemeHierarchyRepository;
	
	@Inject
	private ProposalPublicationHelper proposalPublicationHelper;
	
	@Inject
	private ProposalPublicationExportHelper helper;	

    @Resource(name = "documentAdapterConfig")
    private Map<String, String> documentAdapterConfig;

	@Inject
	private EntityManager entityManager;

	@Transactional
	@Test
	public void testExport() throws IOException, ParseException {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		sctItems.add(createSctItem("A01N65/26", DotLevelType.fromIndentLevel(9), SchemeChangeType.C));
		//sctItems.add(createSctItem("A01B1/02", DotLevelType.fromIndentLevel(8), SchemeChangeType.M));

		sctItems.add(createSctItem("A01N37/12", 
				DotLevelType.fromIndentLevel(8), 
				SchemeChangeType.C));

		
				
		File directory =  new File("target/export_test_case");
		if (!directory.exists() ) {
			directory.mkdir();
		}
		
		helper.exportSymbols(GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"),
				directory);
		
		
		File zip = new File("target/resources/cloud/XX12245.zip");
		assertTrue(zip.exists() );
		assertTrue(zip.isFile() );
	
		List<String> filenames =  new ArrayList<>();
		try (ZipFile zipFile = new ZipFile(zip)) {
			zipFile.stream()
		       .map(ZipEntry::getName)
		       .forEach(filenames::add);
		}
		log.debug("Filenames in zip = {}", filenames);
		assertTrue(filenames.size() > 0);
//		assertTrue(filenames.contains("cpc-scheme-A.xml")); 
//		assertTrue(filenames.contains("cpc-scheme-A01N.xml"));
//		
//		assertTrue(filenames.contains("Image\\cpc-sch-A01N-0932.gif")); 
//		assertTrue(filenames.contains("Image\\cpc-sch-A01N-0933.gif"));
	}

	@Transactional
	@Test
	public void testExportDefinitions() throws IOException {
		long count = schemeHierarchyRepository.count();
//		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
//		sctItems.add(createSctItem("A01N65/26", DotLevelType.fromIndentLevel(9), SchemeChangeType.C));
//		//sctItems.add(createSctItem("A01B1/02", DotLevelType.fromIndentLevel(8), SchemeChangeType.M));
//
//		sctItems.add(createSctItem("A01N37/12", 
//				DotLevelType.fromIndentLevel(8), 
//				SchemeChangeType.C));
//
//		
				
		File directory =  new File("target/export_definitions_test_case");
		if (!directory.exists() ) {
			directory.mkdir();
		}
		
		helper.exportDefinitions(UUID.fromString("6b89147b-1120-4422-b670-a60e066a423f"),
				directory);
		
		
		File zip = new File("target/resources/cloud/XX12245_definitions.zip");
		assertTrue(zip.exists() );
		assertTrue(zip.isFile() );
	
		List<String> filenames =  new ArrayList<>();
		try (ZipFile zipFile = new ZipFile(zip)) {
			zipFile.stream()
		       .map(ZipEntry::getName)
		       .forEach(filenames::add);
		}
		log.debug("Filenames in zip = {}", filenames);
		assertTrue(filenames.size() > 0);
//		assertTrue(filenames.contains("cpc-scheme-A.xml")); 
//		assertTrue(filenames.contains("cpc-scheme-A01N.xml"));
//		
//		assertTrue(filenames.contains("Image\\cpc-sch-A01N-0932.gif")); 
//		assertTrue(filenames.contains("Image\\cpc-sch-A01N-0933.gif"));
	}

	
	
	private RevisionChangeItemRequest createSctItem(String symbolName, DotLevelType dotLevel, SchemeChangeType changeType) {
		RevisionChangeItemRequest item = new RevisionChangeItemRequest();
		item.setSymbolName(SymbolName.normalize(symbolName));
		IpcConcordanceMapping ipcConcordanceMapping = new IpcConcordanceMapping();
		ipcConcordanceMapping.setSymbolName(symbolName);
		item.setIpcSymbol(ipcConcordanceMapping);
		String titleXmlFile = "data/xml/fragments/A01D_title_fragment.xml";
		TitlePartTree title = null;
		try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(titleXmlFile)) {
			assertNotNull("failed to find " + titleXmlFile+" for symbol "+symbolName, is);
			String baseTitle = IOUtils.toString(is);

			SchemeHierarchy dbSymbol = schemeHierarchyRepository
					.findByNameFromLatestSchemeNotIncludingHeadingSymbols(symbolName);

			if (dbSymbol != null) {
				String xml = dbSymbol.getTitle();
				title = (TitlePartTree) AdapterUtils.latest(documentAdapterConfig).mapTitleXmlDocument(xml);

			} else {
				title = (TitlePartTree) AdapterUtils.latest(documentAdapterConfig).mapTitleXmlDocument(baseTitle);
			}
			TitlePartRawText raw = new TitlePartRawText();
			raw.setContent("This is a minor edit forcing difference in case of testing publication");

			TitlePartText txt = new TitlePartText();
			txt.getChildren().add(raw);
			title.getChildren().add((TitlePart)txt);
		} catch (Exception e) {
			log.debug("exc = ", e);
		}
		item.setTitle(title);
		item.setDotLevel(dotLevel.getDisplayValue());
		item.setEntryType(changeType.name());
		DefSectionItemEditRequest def =  new DefSectionItemEditRequest();
		def.setApplicationReferences(new ApplicationReferences());
		def.getApplicationReferences().setSuggestionStart("123");

		def.getApplicationReferences().setSuggestionEnd("123");
		item.getDefinitionItems().add(def);
		return item;
	}


	@Before
	public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();
//		datasetTestingService.emptyTables(conn);
//		datasetTestingService.loadAllDatasets(conn);
		
	    unifiedCloudResourcePersistenceService.setPersistenceServices(Arrays.asList(localTestCloudResourcePersistenceService));

	    helper.setCloudResourcePersistenceService(unifiedCloudResourcePersistenceService);
	    
	    String imageSrcDirectoryPath = Thread.currentThread().getContextClassLoader().getResource("cpc-objects/images").getFile();

	    log.debug("using {} as source image dir", imageSrcDirectoryPath);
	    File srcDirectory = new File(imageSrcDirectoryPath);
	    log.debug("src dir file = {}", srcDirectory);
	    File[] srcFiles = srcDirectory.listFiles();
	    log.debug("file listing = {}", srcFiles);
	    
	    File destinationDirectory =  new File(LocalTestCloudResourcePersistenceService.FILE_PATH_PREFIX);
	    destinationDirectory.mkdirs();
	    for (File imgFile: srcFiles) {
	    	FileUtils.copyFile(imgFile, new File(destinationDirectory.getAbsolutePath()+File.separator+imgFile.getName()));
	    	FileUtils.writeByteArrayToFile(new File(LocalTestCloudResourcePersistenceService.getMetadataFilename(imgFile.getName())),
	    			("original-filename="+imgFile.getName()).getBytes());
	    	
	    }
	    
		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

	}

}
