package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.apache.commons.collections4.comparators.ComparatorChain;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.CharEncoding;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.projection.ReclassTransferViewProjection;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalTWLRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.collections.NullSafeBeanComparator;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassTransferView;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassificationTypeCategory;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalTWLServiceTest {
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ChangeProposalTWLRepository changeProposalTWLRepository;
    
    @Inject
    private ChangeProposalRepository changeProposalRepository;
    
    @Inject
    private ProposalTWLService proposalTWLService;
    
	private static final String DATE_FORMAT="MMddyy";

           

    @Test
    public void testGetExportTWLFileName() {
    	String fileName=proposalTWLService.getExportTWLXlsxFileName(GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7"));
    	String dateFormat=new LocalDateTime().toString(DATE_FORMAT);
    	assertNotNull(fileName);
    	assertEquals(fileName,"TWL_DP0027_"+dateFormat+".xlsx.xml");	
    }
    @Test
    public void testGetExportTWLFileNameRecordNotFound() {
    	String fileName=proposalTWLService.getExportTWLXlsxFileName(GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb9"));
    	String dateFormat=new LocalDateTime().toString(DATE_FORMAT);
    	assertNotNull(fileName);
    	assertEquals(fileName,"");	
    }
//    @Test
//    public void testExportTWLDataIntoXlsx() throws IOException {
//    	UUID proposalID=GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7");
//    	UUID proposalRevisionUUID=GUIDUtils.fromDatabaseFormat("0a940f78a42a41cbae5f9dd37450034b");
//    	byte[] exportData=proposalTWLService.exportTWLDataIntoXlsx(proposalID, proposalRevisionUUID);
//    	
//    	assertNotNull(exportData);
//    	
//    	ByteArrayInputStream bin = new ByteArrayInputStream(exportData);
//    	Workbook workbook = new XSSFWorkbook(bin);
//
//    	assertEquals(4,workbook.getNumberOfSheets());
//    	assertEquals("DP0027",workbook.getSheet("STATS").getRow(0).getCell(1).getStringCellValue());
//    	
//    }
    // TODO: validate with xml
//    @Test
//    public void testExportTWLDataIntoXlsxNoRecords() throws IOException {
//    	UUID proposalID=GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb9");
//    	UUID proposalRevisionUUID=GUIDUtils.fromDatabaseFormat("0a940f78a42a41cbae5f9dd3745003e9");
//    	byte[] exportData=proposalTWLService.exportTWLDataIntoXlsx(proposalID, proposalRevisionUUID);
//    	
//    	assertNotNull(exportData);
//    	
//    	ByteArrayInputStream bin = new ByteArrayInputStream(exportData);
//    	Workbook workbook = new XSSFWorkbook(bin);
//
//    	assertEquals(4,workbook.getNumberOfSheets());
//    	assertEquals(null,workbook.getSheet("STATS").getRow(0).getCell(1));
//    	
//    }
    @Test
    public void testExportTWLDataIntoXlsx_file() throws IOException {
    	UUID proposalID=GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7");
    	UUID proposalRevisionUUID=GUIDUtils.fromDatabaseFormat("0a940f78a42a41cbae5f9dd37450034b");
    	byte[] exportData=proposalTWLService.exportTWLDataIntoXlsx(proposalID, proposalRevisionUUID);
    	
    	assertNotNull(exportData);
    	IOUtils.write(exportData, new FileOutputStream(new File("target/export_twl.xlsx.xml")));    	
    	String xml =  new String(exportData, CharEncoding.UTF_8);
    	log.info("Exported TWL xlsx/xml as {}", xml);
    	
    
    	
    	assertTrue(xml.contains("<Data ss:Type=\"String\">US 100003</Data>"));
    	
    }
    
    
    
    private List<ReclassTransferView> createReclassTransfersForTWLExport() {
		List<ReclassTransferView> reclasses = new ArrayList<>();
		reclasses.add(new ReclassTransferViewProjection(UUID.randomUUID(), "A01N01/100",
				"A01B01/100",
				"M", ReclassificationTypeCategory.ADMIN));
		reclasses.add(new ReclassTransferViewProjection(UUID.randomUUID(), "A01N01/101",
				"A01B01/100",
				"M", ReclassificationTypeCategory.ADMIN));
		reclasses.add(new ReclassTransferViewProjection(UUID.randomUUID(), "A01N01/102",
				"A01B01/102",
				"M", ReclassificationTypeCategory.ADMIN));		
		reclasses.add(new ReclassTransferViewProjection(UUID.randomUUID(), "A01N01/70",
						"A01B01/75",
						null, ReclassificationTypeCategory.ADMIN));
		Collections.sort(reclasses, new ComparatorChain(Arrays.asList(
				   new NullSafeBeanComparator("changeType"), 
				   new NullSafeBeanComparator("sourceSymbolName"))));
		return reclasses;
	}

	//    @Test
//    public void testExportTWLDataIntoXlsxNoRecords() throws IOException {
//    	UUID proposalID=GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb9");
//    	UUID proposalRevisionUUID=GUIDUtils.fromDatabaseFormat("0a940f78a42a41cbae5f9dd3745003e9");
//    	byte[] exportData=proposalTWLService.exportTWLDataIntoXlsx(proposalID, proposalRevisionUUID);
//    	
//    	assertNotNull(exportData);
//    	
//    	ByteArrayInputStream bin = new ByteArrayInputStream(exportData);
//    	Workbook workbook = new XSSFWorkbook(bin);
//
//    	assertEquals(4,workbook.getNumberOfSheets());
//    	assertEquals(null,workbook.getSheet("STATS").getRow(0).getCell(1));
//    	
//    }
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
                "bkuppusamy", "Boops","Kuppusamy", "US");
            UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "boopathi.kuppusamy@uspto.gov", token,
                Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
                        new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
                        new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
        SecurityContextHolder.getContext().setAuthentication(springUser);  

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/proposals/xxx/twl")));
    }

}
