package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalDocument;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalDocumentRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DocumentPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocument;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentApproval;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentApprovalComment;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentApprovalRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentPage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentVersionClassificationCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationPhase;
import jakarta.inject.Inject;
import jakarta.persistence.EntityNotFoundException;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalDocumentControllerTest  {
    
    @Inject
    private ChangeProposalDocumentRepository changeProposalDocumentRepository;    
    @Inject
    private ProposalDocumentController proposalDocumentController;
    
    @Inject
    private DatasetTestingService datasetTestingService;
   
    
    /**
     * Test with absurdly large pagesize where all 
     * results in db would fit on first page but ask for second
     *  
     */
    @Test
    public void testListDocumentsPagingEmptyPageCase1() {    	
			
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
        		1,7000,null,
        		null, null, null,
                null, true,false, false, null);
        assertNotNull(resp);
        assertEquals(HttpStatus.NO_CONTENT, resp.getStatusCode());
               
    }
    
    @Test
    public void testListDocumentsPagingCase1() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                null, null, null,
                null, false, false, true, null);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
               
    }
    
    @Test
    public void testListDocuments_filterPhase() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                null, null, DocumentPhase.PUB,
                null, false, false, false, null);
        assertNotNull(resp);
       assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(1, resp.getBody().getList().size());
               
    }
    
    @Test
    public void testListDocumentsPagingCase2() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                Arrays.asList(ProposalDocumentTypeCode.TWL),  null, null,
                Arrays.asList(ProposalDocumentVersionClassificationCode.Initial), false, false, true, null);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertTrue(resp.getBody().getList().size() >=2);
               
    }
    
    @Test
    public void testListDocumentsPagingCaseWithFiltered() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                Arrays.asList(ProposalDocumentTypeCode.TWL,ProposalDocumentTypeCode.PUB), null, null,
                Arrays.asList(ProposalDocumentVersionClassificationCode.Initial), false, true, false, null);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        log.info("size: {}",resp.getBody().getList().size());
        assertTrue(resp.getBody().getList().size() == 4);
               
    }
    @Test
    public void testListDocumentsWithDocumentTypeList() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                Arrays.asList(ProposalDocumentTypeCode.TWL,ProposalDocumentTypeCode.PUB), null, null,
                Arrays.asList(ProposalDocumentVersionClassificationCode.Initial), false, false, true, null);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        log.info("size: {}",resp.getBody().getList().size());
        assertEquals(4,resp.getBody().getList().size());
               
    }
    @Test
    public void testListDocumentsPagingCaseWithFilteredNotApprovedByAll() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                Arrays.asList(ProposalDocumentTypeCode.TWL,ProposalDocumentTypeCode.PUB), null, null,
                Arrays.asList(ProposalDocumentVersionClassificationCode.Initial), false, false, false, null);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        log.info("size: {}",resp.getBody().getList().size());
        
        assertTrue(resp.getBody().getList().size() == 4);
               
    }
    
    // Adding unit test cases for 4 scenarios
    // Anx Number Sort ASC and Type Sort ASC
    @Test
    public void testListDocumentsWithAscendingAnxAndAscendingType() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                Arrays.asList(ProposalDocumentTypeCode.TWL, ProposalDocumentTypeCode.PUB), null, null,
                Arrays.asList(ProposalDocumentVersionClassificationCode.Initial), false, false, false, false);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        log.info("size: {}",resp.getBody().getList().size());
        assertTrue(resp.getBody().getList() != null && resp.getBody().getList().size() == 4);
        assertEquals(2, resp.getBody().getList().get(0).getAnxNumber().intValue());
        assertEquals(ProposalDocumentTypeCode.PUB, resp.getBody().getList().get(0).getDocumentType());
        assertEquals(5, resp.getBody().getList().get(1).getAnxNumber().intValue());
        assertEquals(ProposalDocumentTypeCode.PUB, resp.getBody().getList().get(0).getDocumentType());
    }
	 
    // Anx Number Sort ASC and Type Sort DESC
    @Test
    public void testListDocumentsWithAscendingAnxAndDescendingType() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                Arrays.asList(ProposalDocumentTypeCode.TWL, ProposalDocumentTypeCode.PUB), null, null,
                Arrays.asList(ProposalDocumentVersionClassificationCode.Initial), false, false, false, true);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        log.info("size: {}",resp.getBody().getList().size());
        assertTrue(resp.getBody().getList().size() == 4);
        assertEquals(1, resp.getBody().getList().get(0).getAnxNumber().intValue());
        assertEquals(ProposalDocumentTypeCode.TWL, resp.getBody().getList().get(0).getDocumentType());
        assertEquals(3, resp.getBody().getList().get(1).getAnxNumber().intValue());
        assertEquals(ProposalDocumentTypeCode.TWL, resp.getBody().getList().get(0).getDocumentType());
    }
	 
    // Anx Number Sort DESC and Type Sort ASC
    @Test
    public void testListDocumentsWithDescendingAnxAndAscendingType() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                Arrays.asList(ProposalDocumentTypeCode.TWL, ProposalDocumentTypeCode.PUB), null, null,
                Arrays.asList(ProposalDocumentVersionClassificationCode.Initial), false, false, true, false);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        log.info("size: {}",resp.getBody().getList().size());
        assertTrue(resp.getBody().getList().size() == 4);
        assertEquals(5, resp.getBody().getList().get(0).getAnxNumber().intValue());
        assertEquals(ProposalDocumentTypeCode.PUB, resp.getBody().getList().get(0).getDocumentType());
        assertEquals(2, resp.getBody().getList().get(1).getAnxNumber().intValue());
        assertEquals(ProposalDocumentTypeCode.PUB, resp.getBody().getList().get(0).getDocumentType());
    }
    
   // Anx Number Sort DESC and Type Sort DESC
    @Test
    public void testListDocumentsWithDescendingAnxAndDescendingType() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                Arrays.asList(ProposalDocumentTypeCode.TWL, ProposalDocumentTypeCode.PUB, ProposalDocumentTypeCode.RID), null, null,
                Arrays.asList(ProposalDocumentVersionClassificationCode.Initial), false, false, true, true);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        log.info("size: {}",resp.getBody().getList().size());
        assertTrue(resp.getBody().getList().size() == 5);
        assertEquals(3, resp.getBody().getList().get(0).getAnxNumber().intValue());
        assertEquals(ProposalDocumentTypeCode.TWL, resp.getBody().getList().get(0).getDocumentType());
        assertEquals(1, resp.getBody().getList().get(1).getAnxNumber().intValue());
        assertEquals(ProposalDocumentTypeCode.TWL, resp.getBody().getList().get(1).getDocumentType());
        assertEquals(6, resp.getBody().getList().get(2).getAnxNumber().intValue());
        assertEquals(ProposalDocumentTypeCode.RID, resp.getBody().getList().get(2).getDocumentType());
    }
    
    @Test
    public void testGetDocumentApprovals() {       
            
        ResponseEntity<List<ProposalDocumentApproval>> resp = proposalDocumentController.listDocumentApprovalsById(
                GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), 
                GUIDUtils.fromDatabaseFormat("c960d30a52a852fc8c51b64dfcc0ea85"));
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertTrue(resp.getBody().size()>= 2);          
    }
    
    @Test
    public void testGetDocumentApprovals_mismatchedProposalAndDoc() {       
            
        try {
        ResponseEntity<List<ProposalDocumentApproval>> resp = proposalDocumentController.listDocumentApprovalsById(
                GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), 
                GUIDUtils.fromDatabaseFormat("c960d30a52a852fc8c51b64dfcc0ea85"));
            fail(); // if you get this far, the mismatched pro/doc relationship is not being detected
        } catch (Exception e) {
            assertEquals(IllegalArgumentException.class, e.getClass());
            assertEquals("Document c960d30a-52a8-52fc-8c51-b64dfcc0ea85 does not belong to proposal d153f9bf-8048-48aa-8ba2-02db9f844db5", e.getMessage());
        }
    }
    
    @Test
    public void testGetDocumentApprovals_entitynotfound() {       
            
        try {
        ResponseEntity<List<ProposalDocumentApproval>> resp = proposalDocumentController.listDocumentApprovalsById(
                GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), 
                UUID.fromString("7af7219c-b604-4359-a2fc-5996484f4672")); // this doc does not exist
            fail(); // if you get this far, the mismatched pro/doc relationship is not being detected
        } catch (Exception e) {
            assertEquals(EntityNotFoundException.class, e.getClass());
            assertEquals("Document 7af7219c-b604-4359-a2fc-5996484f4672 does not exist", e.getMessage());
        }
    }

    
    @Test
    public void testListDocumentsPagingCase3() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("5578f1c578d64e2887af1a27bb789ff2"),
                Arrays.asList(ProposalDocumentTypeCode.TWL), null, null,
                Arrays.asList(ProposalDocumentVersionClassificationCode.Initial), true, false, true, null);
        assertNotNull(resp);
        assertEquals(HttpStatus.NO_CONTENT, resp.getStatusCode());
               
    }
    
    @Test
    public void testUpdateDocumentComment() {

        Date now = new Date();
        UUID changeProposalExternalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        UUID proposalDocumentExternalId = GUIDUtils.fromDatabaseFormat("c960d30a52a852fc8c51b64dfcc0ea85");

        ProposalDocumentRequest pDocument = new ProposalDocumentRequest();
        pDocument.setComment("pre-approval comment");
        pDocument.setUpdateTs(now);
        pDocument.setId(proposalDocumentExternalId);

        ProposalDocumentApprovalRequest pDocumentApproval = new ProposalDocumentApprovalRequest();
        pDocumentApproval.setId(GUIDUtils.fromDatabaseFormat("f70de2e14d774a7d929d564262e84e5a"));
        pDocumentApproval.setComment("Approved By Tester");
        pDocumentApproval.setUpdateTs(now);

        pDocument.getApprovals().add(pDocumentApproval);

        ResponseEntity response = proposalDocumentController.updateExistingDocumentComment(changeProposalExternalId,
                proposalDocumentExternalId, pDocument);
        assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());

        ChangeProposalDocument cpd = changeProposalDocumentRepository.findByExternalId(GUIDUtils.toDatabaseFormat(proposalDocumentExternalId));
        assertEquals("pre-approval comment", cpd.getUploadComment());

    }
    @Test
    public void testListDocumentsWithEmptyDocumentTypeList() {       
            
        ResponseEntity<ProposalDocumentPage> resp = proposalDocumentController.listProposalDocuments(
                0,25,GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"),
                Arrays.asList(),  null, null,
                Arrays.asList(ProposalDocumentVersionClassificationCode.Initial), false, false, false, null);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
//        log.info("size: {}",resp.getBody().getList().size());
//        assertEquals(4,resp.getBody().getList().size());
            
    }    
    

    @Test
    public void testListProposalDocuments_ApprovedReclassDocuments() {

		ResponseEntity<ProposalDocumentPage> listDocsResp = proposalDocumentController.listProposalDocuments(0, 25,
				GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), null, null, DocumentPhase.RECLASS, null,
				false, true, false, null);

		assertNotNull(listDocsResp);
		assertEquals(HttpStatus.OK, listDocsResp.getStatusCode());
		assertEquals(1, listDocsResp.getBody().getList().size());
	 }
    
    @Test
    public void testListProposalDocuments_RejectedReclassDocuments() {

		ResponseEntity<ProposalDocumentPage> listDocsResp = proposalDocumentController.listProposalDocuments(0, 25,
				GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), null, null, DocumentPhase.RECLASS, null,
				false, false, false, null);

		assertNotNull(listDocsResp);
		assertEquals(HttpStatus.OK, listDocsResp.getStatusCode());
		assertEquals(1, listDocsResp.getBody().getList().size());
	 }
    @Test
    public void testListProposalDocuments_PubPhase_PI() {

		ResponseEntity<ProposalDocumentPage> listDocsResp = proposalDocumentController.listProposalDocuments(0, 25,
				GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), null, Arrays.asList(PublicationPhase.PI), null, null,
				false, null, false, null);

		assertNotNull(listDocsResp);
		assertEquals(HttpStatus.OK, listDocsResp.getStatusCode());
		assertEquals(2, listDocsResp.getBody().getList().size());
	 }
    @Test
    public void testListProposalDocuments_PubPhase_PF() {

		ResponseEntity<ProposalDocumentPage> listDocsResp = proposalDocumentController.listProposalDocuments(0, 25,
				GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), null, Arrays.asList(PublicationPhase.PF), null, null,
				false, null, false, null);

		assertNotNull(listDocsResp);
		assertEquals(HttpStatus.OK, listDocsResp.getStatusCode());
		assertEquals(1, listDocsResp.getBody().getList().size());
	 }
    @Test
    public void testListProposalDocuments_PubPhase_OTH() {

		ResponseEntity<ProposalDocumentPage> listDocsResp = proposalDocumentController.listProposalDocuments(0, 25,
				GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), null, Arrays.asList(PublicationPhase.OTH), null, null,
				false, null, false, null);

		assertNotNull(listDocsResp);
		assertEquals(HttpStatus.OK, listDocsResp.getStatusCode());
		assertEquals(3, listDocsResp.getBody().getList().size());
	 }
    @Test
    public void testListProposalDocuments_PubPhase_List() {

		ResponseEntity<ProposalDocumentPage> listDocsResp = proposalDocumentController.listProposalDocuments(0, 25,
				GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), null,
				Arrays.asList(PublicationPhase.OTH, PublicationPhase.PF, PublicationPhase.PI), null, null, false, null,
				false, null);

		assertNotNull(listDocsResp);
		assertEquals(HttpStatus.OK, listDocsResp.getStatusCode());
		assertEquals(6, listDocsResp.getBody().getList().size());
	 }
    
    @Test
    public void testListProposalDocuments_with_multi_comments() {

		ResponseEntity<ProposalDocumentPage> listDocsResp = proposalDocumentController.listProposalDocuments(0, 25,
				GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"), null, null, null, null,
				false, null, false, null);

		assertNotNull(listDocsResp);
		assertEquals(HttpStatus.OK, listDocsResp.getStatusCode());
		int foundTarget = 0;
		for (ProposalDocument doc: listDocsResp.getBody().getList() ) {
			for (ProposalDocumentApproval approval: doc.getApprovals()) {
				if (approval.getId().equals(GUIDUtils.fromDatabaseFormat("f70de2e14d774a7d929d564262e84e5a")) 
						&& approval.getComments().size() == 2) {
					foundTarget ++;
					assertTrue(approval.getComments().get(0).getCreateTs()
							.after(approval.getComments().get(1).getCreateTs()));
				}
				for (ProposalDocumentApprovalComment comment: approval.getComments()) {
					assertNotNull(comment.getId());
					assertNotNull(comment.getCreateTs());
					assertTrue(StringUtils.isNotEmpty(comment.getCommentText()));

					assertTrue(StringUtils.isNotEmpty(comment.getCreateUserId()));
				}
			}
		}
		assertTrue(foundTarget > 0);
	 }
    
    /**
    @Test
    public void testDeleteDocumentComment() {
    	Date now = new Date();
        UUID changeProposalExternalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        UUID proposalDocumentExternalId = GUIDUtils.fromDatabaseFormat("c960d30a52a852fc8c51b64dfcc0ea85");
        UUID approvalCommentExternalId = GUIDUtils.fromDatabaseFormat("f70de2e14d774a7d929d564262e84e5a");
        ResponseEntity response = proposalDocumentController.deleteApproval(changeProposalExternalId,
                proposalDocumentExternalId, approvalCommentExternalId);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
    */
    
    @Test
    @Transactional
    public void testExportDocsIntoZipByChangeProposalId() throws Exception {        
        String guid = "c960d30a52a847fc8c51b64dfcc0ea85";
        HttpServletResponse resp = WebMocker.mockHttpResponse();
        List<String> documentGuids = new ArrayList<>();
        documentGuids.add("352b5e1c-7419-4375-b9a5-05ab27db1d0e");
        proposalDocumentController.exportChangeProposalDocuments(GUIDUtils.fromDatabaseFormat(guid), documentGuids, resp);
        File f = new File("target/proposaldocs.zip");
        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
        Assert.assertTrue(f != null && f.exists() && f.length() >10);

    }
    
	@Test
	@Transactional
	public void testListProposalDocuments_DFN_DFM_DocumentType() {

		ResponseEntity<ProposalDocumentPage> listDocsResp = proposalDocumentController.listProposalDocuments(0, 25,
				GUIDUtils.fromDatabaseFormat("405cfba610d54d05a25db281d335214d"),
				Arrays.asList(ProposalDocumentTypeCode.DFM), null, null, null, false,
				null, false, null);

		assertNotNull(listDocsResp);
		assertEquals(HttpStatus.OK, listDocsResp.getStatusCode());
		assertEquals(1, listDocsResp.getBody().getList().size());
		assertEquals(ProposalDocumentTypeCode.DFM, listDocsResp.getBody().getList().get(0).getDocumentType());
		
		listDocsResp = proposalDocumentController.listProposalDocuments(0, 25,
				GUIDUtils.fromDatabaseFormat("405cfba610d54d05a25db281d335214d"),
				Arrays.asList(ProposalDocumentTypeCode.DFN), null, null, null, false,
				null, false, null);

		assertNotNull(listDocsResp);
		assertEquals(HttpStatus.OK, listDocsResp.getStatusCode());
		assertEquals(1, listDocsResp.getBody().getList().size());
		assertEquals(ProposalDocumentTypeCode.DFN, listDocsResp.getBody().getList().get(0).getDocumentType());
	 }
	
      
    @Before
    public void setUp() throws Exception {
        datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
    			"bkuppusamy", "Boops","Kuppusamy", "US");
    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"boopathi.kuppusamy@uspto.gov", token,
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }

}