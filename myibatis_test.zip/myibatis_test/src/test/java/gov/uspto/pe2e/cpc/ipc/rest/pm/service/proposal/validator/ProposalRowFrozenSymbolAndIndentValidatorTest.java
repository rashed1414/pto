package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowFrozenSymbolAndIndentValidatorTest {
    private static final Logger log = LoggerFactory.getLogger(TitleReferencePartValidatorTest.class);

    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalRowFrozenSymbolAndIndentValidator proposalRowFrozenSymbolAndIndentValidator;

    @Resource
    private List<ProposalValidator> proposalValidators;

    @Test
    public void testConfigCorrectlyIncludesGrammarValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName()
                    .equals(proposalRowFrozenSymbolAndIndentValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }

    @Test
    public void testValidate() {
        
        log.info("In ProposalRowFrozenSymbolAndIndentValidatorTest");
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01B63/00", "0", "Testing",
                new String[] {}));

        ProposalValidationContext proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenSymbolAndIndentValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

        rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B63/00", "1", "Testing",
                new String[] {}));

        proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenSymbolAndIndentValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Cannot change the indent of this Frozen group.",
                rows.get(0).getValidationMessages().get(0).getMessageText());

        Assert.assertEquals(ValidationCost.MEDIUM, proposalRowFrozenSymbolAndIndentValidator.getCost());
        Assert.assertEquals(ValidationMessageType.RECORD,
                proposalRowFrozenSymbolAndIndentValidator.getValidationType());

        rows = new ArrayList<>();
        proposalRowFrozenSymbolAndIndentValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.size());

        rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "", "1", "Testing", new String[] {}));

        proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenSymbolAndIndentValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

        rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B63/00112", "1", "Testing",
                new String[] {}));

        proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenSymbolAndIndentValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

        rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B63/002", "1", "Testing",
                new String[] {}));

        proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenSymbolAndIndentValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

    }

    @Before
    public void setUp() throws Exception {

        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        DateTimeZone.setDefault(DateTimeZone.UTC);
        datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }
}
