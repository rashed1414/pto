package gov.uspto.pe2e.cpc.ipc.rest.pm.job;

import java.util.Date;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.LocalDateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposal;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalLock;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalLockRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalLockCleanupHelperJobTest {
    private static final Logger log = LoggerFactory.getLogger(ProposalLockCleanupHelperJobTest.class);
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject 
    private ChangeProposalRepository changeProposalRepository;

    @Inject 
    private ChangeProposalLockRepository changeProposalLockRepository;

    @Inject 
    private ProposalLockCleanupHelperJob proposalLockCleanupHelperJob;

    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }


    @Test
    @Transactional
    public void test() {
        Date inpast = new LocalDateTime().plusMinutes(-15).toDate(); 
        ChangeProposal p = changeProposalRepository.findById(1000000001L).get();
        ChangeProposalLock lock = new ChangeProposalLock();
        lock.setId(p.getId());
        lock.setCreateTs(inpast);
        lock.setCreateUserId("me");
        lock.setExpirationTs(inpast);
        lock.setLastModTs(inpast);
        lock.setLastModUserId("me");
        lock.setLockControl(0);
        lock.setLockedUserId("me");
        changeProposalLockRepository.save(lock);
        long count = changeProposalLockRepository.count();
        log.debug("Records exist {} ",count);
        Assert.assertEquals(1, count);
        proposalLockCleanupHelperJob.kickCleanup();
        long shouldBeZero = changeProposalLockRepository.count();
        Assert.assertEquals(0, shouldBeZero);
        
    }

}
