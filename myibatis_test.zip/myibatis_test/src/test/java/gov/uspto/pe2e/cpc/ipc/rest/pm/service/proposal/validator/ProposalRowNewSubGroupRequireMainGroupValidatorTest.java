package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowNewSubGroupRequireMainGroupValidatorTest {
	
	private static final Logger log = LoggerFactory.getLogger(ProposalRowNewSubGroupRequireMainGroupValidatorTest.class);
	
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ProposalRowNewSubGroupRequireMainGroupValidator proposalRowNewSubGroupRequireMainGroupValidator;
    
    @Inject
    private ProposalValidationService proposalValidationService;

    private static final String ERROR_MSG = "Cannot insert new subgroup which has no corresponding main group.";
    
    private Date lastInit =  null;
    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.HIGH, proposalRowNewSubGroupRequireMainGroupValidator.getCost());
    }
    
    @Test
    public void testGetValidationType() {
        Assert.assertEquals(ValidationMessageType.GLOBAL, proposalRowNewSubGroupRequireMainGroupValidator.getValidationType());
    }

    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();
	        SchemePublicationVersion version = new SchemePublicationVersion();
	        version.setClassificationSchemeId(1L);
	        version.setCpcXsdVersion("1.7");
	        version.setDefinitionXsdVersion("1.0");
	        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
	        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
	        SchemePublicationVersionContextHolder.setContext(version);
    }
    
    @Test
    @Transactional
    public void testValidateSortKeySymbolFoundInSCT() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N2005/123", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "H04N5/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N5/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    @Transactional
    public void testValidateSortKeySymbolNotFoundInSCT() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N2005/123", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "H04N5/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        Assert.assertEquals(ValidationMessageField.SYMBOL_NAME, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
        Assert.assertEquals(ERROR_MSG, msg.getMessageText());
    } 
    
    @Test
    @Transactional
    public void testValidateSortKeySymbolFoundInSCTWithTypeN() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N2005/123", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "H04N5/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    } 
    
    @Test
    @Transactional
    public void testValidateSortKeySymbolNotFoundInDBWithTypeC() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N2005/123", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("C", "H04N5/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        Assert.assertEquals(ValidationMessageField.SYMBOL_NAME, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
        Assert.assertEquals(ERROR_MSG, msg.getMessageText());
    } 
    
    @Test
    @Transactional
    public void testValidateSortKeySymbolFoundInDBWithTypeC() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01B1/015", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("C", "A01B1/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    } 
    
    
    @Test
    @Transactional
    public void testValidateSortKeySymbolFoundInSCTWithUType() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N2005/123", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "H04N5/00", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        Assert.assertEquals(ValidationMessageField.SYMBOL_NAME, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
        Assert.assertEquals(ERROR_MSG, msg.getMessageText());
    } 
    
    @Test
    @Transactional
    public void testValidateSortKeySymbolFoundInGoldCopy() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A01B1/015", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);      
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    @Transactional //
    public void testValidateSortKeySymbolNotFoundInGoldCopy() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01B12/015", "0", "Bold Error ##BOLD##", new String[] {"A01B1/99"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        Assert.assertEquals(ValidationMessageField.SYMBOL_NAME, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
        Assert.assertEquals(ERROR_MSG, msg.getMessageText());
    } 
    
    @Test
    @Transactional
    public void testValidateSymbolNotASubGroupSymbol() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A01B1", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);      
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    @Transactional
    public void testValidateSymbolWithBlank() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", " ", "0", "Bold Error ##BOLD##", new String[] {"A01B1/999"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);      
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    @Transactional
    public void testValidateSymbolWithNull() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(null);
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);      
        Assert.assertNull(rows.get(0));
    }
    
    @Test
    @Transactional
    public void testValidateSymbolWithEmptySCT() {
        List<RevisionChangeItem> rows = null;      
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNewSubGroupRequireMainGroupValidator.validate(proposalValidationContext, rows);
        Assert.assertNull(rows);        
    }
}
