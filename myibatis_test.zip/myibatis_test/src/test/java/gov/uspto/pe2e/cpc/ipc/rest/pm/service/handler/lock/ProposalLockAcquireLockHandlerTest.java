package gov.uspto.pe2e.cpc.ipc.rest.pm.service.handler.lock;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.UUID;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockServletContext;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import com.amazonaws.HttpMethod;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import jakarta.servlet.http.HttpServletRequest;

public class ProposalLockAcquireLockHandlerTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Test
	public void testIsNotExcluded() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamy@uspto.gov", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		UUID uuid = UUID.randomUUID();
		
		HttpServletRequest request = new MockHttpServletRequest(new MockServletContext("/cpcipcrestweb"),HttpMethod.POST.name(), "/proposals/"+uuid.toString()+"/meetings");
		
		ProposalLockAcquireLockHandler handler = new ProposalLockAcquireLockHandler();
		assertTrue(handler.isModifying(request));
		assertTrue(handler.isExcluded(request, uuid));
	
	}

}
