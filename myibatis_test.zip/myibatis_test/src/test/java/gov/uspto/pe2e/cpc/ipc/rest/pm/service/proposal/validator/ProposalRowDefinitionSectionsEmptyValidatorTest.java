package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import static org.junit.Assert.assertNotNull;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefinitionSectionType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationPhase;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionStatement;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionTitle;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.GlossaryOfTerms;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.LimitingReferences;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.Relationship;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.SynonymsKeywords;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowDefinitionSectionsEmptyValidatorTest {

    private static final Logger log = LoggerFactory.getLogger(ProposalRowDefinitionSectionsEmptyValidatorTest.class);
    
    private static final String VALIDATION_MESSAGE = "Definition section with Type U, N, M, or D cannot be empty.";
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalRowDefinitionSectionsEmptyValidator proposalRowDefinitionSectionsEmptyValidator;

    @Resource(name = "proposalConsistencyValidator")
    private List<ProposalValidator> consistencyValidators;

    @Inject
    private ProposalValidationService proposalValidationService;

    private DocumentAdapter docAdapter;

    
    @Test
    public void testConfigCorrectlyIncludesDefinitionSectionsEmptyValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : consistencyValidators) {
            if (validator.getClass().getCanonicalName()
                    .equals(proposalRowDefinitionSectionsEmptyValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }

    /**
     * This is a single comprehensive test that has multiple null definition,
     * multiple nonnulls (3) 2 sections will have multiple errors each
     */
    @Test
    public void testValidateDefinitionSectionsEmpty() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemWithDefinitionStatements("U", "A01B1/02", "0", "test;hello",
                new String[] { "A01B 5/005", "A01B 5/008" }));

        ProposalValidationContext proposalValidationContext = proposalValidationService
                .createProposalValidationContext(rows);
        proposalRowDefinitionSectionsEmptyValidator.validate(proposalValidationContext, rows);
        
        Assert.assertEquals(VALIDATION_MESSAGE, 
                                    rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals(VALIDATION_MESSAGE, 
                rows.get(0).getValidationMessages().get(1).getMessageText()); 
        Assert.assertEquals(ValidationMessageField.GLOSSARY_OF_TERMS, rows.get(0).getValidationMessages().get(0).getTriggerField());
        Assert.assertEquals(ValidationMessageField.LIMITING_REFERENCES, rows.get(0).getValidationMessages().get(1).getTriggerField()); 
        Assert.assertEquals(ValidationPhase.CONSISTENCY, rows.get(0).getValidationMessages().get(0).getPhase());                
        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(0).getLevel());
        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(0).getMessageType());

    }

    public RevisionChangeItem createRevisionChangeItemWithDefinitionStatements(String entryType, String symbolName,
            String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel,
                titleGrammar, reclassTargets);
        item.getDefinitionItems().add(createDefinitionTitleSection(SCTComponentChangeType.M));
        item.getDefinitionItems().add(createDefinitionStatementSection(SCTComponentChangeType.M));
        item.getDefinitionItems().add(createDefinitionGlossarySection(SCTComponentChangeType.N));
        item.getDefinitionItems().add(createDefinitionLimitingReferenceSection(SCTComponentChangeType.U));
        item.getDefinitionItems().add(createDefinitionSynonymsNKeywordsSection(SCTComponentChangeType.D));       
        return item;
    }
   
    @Test
    public void testValidateEmptyLimingDefinitionSection() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemWithEmptyLimitingDefinitionSection("U", "A01B1/02", "0", "test;hello",
                new String[] { "A01B 5/005", "A01B 5/008" }));

        ProposalValidationContext proposalValidationContext = proposalValidationService
                .createProposalValidationContext(rows);
        proposalRowDefinitionSectionsEmptyValidator.validate(proposalValidationContext, rows);
        
        Assert.assertEquals(VALIDATION_MESSAGE, 
                                    rows.get(0).getValidationMessages().get(0).getMessageText());      
        Assert.assertEquals(ValidationPhase.CONSISTENCY, rows.get(0).getValidationMessages().get(0).getPhase());                
        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(0).getLevel());
        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(0).getMessageType());

    }
    
    public RevisionChangeItem createRevisionChangeItemWithEmptyLimitingDefinitionSection(String entryType, String symbolName,
            String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel,
                titleGrammar, reclassTargets);
        item.getDefinitionItems().add(createDefinitionEmptyLimitingSection(SCTComponentChangeType.M));        
        return item;
    }
    
    
    @Test
    public void testValidateEmptyRelationDefinitionSection() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemWithEmptyRelationDefinitionSection("U", "A01B1/02", "0", "test;hello",
                new String[] { "A01B 5/005", "A01B 5/008" }));

        ProposalValidationContext proposalValidationContext = proposalValidationService
                .createProposalValidationContext(rows);
        proposalRowDefinitionSectionsEmptyValidator.validate(proposalValidationContext, rows);
        
        Assert.assertEquals(VALIDATION_MESSAGE, 
                                    rows.get(0).getValidationMessages().get(0).getMessageText());      
        Assert.assertEquals(ValidationPhase.CONSISTENCY, rows.get(0).getValidationMessages().get(0).getPhase());                
        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(0).getLevel());
        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(0).getMessageType());

    }
    
    public RevisionChangeItem createRevisionChangeItemWithEmptyRelationDefinitionSection(String entryType, String symbolName,
            String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel,
                titleGrammar, reclassTargets);
        item.getDefinitionItems().add(createDefinitionEmptyRelationSection(SCTComponentChangeType.M));        
        return item;
    }
    
    @Test
    public void testValidateEmptyDefinitionStatementSection() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemWithEmptyDefinitionStatementSection("U", "A01B1/02", "0", "test;hello",
                new String[] { "A01B 5/005", "A01B 5/008" }));

        ProposalValidationContext proposalValidationContext = proposalValidationService
                .createProposalValidationContext(rows);
        proposalRowDefinitionSectionsEmptyValidator.validate(proposalValidationContext, rows);
        
        Assert.assertEquals(VALIDATION_MESSAGE, 
                                    rows.get(0).getValidationMessages().get(0).getMessageText());      
        Assert.assertEquals(ValidationPhase.CONSISTENCY, rows.get(0).getValidationMessages().get(0).getPhase());                
        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(0).getLevel());
        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(0).getMessageType());

    }
    
    @Test
    public void testValidateEmptyDefinitionStatementSectionWithImage() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRCItemWithImageDefinitionStatementSection("U", "A01B1/02", "0", "test;hello",
                new String[] { "A01B 5/005", "A01B 5/008" }));

        ProposalValidationContext proposalValidationContext = proposalValidationService
                .createProposalValidationContext(rows);
        proposalRowDefinitionSectionsEmptyValidator.validate(proposalValidationContext, rows);
        
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
    }
    
    public RevisionChangeItem createRevisionChangeItemWithEmptyDefinitionStatementSection(String entryType, String symbolName,
            String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel,
                titleGrammar, reclassTargets);
        item.getDefinitionItems().add(createDefinitionEmptyStatmentSection(SCTComponentChangeType.M));  
        item.getDefinitionItems().add(createDefinitionSynonymsNKeywordsSectionWithImage(SCTComponentChangeType.D));
        return item;
    }
    
    public RevisionChangeItem createRCItemWithImageDefinitionStatementSection(String entryType, String symbolName,
            String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel,
                titleGrammar, reclassTargets);
        item.getDefinitionItems().add(createDefinitionSynonymsNKeywordsSectionWithImage(SCTComponentChangeType.D));
        return item;
    }
    
    private DefSectionItemEditRequest createDefinitionStatementSection(
            SCTComponentChangeType updateType) {
        DefSectionItemEditRequest req = new DefSectionItemEditRequest();
        req.setChangeType(updateType);
        req.setSectionType(DefinitionSectionType.DEFINITION_STATEMENT);
        DefinitionStatement def = null;       
        try( InputStream is = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/definition_definitionstatement_non_empty.xml"))  {           
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
                +IOUtils.toString(is)+"</definition-item>");
            def = defItem.getDefinitionStatement();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        }
        
        req.setDefinitionStatement(def);
        assertNotNull(req.getDefinitionStatement());
        return req;
    }
    
    private DefSectionItemEditRequest createDefinitionTitleSection(
            SCTComponentChangeType updateType) {
        DefSectionItemEditRequest req = new DefSectionItemEditRequest();
        req.setChangeType(updateType);
        req.setSectionType(DefinitionSectionType.DEFINITION_TITLE);
        DefinitionTitle defTitle = null;      
        try(InputStream is = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/definition_title_non_empty.xml"))  {            
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
                +IOUtils.toString(is)+"</definition-item>");
            defTitle = defItem.getDefinitionTitle();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        }
        
        req.setDefinitionTitle(defTitle);
        assertNotNull(req.getDefinitionTitle());
        return req;
    }
    
    private DefSectionItemEditRequest createDefinitionEmptyLimitingSection(
            SCTComponentChangeType updateType) {
        DefSectionItemEditRequest req = new DefSectionItemEditRequest();
        req.setChangeType(updateType);
        req.setSectionType(DefinitionSectionType.LIMITING_REFERENCES);
        LimitingReferences limiting = null;       
        try(InputStream is = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/definition_section_limit_empty.xml"))  {            
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
                +IOUtils.toString(is)+"</references></definition-item>");
            limiting = defItem.getReferences().getLimitingReferences();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        }        
        req.setLimitingReferences(limiting);
        assertNotNull(req.getLimitingReferences());
        return req;
    }
    
    private DefSectionItemEditRequest createDefinitionEmptyRelationSection(
            SCTComponentChangeType updateType) {
        DefSectionItemEditRequest req = new DefSectionItemEditRequest();
        req.setChangeType(updateType);
        req.setSectionType(DefinitionSectionType.RELATIONSHIP);
        Relationship relation = null;      
        try(InputStream is = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/definition_section_relation_empty.xml"))  {
            
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
                +IOUtils.toString(is)+"</definition-item>");
            relation = defItem.getRelationship();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        }        
        req.setRelationship(relation);
        assertNotNull(req.getRelationship());
        return req;
    }
    
    private DefSectionItemEditRequest createDefinitionEmptyStatmentSection(
            SCTComponentChangeType updateType) {
        DefSectionItemEditRequest req = new DefSectionItemEditRequest();
        req.setChangeType(updateType);
        req.setSectionType(DefinitionSectionType.DEFINITION_STATEMENT);
        DefinitionStatement statement = null;
       
        try(InputStream is = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/definition_section_statement_empty.xml"))  {            
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
                +IOUtils.toString(is)+"</definition-item>");
            statement = defItem.getDefinitionStatement();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        }        
        req.setDefinitionStatement(statement);
        assertNotNull(req.getDefinitionStatement());
        return req;
    }
    
    private DefSectionItemEditRequest createDefinitionGlossarySection(
            SCTComponentChangeType updateType) {
        DefSectionItemEditRequest req = new DefSectionItemEditRequest();
        req.setChangeType(updateType);
        req.setSectionType(DefinitionSectionType.GLOSSARY_OF_TERMS);
        GlossaryOfTerms goft = null;
       
        try(InputStream is = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/definition_glossaryterms_empty.xml"))  {          
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
                +IOUtils.toString(is)+"</definition-item>");
            goft = defItem.getGlossaryOfTerms();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        }        
        req.setGlossaryOfTerms(goft);
        assertNotNull(req.getGlossaryOfTerms());
        return req;
    }
    
    private DefSectionItemEditRequest createDefinitionLimitingReferenceSection(
            SCTComponentChangeType updateType) {
        DefSectionItemEditRequest req = new DefSectionItemEditRequest();
        req.setChangeType(updateType);
        req.setSectionType(DefinitionSectionType.LIMITING_REFERENCES);
        LimitingReferences lr = null;     
        try(InputStream is = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/definition_limitingreference_empty.xml"))  {            
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
                +IOUtils.toString(is)+"</references></definition-item>");
            lr = defItem.getReferences().getLimitingReferences();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        }        
        req.setLimitingReferences(lr);
        assertNotNull(req.getLimitingReferences());
        return req;
    }
    
    private DefSectionItemEditRequest createDefinitionSynonymsNKeywordsSection(
            SCTComponentChangeType updateType) {
        DefSectionItemEditRequest req = new DefSectionItemEditRequest();
        req.setChangeType(updateType);
        req.setSectionType(DefinitionSectionType.SYNONYMS_AND_KEYWORDS);
        SynonymsKeywords snk = null;     
        try(InputStream is = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/definition_snk_empty.xml"))  {            
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
                +IOUtils.toString(is)+"</definition-item>");
            snk = defItem.getSynonymsKeywords();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        }        
        req.setSynonymsKeywords(snk);
        assertNotNull(req.getSynonymsKeywords());
        return req;
    }
    
    private DefSectionItemEditRequest createDefinitionSynonymsNKeywordsSectionWithImage(
            SCTComponentChangeType updateType) {
        DefSectionItemEditRequest req = new DefSectionItemEditRequest();
        req.setChangeType(updateType);
        req.setSectionType(DefinitionSectionType.SYNONYMS_AND_KEYWORDS);
        SynonymsKeywords snk = null;
        try(InputStream is  = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/definition_snk_with_image.xml"))  {
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
                +IOUtils.toString(is)+"</definition-item>");
            snk = defItem.getSynonymsKeywords();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        }         
        req.setSynonymsKeywords(snk);
        assertNotNull(req.getSynonymsKeywords());
        return req;
    }
    
    @Test
    public void testEmptyRows() {
        List<RevisionChangeItem> rows = new ArrayList<>();      
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowDefinitionSectionsEmptyValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.size());
    } 
    
    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.MEDIUM, proposalRowDefinitionSectionsEmptyValidator.getCost());

    }
    
    @Test
    public void testGetValidationType() {
        Assert.assertEquals(ValidationMessageType.RECORD, proposalRowDefinitionSectionsEmptyValidator.getValidationType());

    }

    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();
        
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        Class adapterClass = Class.forName(DocumentAdapter.class.getCanonicalName());
        docAdapter = (DocumentAdapter) adapterClass.newInstance();

    	
    }

}
