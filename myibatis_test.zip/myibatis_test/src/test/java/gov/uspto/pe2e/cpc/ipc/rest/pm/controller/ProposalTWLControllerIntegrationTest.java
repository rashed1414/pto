package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.InputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalTWL;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalTWLRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.TWLDocument;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.TWLDocumentStatus;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test-oraclelocal.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalTWLControllerIntegrationTest  {
    private static final Logger log = LoggerFactory.getLogger(ProposalTWLControllerIntegrationTest.class);
    
    @Inject
    private ProposalTWLController proposalTWLController;
    
    @Inject
    private ChangeProposalTWLRepository changeProposalTWLRepository;
 
    
    /**
     * happy path success test
     */
    @Transactional
    @Test
    public void testSaveNew() {        
        
    	UUID proposalId = UUID.fromString("66fad4fd-073a-4c70-a4fa-890eee9e4f82");
    	
    	try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("data/json/twl/twl_savefirst.json")) {
        
        Date now = new Date();
        TWLDocument twl = JsonUtils.fromJson(is, TWLDocument.class);
        twl.setProposalId(proposalId);
        		
        
        
            ResponseEntity<Void> resp = proposalTWLController.save(twl.getProposalId(), Arrays.asList(twl));
           
            assertEquals(1,  resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).size());
            String dbguid = StringUtils.remove(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0), "-");
            log.info("looking up by external id = {}", dbguid);
            ChangeProposalTWL dbTwl = changeProposalTWLRepository.findByExternalId(dbguid);
            assertNotNull(dbTwl);
            assertEquals(TWLDocumentStatus.PENDING, dbTwl.getStatus());
            assertEquals(3, dbTwl.getDetails().size());
    	} catch (Exception e) {
    		log.error("Exception ", e);
    	}
    	
    	
    }

    @After
    public void checkDb() {
    	log.debug(" count {}", changeProposalTWLRepository.count());
    }
    
    @Before
    public void setUp() throws Exception {
//        IDatabaseConnection conn = datasetTestingService.getConnection();
//        datasetTestingService.emptyTables(conn);
//        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
    			"bkuppusamy", "Boops","Kuppusamy", "US");
    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"boopathi.kuppusamy@uspto.gov", token,
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/proposals/1/twl")));
    }

    
    
}