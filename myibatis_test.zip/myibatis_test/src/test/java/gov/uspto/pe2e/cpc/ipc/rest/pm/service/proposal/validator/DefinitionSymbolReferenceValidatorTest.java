package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.stream.XMLStreamReader;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.CloseableUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.NamespaceXmlReader;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefinitionSectionType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionStatement;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.GlossaryOfTerms;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.SynonymsKeywords;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class DefinitionSymbolReferenceValidatorTest {
	
    private static final Logger log = LoggerFactory.getLogger(DefinitionSymbolReferenceValidatorTest.class);

    
    @Inject
    private DatasetTestingService datasetTestingService;
    
    
    @Inject
    private  DefinitionSymbolReferenceExistsValidator definitionSymbolReferenceExistsValidator;
    
    @Inject
    private DefinitionSymbolReferenceFormatValidator definitionSymbolReferenceFormatValidator;

    @Resource(name="proposalCompletenessValidator")
    private List<ProposalValidator> completenessValidators;
   
    @Resource(name="proposalConsistencyValidator")
    private List<ProposalValidator> consistencyValidators;
    
    @Inject
    private ProposalValidationService proposalValidationService;
    
    private DocumentAdapter docAdapter;
    

    @Test
    public void testConfigCorrectlyIncludesDefinitionSymbolReferenceValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : consistencyValidators) {
            if (validator.getClass().getCanonicalName().equals(definitionSymbolReferenceExistsValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
        isIncluded = false;
        for (ProposalValidator validator : completenessValidators) {
            if (validator.getClass().getCanonicalName().equals(definitionSymbolReferenceFormatValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);

    }
    
    /**
     * This is a single comprehensive test that has multiple null definition, multiple nonnulls (3)
     * 2 sections will have multiple errors each
     */
    @Test
    public void testValidateMultipleSectionsWithNulls() {
    	
    	  List<RevisionChangeItem> rows = new ArrayList<>();
          rows.add(createRevisionChangeItemWithDefinitionStatements("U", "A01B1/02", "0", "test;hello (section ##SYMBOL##A01B1/0241##/SYMBOL## test); Hello ##SYMBOL##A01B1/0261##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
          rows.add(createRevisionChangeItemWithDefinitionStatements("D", "A01N65/46", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
          rows.add(createRevisionChangeItemWithDefinitionStatements("M", "A01B1/0261", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
          rows.add(createRevisionChangeItemWithDefinitionStatements("N", "A01B1/0261", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
          rows.add(createRevisionChangeItemWithDefinitionStatements("N", "A01B 1/0262", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
          rows.add(createRevisionChangeItemWithDefinitionStatements("M", "A01B 1/0263", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
          
          ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
          definitionSymbolReferenceFormatValidator.validate(proposalValidationContext, rows);
          definitionSymbolReferenceExistsValidator.validate(proposalValidationContext, rows);
          Assert.assertEquals(5, rows.get(0).getValidationMessages().size());       
          int i = 0;
          for (ValidationMessage msg: rows.get(0).getValidationMessages()) {
        	  log.debug("{}  {} ", msg.getTriggerField(), msg.getMessageText());
        	  assertTrue(Arrays.asList(ValidationMessageField.DEFINITION_STATEMENT, 
        			  ValidationMessageField.GLOSSARY_OF_TERMS).contains(msg.getTriggerField()));
        	  if (i == 0) {
        		  assertEquals("Symbol(s) [NOTVALIDSYMBOLFMT] is not well formed (Does not match expected pattern)!",
        				  msg.getMessageText());
        	  }
        	  if (i == 1) {
        		  assertEquals("Symbol NOTVALIDSYMBOLFMT does not exist.", msg.getMessageText());
        	  }
        	  if (i == 4) {
        		  assertEquals("Symbol A01N65/46 is subject to deletion in this proposal.", msg.getMessageText());
        	  }
        	  i++;
          }
//          Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
//          log.debug("Validation Message" + rows.get(0).getValidationMessages().get(0).getMessageText());
//          Assert.assertEquals("Symbol A01B1/0241, A01C63/00 does not exist.", rows.get(0).getValidationMessages().get(0).getMessageText());
//          

    	
    }

    /**
     * This is a single comprehensive test that has multiple null definition, multiple nonnulls (3)
     * 2 sections will have multiple errors each
     */
    @Test
    public void testValidateSynonims() {
    	
    	  List<RevisionChangeItem> rows = new ArrayList<>();
          rows.add(createRevisionChangeItemWithOnlySNKDef("U", "A01B1/02", "0", "test;hello (section ##SYMBOL##A01B1/0241##/SYMBOL## test); Hello ##SYMBOL##A01B1/0261##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
          
          ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
          definitionSymbolReferenceFormatValidator.validate(proposalValidationContext, rows);
          definitionSymbolReferenceExistsValidator.validate(proposalValidationContext, rows);
          Assert.assertEquals(5, rows.get(0).getValidationMessages().size());       
          int i = 0;
          for (ValidationMessage msg: rows.get(0).getValidationMessages()) {
        	  log.debug("{}  {} ", msg.getTriggerField(), msg.getMessageText());
        	  assertTrue(Arrays.asList(ValidationMessageField.SYNONYMS_AND_KEYWORDS).contains(msg.getTriggerField()));
        	  if (i == 0) {
        		  assertEquals("Symbol(s) [NOTVALIDSYMBOLFMT] is not well formed (Does not match expected pattern)!",
        				  msg.getMessageText());
        	  }
        	  if (i == 1) {
        		  assertEquals("Symbol(s) [A01G/99] is not well formed (Does not match expected pattern)!", msg.getMessageText());
        	  }
        	  if (i == 4) {
        		  assertEquals("Symbol A01G3/06999 does not exist.", msg.getMessageText());
        	  }
        	  i++;
          }
//          Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
//          log.debug("Validation Message" + rows.get(0).getValidationMessages().get(0).getMessageText());
//          Assert.assertEquals("Symbol A01B1/0241, A01C63/00 does not exist.", rows.get(0).getValidationMessages().get(0).getMessageText());
//          

    	
    }

    public RevisionChangeItem createRevisionChangeItemWithDefinitionStatements(String entryType, String symbolName, String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel, titleGrammar, reclassTargets); 
        item.getDefinitionItems().add(createDefinitionStatementSection(SCTComponentChangeType.M));
        item.getDefinitionItems().add(createDefinitionGlossarySection(SCTComponentChangeType.M));
        return item;
    }
  
    public RevisionChangeItem createRevisionChangeItemWithOnlySNKDef(String entryType, String symbolName, String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel, titleGrammar, reclassTargets); 
        item.getDefinitionItems().add(createDefinitionSnKSection(SCTComponentChangeType.M));
        return item;
    }
    
    private DefSectionItemEditRequest createDefinitionSnKSection(SCTComponentChangeType updateType) {
  		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
  		req.setChangeType(updateType);
  		req.setSectionType(DefinitionSectionType.SYNONYMS_AND_KEYWORDS);
  		SynonymsKeywords snk = null;
  		InputStream is = null;
  		XMLStreamReader xsr = null;
  		NamespaceXmlReader xr = null;
  		try  {
  			is = Thread.currentThread().getContextClassLoader()
  		
  				.getResourceAsStream("data/xml/fragments/definition_snk_with_invalid_symbols.xml");
  			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
  				+IOUtils.toString(is)+"</definition-item>");	
//  			xsr = XMLInputFactory.newFactory("com.sun.xml.internal.stream.XMLInputFactoryImpl",
//  		                Thread.currentThread().getContextClassLoader()).createXMLStreamReader(is);
//  				xr = new NamespaceXmlReader(xsr, JaxbUtils.extractNamespace(DefinitionStatement.class));
//  				Unmarshaller um = STATEMENT_CTX.createUnmarshaller();
//  			statement = (DefinitionStatement)um.unmarshal(xr);
  			snk = defItem.getSynonymsKeywords();
  		} catch (Exception je) {
  			throw new IllegalArgumentException(je);
  		} finally {
  			CloseableUtils.closeQuietly(xr);
  			CloseableUtils.closeQuietly(xsr);
  			IOUtils.closeQuietly(is);
  		}
  		
  		req.setSynonymsKeywords(snk);
  		assertNotNull(req.getSynonymsKeywords());
  		return req;
  	}

  
      
    private DefSectionItemEditRequest createDefinitionStatementSection(SCTComponentChangeType updateType) {
		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
		req.setChangeType(updateType);
		req.setSectionType(DefinitionSectionType.DEFINITION_STATEMENT);
		DefinitionStatement statement = null;
		InputStream is = null;
		XMLStreamReader xsr = null;
		NamespaceXmlReader xr = null;
		try  {
			is = Thread.currentThread().getContextClassLoader()
		
				.getResourceAsStream("data/xml/fragments/definition_statement_with_invalid_symbols.xml");
			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
				+IOUtils.toString(is)+"</definition-item>");	
//			xsr = XMLInputFactory.newFactory("com.sun.xml.internal.stream.XMLInputFactoryImpl",
//		                Thread.currentThread().getContextClassLoader()).createXMLStreamReader(is);
//				xr = new NamespaceXmlReader(xsr, JaxbUtils.extractNamespace(DefinitionStatement.class));
//				Unmarshaller um = STATEMENT_CTX.createUnmarshaller();
//			statement = (DefinitionStatement)um.unmarshal(xr);
			statement = defItem.getDefinitionStatement();
		} catch (Exception je) {
			throw new IllegalArgumentException(je);
		} finally {
			CloseableUtils.closeQuietly(xr);
			CloseableUtils.closeQuietly(xsr);
			IOUtils.closeQuietly(is);
		}
		
		req.setDefinitionStatement(statement);
		assertNotNull(req.getDefinitionStatement());
		return req;
	}

    private DefSectionItemEditRequest createDefinitionGlossarySection(SCTComponentChangeType updateType) {
  		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
  		req.setChangeType(updateType);
  		req.setSectionType(DefinitionSectionType.GLOSSARY_OF_TERMS);
  		GlossaryOfTerms glossary = null;
  		InputStream is = null;
  		XMLStreamReader xsr = null;
  		NamespaceXmlReader xr = null;
  		try  {
  			is = Thread.currentThread().getContextClassLoader()
  		
  				.getResourceAsStream("data/xml/fragments/definition_glossary_1_invalid_and_1_deleted_symbol.xml");
  			DefinitionItem defItem=	docAdapter.parseDefinition("<definition-item>"
  					+IOUtils.toString(is)+"</definition-item>");
//  			
//  			xsr = XMLInputFactory.newFactory("com.sun.xml.internal.stream.XMLInputFactoryImpl",
//  		                Thread.currentThread().getContextClassLoader()).createXMLStreamReader(is);
//  				xr = new NamespaceXmlReader(xsr, JaxbUtils.extractNamespace(GlossaryOfTerms.class));
//  				Unmarshaller um = GLOSSARY_CTX.createUnmarshaller();
  			glossary = defItem.getGlossaryOfTerms();
  		} catch (Exception je) {
  			throw new IllegalArgumentException(je);
  		} finally {
  			CloseableUtils.closeQuietly(xr);
  			CloseableUtils.closeQuietly(xsr);
  			IOUtils.closeQuietly(is);
  		}
  		
  		req.setGlossaryOfTerms(glossary);
  		assertNotNull(req.getGlossaryOfTerms());
  		return req;
  	}

	@Before
    public void setUp() throws Exception {
		datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        Class adapterClass = Class.forName(DocumentAdapter.class.getCanonicalName());
        docAdapter = (DocumentAdapter)adapterClass.newInstance();

    }

}
