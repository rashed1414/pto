package gov.uspto.pe2e.cpc.ipc.rest.pm.service;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

//import org.hamcrest.Matchers;


import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ExternalSystemCategory;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposal;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalAlias;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalState;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalStateTask;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalVersion;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ClassificationScheme;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.DescriptionNote;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalVersionRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.AssignmentGroup;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.OfficeContactType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalStateType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalSubphase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.SmeConsultationStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.GplSortBy;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.LastValidateStatusCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.OfficeContact;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PagableProposalSummary;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProjectSizeCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalMetadataUpdateRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalNamePrefix;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalRevisionSummary;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalSummary;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.TaskStateDetails;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalFactoryHelper;
import gov.uspto.pe2e.cpc.ipc.rest.pm.util.ProposalNameUtils;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityNotFoundException;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalServiceTest {
    
    private static final Logger log = LoggerFactory.getLogger(ProposalServiceTest.class);
    
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalService proposalService;
    
    @Inject
    private ChangeProposalRepository changeProposalRepository;

    @Inject
    private ChangeProposalVersionRepository changeProposalVersionRepository;

    @Inject
    private SecurityService securityService;
    
    @Inject
    private ProposalFactoryHelper proposalFactoryHelper;
    
    @Inject
    private EntityManagerFactory emf;
    
    @Test(expected=IllegalArgumentException.class)
    public  void testUpdateMissingMetadata () {
    	proposalService.updateProposalMetadata(UUID.randomUUID(), new ProposalMetadataUpdateRequest(), null);
    }
    
//	 Commented this test, since this functionality is no longer user
//    @Test(expected=EntityNotFoundException.class)
//    public void testUpdateProposalContactsNotValidProposal() {
//    	proposalService.updateProposalContacts(UUID.randomUUID(), null, null, null);
//    }
    
    @Test 
    public void testUpdateOfRappateurOfficeDuringMetadataUpdate() {
    	
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	 ProposalMetadataUpdateRequest request = new ProposalMetadataUpdateRequest();
         
         request.setId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));//"XX0026");              
         request.setSize(ProjectSizeCategory.MEDIUM);       
         
         request.setRapporteurOffice(StandardIpOfficeCode.US);
         
         List<OfficeContact> primaryContacts = new ArrayList<>();
         primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,OfficeContactType.COORDINATOR,"matt.young@uspto.gov"));
         primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,OfficeContactType.EDITORIAL_BOARD,"boops@uspto.gov"));
         primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,OfficeContactType.QN_TECH_EXPERT,"venkat@uspto.gov"));
         
         List<OfficeContact> secondaryContacts = new ArrayList<>();
         secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,OfficeContactType.COORDINATOR,"venkat@uspto.gov"));
         secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,OfficeContactType.EDITORIAL_BOARD,"boops@uspto.gov"));
         secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,OfficeContactType.QN_TECH_EXPERT,"matt.young@uspto.gov"));
         
         request.getPrimaryOfficeContacts().addAll(primaryContacts);
         request.getSecondaryOfficeContacts().addAll(secondaryContacts);
         
         ProposalSummary p = proposalService.updateProposalMetadata(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), request, authToken);

         Assert.assertNotNull(p);
         Assert.assertEquals("XX0026", p.getDisplayName());
         
//         Assert.assertEquals(3, p.getTechnologies().size());
         Assert.assertEquals(2, p.getPrimaryOfficeContacts().size());
         Assert.assertEquals(1, p.getSecondaryOfficeContacts().size());
    	
    }
    @Test 
    public void testUpdateOfRappateurOfficeDuringMetadataUpdate2() {
    	
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	 ProposalMetadataUpdateRequest request = new ProposalMetadataUpdateRequest();
         
         request.setId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));//"XX0026");              
         request.setSize(ProjectSizeCategory.MEDIUM);       
         
         request.setRapporteurOffice(StandardIpOfficeCode.EP);
         
         List<OfficeContact> primaryContacts = new ArrayList<>();
         primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,OfficeContactType.COORDINATOR,"matt.young@uspto.gov"));
         primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,OfficeContactType.EDITORIAL_BOARD,"boops@uspto.gov"));
         primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,OfficeContactType.QN_TECH_EXPERT,"venkat@uspto.gov"));
         
         List<OfficeContact> secondaryContacts = new ArrayList<>();
         secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,OfficeContactType.COORDINATOR,"venkat@uspto.gov"));
         secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,OfficeContactType.EDITORIAL_BOARD,"boops@uspto.gov"));
         secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,OfficeContactType.QN_TECH_EXPERT,"matt.young@uspto.gov"));
         
         request.getPrimaryOfficeContacts().addAll(primaryContacts);
         request.getSecondaryOfficeContacts().addAll(secondaryContacts);
         ProposalSummary p = proposalService.updateProposalMetadata(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), request, authToken);

         Assert.assertNotNull(p);
         Assert.assertEquals("XX0026", p.getDisplayName());
        
//         Assert.assertEquals(3, p.getTechnologies().size());
         Assert.assertEquals(1, p.getPrimaryOfficeContacts().size());
         Assert.assertEquals(2, p.getSecondaryOfficeContacts().size());
    	
    }
    
    @Test
    @Transactional
    public void testAliasMapping() {
    	ChangeProposal cp = new ChangeProposal();
    	cp.setExternalId(GUIDUtils.toDatabaseFormat(UUID.randomUUID()));
    	for (String name: Arrays.asList("CE:XX1234", "CE:RR1234", "CEF:RP1234","IP5:IF1234")) {
    		ChangeProposalAlias dbAlias = new ChangeProposalAlias();
    		dbAlias.setChangeProposal(cp);
    		dbAlias.setCreateTs(new Date());
    		dbAlias.setLastModifiedTs(dbAlias.getCreateTs());
    		dbAlias.setCreateUserId("TEST");
    		dbAlias.setLastModifiedUserId("TEST");
    		
    		String[] parts = name.split(":");
    		if ( JaxbUtils.isValidXmlEnumValue(ExternalSystemCategory.class, parts[0])) {
    			ExternalSystemCategory category = ExternalSystemCategory.fromValue(parts[0]);
    			dbAlias.setLastModifiedTs(new Date());
    			dbAlias.setSystemCategory(category);
    			dbAlias.setName(parts[1]);
    			boolean success = cp.getAliases().add(dbAlias);
    			log.debug("added {} successfully = {} hash={}", dbAlias.getName(), success, dbAlias.hashCode());
    		} else {
    			log.debug("{} not found in enum", parts[0]);
    		}
    	}

    	assertEquals(4, cp.getAliases().size());
    	ProposalSummary p = proposalService.mapToProposalSummary(cp, null, false, false, false);
    	assertNotNull(p);
    	assertEquals("RR1234", p.getDisplayName());
    	assertEquals(4, p.getAliases().size());
    	log.debug("proposal with aliases {}", JsonUtils.toJsonOrStacktrace(p));
    	assertEquals("IF1234", p.getAliases().get(0).getName());

    	assertEquals(ExternalSystemCategory.IP5.name(), p.getAliases().get(0).getSystemCategory());
    	assertEquals("RP1234", p.getAliases().get(1).getName());
    	assertEquals(ExternalSystemCategory.CEF.name(), p.getAliases().get(1).getSystemCategory());
    	assertEquals("RR1234", p.getAliases().get(2).getName());
    	assertEquals(ExternalSystemCategory.CE.name(), p.getAliases().get(2).getSystemCategory());
    	assertEquals("XX1234", p.getAliases().get(3).getName());
    	assertEquals(ExternalSystemCategory.CE.name(), p.getAliases().get(3).getSystemCategory());
    	
    	// TODO Verify DB Mapping allows IP5 as column value not IP_5

    }
    

//    @Transactional 
//    @Test
//    public void testListProposalSummary2(){
//        
//        PagableProposalSummary p = proposalService.listProposalSummary(0,1);
//        Assert.assertNotNull(p);
//    }
    
    // 
    @Transactional 
    @Test
    public void testGetProposalRevisionListByProjectId(){
        List<ProposalRevisionSummary> p = proposalService.getProposalRevisionListByProjectId(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
        Assert.assertTrue((p.size()>0)); 
        log.debug(" comment {} ", p.get(0).getComments().get(0).getCommentText());
        Assert.assertTrue(CollectionUtils.isNotEmpty(p.get(0).getComments()));
    //    Assert.assertTrue(StringUtils.isNotEmpty(p.get(0).getComments().get(0).getCommentText()));
        
       
    }

    @Transactional 
    @Test
    public void testGetProposalRevisionListByProjectId2(){
        
        List<ProposalRevisionSummary> p = proposalService.getProposalRevisionListByProjectId(UUID.randomUUID());
        Assert.assertFalse((p.size()>0));
    }
    
    @Transactional 
    @Test(expected=IllegalArgumentException.class)
    public void testCheckProposalVersionExistsWithRandomID() {        
        proposalService.checkProposalVersionExistsWithData(UUID.randomUUID());
    }
    
    @Transactional 
    @Test
    public void testCheckProposalVersionExistsWithData() {        
        proposalService.checkProposalVersionExistsWithData(GUIDUtils.fromDatabaseFormat("5578f1c578d64e2887af1a27bb789ff2"));
        Assert.assertTrue(true);
    }
    
    //1000000008
    //1000000004
    @Transactional 
    @Test
    public void testGetProposalRevisionListByProjectId3(){
        
        long id = 1000000004;
        List<ProposalRevisionSummary> p = proposalService.getProposalRevisionListByProjectId(GUIDUtils.fromDatabaseFormat("5578f1c578d64e2887af1a27bb789ff2"));
        Assert.assertTrue((p.size()>0));

    }

    @Transactional
    @Test
    public void testMapDbToWebModel() throws ParseException {
    	String dateFormat = "yyyy-MM-dd HH:mm:ss";
    	ChangeProposalVersion ver = changeProposalVersionRepository.findById("080f8146bd4e4e349350c1b184db1b56").get();
    			
//    			new ChangeProposalVersion();
//    	ver.setVersionId(5L);
//    	ver.setChangeProposal(chProp);
//    	ver.setVersionCreateTs(new DateTime().plusDays(-5).toDate());
//    	ver.setCreateTs(new Date());
//    	ver.setLastModifiedTs(new Date());
//    	ver.setLastModifiedUserId("Test user Modified");
//    	ver.setCreateUserId("Create user");
//    	
    	
        ProposalSummary p = proposalService.mapToProposalSummary(ver.getChangeProposal(), 
                null, true, false, false);
        assertNotNull(p);
        assertEquals("DP0026", p.getDisplayName());

        assertEquals(3, p.getAliases().size());
        //Assert.assertEquals(1L, p.getRevision());
        //Assert.assertEquals("Synchronization of signals Change Proposal", p.getDescription());

//        Assert.assertEquals("Synchronization of signals", p.getSubject());

       
        Assert.assertEquals(DateFormatUtils.format(
        		DateUtils.parseDate("2017-11-10 20:38:25" , dateFormat), dateFormat),
        		DateFormatUtils.format(p.getCreateTs(), dateFormat));
        Assert.assertEquals(DateFormatUtils.format(
        		DateUtils.parseDate("2017-11-10 20:38:25" , dateFormat), dateFormat), 
        		DateFormatUtils.format(p.getUpdateTs(), dateFormat));
        Assert.assertEquals("myoung@uspto.gov",p.getCreateUserId());
        Assert.assertEquals("myoung@uspto.gov", p.getUpdateUserId());
        
        ChangeProposalVersion cpv = new ChangeProposalVersion();
        //cpv.setId(234L);
        cpv.setCefAnnex("123");
        cpv.setExternalId("345");
        
        ChangeProposal cp = new ChangeProposal();

        cp.setExternalId(GUIDUtils.toDatabaseFormat(UUID.randomUUID()));
        cpv.setChangeProposal(cp);
        
        ClassificationScheme cs = new ClassificationScheme();
        cs.setCurrentIn(Boolean.TRUE);
        cpv.setClassificationScheme(cs);
        cpv.setLastValidateStatus(LastValidateStatusCategory.SUCCESS);
        cpv.setSctItems(null);
        cpv.setDescriptionNotes(null);
        
        ChangeProposalVersion cpv1 = new ChangeProposalVersion();
        //cpv1.setId(334L);
        cpv1.setCefAnnex("435");
        cpv1.setExternalId("654");
        
        ChangeProposal cp1 = new ChangeProposal();
        cp1.setExternalId(GUIDUtils.toDatabaseFormat(UUID.randomUUID()));
        cpv1.setChangeProposal(cp1);
        
        ClassificationScheme cs1 = new ClassificationScheme();
        cs1.setCurrentIn(Boolean.TRUE);
        
        cpv1.setClassificationScheme(cs1);
        cpv1.setLastValidateStatus(LastValidateStatusCategory.SUCCESS);
        cpv1.setSctItems(null);
        
        Assert.assertNotEquals(cpv, cpv1);
        Assert.assertEquals(cpv, cpv);
        Assert.assertEquals(cpv1, cpv1);        
        ChangeProposalVersion cpv2=cpv1;
        Assert.assertEquals(cpv2, cpv1);
        Assert.assertNotEquals(cpv2, null); 
        Assert.assertFalse(cpv2.equals(new String()));
        Assert.assertNotNull(cpv.getDescriptionNotes());
        Assert.assertNotNull(cpv.getSctItems());
        
        Assert.assertEquals(
                "ChangeProposalVersion [externalId=345, changeProposal=null, versionId=null, cefAnnex=123, cefPostDate=null, versionCreateUserId=null, versionCreateTs=null, createUserId=null, createTs=null, lastModifiedUserId=null, lastModifiedTs=null, lockControl=null, lastValidateDate=null]",
                cpv.toString());  
        
        DescriptionNote dn = new DescriptionNote();
       // dn.setId(234L);
        dn.setChangeProposalVersion(cpv);
        dn.setExternalId("345");
        
        DescriptionNote dn1 = new DescriptionNote();
       // dn1.setId(456L);
        dn1.setChangeProposalVersion(cpv1);
        dn1.setExternalId("456");
        
        Assert.assertNotEquals(dn, dn1);
        Assert.assertEquals(dn, dn);
        Assert.assertEquals(dn1, dn1); 
        DescriptionNote dn2 = dn1;
        Assert.assertEquals(dn1, dn2);
        Assert.assertEquals(dn2, dn1); 
        Assert.assertEquals(dn2, dn2); 
        Assert.assertNotEquals(dn1, null); 
        Assert.assertNotEquals(dn1, new String());
        
    }
    
    
    
    @Transactional
    @Test
    public void testLookupWithMissingContacts() throws ParseException {
    	
        ProposalSummary p = proposalService.getProposalSummaryByExternalId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));
        Assert.assertNotNull(p);
        Assert.assertEquals("XX0026", p.getDisplayName());
        assertEquals(2,p.getAliases().size());
        Assert.assertEquals(2, p.getPrimaryOfficeContacts().size());
        Assert.assertEquals("US", p.getRapporteurOffice().value());
        Assert.assertEquals(1, p.getSecondaryOfficeContacts().size());
    }
    

    @Transactional
    @Test
    public void testUpdateMetadaFromTaskInfo() throws ParseException {
        ProposalMetadataUpdateRequest request = new ProposalMetadataUpdateRequest();
        
        request.setId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));//"XX0026");               
        request.setSize(ProjectSizeCategory.MEDIUM);        
        
        List<OfficeContact> primaryContacts = new ArrayList<>();
        primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,OfficeContactType.COORDINATOR,"matt.young@uspto.gov"));
        primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,OfficeContactType.EDITORIAL_BOARD,"boops@uspto.gov"));
        primaryContacts.add(createOfficeContact(StandardIpOfficeCode.EP,OfficeContactType.QN_TECH_EXPERT,"venkat@uspto.gov"));
        
        List<OfficeContact> secondaryContacts = new ArrayList<>();
        secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,OfficeContactType.COORDINATOR,"venkat@uspto.gov"));
        secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,OfficeContactType.EDITORIAL_BOARD,"boops@uspto.gov"));
        secondaryContacts.add(createOfficeContact(StandardIpOfficeCode.US,OfficeContactType.QN_TECH_EXPERT,"matt.young@uspto.gov"));
        
        request.getPrimaryOfficeContacts().addAll(primaryContacts);
        request.getSecondaryOfficeContacts().addAll(secondaryContacts);
        
//        request.getTechnologies().add(createTechnology(StandardIpOfficeCode.IP, TechnologyCode.E));
//        request.getTechnologies().add(createTechnology(StandardIpOfficeCode.EP, TechnologyCode.HBC));
//        request.getTechnologies().add(createTechnology(StandardIpOfficeCode.US, TechnologyCode.E_O));
        
        ProposalSummary p = proposalService.updateProposalMetaDataFromWMSTaskInfo("vkommareddy@uspto.gov", request);
        Assert.assertNotNull(p);
        Assert.assertEquals("XX0026", p.getDisplayName());
        
//        Assert.assertEquals(3, p.getTechnologies().size());
        Assert.assertEquals(3, p.getPrimaryOfficeContacts().size());
        Assert.assertEquals(3, p.getSecondaryOfficeContacts().size());
    }
    
    @Transactional
    @Test
    public void testUpdateMetadaFromTaskInfoWithEmpty() throws ParseException {
        ProposalMetadataUpdateRequest request = new ProposalMetadataUpdateRequest();
        
        request.setId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));//"XX0026");        

        ProposalSummary p = proposalService.updateProposalMetaDataFromWMSTaskInfo("vkommareddy@uspto.gov", request);
        Assert.assertNotNull(p);
    }
    
    @Transactional
    @Test(expected=EntityNotFoundException.class)
    public void testUpdateMetadaFromTaskInfoWithException() throws ParseException {
        ProposalMetadataUpdateRequest request = new ProposalMetadataUpdateRequest();
        request.setId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db4"));//This one does not exist        

        ProposalSummary p = proposalService.updateProposalMetaDataFromWMSTaskInfo("vkommareddy@uspto.gov", request);
        Assert.assertNotNull(p);
    }
    
    @Transactional
    @Test(expected=EntityNotFoundException.class)
    public void testUpdateMetadaFromTaskInfoWithUnKnownProposalCode() throws ParseException {
        ProposalMetadataUpdateRequest request = new ProposalMetadataUpdateRequest();
        
        request.setId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));//"XX0026");        
        request.setProposalTypeCode("XZ");
        ProposalSummary p = proposalService.updateProposalMetaDataFromWMSTaskInfo("vkommareddy@uspto.gov", request);
        Assert.assertNotNull(p);
    }
    
    private OfficeContact createOfficeContact(StandardIpOfficeCode office, OfficeContactType type,
            String email) {
        OfficeContact contact = new OfficeContact();
        contact.setContactType(type);
        contact.setIpOffice(office);
        contact.setEmail(email);
        return contact;
    }
    
//    private Technology createTechnology(StandardIpOfficeCode office,
//            TechnologyCode technologyCode) {
//        Technology t = null;
//        if (office != null && technologyCode != null) {
//            t = new Technology();
//            t.setIpOffice(office);
//            t.setTechnologyCode(technologyCode);
//        }
//        return t;
//    }
    
    
    @Transactional
    @Test
    public void testupdateProposalStatusInfoWithInstanceEndTs() throws ParseException {
       
        String wmsProcessInstanceId = "2345";
        String wmsDefinitionId = "CE_WMS_WorkFlow:13:11234";
        
        TaskStateDetails taskState = new TaskStateDetails();
        taskState.setActualElapsedDays(1);
        taskState.setAssignee("vkommareddy@uspto.gov");
        taskState.setIpOffice(StandardIpOfficeCode.US);
        taskState.setOfficeContactType(OfficeContactType.COORDINATOR);
        taskState.setTaskedOffice(StandardIpOfficeCode.EP);
        taskState.setTaskedRole("UBERBOSS");
        taskState.setTaskId("2345");
        taskState.setTaskName("Test Task Name 2345");
        taskState.setStartTs(DateUtils.parseDate("2018-25-08", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        
        AssignmentGroup ag = new AssignmentGroup();
        ag.setRole(OfficeContactType.COORDINATOR);
        ag.getOffices().add(StandardIpOfficeCode.EP);
        ag.getOffices().add(StandardIpOfficeCode.US);   
        
        AssignmentGroup ag1 = new AssignmentGroup();
        ag1.setRole(OfficeContactType.EDITORIAL_BOARD);
        ag1.getOffices().add(StandardIpOfficeCode.CN);
        ag1.getOffices().add(StandardIpOfficeCode.US);
        
        taskState.getAssigneeCandidateGroups().add(ag);
        taskState.getAssigneeCandidateGroups().add(ag1);
        
        TaskStateDetails[] taskStateList = new TaskStateDetails[]{ taskState };
        
       proposalService.updateProposalStatus(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), 
                wmsProcessInstanceId, wmsDefinitionId, 
               new Date(), null, 
               ProposalPhase.PROJECT, ProposalSubphase.INTERNAL, ProposalStateType.ACTIVE, 
               "vkommareddy@uspto.gov",
               ProposalNamePrefix.RR,
               taskStateList);
       ChangeProposal p = changeProposalRepository.findByChangeProposalCodeIgnoreCase("RR0026");
       Assert.assertNotNull(p);
       ChangeProposalState state = p.getState();
       Assert.assertNotNull(state);
       for(ChangeProposalStateTask task: state.getActiveTasks()) {
           assertEquals("2345", task.getTaskId());
           assertEquals("Test Task Name 2345", task.getTaskName());
           assertEquals(4, task.getAssignmentGroups().size());
           assertEquals("UBERBOSS",task.getTaskedRole());
           assertEquals(StandardIpOfficeCode.EP,task.getTaskedOffice());
       }
       
    }
    
    @Transactional
    @Test
    public void testupdateProposalStatusInfoWithOutInstanceEndTs() throws ParseException {
       
        String wmsProcessInstanceId = "12345";
        String wmsDefinitionId = "CE_WMS_WorkFlow:13:19500";
        
        TaskStateDetails taskState = new TaskStateDetails();
        taskState.setActualElapsedDays(1);
        taskState.setAssignee("vkommareddy@uspto.gov");
        taskState.setIpOffice(StandardIpOfficeCode.US);
        taskState.setOfficeContactType(OfficeContactType.COORDINATOR);
        taskState.setTaskId("1234");
        taskState.setTaskName("Test Task Name 1234");
        taskState.setStartTs(DateUtils.parseDate("2018-25-09", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));        

        AssignmentGroup ag1 = new AssignmentGroup();
        ag1.setRole(OfficeContactType.EDITORIAL_BOARD);
        ag1.getOffices().add(StandardIpOfficeCode.CN);
        ag1.getOffices().add(StandardIpOfficeCode.US);
        taskState.getAssigneeCandidateGroups().add(ag1);
        
        TaskStateDetails[] taskStateList = new TaskStateDetails[] {taskState};
        
       proposalService.updateProposalStatus(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), 
                wmsProcessInstanceId, wmsDefinitionId, 
               new Date(), null, 
               ProposalPhase.INTERNAL, ProposalSubphase.POST_PROCESSING, ProposalStateType.ACTIVE, "vkommareddy@uspto.gov", 
               ProposalNamePrefix.RR, taskStateList);
       ChangeProposal p = changeProposalRepository.findByExternalId("d153f9bf804848aa8ba202db9f844db5");
       
       assertNotNull(p);
       assertEquals("RR0026", ProposalNameUtils.getDisplayName(p.getAliases()));
       ChangeProposalState state = p.getState();
       assertNotNull(state);
       assertEquals(1,state.getActiveTasks().size());
       for(ChangeProposalStateTask task: state.getActiveTasks()) {
           assertEquals("1234", task.getTaskId());
           assertEquals("Test Task Name 1234", task.getTaskName());
           assertEquals(2, task.getAssignmentGroups().size());
       }
    }
    
    @Transactional
    @Test
    public void testupdateProposalStatusInfoWithExistingState() throws ParseException {
       
        String wmsProcessInstanceId = "12345";
        String wmsDefinitionId = "CE_WMS_WorkFlow:13:19500";
        
        TaskStateDetails taskState = new TaskStateDetails();
        taskState.setActualElapsedDays(1);
        taskState.setAssignee("vkommareddy@uspto.gov");
        taskState.setIpOffice(StandardIpOfficeCode.US);
        taskState.setOfficeContactType(OfficeContactType.COORDINATOR);
        taskState.setTaskId("1234");
        taskState.setTaskName("Test Task Name 1234");
        taskState.setStartTs(DateUtils.parseDate("2018-25-09", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        
        AssignmentGroup ag = new AssignmentGroup();
        ag.setRole(OfficeContactType.QN_TECH_EXPERT);
        ag.getOffices().add(StandardIpOfficeCode.EP);
        ag.getOffices().add(StandardIpOfficeCode.US); 
        
        taskState.getAssigneeCandidateGroups().add(ag);
        
        TaskStateDetails[] taskStateList = new TaskStateDetails[] {taskState};
        
       proposalService.updateProposalStatus(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), 
                wmsProcessInstanceId, wmsDefinitionId, 
               new Date(), null, 
               ProposalPhase.INTERNAL, ProposalSubphase.POST_PROCESSING, ProposalStateType.ACTIVE, "vkommareddy@uspto.gov", 
               null, taskStateList);
       ChangeProposal p = changeProposalRepository.findByChangeProposalCodeIgnoreCase("XX0026");
       Assert.assertNotNull(p);
       ChangeProposalState state = p.getState();
       Assert.assertNotNull(state);
       
       Assert.assertEquals(1, state.getActiveTasks().size());
      
    }
    
    @Transactional
    @Test
    public void testupdateProposalStatusInfoWithNoTasks() throws ParseException {
       
        String wmsProcessInstanceId = "23411";
        String wmsDefinitionId = "CE_WMS_WorkFlow:13:23453";
        
       proposalService.updateProposalStatus(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), 
                wmsProcessInstanceId, wmsDefinitionId, 
               new Date(), null, 
               ProposalPhase.PROJECT, ProposalSubphase.POST_PROCESSING, ProposalStateType.COMPLETED, "vkommareddy@uspto.gov",null);
       ChangeProposal p = changeProposalRepository.findByChangeProposalCodeIgnoreCase("XX0026");
       Assert.assertNotNull(p);
       ChangeProposalState state = p.getState();
       Assert.assertNotNull(state);
       
       Assert.assertEquals(0, state.getActiveTasks().size());
      
    }
    
    @Test
    public void testCreateNewProposalName() {
    	assertEquals("RP1011", proposalService.createNewProposalName("XX1011", ProposalNamePrefix.RP));
    	assertEquals("RPZZ1011", proposalService.createNewProposalName("ZZ1011", ProposalNamePrefix.RP));
    	assertEquals("RP1", proposalService.createNewProposalName("XX1", ProposalNamePrefix.RP));
    	assertEquals("RPR", proposalService.createNewProposalName("R", ProposalNamePrefix.RP));
    	assertEquals("MP2000", proposalService.createNewProposalName("MP2000", ProposalNamePrefix.MP));
    	assertEquals("RP1011", proposalService.createNewProposalName("1011", ProposalNamePrefix.RP));

    }

    
    @Test(expected=IllegalArgumentException.class)
    public void testCreate() throws GrammarParseException {
    	           	proposalService.createProposalRevisionFromSchemeChangeTable(null, 
    			null, null, "This should fail", "myoung@fail.com", null, null);


    }

    @Test
    public void testUpdateProposalStatus() {
    	 
        ChangeProposal p1 = changeProposalRepository.findByChangeProposalCodeIgnoreCaseIncludeWmsState("5578f1c578d64e2887af1a27bb789ff2");
        ChangeProposalState state1 = p1.getState();
        Assert.assertEquals(2, state1.getActiveTasks().size());
        
        String wmsProcessInstanceId = "12345";
        String wmsDefinitionId = "CE_WMS_WorkFlow:13:19500";
        
        TaskStateDetails taskState = new TaskStateDetails();      
        taskState.setAssignee("myoung@uspto.gov");
        taskState.setTaskId("18852");
        taskState.setTaskName("UNKNOWN TASK");
        
        AssignmentGroup ag1 = new AssignmentGroup();
        ag1.setRole(OfficeContactType.COORDINATOR);
        ag1.getOffices().add(StandardIpOfficeCode.US);
        taskState.getAssigneeCandidateGroups().add(ag1);
        
        AssignmentGroup ag2 = new AssignmentGroup();
        ag2.setRole(OfficeContactType.COORDINATOR);
        ag2.getOffices().add(StandardIpOfficeCode.EP);
        
        taskState.getAssigneeCandidateGroups().add(ag2);
        
        p1 = null;
        state1=null;
        TaskStateDetails[] taskStateList = new TaskStateDetails[] {taskState};
        proposalService.updateProposalStatus(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), wmsProcessInstanceId, wmsDefinitionId, 
        		    new Date(), null,  ProposalPhase.INTERNAL, ProposalSubphase.POST_PROCESSING, ProposalStateType.ACTIVE, "vkommareddy@uspto.gov", 
                    ProposalNamePrefix.CM,taskStateList);
        ChangeProposal p = changeProposalRepository.findByChangeProposalCodeIgnoreCaseIncludeWmsState("d153f9bf804848aa8ba202db9f844db5");
       Assert.assertNotNull(p);
       ChangeProposalState state = p.getState();
       

       for(ChangeProposalStateTask task: state.getActiveTasks()) {
           log.debug("task = {}", task);
           Assert.assertEquals("18852", task.getTaskId());
           Assert.assertEquals("UNKNOWN TASK", task.getTaskName());
       }

       Assert.assertNotNull(state);
       Assert.assertEquals(1,state.getActiveTasks().size());
       
    
    }

    @Test
    @Transactional
    public void testConvertProposalType() {
    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);        


    	proposalService.convertProposalPrefix(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), "CM0026", ExternalSystemCategory.CE, "test.user@uspto.gov");
    	ChangeProposal p = changeProposalRepository.findByChangeProposalCodeIgnoreCase("CM0026");
    	assertEquals("d153f9bf804848aa8ba202db9f844db5", p.getExternalId());
    	assertEquals(2+"",p.getLockControl()+"");
    	assertEquals(null, p.getProposalType());
    	assertEquals("test.user@uspto.gov",p.getLastModifiedUserId());
    	assertEquals(0,Days.daysBetween(new DateTime(p.getLastModifiedTs()), 
    			new DateTime(new Date())).getDays());
    }

  

    //@org.springframework.transaction.annotation.Transactional(readOnly=true)
    @Transactional
    @Test
    public void testSearchByAlias() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		

		SecurityContextHolder.getContext().setAuthentication(springUser);
    	
    	 UsptoAuthenticationToken authToken = securityService
                 .mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0,50, authToken, null, 
    			null, null, null, null, 
    			null, null, null, "XX0027", null, null, null, null,
    			null, false,null, null, null, null, null, null, null, null, null, false, true, false, null, null,null, null);
    	assertEquals(1,page.getList().size());
    	assertEquals(GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7"), page.getList().get(0).getId());
    	
    	page = proposalService.listProposalSummaries(0,50, authToken, null, 
    			null, null, null, null, null,
    			null, null, "DP0026", null, null, null, null,
    			null, false, null,null, null, null, null, null, null, null, null, false, true,false, null, null,null, null);
    	assertEquals(1,page.getList().size());
    								 // c960d30a 52a8 47fc 8c51 b64dfcc0ea85
    	assertEquals(UUID.fromString("c960d30a-52a8-47fc-8c51-b64dfcc0ea85"), page.getList().get(0).getId());
    	assertEquals(16, page.getList().get(0).getProposalDetails().size());
    }
    
    @Transactional
    @Test
    public void testSearch_myassignment() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("msingh4@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("msingh4@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		

		SecurityContextHolder.getContext().setAuthentication(springUser);
    	
    	 UsptoAuthenticationToken authToken = securityService
                 .mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0,50, authToken, null, 
    			null, null, null, null, 
    			null, null, null, null, null, null, null, null,
    			null, true,null, null, null, null, null, null, null, null, null, false, true, false, null, null,null, null);
    	assertEquals(2,page.getList().size());    	
    }

    @Transactional
    @Test
    public void testMigrateDraft() {
    	ChangeProposal cp = changeProposalRepository.findByExternalId("d153f9bf804848aa8ba202db9f844d41");
    	assertEquals("XX0089", ProposalNameUtils.getDisplayName(cp.getAliases()));
    	
    	String newAlias = proposalService.migrateDraft(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844d41"), "myoung@uspto.gov");
    	assertEquals("RP0089", newAlias);
    }
    
    @Transactional
    @Test
    public void testMigrateDraft_missingproposal() {
    	try {
    		
    	
    		String newAlias = proposalService.migrateDraft(UUID.fromString("f94fba5b-d983-482f-b617-49dcb92b8fe0"), "myoung@uspto.gov");
    		fail("did not fail as expected");
    	} catch (Exception e) {
    		assertEquals(EntityNotFoundException.class, e.getClass());
    		assertEquals("Proposal f94fba5b-d983-482f-b617-49dcb92b8fe0 does not exist", e.getMessage());
    	}
    }

    @Transactional
    @Test
    public void testMigrateDraft_proposalnotdraft() {
    	try {
    		
    		                                                                
    		String newAlias = proposalService.migrateDraft(UUID.fromString("51614cc0-0eb7-4436-a33d-ca859119eeb7"), "myoung@uspto.gov");
    		fail("did not fail as expected");
    	} catch (Exception e) {
    		assertEquals(IllegalArgumentException.class, e.getClass());
    		assertEquals("Proposal 51614cc0-0eb7-4436-a33d-ca859119eeb7 is not a Draft.  Authoritative alias is DP0027.", e.getMessage());
    	}
    }

    // US338246
    @Test
    @Transactional
    public void testGetDraftName_verifyPadding() {
    	assertEquals("10024",String.format("%04d", 10024));

    	assertEquals("0024",String.format("%04d", 24));
    	String initialName = proposalFactoryHelper.getInitialName("SB");
    	log.debug(initialName);
    	assertTrue(Pattern.matches("^SB\\d{5,8}$", initialName));
    	initialName = proposalFactoryHelper.getInitialName("XX");
    	log.debug(initialName);
    	assertTrue(Pattern.matches("^XX\\d{5,8}$", initialName));
    }
    

    
    @Transactional
    @Test
    public void testMigrateDraft_invalidtype() {
    	try {
    		
    		                                                                
    		String newAlias = proposalService.migrateDraft(UUID.fromString("d153f9bf-8048-48aa-8ba2-02db9f844d42"), "myoung@uspto.gov");
    		fail("did not fail as expected");
    	} catch (Exception e) {
    		assertEquals(IllegalArgumentException.class, e.getClass());
    		assertEquals("Proposal d153f9bf-8048-48aa-8ba2-02db9f844d42 prefix value QQ is not as valid prefix.  hint: check project details PROJECT_DETAIL/projectType_PD", e.getMessage());
    	}
    }
    
    @Transactional
    @Test
    public void testGetInitialName() { 
    	
    	String name = proposalFactoryHelper.getInitialName(ProposalNamePrefix.SB.name());
    	assertTrue(Pattern.matches("^SB\\d+$", name));
    	int numberPart = Integer.parseInt(StringUtils.substringAfter(name, "SB"));
    	assertTrue (numberPart < 100); // the sandbox sequence starts @ 10 there should not be 
    								   // 90 other tests creating sandbox sequences
    	
    	String draftName = proposalFactoryHelper.getInitialName(ProposalNamePrefix.XX.name());
    	assertTrue(Pattern.matches("^XX\\d+$", draftName));
    	
    	String notypeGivenName = proposalFactoryHelper.getInitialName(null);
    	assertTrue(Pattern.matches("^XX\\d+$", notypeGivenName));
    	
    }
    
    @Test
    @Transactional
    public void testFindActive_nosandbox() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	UUID sandboxId =  GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5");
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.ACTIVE), null, null, null, null, null, null, null, null, false, false, false, null, null,null, null);
    	for (ProposalSummary s: page.getList()) {
    		if (CollectionUtils.isNotEmpty(s.getAliases())) {
    			assertFalse(s.getAliases().get(0).getName().startsWith("SB"));
    		}
    		assertNotEquals(sandboxId, s.getId() );
    	}
    }
    @Test
    @Transactional
    public void testProposalSummaries_sortByCreatedUserId() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.CREATE_BY,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("DP0022",summaries.get(0).getDisplayName()); 	
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.CREATE_BY,Direction.DESC, null);
    	
    	summaries=page.getList();
    	assertEquals("DP0022",summaries.get(summaries.size()-1).getDisplayName());
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_sortByUSCoordinator() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.US_COORDINATOR,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TDOD : Fix test data
//    	assertEquals("DP11111",summaries.get(0).getDisplayName()); 	
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.US_COORDINATOR,Direction.DESC, null);
    	
    	summaries=page.getList();
//    	assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_sortByEPCoordinator() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.EP_COORDINATOR,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TODO: Fix test data
    	//assertEquals("DP11111",summaries.get(0).getDisplayName()); 	
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.EP_COORDINATOR,Direction.DESC, null);
    	
    	summaries=page.getList();
    	//assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    }
    @Test
    @Transactional
    public void testProposalSummaries_sortByProposalCode() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PROJECT,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TODO: Fix test data
    	//assertEquals("DP11111",summaries.get(0).getDisplayName()); 	
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PROJECT,Direction.DESC, null);
    	
    	summaries=page.getList();
    	//assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    }
    @Test
    @Transactional
    public void testProposalSummaries_sortByPhase() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TODO: Fix test data
    	//assertEquals("DP11111",summaries.get(0).getDisplayName()); 	
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.DESC, null);
    	
    	summaries=page.getList();
    	//assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_sortByTCDir() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.TC_DIR, Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TODO: Fix test data
//    	assertEquals("DP11111",summaries.get(0).getDisplayName()); 
//    	assertEquals("DP0022",summaries.get(summaries.size()-1).getDisplayName());
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.TC_DIR, Direction.DESC, null);
    	
    	summaries=page.getList();
//    	assertEquals("DP0022",summaries.get(0).getDisplayName()); 
//    	assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_sortByArtUnit() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.ART_UNIT, Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TODO: Fix test data for new projects
//    	assertEquals("DP11111",summaries.get(0).getDisplayName()); 
//    	assertEquals("DP11338",summaries.get(summaries.size()-1).getDisplayName());
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.ART_UNIT, Direction.DESC, null);
    	
    	summaries=page.getList();
    	//TODO: Fix test data for new projects
//    	assertEquals("DP11337",summaries.get(0).getDisplayName()); 
//    	assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_sortByTCRank() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.TC_RANK, Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TODO: Fix test data for new projects
//    	assertEquals("DP11111",summaries.get(0).getDisplayName()); 	
//    	assertEquals("DP0026",summaries.get(summaries.size()-1).getDisplayName());
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.TC_RANK, Direction.DESC, null);
    	
    	summaries=page.getList();
//    	assertEquals("DP0026",summaries.get(0).getDisplayName());
//    	assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    	
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_sortByTCPriority() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.TC_PRIORITY, Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TODO: Fix test data
//    	assertEquals("DP11111",summaries.get(0).getDisplayName()); 	
//    	assertEquals("DP11338",summaries.get(summaries.size()-1).getDisplayName());
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.TC_PRIORITY, Direction.DESC, null);
    	
    	summaries=page.getList();
//    	assertEquals("DP11337",summaries.get(0).getDisplayName()); 	
//    	assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    }
    
    
    @Test
    @Transactional
    public void testProposalSummaries_sortBySubject() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.SUBJECT, Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TDOD: FIx test data
//    	assertEquals("DP11111",summaries.get(0).getDisplayName()); 	
//    	assertEquals("DP0027",summaries.get(summaries.size()-1).getDisplayName());
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.SUBJECT, Direction.DESC,null);
    	
    	summaries=page.getList();
//    	assertEquals("DP11337",summaries.get(0).getDisplayName()); 	
//    	assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_sortByCpcScope() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.CPC_SCOPE, Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TODO: FIx test data
//    	assertEquals("DP11111",summaries.get(0).getDisplayName()); 	
//    	assertEquals("DP0027",summaries.get(summaries.size()-1).getDisplayName());
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.CPC_SCOPE, Direction.DESC, null);
    	
    	summaries=page.getList();
//    	assertEquals("DP11337",summaries.get(0).getDisplayName()); 	
//    	assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    }
    
    
    @Test
    @Transactional
    public void testProposalSummaries_sortByPreferenceForSubclass() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PREFERENCE_FOR_SUBCLASS, Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TODO: Fix test data
//    	assertEquals("DP11111",summaries.get(0).getDisplayName()); 	
//    	assertEquals("DP11338",summaries.get(summaries.size()-1).getDisplayName());
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PREFERENCE_FOR_SUBCLASS, Direction.DESC, null);
    	
    	summaries=page.getList();
//    	assertEquals("DP11338",summaries.get(0).getDisplayName()); 	
//    	assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_sortByExpeditedRequest() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@uspto.gov", "test.user@uspto.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.EXPEDITED_REQUEST, Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	//TODO: Fix Test data
//    	assertEquals("DP11111",summaries.get(0).getDisplayName()); 	
//    	assertEquals("DP0027",summaries.get(summaries.size()-1).getDisplayName());
    	
    	page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.EXPEDITED_REQUEST, Direction.DESC, null);
    	
    	summaries=page.getList();
//    	assertEquals("DP11256",summaries.get(0).getDisplayName()); 	
//    	assertEquals("DP11111",summaries.get(summaries.size()-1).getDisplayName());
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_filterActiveProjects() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name()))); 
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.ACTIVE), null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("RP10001",summaries.get(0).getDisplayName()); 	   	
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_filterActiveAndProposalsProjects() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name()))); 
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.ACTIVE, ProposalStatus.PROPOSAL), null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, null);
    	
    	assertNotNull(page);
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals(4, summaries.size());
    	assertEquals("DP0027",summaries.get(0).getDisplayName()); 	   	
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_filterCompletedProjects() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name()))); 
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.COMPLETED), null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("XX0090",summaries.get(0).getDisplayName()); 	   	
    }
    @Test
    @Transactional
    public void testProposalSummaries_filterProposalProjects() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@epo.gov", "test.user@epo.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.PROPOSAL), null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("DP0027",summaries.get(0).getDisplayName()); 	   	
    }
    @Test
    @Transactional
    public void testProposalSummaries_filterProjectDocumentationProjects() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@epo.gov", "test.user@epo.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.PROJECT_DOCUMENTATION), null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("DP0022",summaries.get(0).getDisplayName()); 	   	
    }
    @Test
    @Transactional
    public void testProposalSummaries_filterProjectManagementProjects() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.PROJECT_MANAGEMENT), null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("XX0089",summaries.get(0).getDisplayName()); 	   	
    }
    @Test
    @Transactional
    public void testProposalSummaries_filterSuspendedProjects() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@epo.gov", "test.user@epo.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.SUSPENDED), null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("MP0028",summaries.get(0).getDisplayName()); 	   	
    }
    @Test
    @Transactional
    public void testProposalSummaries_filterSandboxProjects() {
    	UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"test.user@epo.gov", "test.user@epo.gov",
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.SANDBOX), null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("XX0026",summaries.get(0).getDisplayName()); 	   	
    }
    @Test
    @Transactional
    public void testProposalSummaries_filterArchivedProjects() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.ARCHIVED), null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("RP10101",summaries.get(0).getDisplayName()); 	   	
    }
    @Test
    @Transactional
    public void testProposalSummaries_filterByProjectSource() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.ARCHIVED), null, null, null, null, null, null, null, null, false, false, false, Arrays.asList("CPC"), GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("RP10101",summaries.get(0).getDisplayName()); 	   	
    }
    @Test
    @Transactional
    public void testProposalSummaries_filterByProjectTypeCode() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, 
    			Arrays.asList("RP"), 
    			null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.ARCHIVED), null, null, null, null, null, null, null, null, false, false, false, Arrays.asList("CPC"), GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("RP10101",summaries.get(0).getDisplayName()); 	   	
    }
    
    @Test
    @Transactional
    public void testProposalSummaries_filterByReleaseDate() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, 
    			null, 
    			null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, Arrays.asList(new DateTime("2017-11-10").toDate()));
    	
		List<ProposalSummary> summaries = page.getList();
		assertEquals("DP0026", summaries.get(0).getDisplayName());
		assertEquals("2017-11-10", summaries.get(0).getSchemeReleaseDt());
    }
    
    @Test
	public void testListSummariesByUSOffice() {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		PagableProposalSummary resp = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.CREATE_BY,Direction.DESC, null);
		Assert.assertNotNull(resp);
		Assert.assertEquals(15, resp.getList().size());
	}
	@Test
	public void testListSummariesByEPOffice() {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		
		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		PagableProposalSummary resp = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.CREATE_BY,Direction.DESC, null);
		Assert.assertNotNull(resp);

		Assert.assertEquals(9, resp.getList().size());
	}
	
	
	@Test
    @Transactional
    public void testProposalSummaries_filterByTwlStatus() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			Arrays.asList(ProposalStatus.ARCHIVED), "Pending", "Ongoing_O", null, null, null, null, null, null, false, false, false, Arrays.asList("CPC"), GplSortBy.PHASE,Direction.ASC, null);


    	List<ProposalSummary> summaries=page.getList();
    	assertEquals("RP10101",summaries.get(0).getDisplayName()); 	   	
    }
	
	@Test
    @Transactional
    public void testProposalSummaries_filterByTwlStatusWithOutPending() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, "Completed", "Ongoing_O", null, null, null, null, null, null, false, false, false, Arrays.asList("CPC"), GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	
    	assertNotNull(summaries);
    	assertEquals(0, summaries.size());	   	
    }
	
	@Test
    @Transactional
    public void testProposalSummaries_filterByTwlAndHpHxStatus() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "EP");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, "Pending", "Begin_B", null, null, null, null, null, null, false, false, false, Arrays.asList("CPC"), GplSortBy.PHASE,Direction.ASC, null);

    	
    	List<ProposalSummary> summaries=page.getList();
    	assertNotNull(summaries);
    	assertEquals(0, summaries.size());
    }
	
	@Test
    @Transactional
    public void testProposalSummaries_filterByTcDir() {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())
					, new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	
    	UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);
    	
    	PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null, null, null, null, null, null, null, null, null, null, false, 
    			null, null, null, "1600" , null, null, null, null, null, false, false, false, null, GplSortBy.PHASE,Direction.ASC, null);
    	
    	List<ProposalSummary> summaries=page.getList();
    	assertNotNull(summaries);
    	assertEquals(1, summaries.size());
    	assertEquals("DP0026", summaries.get(0).getDisplayName());
    }
	
	@Test
	@Transactional
	public void testProposalSummaries_filterByPhaseDraft() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null,
				null, null, null, null, null, null, null, null, null, null, Arrays.asList(ProposalPhase.XX), null, false, null,
				null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(6, summaries.size());
		//TODO: FIx test data
		//assertEquals("DP11111", summaries.get(0).getDisplayName());
	}
	
	@Test
	@Transactional
	public void testProposalSummaries_filterByMultiplePhase() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null,
				null, null, null, null, null, null, null, null, null, null,
				Arrays.asList(ProposalPhase.XX, ProposalPhase.A, ProposalPhase.C), null, false, null, null, null,
				null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(14, summaries.size());
	}
	
	@Test
	@Transactional
	public void testProposalSummaries_filterByCoordinatorEmail() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null,
				null, null, null, null, null, null, null, null, "DOESNOTEXIST@yahoo.com", null,
				new ArrayList<>(), null, false, null, null, null,
				null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(0, summaries.size());
		
		
		
//		US_SCE_NM="US_SCE_NM@uspto.gov" US_BACKUP_SCE_NM="US_BACKUP_SCE_NM@uspto.gov" US_EB_NM="US_EB_NM@usptp.gov" 
//				EP_EB_NM="EP_EB_NM@uspto.gov" US_SCESPE_NM="US_SCESPE@uspto.gov" US_SPC_NM="US_SPC_NM@uspto.gov" 
//				EP_QN_NM="EP_QN_NM@uspto.gov" EP_GERANT_NM="EP_GERANT_NM@uspto.gov" EP_CPBM_NM="EP_CPBM_NM@uspto.gov"
//				US_RECLASS_MGR_NM="US_RECLASS_MGR_NM@uspto.com" EP_RECLASS_MGR_NM="EP_RECLASS_MGR_NM@uspto.gov" 
//				PUB_WRITER_EDITOR_NM="PUB_WRITER_EDITOR_NM@uspto.gov" PUB_SPECIALIST_NM="PUB_SPECIALIST_NM@uspto.gov" 
//				PUB_MGR_NM="PUB_MGR_NM@uspto.gov"
		// verify US_PC_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "xboopathi@uspto.gov", null,
				new ArrayList<>(), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(2, summaries.size());		
		// verify EP_PC_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "xepotest1@epo.gov", null, new ArrayList<>(), null, false, null, null,
				null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(2, summaries.size());

		// verify US_SCE_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "US_SCE_NM@uspto.gov", null, new ArrayList<>(), null, false, null, null,
				null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
		assertEquals("PD11009", summaries.get(0).getDisplayName());
				

		// verify US_BACKUP_SCE_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "US_BACKUP_SCE_NM@uspto.gov", null,
				new ArrayList<>(), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());		
		assertEquals("PD11009",summaries.get(0).getDisplayName());
		
		// verify US_EB_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "US_EB_NM@uspto.gov", null,
				new ArrayList<>(), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());			
		assertEquals("PD11009",summaries.get(0).getDisplayName());
		
		// verify EP_EB_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "EP_EB_NM@uspto.gov", null,
				new ArrayList<>(), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());		
		assertEquals("PD11009",summaries.get(0).getDisplayName());
		
		// verify US_SCESPE
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "US_SCESPE@uspto.gov", null,
				new ArrayList<>(), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());		
		assertEquals("PD11009",summaries.get(0).getDisplayName());
		
		// verify US_SPC_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "US_SPC_NM@uspto.gov", null,
				new ArrayList<>(), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
		assertEquals("PD11009",summaries.get(0).getDisplayName());

		// verify EP_QN_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "EP_QN_NM@uspto.gov", null,
				new ArrayList<>(), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
		assertEquals("PD11009",summaries.get(0).getDisplayName());

		
		// verify EP_GERANT_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "EP_GERANT_NM@uspto.gov", null,
				new ArrayList<>(), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
		assertEquals("PD11009",summaries.get(0).getDisplayName());

		
		// verify EP_CPBM_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "EP_CPBM_NM@uspto.gov", null,
				new ArrayList<>(), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
		assertEquals("PD11009",summaries.get(0).getDisplayName());

		
		// verify US_RECLASS_MGR_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "US_RECLASS_MGR_NM@uspto.com", null,
				Arrays.asList(ProposalPhase.XX, ProposalPhase.A, ProposalPhase.C), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
		assertEquals("PD11009",summaries.get(0).getDisplayName());
		
		// verify EP_RECLASS_MGR_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "EP_RECLASS_MGR_NM@uspto.gov", null,
				Arrays.asList(ProposalPhase.XX, ProposalPhase.A, ProposalPhase.C), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
		assertEquals("PD11009",summaries.get(0).getDisplayName());
		
		// verify PUB_WRITER_EDITOR_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, "PUB_WRITER_EDITOR_NM@uspto.gov", null,
				Arrays.asList(ProposalPhase.XX, ProposalPhase.A, ProposalPhase.C), null, false, null, null, null, null,
				null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
		assertEquals("PD11009",summaries.get(0).getDisplayName());
		
		// verify PUB_SPECIALIST_NM
		page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null,
				null, null, null, null, null, null, null, null, "PUB_SPECIALIST_NM@uspto.gov", null,
				Arrays.asList(ProposalPhase.XX, ProposalPhase.A, ProposalPhase.C), null, false, null, null, null,
				null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
		
		assertEquals("PD11009",summaries.get(0).getDisplayName());

		
	    page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null,
						null, null, null, null, null, null, null, null, "PUB_MGR_NM@uspto.gov", null,
						Arrays.asList(ProposalPhase.XX, ProposalPhase.A, ProposalPhase.C), null, false, null, null, null,
						null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
				
		assertEquals("PD11009",summaries.get(0).getDisplayName());

	}
	
	@Test
	@Transactional
	public void testProposalSummaries_filterByUserGroupAndEmail() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		
		// verify US_SCE_NM
		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, null, null, new ArrayList<>(), null, false, null, null,
				null, null, null, "US_SCE_NM", "US_SCE_NM@uspto.gov", null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
		assertEquals("PD11009", summaries.get(0).getDisplayName());
	}
	
	@Test
	@Transactional
	public void testProposalSummaries_filterByCsdGroup() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		
		// verify US_SCE_NM
		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, null, null, new ArrayList<>(), null, false, null, null,
				null, null, null, null, null, "CSDC", null,false,false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(2, summaries.size());
		assertEquals("PD11009", summaries.get(1).getDisplayName());
	}
	
	@Test
	@Transactional
	public void testProposalSummariesNewColumnsFromWms() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		
		// verify US_SCE_NM
		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, null, null, new ArrayList<>(), null, false, null, null,
				null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
	}
	
	@Test
	@Transactional
	public void testProposalSummaries_filterByConsultationStatus() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		
		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, null, null, new ArrayList<>(), null, false, null, null,
				null, null, null, null, null, null, SmeConsultationStatus.PENDING, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);

		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(3, summaries.size());
	}
	
	@Test
	@Transactional
	public void testProposalSummaries_filterByUsQn() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@epo.org", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@epo.org",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		
		// verify US_QN
		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null, null, null, null,
				null, null, null, null, null, null, null, new ArrayList<>(), null, false, null, null,
				null, null, null, "US_QN", "matthew.martin@USPTO.GOV", null, null, false, false, false, null, GplSortBy.PHASE, Direction.ASC, null);
		
		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
		assertEquals(1, summaries.size());
	}
	
	@Test
	@Transactional
	public void testProposalSummaries_sortByFamilyCount() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null,
				null, null, null, null, null, null, null, null, null, null, Arrays.asList(ProposalPhase.XX), null, false, null,
				null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.FAMILY_COUNT, Direction.ASC, null);

		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
		System.out.println(summaries);
		assertEquals(6, summaries.size());
		//TODO: Fix test data
//		assertEquals("DP11111", summaries.get(0).getDisplayName());
	}
	
	@Test
	@Transactional
	public void testProposalSummaries_sortBy_PI_SCHEME_RELEASE_DT() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null,
				null, null, null, null, null, null, null, null, null, null, Arrays.asList(ProposalPhase.XX), null, false, null,
				null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PI_SCHEME_RELEASE_DT, Direction.DESC, null);

		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
		System.out.println(" Sort By PI_SCHEME_RELEASE_DT");
		System.out.println(summaries);
		assertEquals(6, summaries.size());
		//TODO: FIx test data
//		assertEquals("DP11111", summaries.get(0).getDisplayName());
	}
	
	@Test
	@Transactional
	public void testProposalSummaries_sortBy_PF_SCHEME_PUBLISH_DT() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null,
				null, null, null, null, null, null, null, null, null, null, Arrays.asList(ProposalPhase.XX), null, false, null,
				null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PF_SCHEME_PUBLISH_DT, Direction.ASC, null);

		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
		System.out.println(" Sort By PF_SCHEME_PUBLISH_DT");
		System.out.println(summaries);
		assertEquals(6, summaries.size());
		//TODO: Fix test data
		//assertEquals("DP11111", summaries.get(0).getDisplayName());
	}
	
	@Test
	@Transactional
	public void testProposalSummaries_sortBy_PROJECT_CRATED_DT() {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("nobody@uspto.gov", "bkuppusamy", "Boops",
				"Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("nobody@uspto.gov",
				token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));

		UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(springUser);

		PagableProposalSummary page = proposalService.listProposalSummaries(0, Integer.MAX_VALUE, authToken, null, null,
				null, null, null, null, null, null, null, null, null, null, Arrays.asList(ProposalPhase.XX), null, false, null,
				null, null, null, null, null, null, null, null, false, false, false, null, GplSortBy.PROJECT_CREATED_DT, Direction.DESC, null);

		List<ProposalSummary> summaries = page.getList();
		assertNotNull(summaries);
		System.out.println(" Sort By PROJECT_CRATED_Date");
		System.out.println(summaries);
		assertEquals(6, summaries.size());
		//TODO: FIx test data
//		assertEquals("DP11111", summaries.get(0).getDisplayName());
	}
	
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }

}
