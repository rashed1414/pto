package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowUniqueSortKeyValidatorTest {
	
	   @Inject
	    private DatasetTestingService datasetTestingService;
	    
	    @Inject
	    private ProposalRowUniqueSortKeyValidator proposalRowUniqueSortKeyValidator;
	    
	    @Inject
	    private ProposalValidationService proposalValidationService;
	    
	    @Resource
	    private List<ProposalValidator> proposalValidators;
	    
	    private Date lastInit = null;
	    
	    @Test
	    public void testConfigCorrectlyIncludesProposalRowUniqueSortKeyValidator() {
	        boolean isIncluded = false;
	        for (ProposalValidator validator: proposalValidators) {
	            if (validator.getClass().getCanonicalName().equals(proposalRowUniqueSortKeyValidator.getClass().getCanonicalName())) {
	                isIncluded = true;
	                break;
	            }
	        }
	        Assert.assertTrue(isIncluded);
	    }
	    
	    
	    @Test
	    public void testValidate1() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A45B2023/0093", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A45B23/0093", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(1,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(1,rows.get(1).getValidationMessages().size());
	        Assert.assertNotNull(rows.get(1).getValidationMessages().get(0).getMessageText());
	        Assert.assertTrue(CollectionUtils.isNotEmpty(rows.get(1).getValidationMessages()));
	        Assert.assertTrue(CollectionUtils.isNotEmpty(rows.get(0).getValidationMessages()));
	        Assert.assertEquals("Duplicate scheme change entries", rows.get(1).getValidationMessages().get(0).getMessageText());
	        Assert.assertEquals(ValidationMessageField.SYMBOL_NAME, rows.get(1).getValidationMessages().get(0).getTriggerField());
	    }
	    
	    @Test
	    public void testValidate2() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A45B2023/0093", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A45B23/0093", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("C", "A45B23/0093", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(1,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(1,rows.get(1).getValidationMessages().size());
	        Assert.assertEquals(1,rows.get(2).getValidationMessages().size());
	        Assert.assertEquals("Duplicate scheme change entries", rows.get(1).getValidationMessages().get(0).getMessageText());
	        Assert.assertEquals(ValidationMessageField.SYMBOL_NAME, rows.get(1).getValidationMessages().get(0).getTriggerField());
	        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertFalse(rows.get(2).getValidationMessages().isEmpty());
	    }

	    
	    @Test
	    public void testValidate4() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A45B2023/0093", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A45B23/0093", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(1,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(1,rows.get(1).getValidationMessages().size());
	        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertFalse(rows.get(1).getValidationMessages().isEmpty());
	        Assert.assertEquals("Duplicate scheme change entries", rows.get(0).getValidationMessages().get(0).getMessageText());
	        Assert.assertEquals("Duplicate scheme change entries", rows.get(1).getValidationMessages().get(0).getMessageText());
	    }
	    
	    @Test
	    public void testValidate5() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A45B2023/0093", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A45B23/0093", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("C", "A45B23/0093", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A45B23/0093", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);	        
	        Assert.assertEquals(1,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(0,rows.get(1).getValidationMessages().size());
	        Assert.assertEquals(1,rows.get(2).getValidationMessages().size());
	        Assert.assertEquals(0,rows.get(3).getValidationMessages().size());	        
	        Assert.assertEquals("Duplicate scheme change entries", rows.get(0).getValidationMessages().get(0).getMessageText());	        
	    }
	    
	    @Test
	    public void testValidate6() {
	        List<RevisionChangeItem> rows = new ArrayList<>();

	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01B", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(1,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(1,rows.get(1).getValidationMessages().size());
	        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
	        Assert.assertNotNull(rows.get(1).getValidationMessages().get(0).getMessageText());
	        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertFalse(rows.get(1).getValidationMessages().isEmpty());	        
	    }
	    
	    @Test
	    public void testValidate7() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("U", "A45B2023/0093", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A45B23/0093", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(1,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(1,rows.get(1).getValidationMessages().size());
	        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertFalse(rows.get(1).getValidationMessages().isEmpty());
	    }

	    @Test
	    public void testValidate8() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("C", "H04N1/234", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "H04N2001/234", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(1,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(1,rows.get(1).getValidationMessages().size());
	        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertFalse(rows.get(1).getValidationMessages().isEmpty());
	    }
	    
	    @Test
	    public void testValidate9() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("C", "H04N1/234", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N2001/234", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(1,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(1,rows.get(1).getValidationMessages().size());
	        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertFalse(rows.get(1).getValidationMessages().isEmpty());
	    }
	    
	    @Test
	    public void testValidate10() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "H04N1/234", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N2001/234", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(0,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(0,rows.get(1).getValidationMessages().size());
	        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
	    }
	    
	    @Test
	    public void testValidate11() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N1/234", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "H04N2001/234", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(0,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(0,rows.get(1).getValidationMessages().size());
	        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
	    }
	    
	    @Test
	    public void testValidate12() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "H04N1/234", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N2001/234", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(1,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(1,rows.get(1).getValidationMessages().size());
	        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertFalse(rows.get(1).getValidationMessages().isEmpty());
	    }
	    
	    @Test
	    public void testValidate13() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("F", "H04N1/234", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "H04N2101/234", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(0,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(0,rows.get(1).getValidationMessages().size());
	        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
	    }
	    
	    @Test
	    public void testValidate14() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "H04N1/234", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "H04N2001/234", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(0,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(0,rows.get(1).getValidationMessages().size());
	        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
	    }
	    
	    @Test
	    public void testValidate15() {
	        List<RevisionChangeItem> rows = new ArrayList<>();
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("F", "H04N1/234", "0", "Test", null));
	        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "H04N2001/234", "0", "Test", null));
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
	        proposalRowUniqueSortKeyValidator.validate(proposalValidationContext, rows);
	        Assert.assertEquals(1,rows.get(0).getValidationMessages().size());
	        Assert.assertEquals(1,rows.get(1).getValidationMessages().size());
	        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
	        Assert.assertFalse(rows.get(1).getValidationMessages().isEmpty());
	    }
	    
	    @Test
	    public void testGetCost() {
	        Assert.assertEquals(ValidationCost.MEDIUM, proposalRowUniqueSortKeyValidator.getCost());
	    }

	    @Test
	    public void testValidationType() {
	        Assert.assertEquals(ValidationMessageType.RECORD, proposalRowUniqueSortKeyValidator.getValidationType());
	    }
	    
	    @Before
	    public void setUp() throws Exception {
	    	datasetTestingService.loadOnce();
	    	SchemePublicationVersion version = new SchemePublicationVersion();
		        version.setClassificationSchemeId(1L);
		        version.setCpcXsdVersion("1.7");
		        version.setDefinitionXsdVersion("1.0");
		        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		        SchemePublicationVersionContextHolder.setContext(version);
	    }

}
