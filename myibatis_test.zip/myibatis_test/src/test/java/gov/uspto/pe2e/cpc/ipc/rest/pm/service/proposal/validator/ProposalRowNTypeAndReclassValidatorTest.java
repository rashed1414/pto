package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowNTypeAndReclassValidatorTest {
	
	private static final Logger log = LoggerFactory.getLogger(ProposalRowNTypeAndReclassValidatorTest.class);
	
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ProposalRowNTypeAndReclassValidator proposalRowNTypeAndReclassValidator;
    
    @Inject
    private ProposalValidationService proposalValidationService;
    
    @Resource
    private List<ProposalValidator> proposalValidators;    
    
    private static String message1="New group of an existing subclass without reclass! Documents cannot be populated into this group without reclassification.";
    private static String message2 = "New group of a new subclass without reclass! Documents cannot be populated into this group without reclassification.";
   
    @Test
    @Transactional
    public void testValidateTypeNSymbolNotExitInReclassTransfers() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N 1/00", "0", "Bold Error ##BOLD##", new String[] {"A01N27/90"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A01N 1/00", "0", "Bold Error ##BOLD##", new String[] {"A01N 1/01"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNTypeAndReclassValidator.validate(proposalValidationContext, rows);
        assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        assertFalse(rows.get(0).getValidationMessages().isEmpty());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        assertEquals(ValidationMessageField.RECLASS_TRANSFER, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        assertEquals(ValidationMessageLevel.CRITICAL, msg.getLevel());
        assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
        assertEquals(message1,msg.getMessageText());
    }
    @Test
    @Transactional
    public void testValidateMessageLevel() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N5/00", "1", "Test 1", new String[] {}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A01N 1/00", "0", "Test 2", new String[] {"H04N5/10"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "H04N", "SUBCLASS", "Test 3", new String[] {}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNTypeAndReclassValidator.validate(proposalValidationContext, rows);
        assertFalse(rows.get(0).getValidationMessages().isEmpty());
        assertEquals(1, rows.get(0).getValidationMessages().size());
        assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        assertEquals(ValidationMessageField.RECLASS_TRANSFER, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        assertEquals(message2,msg.getMessageText());
        assertEquals(ValidationMessageLevel.ERROR, msg.getLevel());
        
        assertTrue(rows.get(1).getValidationMessages().isEmpty());
        assertEquals(0, rows.get(1).getValidationMessages().size());
       
        assertTrue(rows.get(2).getValidationMessages().isEmpty());
        assertEquals(0, rows.get(2).getValidationMessages().size());
       
    }
    
    @Test
    @Transactional
    public void testValidateTypeNSymbolNotExitInReclassTransfers1() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N 1/00", "0", "Bold Error ##BOLD##", new String[] {"A01N27/90"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N 1/00", "0", "Bold Error ##BOLD##", new String[] {"A01N 1/00"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNTypeAndReclassValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);       
        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
        Assert.assertEquals(message1,msg.getMessageText());
    }
    
    @Test
    @Transactional
    public void testValidateTypeNSymbolExitInReclassTransfers1() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N 27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N 27/99","A01B61/00"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "", "0", "Bold Error ##BOLD##", new String[] {"A01N 27/99"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNTypeAndReclassValidator.validate(proposalValidationContext, rows);
        for(int i =0; i < rows.size(); i++) {
            Assert.assertTrue(rows.get(i).getValidationMessages().isEmpty());
        }
    }
    
    @Test
    @Transactional
    public void testValidateTypeNSymbolExitInReclassTransfers2() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N 27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N 27/99","A01B61/00"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A01N 27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N 27/99"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A01N 27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N 27/99"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A01N 27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N 27/99"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N27/98", "0", "Bold Error ##BOLD##", new String[] {"A01B61/00"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01B61/00", "0", "Bold Error ##BOLD##", new String[] {"A01N27/98"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "", "0", "Bold Error ##BOLD##", new String[] {"A01N27/98"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("", "A01B61/00", "0", "Bold Error ##BOLD##", new String[] {"A01N27/98"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N 27/99", "0", "Bold Error ##BOLD##", new String[] {"A01B61/01"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNTypeAndReclassValidator.validate(proposalValidationContext, rows);
        for(int i =0; i < rows.size(); i++) {
            Assert.assertTrue(rows.get(i).getValidationMessages().isEmpty());
        }
    }
    
    @Test
    @Transactional
    public void testValidateTypeNSymbolExitInReclassTransfers3() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N 27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N 27/99","A01B61/00"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A01N 27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N 27/99"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N27/98", "0", "Bold Error ##BOLD##", new String[] {"A01B61/00"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01B61/00", "0", "Bold Error ##BOLD##", new String[] {"A01N27/98"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "", "0", "Bold Error ##BOLD##", new String[] {"A01N27/98"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("", "A01B61/00", "0", "Bold Error ##BOLD##", new String[] {"A01N27/98"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N 27/99", "0", "Bold Error ##BOLD##", new String[] {"A01B61/01"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNTypeAndReclassValidator.validate(proposalValidationContext, rows);
        for(int i =0; i < rows.size(); i++) {
            Assert.assertTrue(rows.get(i).getValidationMessages().isEmpty());
        }
    }
    
    @Test
    @Transactional
    public void testValidateTypeNWithEmptyRows() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowNTypeAndReclassValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows);
        Assert.assertEquals(0, rows.size());
    } 
    
    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.HIGH, proposalRowNTypeAndReclassValidator.getCost());

    }
    
    @Test
    public void testGetValidationType() {
        Assert.assertEquals(ValidationMessageType.RECORD, proposalRowNTypeAndReclassValidator.getValidationType());

    }

    @Before
    public void setUp() throws Exception {
        datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
    }
}
