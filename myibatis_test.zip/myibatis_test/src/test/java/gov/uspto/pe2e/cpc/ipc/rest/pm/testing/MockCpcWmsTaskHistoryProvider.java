/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.pm.testing;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.joda.time.DateTime;
import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.CpcWmsTaskHistoryProvider;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.WmsFormActionInput;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.WmsPhases;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.TaskAction;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.TaskStateDetails;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 2020 Development Team (myoung3)
 *
 */
@Service
@Slf4j
public class MockCpcWmsTaskHistoryProvider implements CpcWmsTaskHistoryProvider {

	/**
	 * This sample returns canned set of data just for tests.  It is supposed to mimic
	 * the wms client making a rest call to get all closed tasks by proposal guid
	 * @param id
	 * @return
	 */
	@Override
	public List<TaskStateDetails> fetchTaskHistory(UUID id) {
		log.debug("Mocking Task hsitory for {}",id);
		List<TaskStateDetails> completedTasks = new ArrayList<>();
		completedTasks.add(createTask("BAT03", "matt.young@uspto.gov", 
				WmsFormActionInput.Approve, "test 123", 
				DateTime.parse("2022-06-01T22:00:00.000").toDate(),  ProposalPhase.A));
		
		completedTasks.add(createTask("BAT02", "emmanuel.bakthavatchalu@uspto.gov", 
				WmsFormActionInput.Approve, "test 123", 
				DateTime.parse("2022-04-01T22:00:00.000").toDate(),  ProposalPhase.A));
		
		completedTasks.add(createTask("BAT01", "matt.young@uspto.gov", 
				WmsFormActionInput.Reject, "test 123", 
				DateTime.parse("2022-04-01T22:00:00.000").toDate(),  ProposalPhase.R));
		
		completedTasks.add(createTask("BAT04", "emmanuel.bakthavatchalu@uspto.gov", 
				WmsFormActionInput.Suspend, "test 123", 
				DateTime.parse("2022-04-01T22:00:00.000").toDate(), ProposalPhase.R));
		
		log.debug("Returning {}", JsonUtils.toJsonOrStacktrace(completedTasks));
		return completedTasks;
	}

	private TaskStateDetails createTask(String taskDefinitionKey, 
			String assignee, WmsFormActionInput action, String comment,
			Date completeTs, ProposalPhase phase) {
		TaskStateDetails task = new TaskStateDetails();
		task.setPhase(phase);
	    switch (action) {
	    case Approve: 
	    	task.setAction(TaskAction.INITIAL_APPROVE);
	    	break;
	    case Reject:
	    	task.setAction(TaskAction.INITIAL_REJECT);
	    	break;
	    case Suspend:
	    	task.setAction(TaskAction.REPEAT_APPROVE);
	    default:	
	    }
	    task.setTaskName("Name_"+taskDefinitionKey);
	    task.setTaskDefinitionKey(taskDefinitionKey);
	    task.setPhaseName( WmsPhases.valueOf(task.getPhase().name()).getPhaseName());
	    task.setAssignee(assignee);
	    task.setCompleteTs(completeTs);
	    task.setStartTs(new DateTime(completeTs).minusDays(3).toDate());
	    task.setComment(comment);
	    task.setActualWorkedDays(200);
	    task.setExemptWorkDays(25);
	    task.setTaskedOffice(StandardIpOfficeCode.US); 

	    
		return task;
	}



}
