package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLStreamReader;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.CloseableUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.NamespaceXmlReader;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefinitionSectionType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationPhase;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.ApplicationReferences;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.InformativeReferences;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.LimitingReferences;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })

public class DefinitionLimitingAndNonLimitingDuplicateSymbolValidatorTest {
	
    private static final Logger log = LoggerFactory.getLogger(DefinitionLimitingAndNonLimitingDuplicateSymbolValidatorTest.class);

    
    @Inject
    private DatasetTestingService datasetTestingService;
    
    
    @Inject
    private  DefinitionLimitingAndNonLimitingDuplicateSymbolValidator definitionLimitingAndNonLimitingDuplicateSymbolValidator;
    
    @Inject
    private DefinitionSymbolReferenceFormatValidator definitionSymbolReferenceFormatValidator;

    @Resource(name="proposalCompletenessValidator")
    private List<ProposalValidator> completenessValidators;
   
    @Resource(name="proposalConsistencyValidator")
    private List<ProposalValidator> consistencyValidators;
    
    @Inject
    private ProposalValidationService proposalValidationService;
    
    private DocumentAdapter docAdapter;
    
    @Test
    public void testValidator() {
    	
    	  List<RevisionChangeItem> rows = new ArrayList<>();
          rows.add(createRevisionChangeItemWithDefinitionLimitingRef("U", "A01B1/02", "0", "test", new String[] {"A01B 5/005","A01B 5/008"}));
          

          ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
          
          definitionLimitingAndNonLimitingDuplicateSymbolValidator.validate(proposalValidationContext, rows);
          
          //log.debug("Messages -->"+rows.get(0).getValidationMessages()); //A01B1/00
          assertEquals(1, rows.get(0).getValidationMessages().size());
          assertEquals("Symbol(s) [[A01B1/00]] appear in the limiting references section and also in a non-limiting reference section of the definition", 
        		  rows.get(0).getValidationMessages().get(0).getMessageText());
          assertEquals(ValidationMessageField.LIMITING_REFERENCES, 
        		  rows.get(0).getValidationMessages().get(0).getTriggerField());
          assertEquals(ValidationMessageLevel.CRITICAL, 
        		  rows.get(0).getValidationMessages().get(0).getLevel());
          assertEquals(ValidationPhase.CONSISTENCY, 
        		  rows.get(0).getValidationMessages().get(0).getPhase());
    	
    }


    public RevisionChangeItem createRevisionChangeItemWithDefinitionLimitingRef(String entryType, String symbolName, String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel, titleGrammar, reclassTargets); 
        item.getDefinitionItems().add(createDefinitionLimitingRef(SCTComponentChangeType.U));
        item.getDefinitionItems().add(createDefinitionApplicationRef(SCTComponentChangeType.U)); 
        item.getDefinitionItems().add(createDefinitionInformativeRef(SCTComponentChangeType.U));
        return item;
    }
  
    
    private DefSectionItemEditRequest createDefinitionApplicationRef(
			SCTComponentChangeType updateType) {
  		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
  		req.setChangeType(updateType);
  		req.setSectionType(DefinitionSectionType.APPLICATION_REFERENCES);
  		ApplicationReferences snk = null;
  		InputStream is = null;
  		XMLStreamReader xsr = null;
  		NamespaceXmlReader xr = null;
  		try  {
  			is = Thread.currentThread().getContextClassLoader()
  									  //data/xml/fragments/definition_limitingref_for_cpconly_match.xml
  				.getResourceAsStream("data/xml/fragments/appref_A01B1.xml");
  			log.debug("inputStream is not null {} ", is != null);
  			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
  				+IOUtils.toString(is)+"</references></definition-item>");	
//  			xsr = XMLInputFactory.newFactory("com.sun.xml.internal.stream.XMLInputFactoryImpl",
//  		                Thread.currentThread().getContextClassLoader()).createXMLStreamReader(is);
//  				xr = new NamespaceXmlReader(xsr, JaxbUtils.extractNamespace(DefinitionStatement.class));
//  				Unmarshaller um = STATEMENT_CTX.createUnmarshaller();
//  			statement = (DefinitionStatement)um.unmarshal(xr);
  			snk = defItem.getReferences().getApplicationReferences();
  		} catch (Exception je) {
  			log.debug("failed to parse xml",je);
  			throw new IllegalArgumentException(je);
  		} finally {
  			CloseableUtils.closeQuietly(xr);
  			CloseableUtils.closeQuietly(xsr);
  			IOUtils.closeQuietly(is);
  		}
  		
  		req.setApplicationReferences(snk);
  		assertNotNull(req.getApplicationReferences());
  		return req;
	}


	private DefSectionItemEditRequest createDefinitionInformativeRef(SCTComponentChangeType updateType) {
  		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
  		req.setChangeType(updateType);
  		req.setSectionType(DefinitionSectionType.INFORMATIVE_REFERENCES);
  		InformativeReferences snk = null;
  		InputStream is = null;
  		XMLStreamReader xsr = null;
  		NamespaceXmlReader xr = null;
  		try  {
  			is = Thread.currentThread().getContextClassLoader()
  									  //data/xml/fragments/definition_limitingref_for_cpconly_match.xml
  				.getResourceAsStream("data/xml/fragments/inforef_A01B1.xml");
  			log.debug("inputStream is not null {} ", is != null);
  			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
  				+IOUtils.toString(is)+"</references></definition-item>");	
//  			xsr = XMLInputFactory.newFactory("com.sun.xml.internal.stream.XMLInputFactoryImpl",
//  		                Thread.currentThread().getContextClassLoader()).createXMLStreamReader(is);
//  				xr = new NamespaceXmlReader(xsr, JaxbUtils.extractNamespace(DefinitionStatement.class));
//  				Unmarshaller um = STATEMENT_CTX.createUnmarshaller();
//  			statement = (DefinitionStatement)um.unmarshal(xr);
  			snk = defItem.getReferences().getInformativeReferences();
  		} catch (Exception je) {
  			log.debug("failed to parse xml",je);
  			throw new IllegalArgumentException(je);
  		} finally {
  			CloseableUtils.closeQuietly(xr);
  			CloseableUtils.closeQuietly(xsr);
  			IOUtils.closeQuietly(is);
  		}
  		
  		req.setInformativeReferences(snk);
  		assertNotNull(req.getInformativeReferences());
  		return req;
  	}

	private DefSectionItemEditRequest createDefinitionLimitingRef(SCTComponentChangeType updateType) {
  		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
  		req.setChangeType(updateType);
  		req.setSectionType(DefinitionSectionType.LIMITING_REFERENCES);
  		LimitingReferences snk = null;
  		InputStream is = null;
  		XMLStreamReader xsr = null;
  		NamespaceXmlReader xr = null;
  		try  {
  			is = Thread.currentThread().getContextClassLoader()
  									  //data/xml/fragments/definition_limitingref_for_cpconly_match.xml
  				.getResourceAsStream("data/xml/fragments/limittingref_A01B1.xml");
  			log.debug("inputStream is not null {} ", is != null);
  			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
  				+IOUtils.toString(is)+"</references></definition-item>");	
//  			xsr = XMLInputFactory.newFactory("com.sun.xml.internal.stream.XMLInputFactoryImpl",
//  		                Thread.currentThread().getContextClassLoader()).createXMLStreamReader(is);
//  				xr = new NamespaceXmlReader(xsr, JaxbUtils.extractNamespace(DefinitionStatement.class));
//  				Unmarshaller um = STATEMENT_CTX.createUnmarshaller();
//  			statement = (DefinitionStatement)um.unmarshal(xr);
  			snk = defItem.getReferences().getLimitingReferences();
  		} catch (Exception je) {
  			log.debug("failed to parse xml",je);
  			throw new IllegalArgumentException(je);
  		} finally {
  			CloseableUtils.closeQuietly(xr);
  			CloseableUtils.closeQuietly(xsr);
  			IOUtils.closeQuietly(is);
  		}
  		
  		req.setLimitingReferences(snk);
  		assertNotNull(req.getLimitingReferences());
  		return req;
  	}
  
      
	@Before
    public void setUp() throws Exception {
		datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        Class adapterClass = Class.forName(DocumentAdapter.class.getCanonicalName());
        docAdapter = (DocumentAdapter)adapterClass.newInstance();

    }



}
