package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalTWL;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalTWLDetail;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalTWLRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.AllocationAgreementCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.NonRequestingOfficeAllocationAgreementCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RequestingOfficeTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.TWLDetail;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.TWLDocument;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalTWLServiceVolatileTest {
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ChangeProposalTWLRepository changeProposalTWLRepository;
    
    @Inject
    private ChangeProposalRepository changeProposalRepository;
    
    @Inject
    private ProposalTWLService proposalTWLService;
    
	private static final String DATE_FORMAT="MMddyy";

       
    @Transactional
    @Test
    public void testSaveAsNew() throws JsonGenerationException, JsonMappingException, IOException {
//    	ChangeProposalTWL dbTWL = changeProposalTWLRepository.findByExternalId(GUIDUtils.toDatabaseFormat(twlId.get(0)));
//        assertNotNull(dbTWL);
//        assertEquals(1, dbTWL.getDetails().size());
//         
    	Date now = new Date();
        TWLDocument twl = new TWLDocument();
        twl.setComment("test 123");
        twl.setCreateTs(now);
        twl.setCreateUserId("myoung@uspto.gov");
        twl.setUpdateTs(now);
        twl.setUpdateUserId("myoung@uspto.gov");
        twl.setPatentDocumentId("10001");
        twl.setProposalId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));
        twl.setPublishedKindCode("A");
        twl.setStandardIpOffice(StandardIpOfficeCode.US);
        TWLDetail detail1 = createTWLDetail(null,
                null,
                AllocationAgreementCategory.AGREE, 
                "Final comment 1", "AA", 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 1",
                "Notes 1", RequestingOfficeTypeCode.A,
                 "Requesting office comment 1",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId());
        twl.getDetails().add(detail1);
        TWLDetail detail2 = createTWLDetail(null,
                null,
                AllocationAgreementCategory.AGREE, 
                "Final comment 2", "AA", 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 2",
                "Notes 2", RequestingOfficeTypeCode.A,
                 "Requesting office comment 2",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId());
        assertFalse(detail1.equals(detail2));
        twl.getDetails().add(detail2);
        twl.getDetails().add(createTWLDetail(null,
                null,
                AllocationAgreementCategory.AGREE, 
                "Final comment 3", "AA", 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 3",
                "Notes 3", RequestingOfficeTypeCode.A,
                 "Requesting office comment 3",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId()));

        StringWriter w = new StringWriter();
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.writeValue(w, twl);
        List<UUID> twlId = proposalTWLService.save(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), Arrays.asList(twl), "myoung@uspto.gov");
        
        ChangeProposalTWL dbTWL = changeProposalTWLRepository.findByExternalId(GUIDUtils.toDatabaseFormat(twlId.get(0)));
        assertNotNull(dbTWL);
       // assertEquals(2, dbTWL.getDetails().size());
    }
    
    private TWLDetail createTWLDetail(UUID id, UUID parentTWLId,  
            AllocationAgreementCategory allocAggrCat, 
            String finalComment,
            String nextActionName, 
            NonRequestingOfficeAllocationAgreementCategory nonRequestingOfficeAllocAgreement, 
            String nonRequestingOfficeComment,
            String notes,
            RequestingOfficeTypeCode requestingIpOffceCode,
            String reqestingOfficeComment,
            String sourceSymbol,
            String targetSymbol,
            Date now, 
            String userId) {
        TWLDetail dtl = new TWLDetail();
        dtl.setCreateTs(now);
        dtl.setCreateUserId(userId);
        dtl.setFinalAllocationAgreement(allocAggrCat);
        dtl.setFinalComment(finalComment);
        dtl.setId(id); 
        dtl.setNextActionName(nextActionName);
        dtl.setNonRequestingOfficeComment(nonRequestingOfficeComment);
        dtl.setNonRequestingOfficeAllocationAgreement(nonRequestingOfficeAllocAgreement);
        dtl.setNotes(notes);
        dtl.setParentId(parentTWLId);
        dtl.setRequestingIpOfficeCode(requestingIpOffceCode);
        dtl.setRequestingIpOfficeComment(reqestingOfficeComment);
        dtl.setSourceSymbolName(sourceSymbol);
        dtl.setTargetSymbolName(targetSymbol);
        dtl.setUpdateTs(now);
        dtl.setUpdateUserId(userId);
        return dtl;
    }

    @Transactional
    @Test
    public void testSaveAsUpdate() {
        Date now = new Date();
        TWLDocument twl = new TWLDocument();
        twl.setId(GUIDUtils.fromDatabaseFormat("eb04002f08694152b6f2083b4df825c2"));
        twl.setComment("test 123");
        twl.setCreateTs(now);
        twl.setCreateUserId("myoung@uspto.gov");
        twl.setUpdateTs(now);
        twl.setUpdateUserId("myoung@uspto.gov");
        twl.setPatentDocumentId("10001");
        twl.setProposalId(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"));
        twl.setPublishedKindCode("A");
        twl.setStandardIpOffice(StandardIpOfficeCode.US);
        TWLDetail detail1 = createTWLDetail(null,
                twl.getId(),
                AllocationAgreementCategory.AGREE, 
                "Final comment 1", "AA", 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 1",
                "Notes 1", RequestingOfficeTypeCode.A,
                 "Requesting office comment 1",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId());
        twl.getDetails().add(detail1);
        TWLDetail detail2 = createTWLDetail(null,
                twl.getId(),
                AllocationAgreementCategory.AGREE, 
                "Final comment 2", "AA", 
                NonRequestingOfficeAllocationAgreementCategory.NR_ADDED,
                "Non requesting office comment 2",
                "Notes 2", RequestingOfficeTypeCode.A,
                 "Requesting office comment 2",
                "A01F2009/00", "A01C3/025",
                twl.getCreateTs(), twl.getCreateUserId());
        assertFalse(detail1.equals(detail2));
        
        twl.getDetails().add(detail2);
        assertEquals(2, twl.getDetails().size());
        List<UUID> twlId = proposalTWLService.save(GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5"), Arrays.asList(twl), "myoung@uspto.gov");
        ChangeProposalTWL dbTWL = changeProposalTWLRepository.findByExternalId(GUIDUtils.toDatabaseFormat(twlId.get(0)));
        assertNotNull(dbTWL);
        for (ChangeProposalTWLDetail dtl: dbTWL.getDetails()) {
        	log.info("{} {}", dtl.getExternalId(), dtl.getFinalComment());
        }
        assertEquals(2, dbTWL.getDetails().size());
    }


    @Test
    public void testGetExportTWLFileNameRecordNotFound() {
    	String fileName=proposalTWLService.getExportTWLXlsxFileName(GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb9"));
    	String dateFormat=new LocalDateTime().toString(DATE_FORMAT);
    	assertNotNull(fileName);
    	assertEquals(fileName,"");	
    }
//    @Test
//    public void testExportTWLDataIntoXlsx() throws IOException {
//    	UUID proposalID=GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7");
//    	UUID proposalRevisionUUID=GUIDUtils.fromDatabaseFormat("0a940f78a42a41cbae5f9dd37450034b");
//    	byte[] exportData=proposalTWLService.exportTWLDataIntoXlsx(proposalID, proposalRevisionUUID);
//    	
//    	assertNotNull(exportData);
//    	
//    	ByteArrayInputStream bin = new ByteArrayInputStream(exportData);
//    	Workbook workbook = new XSSFWorkbook(bin);
//
//    	assertEquals(4,workbook.getNumberOfSheets());
//    	assertEquals("DP0027",workbook.getSheet("STATS").getRow(0).getCell(1).getStringCellValue());
//    	
//    }
    
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
                "bkuppusamy", "Boops","Kuppusamy", "US");
            UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "boopathi.kuppusamy@uspto.gov", token,
                Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
                        new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
                        new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
        SecurityContextHolder.getContext().setAuthentication(springUser);  

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/proposals/xxx/twl")));
    }

}
