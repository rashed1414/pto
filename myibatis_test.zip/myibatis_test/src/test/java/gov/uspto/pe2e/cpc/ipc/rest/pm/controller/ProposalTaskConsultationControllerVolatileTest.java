package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.WfSmeConsultation;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.WfSmeConsultationComment;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.WfSmeConsultationRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.OfficeContactType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDetailCreationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalFormType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.smeconsult.v1_0.Consultation;
import gov.uspto.pe2e.cpc.ipc.rest.contract.smeconsult.v1_0.ConsultationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalDetailsService;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalTaskConsultationControllerVolatileTest {
	 
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private ProposalTaskConsultationController controller;
    
    @Inject
    private WfSmeConsultationRepository wfSmeConsultationRepository;
    
    @Inject
    private ProposalDetailsService proposalDetailsService;

    @Inject
    private EntityManager entityManager;

    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

//        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("myoung3@uspto.gov", "myoung3@uspto.gov", Arrays
//                .asList(new BasicTestingGrantedAuthority("test"), 
//                		new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
//
//        SecurityContextHolder.getContext().setAuthentication(token);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
    			"bkuppusamy", "Boops","Kuppusamy", "US");
    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"boopathi.kuppusamy@uspto.gov", token,
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);        


        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/proposaltaskconsultation")));
    }
    
	@Test
	@Transactional
	public void testStartConsultation() {
		
		  SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
	    			"bkuppusamy", "Boops","Kuppusamy", "US");
	    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
	    			"boopathi.kuppusamy@uspto.gov", token,
	    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
	    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
	    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
	    	SecurityContextHolder.getContext().setAuthentication(springUser);        


	     UUID proposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
	     ConsultationRequest req = new ConsultationRequest();
	     req.setSmeNotificationEnabled(true);
    	 req.setWorkflowTaskInstanceId(999L);
    	 req.setComment("This is a test comment");
	     ResponseEntity<Void> resp = controller.startConsultation(proposalId, "IRT01", req);
	     assertNotNull(resp);
	     assertEquals(HttpStatus.CREATED, resp.getStatusCode());
	     UUID consultationId = UUID.fromString(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
	 
	     assertNotNull(consultationId);
	     String key = GUIDUtils.toDatabaseFormat(consultationId);
	     WfSmeConsultation dbRec = wfSmeConsultationRepository.findById(key).get();
	     assertNotNull(dbRec);
	     assertEquals((Integer)1, (Integer)dbRec.getComments().size());

	     assertNotNull(dbRec.getStartTs());
	     assertEquals((Long)999L, (Long)dbRec.getWorkflowTaskInstanceId());
	     
	     WfSmeConsultationComment comment = dbRec.getComments().iterator().next();
	     assertNotNull(comment);
	     assertEquals("This is a test comment", comment.getComment());
	     assertEquals("IRT01", dbRec.getTaskConfig().getId());
	     assertEquals("Set Internal Request Form", dbRec.getTaskConfig().getTitle());
	     
	     
	     
	}

	@Test
	@Transactional
	public void testAddComment() {
		
		  SAMLCredential token = SamlTestingUtil.createTestSamlCredential("test.SME@uspto.gov", 
	    			"tsme", "Test","SME", "US");
	    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
	    			"test.SME@uspto.gov", token,
	    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
	    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
	    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name()),
	    					new BasicTestingGrantedAuthority(ApplicationPermission.SME_RESPONSE.name())));
	    	SecurityContextHolder.getContext().setAuthentication(springUser);        

	    UUID proposalId = GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844db5");
	     ResponseEntity<Void> resp = controller.addComment(proposalId, "IRT04",
	    		 GUIDUtils.fromDatabaseFormat("5b9043e2dfb74f0d97588ae3d305de49"),
	    		 "second comment");
	     assertNotNull(resp);
	     assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
	     UUID commentId = UUID.fromString(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
	 
	     assertNotNull(commentId);
	     String key = GUIDUtils.toDatabaseFormat(commentId);
	     WfSmeConsultation dbRec = wfSmeConsultationRepository.findById("5b9043e2dfb74f0d97588ae3d305de49").get();
	     assertNotNull(dbRec);
	     assertEquals((Integer)2, (Integer)dbRec.getComments().size());
	     assertEquals("IRT04", dbRec.getTaskConfig().getId());
	     for (WfSmeConsultationComment comment : dbRec.getComments()) {
	    	 if ( StringUtils.equals(GUIDUtils.toDatabaseFormat(commentId), 
	    			 comment.getId())) {
	    		 assertEquals("second comment", comment.getComment());
	    		 assertEquals(OfficeContactType.SCE, comment.getApproverRole());
	    	 } else if ( StringUtils.equals("dd35da34f0424cfe882de864a77b269a", 
	    			 comment.getId())) {
		    	 assertEquals("FIRST COMMENT!", comment.getComment());

	    		 assertEquals(OfficeContactType.COORDINATOR, comment.getApproverRole());
	    	 }
	    	 
	     }
	}

	
	@Test
	@Transactional//(value = TxType.NEVER)
	public void testConsultEndedByPCChange() {
		Date now = new Date();
	    UUID proposalId = GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844d41");
	    List<WfSmeConsultation> consults = wfSmeConsultationRepository.findByProposalExternalId(GUIDUtils.toDatabaseFormat(proposalId));
	         assertEquals(1, consults.size());
	         assertNull(consults.get(0).getEndTs());
	         consults =  new ArrayList<>();
		
		  SAMLCredential token = SamlTestingUtil.createTestSamlCredential("test.SME@uspto.gov", 
	    			"tsme", "Test","SME", "US");
	    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
	    			"test.SME@uspto.gov", token,
	    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
	    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
	    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name()),
	    					new BasicTestingGrantedAuthority(ApplicationPermission.SME_RESPONSE.name())));
	    	SecurityContextHolder.getContext().setAuthentication(springUser);        

	     
	     
	     proposalDetailsService.save(proposalId, 
	    		 Arrays.asList(createProposalDetailsCreationRequest()), 
	    		 "text_completed_consult");
	     entityManager.flush();
	     entityManager.clear();
         consults = wfSmeConsultationRepository.findByProposalExternalId(GUIDUtils.toDatabaseFormat(proposalId));
         assertEquals(1, consults.size());
         assertEquals((Integer)2, (Integer)consults.get(0).getLockControl());
         assertNotNull(consults.get(0).getEndTs());
//         assertTrue(now.equals(consults.get(0).getEndTs()) );
         assertEquals("text_completed_consult", consults.get(0).getLastModifiedUserId());
         
         
         ResponseEntity<List<Consultation>> resp = 
        		 controller.listConsultationsByProposalAndTask(proposalId, "IRT04", null, null);
         assertEquals(1, resp.getBody().size());
         assertNotNull(resp.getBody().get(0).getEndTs());
         
	}

	private ProposalDetailCreationRequest createProposalDetailsCreationRequest() {
		ProposalDetailCreationRequest req = new ProposalDetailCreationRequest();
		req.setFormType(ProposalFormType.PROJECT_DETAIL);
		req.setItemName("coordinatorUS_PD");
		req.setDetails("matt@uspto.gov");
	
		return req;
	}

}
