package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class TitleSymbolReferenceValidatorTest {
    private static final Logger log = LoggerFactory.getLogger(TitleSymbolReferenceValidatorTest.class);
    
    @Inject
    private DatasetTestingService datasetTestingService;


        @Inject
        private TitleSymbolReferenceValidator titleSymbolReferenceValidator;

        
        @Inject 
        private ProposalValidationService proposalValidationService;

        @Inject
        private TitleService titleService;
        
        @Resource(name="proposalCompletenessValidator")
        private List<ProposalValidator> proposalValidators;
        
        private Date lastInit = null;

        @Test
        public void testConfigCorrectlyIncludesGrammarValidator() {
            boolean isIncluded = false;
            for (ProposalValidator validator: proposalValidators) {
                if (validator.getClass().getCanonicalName().equals(titleSymbolReferenceValidator.getClass().getCanonicalName())) {
                    isIncluded = true;
                    break;
                }
            }
            Assert.assertTrue(isIncluded);
        }
     
    @Test
    public void testValidate() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", " test ##SYMBOL##This will not pass##/SYMBOL## test ##SYMBOL##A##/SYMBOL## test ##SYMBOL##AXX##/SYMBOL##", null));

        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "##SYMBOL##A01N01T/3002##/SYMBOL## This symbol should exist ##SYMBOL##A01N##/SYMBOL##", null));
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "Test ##SYMBOL##D01N01/2001##/SYMBOL##", null));
        

        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
        titleSymbolReferenceValidator.validate(proposalValidationContext, rows);
        int i =1;
        for (RevisionChangeItem row: rows) {
            log.debug("line {} has {} validation messages",i,row.getValidationMessages().size());
            int j = 1;
            for (ValidationMessage msg: row.getValidationMessages()) {
                log.debug("Mesg = {}", msg.getMessageText());
                Assert.assertEquals(ValidationMessageField.TITLE, msg.getTriggerField());
                switch (i) {
                case 1: 
                    switch (j) {
                    case (1):
                        Assert.assertEquals("Symbol 'Thiswillnotpass' is not well formed and does not meet the required CPC symbol pattern.", msg.getMessageText());
                        break;
                    case (2):
                        Assert.assertEquals("Symbol 'AXX' is not well formed and does not meet the required CPC symbol pattern.", msg.getMessageText());
                        break;
    
                    default: 
                        Assert.assertTrue(row.getValidationMessages().size()==2);   
                    }
                    break;
                case 2:
                    switch (j) { //Symbol 'D01N01/2001' is not well formed and does not meet the required CPC symbol pattern.
                    case (1):
                        Assert.assertEquals("Symbol 'A01N01T/3002' is not well formed and does not meet the required CPC symbol pattern.", msg.getMessageText());
                        break;
                    default: 
                        Assert.assertTrue(row.getValidationMessages().size()==1);                       }
                    break;
                case 3:
                    switch (j) {
                    case (1):
                        Assert.assertEquals("Symbol 'D01N01/2001' is not well formed and does not meet the required CPC symbol pattern.", msg.getMessageText());
                        break;
                    default: 
                        Assert.assertTrue(row.getValidationMessages().size()==1);                       }
                    break;
                   
                default:
                    Assert.assertFalse(true); // this condition should not be reached as switch(i) covers all rows with errors
                }
                Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
                j++;
            }
            i++;
        }

    }
    
    @Test
    public void testValidate1() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", " test ##SYMBOL##H05N 5/232939##/SYMBOL## test", null));

        rows.add(createRevisionChangeItemAndValidateTitleGrammar("N", "H05N 5/232939", "0", "Test", null));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
        titleSymbolReferenceValidator.validate(proposalValidationContext, rows);
        //Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
/*        ValidationMessage msg = rows.get(0).getValidationMessages().get(0);
        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, msg.getTriggerField());
        log.debug(msg.getMessageText());        
        Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
        Assert.assertEquals("Invalid Transfer-to Symbol 'A01B61/00' - it's Frozen in Gold copy (or) Frozen/Deleted in this proposal",msg.getMessageText());
*/
    	
    }
    
    @Test
    public void testValidateTitleReferenceNotInProposalContext() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", " test ##SYMBOL##H05N 5/23293##/SYMBOL## test", null));

        rows.add(createRevisionChangeItemAndValidateTitleGrammar("C", "H05N 5/23293", "0", "Test", null));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
        titleSymbolReferenceValidator.validate(proposalValidationContext, rows);
        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
    }
    
    @Test
    public void testGetCost() {
        
        Assert.assertEquals(ValidationCost.HIGH, titleSymbolReferenceValidator.getCost());
        
    }
    
    @Test 
    public void testGetValidatorType() {
        Assert.assertEquals(ValidationMessageType.RECORD, titleSymbolReferenceValidator.getValidationType());
        
        
    }
    
    public RevisionChangeItem createRevisionChangeItemAndValidateTitleGrammar(String entryType, String symbolName, String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel, titleGrammar, reclassTargets); 
        try {
            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
            item.setTitle(tree);
        } catch (GrammarParseException gpe) {
            item.getValidationMessages().addAll(gpe.getValidationMessages());
        }
        return item;
    }
    

    @Before
    public void setUp() throws Exception {
        
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        DateTimeZone.setDefault(DateTimeZone.UTC);
        datasetTestingService.loadOnce();
        

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

//        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1", "user@user.com",
//                Arrays.asList(new BasicTestingGrantedAuthority("test")));
//
//        SecurityContextHolder.getContext().setAuthentication(token);
//
//        RequestContextHolder.setRequestAttributes(
//                new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
    }



}
