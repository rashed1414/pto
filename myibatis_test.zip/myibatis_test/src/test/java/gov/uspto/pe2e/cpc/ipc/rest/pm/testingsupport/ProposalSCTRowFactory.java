package gov.uspto.pe2e.cpc.ipc.rest.pm.testingsupport;

import static org.junit.Assert.assertNotNull;

import java.io.InputStream;

import javax.xml.stream.XMLStreamReader;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.CloseableUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.NamespaceXmlReader;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefinitionSectionType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.ApplicationReferences;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionStatement;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.GlossaryOfTerms;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.InformativeReferences;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.LimitingReferences;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.ResidualReferences;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.SynonymsKeywords;
import jakarta.annotation.PostConstruct;

/**
 * 
 * 
 * @author 2020
 * @date Sep 13, 2018
 * @since 1.13.0
 * @version 1.13.0
 */
@Service("proposalSCTRowFactory")
public class ProposalSCTRowFactory {
	
	private static final Logger log = LoggerFactory.getLogger(ProposalSCTRowFactory.class);
	
	private DocumentAdapter docAdapter;
	
	
    public RevisionChangeItem createRevisionChangeItemWithDefinitionStatements(String entryType, String symbolName, String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel, titleGrammar, reclassTargets); 
        item.getDefinitionItems().add(createDefinitionStatementSection(SCTComponentChangeType.M,"data/xml/fragments/definition_statement_with_invalid_symbols.xml"));
        item.getDefinitionItems().add(createDefinitionGlossarySection(SCTComponentChangeType.M,"data/xml/fragments/definition_glossary_1_invalid_and_1_deleted_symbol.xml"));
        return item;
    }
  
    public RevisionChangeItem createRevisionChangeItemWithOnlySNKDef(String entryType, String symbolName, String dotLevel, String titleGrammar, String[] reclassTargets, String filename) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel, titleGrammar, reclassTargets); 
        item.getDefinitionItems().add(createDefinitionSnKSection(SCTComponentChangeType.M, filename));
        return item;
    }
    
    public DefSectionItemEditRequest createDefinitionSnKSection(SCTComponentChangeType updateType, String filename) {
  		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
  		req.setChangeType(updateType);
  		req.setSectionType(DefinitionSectionType.SYNONYMS_AND_KEYWORDS);
  		SynonymsKeywords snk = null;
  		InputStream is = null;
  		XMLStreamReader xsr = null;
  		NamespaceXmlReader xr = null;
  		try  {
  			is = Thread.currentThread().getContextClassLoader()
  				.getResourceAsStream(filename);
  			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
  				+IOUtils.toString(is)+"</definition-item>");	
  			snk = defItem.getSynonymsKeywords();
  		} catch (Exception je) {
  			throw new IllegalArgumentException(je);
  		} finally {
  			CloseableUtils.closeQuietly(xr);
  			CloseableUtils.closeQuietly(xsr);
  			IOUtils.closeQuietly(is);
  		}
  		
  		req.setSynonymsKeywords(snk);
  		assertNotNull(req.getSynonymsKeywords());
  		return req;
  	}
    

	public DefSectionItemEditRequest createResidualReference(SCTComponentChangeType updateType, String filename) {
  		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
  		req.setChangeType(updateType);
  		req.setSectionType(DefinitionSectionType.RESIDUAL_REFERENCES);
  		ResidualReferences resref = null;
  		InputStream is = null;
  		XMLStreamReader xsr = null;
  		NamespaceXmlReader xr = null;
  		try  {
  			is = Thread.currentThread().getContextClassLoader()
  				.getResourceAsStream(filename);
  			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
  				+IOUtils.toString(is)+"</references></definition-item>");	
  			resref = defItem.getReferences().getResidualReferences();
  		} catch (Exception je) {
  			throw new IllegalArgumentException(je);
  		} finally {
  			CloseableUtils.closeQuietly(xr);
  			CloseableUtils.closeQuietly(xsr);
  			IOUtils.closeQuietly(is);
  		}
  		
  		req.setResidualReferences(resref);
  		assertNotNull(req.getResidualReferences());
  		return req;
	}

	public DefSectionItemEditRequest createInformativeReference(SCTComponentChangeType updateType, 
			String filename) {
  		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
  		req.setChangeType(updateType);
  		req.setSectionType(DefinitionSectionType.INFORMATIVE_REFERENCES);
  		InformativeReferences infoRef = null;
  		InputStream is = null;
  		try  {
  			log.debug("Classloading file = {}", filename);
  			is = Thread.currentThread().getContextClassLoader()
  				.getResourceAsStream(filename);
  			log.debug("IS value is null = {}", (is == null));
  			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
  				+IOUtils.toString(is)+"</references></definition-item>");	
  			infoRef = defItem.getReferences().getInformativeReferences();
  		} catch (Exception je) {
  			throw new IllegalArgumentException(je);
  		} finally {
  			IOUtils.closeQuietly(is);
  		}
  		
  		req.setInformativeReferences(infoRef);
  		assertNotNull(req.getInformativeReferences());
  		return req;	
  	}


  
      
    private DefSectionItemEditRequest createDefinitionStatementSection(SCTComponentChangeType updateType, String filename) {
		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
		req.setChangeType(updateType);
		req.setSectionType(DefinitionSectionType.DEFINITION_STATEMENT);
		DefinitionStatement statement = null;
		InputStream is = null;
		XMLStreamReader xsr = null;
		NamespaceXmlReader xr = null;
		try  {
			is = Thread.currentThread().getContextClassLoader()
		
				.getResourceAsStream(filename);
			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
				+IOUtils.toString(is)+"</definition-item>");	
			statement = defItem.getDefinitionStatement();
		} catch (Exception je) {
			throw new IllegalArgumentException(je);
		} finally {
			CloseableUtils.closeQuietly(xr);
			CloseableUtils.closeQuietly(xsr);
			IOUtils.closeQuietly(is);
		}
		
		req.setDefinitionStatement(statement);
		assertNotNull(req.getDefinitionStatement());
		return req;
	}

	public RevisionChangeItem createRevisionChangeItemWithApplicationReferences(String entryType, String symbolName, String dotLevel, String titleGrammar, String[] reclassTargets, String filename) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel, titleGrammar, reclassTargets); 
        item.getDefinitionItems().add(createApplicationReference(SCTComponentChangeType.M,filename));
        return item;
	}
	
	public DefSectionItemEditRequest createApplicationReference(SCTComponentChangeType updateType, String filename) {
		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
  		req.setChangeType(updateType);
  		req.setSectionType(DefinitionSectionType.APPLICATION_REFERENCES);
  		ApplicationReferences snk = null;
  		InputStream is = null;
  		XMLStreamReader xsr = null;
  		NamespaceXmlReader xr = null;
  		try  {
  			is = Thread.currentThread().getContextClassLoader()
  									  //data/xml/fragments/definition_limitingref_for_cpconly_match.xml
  				.getResourceAsStream(filename);
  			log.debug("inputStream is not null {} ", is != null);
  			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
  				+IOUtils.toString(is)+"</references></definition-item>");	
  			snk = defItem.getReferences().getApplicationReferences();
  		} catch (Exception je) {
  			log.debug("failed to parse xml",je);
  			throw new IllegalArgumentException(je);
  		} finally {
  			CloseableUtils.closeQuietly(xr);
  			CloseableUtils.closeQuietly(xsr);
  			IOUtils.closeQuietly(is);
  		}
  		
  		req.setApplicationReferences(snk);
  		assertNotNull(req.getApplicationReferences());
  		return req;

	}

	
	public DefSectionItemEditRequest createDefinitionLimitingRef(SCTComponentChangeType updateType, String xmlFragmentPath) {
	  		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
	  		req.setChangeType(updateType);
	  		req.setSectionType(DefinitionSectionType.LIMITING_REFERENCES);
	  		LimitingReferences snk = null;
	  		InputStream is = null;
	  		XMLStreamReader xsr = null;
	  		NamespaceXmlReader xr = null;
	  		try  {
	  			is = Thread.currentThread().getContextClassLoader()
	  									  //data/xml/fragments/definition_limitingref_for_cpconly_match.xml
	  				.getResourceAsStream(xmlFragmentPath);
	  			log.debug("inputStream is not null {} ", is != null);
	  			DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
	  				+IOUtils.toString(is)+"</references></definition-item>");	
	  			snk = defItem.getReferences().getLimitingReferences();
	  		} catch (Exception je) {
	  			log.debug("failed to parse xml",je);
	  			throw new IllegalArgumentException(je);
	  		} finally {
	  			CloseableUtils.closeQuietly(xr);
	  			CloseableUtils.closeQuietly(xsr);
	  			IOUtils.closeQuietly(is);
	  		}
	  		
	  		req.setLimitingReferences(snk);
	  		assertNotNull(req.getLimitingReferences());
	  		return req;
	  	}


    private DefSectionItemEditRequest createDefinitionGlossarySection(SCTComponentChangeType updateType, String filename) {
  		DefSectionItemEditRequest req = new DefSectionItemEditRequest();
  		req.setChangeType(updateType);
  		req.setSectionType(DefinitionSectionType.GLOSSARY_OF_TERMS);
  		GlossaryOfTerms glossary = null;
  		InputStream is = null;
  		XMLStreamReader xsr = null;
  		NamespaceXmlReader xr = null;
  		try  {
  			is = Thread.currentThread().getContextClassLoader()
  		
  				.getResourceAsStream(filename);
  			DefinitionItem defItem=	docAdapter.parseDefinition("<definition-item>"
  					+IOUtils.toString(is)+"</definition-item>");
  			glossary = defItem.getGlossaryOfTerms();
  		} catch (Exception je) {
  			throw new IllegalArgumentException(je);
  		} finally {
  			CloseableUtils.closeQuietly(xr);
  			CloseableUtils.closeQuietly(xsr);
  			IOUtils.closeQuietly(is);
  		}
  		
  		req.setGlossaryOfTerms(glossary);
  		assertNotNull(req.getGlossaryOfTerms());
  		return req;
  	}


    @PostConstruct
    public void init() {
    	try {
    	 Class adapterClass = Class.forName(DocumentAdapter.class.getCanonicalName());
         docAdapter = (DocumentAdapter)adapterClass.newInstance();
    	}
    	catch (Exception e) {
    		log.error("Failed to init docadapter for test factory", e);
    		
    	}
    }


}
