package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import static org.junit.Assert.assertNotNull;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefinitionSectionType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.LimitingReferences;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.SynonymsKeywords;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })

public class ProposalRowDefinitionSectionsStructuralTableValidatorTest {

    private static final Logger log = LoggerFactory.getLogger(ProposalRowDefinitionSectionsStructuralTableValidatorTest.class);

    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalRowDefinitionSectionsStructuralTableValidator proposalRowDefinitionSectionsStructuralTableValidator;

    @Resource(name = "proposalConsistencyValidator")
    private List<ProposalValidator> consistencyValidators;

    @Inject
    private ProposalValidationService proposalValidationService;

    private DocumentAdapter docAdapter;

    @Test
    public void testConfigCorrectlyIncludesDefinitionSectionsValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : consistencyValidators) {
            if (validator.getClass().getCanonicalName()
                    .equals(proposalRowDefinitionSectionsStructuralTableValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }


    @Test
    public void testProposalRowDefinitionSectionsStructural() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRow("definition_limiting_references_bad_structural.xml"));
        rows.add(createRow("definition_limitingreference_empty.xml"));

        ProposalValidationContext proposalValidationContext = proposalValidationService
                .createProposalValidationContext(rows);
        proposalRowDefinitionSectionsStructuralTableValidator.validate(proposalValidationContext, rows);
        
        
        Assert.assertEquals("Definition section does not contain a table.",
                rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertTrue(CollectionUtils.isEmpty(rows.get(1).getValidationMessages()));

    }
    
    @Test
    public void testProposalRowDefinitionSectionsAbbrevations() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createSnKRow());

        ProposalValidationContext proposalValidationContext = proposalValidationService
                .createProposalValidationContext(rows);
        proposalRowDefinitionSectionsStructuralTableValidator.validate(proposalValidationContext, rows);        
        
        Assert.assertEquals("Definition section [Instead-of Words] does not contain a table.",
                rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertFalse(CollectionUtils.isEmpty(rows.get(0).getValidationMessages()));
       
        Assert.assertTrue(rows.get(0).getValidationMessages().size() == 1);

    }
    
    @Test
    public void testProposalRowDefinitionSectionsInsteadOfWords() {

        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createSnKInstedOfWordsRow());

        ProposalValidationContext proposalValidationContext = proposalValidationService
                .createProposalValidationContext(rows);
        proposalRowDefinitionSectionsStructuralTableValidator.validate(proposalValidationContext, rows);        
        
        Assert.assertEquals("Definition section [Abbreviations] does not contain a table.",
                rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals("Definition section [Special Meanings] does not contain a table.",
                rows.get(0).getValidationMessages().get(1).getMessageText());
       
        Assert.assertTrue(rows.get(0).getValidationMessages().size() == 2);

    }
    
    public RevisionChangeItem createSnKInstedOfWordsRow() {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0", "test;hello",
                new String[] { "A01B 5/005", "A01B 5/008" });

        DefSectionItemEditRequest req = new DefSectionItemEditRequest();

        req.setChangeType(SCTComponentChangeType.M);
        req.setSectionType(DefinitionSectionType.SYNONYMS_AND_KEYWORDS);
        SynonymsKeywords snk = null;
        try(InputStream is  = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/definition_snk_insteadofwords.xml"))  {
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
                +IOUtils.toString(is)+"</definition-item>");
            snk = defItem.getSynonymsKeywords();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        } 
        req.setSynonymsKeywords(snk);
        assertNotNull(req.getSynonymsKeywords());
        item.getDefinitionItems().add(req);
        return item;
    }

    
    public RevisionChangeItem createSnKRow() {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0", "test;hello",
                new String[] { "A01B 5/005", "A01B 5/008" });

        DefSectionItemEditRequest req = new DefSectionItemEditRequest();

        req.setChangeType(SCTComponentChangeType.M);
        req.setSectionType(DefinitionSectionType.SYNONYMS_AND_KEYWORDS);
        SynonymsKeywords snk = null;
        try(InputStream is  = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/definition_snk_abbrevations.xml"))  {
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item>"
                +IOUtils.toString(is)+"</definition-item>");
            snk = defItem.getSynonymsKeywords();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        } 
        req.setSynonymsKeywords(snk);
        assertNotNull(req.getSynonymsKeywords());
        item.getDefinitionItems().add(req);
        return item;
    }

    public RevisionChangeItem createRow(String fileName) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem("U", "A01B1/02", "0", "test;hello",
                new String[] { "A01B 5/005", "A01B 5/008" });

        DefSectionItemEditRequest req = new DefSectionItemEditRequest();

        req.setChangeType(SCTComponentChangeType.M);
        req.setSectionType(DefinitionSectionType.LIMITING_REFERENCES);
        LimitingReferences def = null;     
        try(InputStream is = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/xml/fragments/" + fileName))  {
            
            log.debug("inputStream is not null {} ", is != null);
            DefinitionItem defItem = docAdapter.parseDefinition("<definition-item><references>"
                +IOUtils.toString(is)+"</references></definition-item>");
            def = defItem.getReferences().getLimitingReferences();
        } catch (Exception je) {
            log.debug("failed to parse xml",je);
            throw new IllegalArgumentException(je);
        }

        req.setLimitingReferences(def);
        assertNotNull(req.getLimitingReferences());

        item.getDefinitionItems().add(req);
        return item;
    }
    
    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        Class adapterClass = Class.forName(DocumentAdapter.class.getCanonicalName());
        docAdapter = (DocumentAdapter) adapterClass.newInstance();

    }


}
