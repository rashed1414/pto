package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.util.regex.Pattern;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;

import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.NamespaceXmlReader;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.GlossaryOfTerms;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DefinitionRequestParseTest {

    public static final JAXBContext TESTCTX = JaxbUtils.initJAXBContext( 
    		 "gov.uspto.pe2e.cpc.standard.definitions.v1_0");
	

	@Test
	public void test() throws JAXBException, Exception {
//		System.setProperty("javax.xml.stream.XMLOutputFactory","com.ctc.wstx.stax.WstxOutputFactory");

        System.setProperty("illegal-access", "debug");
		InputStream is = Thread.currentThread().getContextClassLoader()
				 .getResourceAsStream("data/xml/definition_section_edit_request.xml");
		
		
		XMLStreamReader xsr = XMLInputFactory.newFactory("javax.xml.stream.XMLInputFactory",
                Thread.currentThread().getContextClassLoader()).createXMLStreamReader(is);
		NamespaceXmlReader xr = new NamespaceXmlReader(xsr, JaxbUtils.extractNamespace(DefinitionItem.class));
		
//		DefinitionItem parsed = (DefinitionItem) TESTCTX.createUnmarshaller().unmarshal(xr);
//
//		 log.debug(JsonUtils.toJson(parsed));
//		 assertNotNull(parsed);
//		 assertNotNull(parsed.getGlossaryOfTerms());
		

	}
	
	@Test
	public void testSerialzeDoc() throws JAXBException, JsonGenerationException, JsonMappingException, IOException {
	
		DefinitionItem def = new DefinitionItem();
		def.setGlossaryOfTerms(new GlossaryOfTerms());
//		def.setChangeType(SCTComponentChangeType.U);
//		def.setGlossaryOfTerms(new GlossaryOfTerms());
	    log.debug("XML = {}", JaxbUtils.marshalToString(def));

//	    DefinitionItem parsed = TESTCTX.createUnmarshaller().unmarshal(
//	    		new StringReader(JaxbUtils.marshalToString(def)), DefinitionItem.class);
//
//		log.debug(JsonUtils.toJson(parsed));

	    
	    
	}
	
	@Test
	public void testReferenceMatch() {
		assertTrue(Pattern.matches("^[A-Za-z0-9]+\\-references$", "informative-references"));

	}
	
	@Before
	public void setup() {
		System.setProperty("com.sun.xml.internal.stream.XMLInputFactoryImpl",
				"com.sun.xml.internal.stream.XMLInputFactoryImpl");
		 System.setProperty("javax.xml.parsers.DocumentBuilderFactory","com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");

	}

}
