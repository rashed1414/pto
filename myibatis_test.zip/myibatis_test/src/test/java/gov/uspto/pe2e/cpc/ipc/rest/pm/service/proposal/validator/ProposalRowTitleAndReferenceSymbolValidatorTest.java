package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowTitleAndReferenceSymbolValidatorTest {
	
    private static final Logger log = LoggerFactory.getLogger(ProposalRowTitleAndReferenceSymbolValidatorTest.class);

    @Inject
    private DatasetTestingService datasetTestingService;
    
    
    @Inject
    private  ProposalRowTitleAndReferenceSymbolValidator  proposalRowTitleAndReferenceSymbolValidator;

    @Resource
    private List<ProposalValidator> proposalValidators;
    
    @Inject
    private ProposalValidationService proposalValidationService;
    
    @Inject
    private TitleService titleService;

    @Test
    public void testConfigCorrectlyIncludesGrammarValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(proposalRowTitleAndReferenceSymbolValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }
    
    @Test
    public void testTitleWithNonGoldCopyMatchSymbols() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitle("U", "A01B1/02", "0", "test;hello (section ##SYMBOL##A01B1/0241##/SYMBOL## test); Hello ##SYMBOL##A01B1/0261##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("D", "A01B 1/0241", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("M", "A01B1/0261", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("N", "A01B1/0261", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("N", "A01B 1/0262", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("M", "A01B 1/0263", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowTitleAndReferenceSymbolValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());       
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        log.debug("Validation Message" + rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals("Symbol A01B1/0241, A01C63/00 does not exist.", rows.get(0).getValidationMessages().get(0).getMessageText());
        
    }
    
    @Test
    public void testTitleWithNandQTypeButNonGoldCopyMatchSymbols() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitle("U", "A01B1/02", "0", "test;hello (section ##SYMBOL##A01B1/0241##/SYMBOL## test); Hello ##SYMBOL##A01B1/0261##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("D", "A01B1/0241", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("M", "A01B1/0241", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("D", "A01B1/0261", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("N", "A01B1/0261", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("N", "A01C63/00", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowTitleAndReferenceSymbolValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());       
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        log.debug("Validation Message" + rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals("Symbol A01B1/0241 does not exist.", rows.get(0).getValidationMessages().get(0).getMessageText());      
       
    }
    
    @Test
    public void testTitleWithNTypeAndGoldCopyMatchSymbols() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitle("U", "A01B 1/02", "0", "test;hello (section ##SYMBOL##A01B1/024##/SYMBOL## test); Hello ##SYMBOL##A01B1/026##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("D", "A01B 1/024", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("D", "A01B 1/026", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("F", "A01B1/026", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("N", "A01B 1/024", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("M", "A01B 1/024", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("N", "A01C63/00", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowTitleAndReferenceSymbolValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());
        
    }
    
    @Test
    public void testTitleWithNorQTypeAndNonGoldCopyMatchSymbols() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitle("U", "A01B1/02", "0", "test;hello (section ##SYMBOL##A01B1/0241##/SYMBOL## test); Hello ##SYMBOL##A01B1/0261##/SYMBOL## (section take precedence ##SYMBOL##A01B1/0261##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        
        rows.add(createRevisionChangeItemAndValidateTitle("N", "A01B 1/0261", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("Q", "A01B 1/0241", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowTitleAndReferenceSymbolValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());
        
    }
    
    @Test
    public void testTitleWithGoldCopyMatchSymbols() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitle("U", "A01B1/02", "0", "test;hello (section ##SYMBOL##A01B1/02##/SYMBOL## test); Hello ##SYMBOL##A01B1/026##/SYMBOL## (section take precedence ##SYMBOL##A01B1/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        
        rows.add(createRevisionChangeItemAndValidateTitle("M", "A01B 1/026", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        rows.add(createRevisionChangeItemAndValidateTitle("U", "A01B 1/024", "0", "test;hello (section take precedence ##SYMBOL##A01B63/00##/SYMBOL## test); Hello ##SYMBOL##A01N2001/3002##/SYMBOL## (section take precedence ##SYMBOL##A01C63/00##/SYMBOL## test;{this is a test})", new String[] {"A01B 5/005","A01B 5/008"}));
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowTitleAndReferenceSymbolValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());
        
    }
    
    @Test
    public void testTitleWithEmpty() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitle("M", "A04C 6/005", "0", null, new String[] {"A01B 5/005","A01B 5/008"}));
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowTitleAndReferenceSymbolValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
    }
    
    @Test
    public void testWithEmptyRows() {
        List<RevisionChangeItem> rows = null;        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowTitleAndReferenceSymbolValidator.validate(proposalValidationContext, rows);
        Assert.assertNull(rows); 
    }
    
    public RevisionChangeItem createRevisionChangeItemAndValidateTitle(String entryType, String symbolName, String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel, titleGrammar, reclassTargets); 
        try {
            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
            item.setTitle(tree);
        } catch (GrammarParseException gpe) {
            item.getValidationMessages().addAll(gpe.getValidationMessages());
        }
        return item;
    }
    
    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.HIGH, proposalRowTitleAndReferenceSymbolValidator.getCost());
    }
    
    @Test 
    public void testGetValidatorType() {
        Assert.assertEquals(ValidationMessageType.RECORD, proposalRowTitleAndReferenceSymbolValidator.getValidationType());        
    }
    
    @Before
    public void setUp() throws Exception {
        datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }

}
