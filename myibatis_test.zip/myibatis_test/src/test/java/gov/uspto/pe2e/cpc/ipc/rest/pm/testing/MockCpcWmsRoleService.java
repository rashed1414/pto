/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.pm.testing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.CpcWmsRoleService;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.AssignmentGroup;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.OfficeContactType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;

/**
 * @author myoung3
 *
 */
@Service
public class MockCpcWmsRoleService implements CpcWmsRoleService {

	/**
	 * This is a really cute mock impl that just sets 3 assignmentGroups for ALL
	 * emails.  It doesn't matter what email you pass in.  Everyon is assumed to be
	 * US and gets the 3 roles (see below).
	 * 
	 * Note: if you need to override this mock you could do it with a switch on the 
	 * email or something.  I don't care so I will carefully construct my dbunit task table
	 * to match the records I am looking for.
	 */
	@Override
	public List<AssignmentGroup> findAssignedRolesByEmail(String email) {
		List<AssignmentGroup> assignmentGroups = new ArrayList<>();
		for (OfficeContactType role: Arrays.asList(OfficeContactType.COORDINATOR,
				OfficeContactType.EDITORIAL_BOARD, OfficeContactType.PUB_WRITER)) {
			AssignmentGroup group = new AssignmentGroup();
			group.setRole(role);
			group.getOffices().add(StandardIpOfficeCode.US);
			assignmentGroups.add(group);
		}
			
		return assignmentGroups;
	}

}
