package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.docx4j.openpackaging.exceptions.Docx4JException;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.wml.Tc;
import org.docx4j.wml.Tr;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.xhtmlrenderer.pdf.ITextRenderer;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalVersion;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.IpcConcordanceRevision;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ReclassTransfer;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.VersionSymbol;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalVersionRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.IpcConcordanceRevisionRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.DocxUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.collections.OrderedCollectionUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcConcordanceMapping;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcSymbol;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ChangeTypeDescription;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefinitionSectionType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalRevisionDetail;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RclStatistic;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassificationTypeCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassificationTypeTargetClassifiationCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SchemeChangeTableStatistic;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SchemeChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteParagraph;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePart;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartRawText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.SectionBody;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.SectionBodyContentNode;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.SynonymsKeywords;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletResponse;
import net.jcip.annotations.NotThreadSafe;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalRevisionControllerTest {
    private static final Logger log = LoggerFactory.getLogger(ProposalRevisionControllerTest.class);
    @Inject
    private ProposalRevisionController proposalRevisionController;
    @Inject
    private ProposalController proposalController;
    @Inject
    private DatasetTestingService datasetTestingService;
    @Inject
	private ChangeProposalVersionRepository changeProposalVersionRepository;
    @Inject
    private IpcConcordanceRevisionRepository ipcConcordanceRevisionRepository;
    
    
    @Test
    public void testGetByRevisionId() {
        String dbUid = "080f8146bd4e4e349350c1b184db1b56";
    	ResponseEntity<ProposalRevisionDetail> respEntity = proposalRevisionController.getRevisionDetailByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(dbUid), false);
    	Assert.assertNotNull(respEntity);
    	Assert.assertNotNull(respEntity.getBody());    	
    	Assert.assertEquals(9,respEntity.getBody().getRevisionChangeItems().size());
    	//Assert.assertEquals("<administrative transfer to A01B63/114 > , A01F2009/00",respEntity.getBody().getRevisionChangeItems().get(1).getReclassTransferExpression().getExpression());
    	Assert.assertEquals("A01F2009/00",respEntity.getBody().getRevisionChangeItems().get(1).getReclassTransfers().get(0).getTargetSymbolName());
    	
		   	
    	RevisionChangeItem revisionChangeItem = respEntity.getBody().getRevisionChangeItems().get(0);
    	
    	Assert.assertNotNull(revisionChangeItem);
    	NoteParagraph note = revisionChangeItem.getNoteItems().get(0).getNoteItem(); 
    	Assert.assertNotNull(note);
    	NoteType noteType = revisionChangeItem.getNoteItems().get(0).getNoteCategory();
    	Assert.assertNotNull(noteType);
    	// todo here next 3lines revisit
 	//Assert.assertEquals(NoteType.NOTE, noteType);    	
//    	Assert.assertEquals(2,revisionChangeItem.getNoteItems().size());
//		Assert.assertEquals("This subclass ", ((gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteRawText)
//		        ((gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteParagraph) note).getChildren().get(0)).getContent());
    	
//    	NoteParagraph warning = revisionChangeItem.getNoteItems().get(1).getNoteItem();
//    	Assert.assertNotNull(warning);
//    	NoteType warningType = revisionChangeItem.getNoteItems().get(1).getNoteCategory();
//    	Assert.assertNotNull(warningType);
//    	Assert.assertEquals(NoteType.WARNING, warningType);
//    	Assert.assertEquals("This is a warning text",
//    	        ((gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteRawText)
//    	                ((gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteParagraph) note).getChildren().get(0)).getContent());
//    	
//    	
//		
//		NoteParagraph oldWarning = revisionChangeItem.getNoteItems().get(0).getNoteItem();
//    	Assert.assertNotNull(oldWarning);
//    	String oldWarningType = oldWarning.getNoteOrWarningType();
//    	Assert.assertNotNull(oldWarningType);
//    	//Assert.assertEquals("warning", oldWarningType);
////    	Assert.assertEquals("This is a old warning text",
////				((gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteRawText) (((gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteParagraph) (oldWarning
////						.getChildren().get(0))).getChildren().get(0))).getContent());
////    	
//    	ReclassTransfer rt = new ReclassTransfer();
    	
    }
    
    
    @Test
    @Transactional
    public void testGetByRevisionIdWithCrossReferenceDetails() {
        String dbUid = "080f8146bd4e4e349350c1b184db1b56";
        ResponseEntity<ProposalRevisionDetail> respEntity = proposalRevisionController.getRevisionDetailByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(dbUid), false);
        Assert.assertNotNull(respEntity);
        Assert.assertNotNull(respEntity.getBody());     
        Assert.assertEquals(9,respEntity.getBody().getRevisionChangeItems().size());            
        RevisionChangeItem revisionChangeItem = respEntity.getBody().getRevisionChangeItems().get(0);        
        Assert.assertNotNull(revisionChangeItem);
        Assert.assertEquals(2, revisionChangeItem.getCrossReferenceModifications().size());        
        RevisionChangeItem revision = respEntity.getBody().getRevisionChangeItems().get(1);        
        Assert.assertNotNull(revision);
        Assert.assertEquals(1, revision.getCrossReferenceModifications().size());
    }
    
    @Test
    public void testGetByRevisionIdIncludingSystemCreated() {
        String dbUid = "080f8146bd4e4e349350c1b184db1b56";
    	ResponseEntity<ProposalRevisionDetail> respEntity = proposalRevisionController.getRevisionDetailByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(dbUid), true);
    	Assert.assertNotNull(respEntity);
    	Assert.assertNotNull(respEntity.getBody());    	
    	Assert.assertEquals(10,respEntity.getBody().getRevisionChangeItems().size());
    	//Assert.assertEquals("<administrative transfer to A01B63/114 > , A01F2009/00",respEntity.getBody().getRevisionChangeItems().get(1).getReclassTransferExpression().getExpression());
    	Assert.assertEquals("A01F2009/00",respEntity.getBody().getRevisionChangeItems().get(1).getReclassTransfers().get(0).getTargetSymbolName());
    }
    
    @Test
    public void testGetConcordanceDetailsByRevisionId() {
        String dbUid = "080f8146bd4e4e349350c1b184db1b56";
    	ResponseEntity<ProposalRevisionDetail> respEntity = proposalRevisionController.getRevisionDetailByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(dbUid), false);
    	Assert.assertNotNull(respEntity);
    	Assert.assertNotNull(respEntity.getBody());    	
    	Assert.assertEquals(9,respEntity.getBody().getRevisionChangeItems().size());
    	Assert.assertTrue(respEntity.getBody().getRevisionChangeItems().get(0).getIpcSymbol().isCpcOnly());
    	Assert.assertEquals("A01B3/462",respEntity.getBody().getRevisionChangeItems().get(0).getIpcSymbol().getSymbolName());
    	log.debug(respEntity.getBody().getRevisionChangeItems().get(2).getIpcSymbol().getGeneratedIpcSymbol().getIpcSymbolName());
    	log.debug(respEntity.getBody().getRevisionChangeItems().get(2).getIpcSymbol().getOverrideIpcSymbol().getIpcSymbolName());
    	Assert.assertEquals("A01B41/02",respEntity.getBody().getRevisionChangeItems().get(2).getIpcSymbol().getGeneratedIpcSymbol().getIpcSymbolName());
    	Assert.assertEquals("A01B41/04",respEntity.getBody().getRevisionChangeItems().get(2).getIpcSymbol().getOverrideIpcSymbol().getIpcSymbolName());
    }

    @Test
    public void testGetRevisionWithSymbolOnlyTitle() {
        String uuidText = "1b3b98c8187a486595aa32f256740c13";
        ResponseEntity<ProposalRevisionDetail> respEntity = proposalRevisionController.getRevisionDetailByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(uuidText), false);
        assertEquals(4, respEntity.getBody().getRevisionChangeItems().size());
        log.debug("SCT count {}", respEntity.getBody().getRevisionChangeItems().size());
        int i=0;
        for (RevisionChangeItem rev: respEntity.getBody().getRevisionChangeItems()) {
        	log.debug("{} {}", i++,rev.getTitleGrammar());
        }
        Assert.assertTrue(StringUtils.isNotBlank(respEntity.getBody().getRevisionChangeItems().get(1).getTitleGrammar()) );
        Assert.assertTrue(StringUtils.isNotBlank(respEntity.getBody().getRevisionChangeItems().get(2).getTitleGrammar()) );
    }
    
    @Test
    public void testGetRevisionWithSymbolBadGrammar() {
        String uuidText = "1b3b98c8187a486595aa32f256740c13";
        ResponseEntity<ProposalRevisionDetail> respEntity = proposalRevisionController.getRevisionDetailByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(uuidText), false);
        log.debug("SCT count {}", respEntity.getBody().getRevisionChangeItems().size());
        Assert.assertTrue(StringUtils.  isNotBlank(respEntity.getBody().getRevisionChangeItems().get(1).getTitleGrammar()) );
    }
  
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1@uspto.gov", "myoung3@uspto.gov", Arrays
                .asList(new BasicTestingGrantedAuthority("test@uspto.gov")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }
    
    
    /**
	 * Test method for
	 * {@link gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalRevisionController#exportRevisionDetailByChangeProposalVersionId()}
	 * .
	 * 
	 * @throws Exception
	 */
	@Test
	@Transactional
	public void testExportRevisionDetailByChangeProposalVersionId() throws Exception {
		
		String guid = "080f8146bd4e4e349350c1b184db1b56";
		HttpServletResponse resp = WebMocker.mockHttpResponse();

		proposalRevisionController.exportRevisionDetailByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
		File f = new File("target/SCT.docx");
		FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
		Assert.assertTrue(f != null && f.exists() && f.length() >10);
	}
	
    /**
	 * Test method for
	 * {@link gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalRevisionController#exportProposalStatisticsByChangeProposalVersionId()}
	 * .
	 * 
	 * @throws Exception
	 */
	@Test
	@Transactional
	public void testExportProposalStatisticsByChangeProposalVersionId() throws Exception {
		
		String guid = "080f8146bd4e4e349350c1b184db1b56";
		HttpServletResponse resp = WebMocker.mockHttpResponse();

		proposalRevisionController.exportProposalStatisticsByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
		File f = new File("target/Statistics.docx");
		FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
		Assert.assertTrue(f != null && f.exists() && f.length() >10);
	}
	
    /**
	 * Test method for
	 * {@link gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalRevisionController#getProposalRevisionStatistics()}
	 * 
	 * @throws Exception
	 */
	@Transactional 
    @Test
    public void testGetProposalSCTStatisticsByRevisionId() throws Exception {
    	String revisionGuid = "0f234aa1ca8c4d01b91aafe6fb9a0c40";
    	ResponseEntity<List<SchemeChangeTableStatistic>> responseEntity = 
    			proposalRevisionController.getProposalRevisionStatistics(GUIDUtils.fromDatabaseFormat(revisionGuid));
        
    	// Begin asserting for valid HTTP response 
    	assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    	
    	// Get the list of SCT statistics
    	List<SchemeChangeTableStatistic> sctStatistics = responseEntity.getBody();
    	
        // Check for overall statistics count
        assertNotNull(sctStatistics);
        assertTrue(sctStatistics.size() > 0);
        
        // Check for individual change types, counts (symbols, notes, warnings and definitions)
        // for entries such as All, Deleted entries (D) and for new entries (N) etc.
        assertTrue(sctStatistics.get(0).getChangeType().equals("ALL"));
        assertEquals(15, sctStatistics.get(0).getSymbolsCount().intValue());
        assertEquals(9, sctStatistics.get(0).getDefinitionsCount().intValue());

        
		assertEquals(SchemeChangeType.N.name(),sctStatistics.get(2).getChangeType());
		assertEquals(ChangeTypeDescription.NEW_SYMBOL_ENTRIES_WHERE_RECLASSIFICATION_INTO_ENTRIES_IS_INVOLVED_NEW_DEFINITION_ENTRIES_FOR_THE_SYMBOL.name(), sctStatistics.get(2).getChangeTypeDescription());
		assertEquals(4, sctStatistics.get(2).getSymbolsCount().intValue());

        assertEquals(SchemeChangeType.D.name(),sctStatistics.get(1).getChangeType());
        assertEquals(ChangeTypeDescription.DELETED_ENTRIES.name(), sctStatistics.get(1).getChangeTypeDescription());
        assertEquals(2, sctStatistics.get(1).getSymbolsCount().intValue());
        assertEquals(1, sctStatistics.get(1).getDefinitionsCount().intValue());
        assertNull(sctStatistics.get(1).getNotesCount());
        assertNull(sctStatistics.get(1).getWarningsCount());


        assertEquals(SchemeChangeType.T.name(),sctStatistics.get(6).getChangeType());
    }
	
	 /**
     * Test method for
     * {@link gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalRevisionController#exportProposalStatisticsByChangeProposalVersionId()}
     * .
     * 
     * @throws Exception
     */
    @Test
    @Transactional
    public void testExportProposalValidationReportByChangeProposalVersionId() throws Exception {
        
        String guid = "080f8146bd4e4e349350c1b184db1b56";
        HttpServletResponse resp = WebMocker.mockHttpResponse();

        proposalRevisionController.exportValidationReportByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
        File f = new File("target/Validation_Report.docx");
        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
        Assert.assertTrue(f != null && f.exists() && f.length() >10);
    }
	
	/**
     * Test method for
     * {@link gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalRevisionController#exportRevisionDetailByChangeProposalVersionId()}
     * .
     * 
     * @throws Exception
     */
    @Test
    @Transactional
    public void testExportSCTinPDF() throws Exception {        
      
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ITextRenderer iTextRenderer = new ITextRenderer();        
        String html = IOUtils.toString(Thread.currentThread().getContextClassLoader().getResourceAsStream("data/html/sct_highlighting.html"));
        
        iTextRenderer.setDocumentFromString(html);
        iTextRenderer.layout();
        iTextRenderer.createPDF(baos);
        baos.flush();
        byte[] out  = baos.toByteArray();
        
        File f = new File("target/SCT.pdf");
        FileUtils.writeByteArrayToFile(f, out);
        
        Assert.assertTrue(f != null && f.exists() && f.length() >10);
    }
	
	
	/**
	 * Test method for
	 * {@link gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalRevisionController#exportCpcToIpcConcordanceListByChangeProposalVersionId()}
	 * .
	 * 
	 * @throws Exception
	 */
	@Test
	@Transactional
	public void testExportCpcToIpcConcordanceListByChangeProposalVersionId() throws Exception {
		
		String guid = "080f8146bd4e4e349350c1b184db1b56";
		HttpServletResponse resp = WebMocker.mockHttpResponse();

		proposalRevisionController.exportCpcToIpcConcordanceListByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
		File f = new File("target/CICL.docx");
		FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
		Assert.assertTrue(f != null && f.exists() && f.length() >10);
	}
	
	/**
	 * Test method for
	 * {@link gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalRevisionController#exportRevisionConcordanceListByChangeProposalVersionId()}
	 * .
	 * 
	 * @throws Exception
	 */
	@Test
	@Transactional
	public void testExportRevisionLConcordanceListByChangeProposalVersionId() throws Exception {
		
		String guid = "080f8146bd4e4e349350c1b184db1b56";
		HttpServletResponse resp = WebMocker.mockHttpResponse();

		proposalRevisionController.exportRevisionConcordanceListByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
		File f = new File("target/RCL.docx");
		FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
		Assert.assertTrue(f != null && f.exists() && f.length() >10);
	}
	
	@Test
	@Transactional
	public void testExportRevisionLConcordanceList_WithTypeC() throws Exception {
		
		String guid = "1b3b98c8187a486595aa32f256740c13";
		HttpServletResponse resp = WebMocker.mockHttpResponse();

		proposalRevisionController.exportRevisionConcordanceListByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
		File f = new File("target/RCL_Test.docx");
		FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
		Assert.assertTrue(f != null && f.exists() && f.length() >10);
	}
	
	/**
     * Test method for
     * {@link gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalRevisionController#exportCrossReferenceListByChangeProposalVersionId()}
     * .
     * 
     * @throws Exception
     */
    @Test
    @Transactional
    public void testExportCRLByChangeProposalVersionId() throws Exception {
        
        String guid = "080f8146bd4e4e349350c1b184db1b56";
        HttpServletResponse resp = WebMocker.mockHttpResponse();

        proposalRevisionController.exportCrossReferenceListByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
        File f = new File("target/CRL.docx");
        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
        Assert.assertTrue(f != null && f.exists() && f.length() >10);
    }
    
    /**
     * Test method for
     * {@link gov.uspto.pe2e.cpc.ipc.rest.pm.controller.ProposalRevisionController#exportCrossReferenceListByChangeProposalVersionId()}
     * .
     * 
     * @throws Exception
     */
    @Test
    @Transactional
    public void testExportCoverSheetByChangeProposalVersionId() throws Exception {
        
        String guid = "0f234aa1ca8c4d01b91aafe6fb9a0c40";
        HttpServletResponse resp = WebMocker.mockHttpResponse();

        proposalRevisionController.exportCoverSheetDetailsByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
        File f = new File("target/CoverSheet.docx");
        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
        Assert.assertTrue(f != null && f.exists() && f.length() >10);
    }
	

    @Test
    @Transactional
    public void testExportCICLWithVlidConcordanceMappings() throws Exception {
        
        List<IpcConcordanceRevision> dbObjs = (List<IpcConcordanceRevision>)ipcConcordanceRevisionRepository.findAll();
        Assert.assertTrue(dbObjs.size() > 0);
        String guid = "080f8146bd4e4e349350c1b184db1b56";
        HttpServletResponse resp = WebMocker.mockHttpResponse();

        proposalRevisionController.exportCpcToIpcConcordanceListByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
        File f = new File("target/CICL2.docx");
        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
        Assert.assertTrue(f != null && f.exists() && f.length() >10);
        
        int rowIdx = 0;
        List<RevisionChangeItemRequest> items = new ArrayList<>();
        try {   
            WordprocessingMLPackage wordMLPackage = 
                WordprocessingMLPackage.load(f);
            MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
            List<Tr> tables = DocxUtils.search(documentPart, Tr.class);
            int i = 0;
            for (Tr docPart: tables) {
            	List<String> cells = new ArrayList();
            	List<Tc> row = DocxUtils.search(docPart, Tc.class);
                for (Tc cell :row) {
                    cells.add(DocxUtils.coalesceText(cell));
                }
                log.info("row[{}] = {}", i++, cells);
            }
            for (Tr docPart: tables) {
                log.info("row = {}", JaxbUtils.marshalToString(docPart));
                List<Tc> row = DocxUtils.search(docPart, Tc.class);
               
                if (rowIdx == 7) {
                    Assert.assertEquals("CPCONLY", DocxUtils.coalesceText(row.get(1)));
                }
                else if (rowIdx == 8) {
                    Assert.assertEquals("A01B41/04", DocxUtils.coalesceText(row.get(1)));
                }
                else if (rowIdx == 9) {
                    Assert.assertEquals("A01B41/04", DocxUtils.coalesceText(row.get(1)));
                }
                rowIdx ++ ;
            }
            
        } catch (Docx4JException  ex) {
            log.debug("docx4j exception",ex);
            throw new IllegalArgumentException("Something is wrong with the docx file.  It  could not be properly read.", ex);
            
        }
        finally {
            
        }
    }
    @Test
    @Transactional
    public void testExportProposalDefinition() throws Exception {
        
        List<IpcConcordanceRevision> dbObjs = (List<IpcConcordanceRevision>)ipcConcordanceRevisionRepository.findAll();
        Assert.assertTrue(dbObjs.size() > 0);
        String guid = "080f8146bd4e4e349350c1b184db1b56";
        HttpServletResponse resp = WebMocker.mockHttpResponse();

        proposalRevisionController.exportRevisionDefinitionsByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), SCTComponentChangeType.M, resp);
        File f = new File("target/proposal_definitions.docx");
        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
        Assert.assertTrue(f != null && f.exists() && f.length() >10);
        
        int rowIdx = 0;
        List<RevisionChangeItemRequest> items = new ArrayList<>();
        try {   
            WordprocessingMLPackage wordMLPackage = 
                WordprocessingMLPackage.load(f);
            MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
            List<Tr> tables = DocxUtils.search(documentPart, Tr.class);
//            for (Tr docPart: tables) {
//                System.out.print("\n");
//                List<Tc> row = DocxUtils.search(docPart, Tc.class);
//                for (Tc cell :row) {
//                    System.out.print(DocxUtils.coalesceText(cell)+",");
//                }
//                if (rowIdx == 1) {
//                    Assert.assertEquals("A47C", DocxUtils.coalesceText(row.get(1)));
//                }
////                else if (rowIdx == 2) {
////                    Assert.assertEquals("A01B41/04", DocxUtils.coalesceText(row.get(1)));
////                }
////                else if (rowIdx == 3) {
////                    Assert.assertEquals("A01B41/04", DocxUtils.coalesceText(row.get(1)));
////                }
//                rowIdx ++ ;
//            }
            
        } catch (Docx4JException  ex) {
            log.debug("docx4j exception",ex);
            throw new IllegalArgumentException("Something is wrong with the docx file.  It  could not be properly read.", ex);
            
        }
        finally {
            
        }
    }

    
    @Test
    @Transactional
    public void testExportProposalDefinitionTypeN() throws Exception {
        
        List<IpcConcordanceRevision> dbObjs = (List<IpcConcordanceRevision>)ipcConcordanceRevisionRepository.findAll();
        Assert.assertTrue(dbObjs.size() > 0);
        String guid = "080f8146bd4e4e349350c1b184db1b56";
        HttpServletResponse resp = WebMocker.mockHttpResponse();

        proposalRevisionController.exportRevisionDefinitionsByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), SCTComponentChangeType.N, resp);
        File f = new File("target/proposal_definitions_N.docx");
        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
        Assert.assertTrue(f != null && f.exists() && f.length() >10);
        
        int rowIdx = 0;
        List<RevisionChangeItemRequest> items = new ArrayList<>();
        try {   
            WordprocessingMLPackage wordMLPackage = 
                WordprocessingMLPackage.load(f);
            MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
            List<Tr> tables = DocxUtils.search(documentPart, Tr.class);
//            for (Tr docPart: tables) {
//                System.out.print("\n");
//                List<Tc> row = DocxUtils.search(docPart, Tc.class);
//                for (Tc cell :row) {
//                    System.out.print(DocxUtils.coalesceText(cell)+",");
//                }
//                if (rowIdx == 1) {
//                    Assert.assertEquals("A47C", DocxUtils.coalesceText(row.get(1)));
//                }
////                else if (rowIdx == 2) {
////                    Assert.assertEquals("A01B41/04", DocxUtils.coalesceText(row.get(1)));
////                }
////                else if (rowIdx == 3) {
////                    Assert.assertEquals("A01B41/04", DocxUtils.coalesceText(row.get(1)));
////                }
//                rowIdx ++ ;
//            }
            
        } catch (Docx4JException  ex) {
            log.debug("docx4j exception",ex);
            throw new IllegalArgumentException("Something is wrong with the docx file.  It  could not be properly read.", ex);
            
        }
        finally {
            
        }
    }
    
    @Test
    @Transactional
    public void testExportDefinitionPartsByChangeProposalVersionId() throws Exception {        
        String guid = "0f234aa1ca8c4d01b91aafe6fb9a0c40";
        HttpServletResponse resp = WebMocker.mockHttpResponse();

        proposalRevisionController.exportDefinitionPartsByChangeProposalVersionId(GUIDUtils.fromDatabaseFormat(guid), resp);
        File f = new File("target/Definitions.zip");
        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
        Assert.assertTrue(f != null && f.exists() && f.length() >10);
        ZipFile zipFile = null;
        List<String> zipEntries = new ArrayList<>();
        try {
            zipFile = new ZipFile(f);
            List<String> fileContent = zipFile.stream()
            		.map(ZipEntry::getName).collect(Collectors.toList());
            log.debug("ZipFile contents - " + fileContent);
            zipEntries.addAll(fileContent);
            zipFile.close();
        }
        catch (IOException ioException) {
            log.debug("Error opening zip file" + ioException);
            fail();
        }
        assertTrue(zipEntries.toString().contains("(GM).docx"));

//        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("")) {
//        RevisionChangeItem sctItem = new RevisionChangeItem();
//        VersionSymbol vs = new VersionSymbol();
//        vs.setDefinitionXml(IOUtils.toString(is));
//        proposalRevisionService.mapDefinition(sctItem, vs);
//        assertEquals(3, sctItem.getDefinitionItems().size());
//        }
        //fail();
    }
   

    // commented out for ASYNC
    @Test
    @Transactional
    public void testExportCICLWithVlidConcordanceMappingsAndActions() throws Exception {

        
        List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
        sctItems.add(createSctRequestItem("D", "A01N", "subclass", "test Title 1", "Invalid reclass expression", true, null,null));
        sctItems.add(createSctRequestItem("M", "A01N01/101", "1", "test Title 1", "Invalid reclass expression", false, "A01B63/12", "A01B63/14" ));
        sctItems.add(createSctRequestItem("M", "A01N01/101", "1", "test Title 1", "Invalid reclass expression", false, "A01B63/12", null ));
        sctItems.add(createSctRequestItem("M", "A01N01/101", "1", "test Title 1", "Invalid reclass expression", false, null, null ));
        sctItems.add(createSctRequestItem("D", "A01N01/101", "1", "test Title 1", "Invalid reclass expression", false, null, null ));
        sctItems.add(createSctRequestItem("N", "A01N01/101", "1", "test Title 1", "Invalid reclass expression", false, null, null ));
    
        ResponseEntity<ProposalRevisionDetail> uploadResp =  proposalController.createNewRevision(UUID.fromString("c960d30a-52a8-47fc-8c51-b64dfcc0ea85"), 
                "53", new Date(), "sample comment", sctItems);
        log.debug("{}", JsonUtils.toJson(uploadResp));
        String uuidStr = uploadResp.getHeaders().getFirst(RestUtils.RESOURCE_ID_HEADER);

        
        HttpServletResponse resp = WebMocker.mockHttpResponse();

        proposalRevisionController.exportCpcToIpcConcordanceListByChangeProposalVersionId(UUID.fromString(uuidStr), resp);
        File f = new File("target/CICL3.docx");
        FileUtils.writeByteArrayToFile(f, ((MockHttpServletResponse)resp).getContentAsByteArray());
        Assert.assertTrue(f != null && f.exists() && f.length() >10);
        
        int rowIdx = 0;
        List<RevisionChangeItemRequest> items = new ArrayList<>();
        try {   
            WordprocessingMLPackage wordMLPackage = 
                WordprocessingMLPackage.load(f);
            MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
            List<Tr> tables = DocxUtils.search(documentPart, Tr.class);
            Assert.assertEquals(4, tables.size());
            for (Tr docPart: tables) {
                System.out.print("\n");
                List<Tc> row = DocxUtils.search(docPart, Tc.class);
                for (Tc cell :row) {
                    System.out.print(DocxUtils.coalesceText(cell)+",");
                }
                if (rowIdx == 1) {
                    Assert.assertEquals("A01B63/14", DocxUtils.coalesceText(row.get(1)));
                    Assert.assertEquals("UPDATE", DocxUtils.coalesceText(row.get(2)));
                }               
                else if (rowIdx == 2) {
                    Assert.assertEquals("", DocxUtils.coalesceText(row.get(1)));
                    Assert.assertEquals("DELETE", DocxUtils.coalesceText(row.get(2)));
                }
                else if (rowIdx == 3) {
                    Assert.assertEquals("", DocxUtils.coalesceText(row.get(1)));
                    Assert.assertEquals("NEW", DocxUtils.coalesceText(row.get(2)));
                }
                rowIdx ++ ;
            }
            
        } catch (Docx4JException  ex) {
            log.debug("docx4j exception",ex);
            throw new IllegalArgumentException("Something is wrong with the docx file.  It  could not be properly read.", ex);
            
        }
        finally {
            
        }
    }

    @Test
    @Transactional
    public void testSaveWithDefinitions() throws Exception {

        
        List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
        sctItems.add(createSctRequestItem("D", "A01N", "subclass", "test Title 1", "Invalid reclass expression", true, null,null));
        sctItems.add(createSctRequestItem("M", "A01N01/101", "1", "test Title 1", "Invalid reclass expression", false, "A01B63/12", "A01B63/14" ));
        sctItems.add(createSctRequestItem("M", "A01N01/101", "1", "test Title 1", "Invalid reclass expression", false, "A01B63/12", null ));
        sctItems.add(createSctRequestItem("M", "A01N01/101", "1", "test Title 1", "Invalid reclass expression", false, null, null ));
        sctItems.add(createSctRequestItem("D", "A01N01/101", "1", "test Title 1", "Invalid reclass expression", false, null, null ));
        sctItems.add(createSctRequestItem("N", "A01N01/101", "1", "test Title 1", "Invalid reclass expression", false, null, null ));
        sctItems.add(createSctRequestItem("N", "A01N01/102", "G.Heading", "test Title 1", "Invalid reclass expression", false, null, null ));
        
        RevisionChangeItemRequest withDefinition = createSctRequestItem("N", "A01N01/121", "1", "test Title 1", null, false, null, null );
        SynonymsKeywords synonyms = new SynonymsKeywords();
        SectionBody special = new SectionBody();
        special.setChangeType("M");
        special.getChildren().add(new SectionBodyContentNode());
       
        synonyms.setSpecialMeanings(special);
        DefSectionItemEditRequest synRequest = new DefSectionItemEditRequest();
        synRequest.setSectionType(DefinitionSectionType.SYNONYMS_AND_KEYWORDS);
        synRequest.setSynonymsKeywords(synonyms);
        withDefinition.getDefinitionItems().add(synRequest);
        
        sctItems.add(withDefinition);
        int defFound = 0;
        try {
        	ResponseEntity<ProposalRevisionDetail> uploadResp =  proposalController.createNewRevision(UUID.fromString("c960d30a-52a8-47fc-8c51-b64dfcc0ea85"), 
                "53", new Date(), "sample comment", sctItems);
        	log.debug("{}", JsonUtils.toJson(uploadResp));
        	String uuidStr = uploadResp.getHeaders().getFirst(RestUtils.RESOURCE_ID_HEADER);
        	assertNotNull(uuidStr);
        	UUID generatedId = UUID.fromString(uuidStr);
        	ResponseEntity<ProposalRevisionDetail> getResp = proposalRevisionController.getRevisionDetailByChangeProposalVersionId(generatedId, false);
        	List<RevisionChangeItem> revisionChangeItems = getResp.getBody().getRevisionChangeItems();
        	for (RevisionChangeItem item: revisionChangeItems) {
        		if (StringUtils.equals(item.getSymbolName(), "A01N01/121")) {
        			
        			assertEquals("M", item.getDefinitionItems().get(0)
        					.getSynonymsKeywords().getSpecialMeanings().getChangeType());
        			defFound++;
        		}
        		
        		if(StringUtils.equals(item.getSymbolName(), "A01N01/102")) {
        			assertEquals("G.Heading", item.getDotLevel());
        		}
        		
        		
        	}
        	assertEquals(1, defFound);
        	
        } catch (Exception e) {
        	log.debug("Test Failed because", e);
        	fail();
        }

            
    }

    public static  RevisionChangeItemRequest createSctRequestItem(String entryType, String symbolName, String dotLevel, String simpleTitleText, String reclassExpression, 
            Boolean cpcOnly, String generatedIpcSymbolName, String overrideIpcSymbolName) {
        RevisionChangeItemRequest req = createSctRequestItem(entryType, symbolName, dotLevel, simpleTitleText, reclassExpression);
        if ((cpcOnly != null && cpcOnly.equals(Boolean.TRUE) 
                || ( StringUtils.isNotBlank(generatedIpcSymbolName) 
                || ( StringUtils.isNoneBlank(overrideIpcSymbolName))) 
                )) {
            IpcConcordanceMapping mapping = new IpcConcordanceMapping();
            mapping.setCpcOnly(false);
            if (cpcOnly != null) {
                mapping.setCpcOnly(cpcOnly);
            }
            if (StringUtils.isNotBlank(generatedIpcSymbolName)) {
                IpcSymbol generated = new IpcSymbol();
                generated.setIpcSymbolName(generatedIpcSymbolName);
                mapping.setGeneratedIpcSymbol(generated);
            }
            
            if (StringUtils.isNotBlank(overrideIpcSymbolName)) {
                IpcSymbol overrideSymbol = new IpcSymbol();
                overrideSymbol.setIpcSymbolName(overrideIpcSymbolName);
                mapping.setOverrideIpcSymbol(overrideSymbol);
            }
            req.setIpcSymbol(mapping);
        }
        return req;
        
    }
    
    public static  RevisionChangeItemRequest createSctRequestItem(String entryType, String symbolName, String dotLevel, String simpleTitleText, String reclassExpression) {
        RevisionChangeItemRequest req = new RevisionChangeItemRequest(); 
        req.setEntryType(entryType);
        req.setSymbolName(symbolName);
        req.setDotLevel(dotLevel);
        if (StringUtils.isNotBlank(simpleTitleText)) {
            TitlePartTree tree = new TitlePartTree();
            TitlePartText tpText = new TitlePartText();
            TitlePartRawText raw = new TitlePartRawText();
            tpText.getChildren().add((TitlePart)raw);
            
            tree.getChildren().add(tpText);
            req.setTitle(tree);
        }
        req.setReclassTransferExpression(reclassExpression);
        return req;
        
    }

    
	@Test
	@Transactional
	public void testUpdateProposalRevisionMetaData() {
		String dbUid = "080f8146bd4e4e349350c1b184db1b56";
		
		Date cefDate = null;
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        String nowAsString = df.format(new Date());
        try {
			  cefDate = (Date)df.parse(nowAsString);
		} catch (ParseException e1) {
			throw new RuntimeException("Unable to parse given cef date "+nowAsString);
		}
		
		ResponseEntity<UUID> respEntity = proposalRevisionController.updateProposalRevisionMetaData(
				GUIDUtils.fromDatabaseFormat(dbUid), "5211", cefDate, "Testing Update Meta Data");
	    Assert.assertNotNull(respEntity);
    	Assert.assertNotNull(respEntity.getBody());
    	ChangeProposalVersion revisionEntity = changeProposalVersionRepository
				.findByExternalId(GUIDUtils.toDatabaseFormat(respEntity.getBody()));
    	
    	Assert.assertEquals("5211",revisionEntity.getCefAnnex());
    	Assert.assertNotNull(revisionEntity.getCefPostDate());
	}
	
	@Test
	@Transactional
	public void testUpdateProposalRevisionMetaDataWithNoProposalId() {
			
		Date cefDate = null;
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        String nowAsString = df.format(new Date());
        try {
			  cefDate = (Date)df.parse(nowAsString);
		} catch (ParseException e1) {
			throw new RuntimeException("Unable to parse given cef date "+nowAsString);
		}
		
		ResponseEntity<UUID> respEntity = proposalRevisionController.updateProposalRevisionMetaData(
				null, "5211", cefDate, "Testing Update Meta Data");
	    Assert.assertEquals(HttpStatus.BAD_REQUEST, respEntity.getStatusCode());
	}
	
	@Test
	@Transactional
	public void testUpdateProposalRevisionMetaDataWithEmptyComment() {
		String dbUid = "080f8146bd4e4e349350c1b184db1b56";
		
		Date cefDate = null;
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        String nowAsString = df.format(new Date());
        try {
			  cefDate = (Date)df.parse(nowAsString);
		} catch (ParseException e1) {
			throw new RuntimeException("Unable to parse given cef date "+nowAsString);
		}
		
		ResponseEntity<UUID> respEntity = proposalRevisionController.updateProposalRevisionMetaData(
				GUIDUtils.fromDatabaseFormat(dbUid), "5211", cefDate, "");
	    Assert.assertNotNull(respEntity);
    	Assert.assertNotNull(respEntity.getBody());
    	ChangeProposalVersion revisionEntity = changeProposalVersionRepository
				.findByExternalId(GUIDUtils.toDatabaseFormat(respEntity.getBody()));
    	
    	Assert.assertEquals("5211",revisionEntity.getCefAnnex());
    	Assert.assertNotNull(revisionEntity.getCefPostDate());
	}
	
	@Test
	@Transactional
	public void testUpdateProposalRevisionMetaDataNull() {
		String dbUid = "080f8146bd4e4e349350c1b184db1b56";
		
	    ResponseEntity<UUID> respEntity = proposalRevisionController.updateProposalRevisionMetaData(GUIDUtils.fromDatabaseFormat(dbUid), null, null, null);
	    Assert.assertNotNull(respEntity);
    	Assert.assertNotNull(respEntity.getBody());
    	ChangeProposalVersion revisionEntity = changeProposalVersionRepository
				.findByExternalId(GUIDUtils.toDatabaseFormat(respEntity.getBody()));
    	log.debug("Entity==> "+revisionEntity.toString());
    	log.debug("Comments==>"+revisionEntity.getDescriptionNotes());
    	

    	Assert.assertNull(revisionEntity.getCefAnnex());
    	Assert.assertNull(revisionEntity.getCefPostDate());
    	Assert.assertTrue(StringUtils.isBlank(OrderedCollectionUtil.convertAndSortDescending(revisionEntity.getDescriptionNotes(), "createTs").get(0).getDescriptionNoteText()));
    	
	}
	
	@Test
	public void testReclassTransferEquals() {
		ReclassTransfer rt = new ReclassTransfer();
		//rt.setId(12345L);
		VersionSymbol source = new VersionSymbol();
		source.setSymbolName("A01B");
		source.setSystemCreated(false);
		rt.setTargetSymbolName("A01B");
		rt.setSourceVersionSymbol(source);
		rt.setReclassificationTypeCategory(ReclassificationTypeCategory.ADMIN);
		rt.setTargetClassificationValueCode(ReclassificationTypeTargetClassifiationCategory.A);
		rt.setExternalId("123466");
		
		ReclassTransfer rt1 = new ReclassTransfer();
		//rt1.setId(467L);
		VersionSymbol source1 = new VersionSymbol();
		VersionSymbol target1 = new VersionSymbol();
		source1.setSymbolName("A01C");
		rt1.setTargetSymbolName("A01C");
		rt1.setSourceVersionSymbol(source1);
		rt1.setReclassificationTypeCategory(ReclassificationTypeCategory.INTELLECTUAL);
		rt1.setTargetClassificationValueCode(ReclassificationTypeTargetClassifiationCategory.I);
		rt1.setExternalId("567889");
		
		ReclassTransfer rt4 = new ReclassTransfer();
		rt4.setTargetSymbolName("A01B");
		rt4.setSourceVersionSymbol(source);
		rt4.setReclassificationTypeCategory(ReclassificationTypeCategory.ADMIN);
		rt4.setTargetClassificationValueCode(ReclassificationTypeTargetClassifiationCategory.A);
		rt4.setExternalId("123466");		
		Assert.assertEquals(rt, rt4);
		Assert.assertFalse(rt.equals(rt1));
		Assert.assertFalse(rt1.equals(rt));
		Assert.assertFalse(rt.equals(null));
		Assert.assertFalse(rt1.equals(new String()));		
		
		ReclassTransfer rt2 = rt;
		Assert.assertEquals(rt, rt2);
		Assert.assertEquals(rt2, rt);
		
		
				
	}
	
	@Test
	@Transactional
	public void testGetSctStatistics() {
		
		ResponseEntity<List<SchemeChangeTableStatistic>> resp = proposalRevisionController
				.getProposalRevisionStatistics(GUIDUtils.fromDatabaseFormat("44c4f7b8b78e4c07aa5d37432db56260"));
		
		assertNotNull(resp);
		assertEquals(HttpStatus.OK, resp.getStatusCode());
		
		List<SchemeChangeTableStatistic> sctStats = resp.getBody();
		assertNotNull(sctStats);
	}
	
	@Test
	@Transactional
	public void getRclStatistics() {
		
		ResponseEntity<RclStatistic> resp = proposalRevisionController
				.getRclStatistics(GUIDUtils.fromDatabaseFormat("44c4f7b8b78e4c07aa5d37432db56260"));
		
		assertNotNull(resp);
		assertEquals(HttpStatus.OK, resp.getStatusCode());
		
		RclStatistic sctStats = resp.getBody();
		assertNotNull(sctStats);
	}
	
}
