package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class TitleReferencePartValidatorTest {
    private static final Logger log = LoggerFactory.getLogger(TitleReferencePartValidatorTest.class);

    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private TitleReferencePartCPCValidator titleReferencePartCPCValidator;

    @Inject
    private ProposalValidationService proposalValidationService;

    @Inject
    private TitleService titleService;

    @Resource(name="proposalCompletenessValidator")
    private List<ProposalValidator> proposalValidators;

    @Test
    public void testConfigCorrectlyIncludesGrammarValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(titleReferencePartCPCValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }

    @Test
    public void testValidate() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (Handy for ; Takes precedence for sewerage ##SYMBOL##E02B 7/18##/SYMBOL## siphon)", null));

        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);
        int i = 1;
        for (RevisionChangeItem row : rows) {
            log.debug("line {} has {} validation messages", i++, row.getValidationMessages().size());
        }
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Modifications to the IPC title are improper, (check curly bracket placement).",
                rows.get(0).getValidationMessages().get(0).getMessageText());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (TaKeS PrEcEdEnce ##SYMBOL##E03F 5/20##/SYMBOL##,##SYMBOL##A01N##/SYMBOL##)", null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(1, rows.get(0).getValidationMessages().size()); // symbol
                                                                            // references
                                                                            // should
                                                                            // come
                                                                            // before

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (TaKe PrEcEdEnce ##SYMBOL##E03F 5/20##/SYMBOL##,##SYMBOL##A01N##/SYMBOL##)", null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (##SYMBOL##E03F 5/20##/SYMBOL## take precedence ##SYMBOL##A01N##/SYMBOL##)", null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (##SYMBOL##E03F 5/20##/SYMBOL## takes precedence ##SYMBOL##E03F 5/20##/SYMBOL## ##SYMBOL##A01N##/SYMBOL##)",
                null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        // I know this assert looks like it should be wrong but the story does
        // not say "takes precedence" must be the first words
        // in the reference but only that it must appear in the first part of
        // the reference.
        // whether or not the placement of the words is wronge related to the
        // other pieces of the first reference part
        // is determined by @see
        // gov.uspto.pe2e.cpc.ipc.rest.web.validator.proposal.TitleReferencePartValidator

        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (Testing;##BOLD##takes##/BOLD## precedence ##SYMBOL##A01N##/SYMBOL##)", null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Modifications to the IPC title are improper, (check curly bracket placement).",
                rows.get(0).getValidationMessages().get(0).getMessageText());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (takes precedence ##SYMBOL##E03F 5/20##/SYMBOL## ##SYMBOL##A01N##/SYMBOL##)", null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());

        // NON PRECEDENCE VALIDATORs BELOW

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (Siphons ##SYMBOL##E03F 5/20##/SYMBOL## for sewerage; E02B 7/18 siphon)", null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);
        i = 1;
        for (RevisionChangeItem row : rows) {
            log.debug("line {} has {} validation messages", i++, row.getValidationMessages().size());
        }
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Modifications to the IPC title are improper, (check curly bracket placement).",
                rows.get(0).getValidationMessages().get(0).getMessageText());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (Siphons ##SYMBOL##E03F 5/20##/SYMBOL##,##SYMBOL##A01N##/SYMBOL##)", null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (Siphons ##SYMBOL##E03F 5/20##/SYMBOL## ##SYMBOL##A01N##/SYMBOL##)", null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (##SYMBOL##E03F 5/20##/SYMBOL##Hello;Test##SYMBOL##A01N##/SYMBOL##); Testing (##SYMBOL##E03F 5/20##/SYMBOL##Hello;Test##SYMBOL##A01N##/SYMBOL##)",
                null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());

        Assert.assertEquals("Modifications to the IPC title are improper, (check curly bracket placement).",
                rows.get(0).getValidationMessages().get(0).getMessageText());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (References ##SYMBOL##E03F 5/20##/SYMBOL##;References ##SYMBOL##E03F 5/20##/SYMBOL##, ##SYMBOL##A01N##/SYMBOL##;References ##SYMBOL##E03F 5/20##/SYMBOL##;References ##SYMBOL##E03F 5/20##/SYMBOL##, ##SYMBOL##A01N##/SYMBOL##); Testing (Test ##SYMBOL##E03F 5/20##/SYMBOL##)",
                null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Title {Mixtures of material (##SYMBOL##D21H 17/69##/SYMBOL## takes precedence) (##SYMBOL##D21H 23/10##/SYMBOL##, ##SYMBOL##D21H 23/70##/SYMBOL##, ##SYMBOL##D21H 23/76##/SYMBOL## take "
                        + " precedence); Pulp or paper comprising several different materials not incorporated by special"
                        + " processes }",
                null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Title (Mixtures of material, takes precedence ##SYMBOL##D21H 17/69##/SYMBOL##,##SYMBOL##D21H 23/10##/SYMBOL##)",
                null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

         Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
         Assert.assertEquals("Modifications to the IPC title are improper, (check curly bracket placement).",
                 rows.get(0).getValidationMessages().get(0).getMessageText());

        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "Testing (##SYMBOL##E03F 5/20##/SYMBOL## takes precedence; more like this are ##SYMBOL##D21H 23/10##/SYMBOL##)",
                null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());
        
        
        rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0",
                "test (non-precedence ##SYMBOL##A01##/SYMBOL##, ##SYMBOL##A01 5/00##/SYMBOL##, ##SYMBOL##D01 4/00##/SYMBOL##)",
                null));

        proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        titleReferencePartCPCValidator.validate(proposalValidationContext, rows);

        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());


    }

    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.MEDIUM, titleReferencePartCPCValidator.getCost());
    }

    @Test
    public void testGetValidatorType() {
        Assert.assertEquals(ValidationMessageType.RECORD, titleReferencePartCPCValidator.getValidationType());

    }

    public RevisionChangeItem createRevisionChangeItemAndValidateTitleGrammar(String entryType, String symbolName,
            String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel,
                titleGrammar, reclassTargets);
        try {
            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
            item.setTitle(tree);
        } catch (GrammarParseException gpe) {
            item.getValidationMessages().addAll(gpe.getValidationMessages());
        }
        return item;
    }

    @Before
    public void setUp() throws Exception {

        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        DateTimeZone.setDefault(DateTimeZone.UTC);
        datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        // UsernamePasswordAuthenticationToken token = new
        // UsernamePasswordAuthenticationToken("user1", "user@user.com",
        // Arrays.asList(new BasicTestingGrantedAuthority("test")));
        //
        // SecurityContextHolder.getContext().setAuthentication(token);
        //
        // RequestContextHolder.setRequestAttributes(
        // new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
        // "/cpcipcrestweb", "/symbols")));
    }

}
