package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.TitleConverter;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.ipc.rest.pm.testingsupport.ProposalDatasetTestingService;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class TitleGoldCopyCircularReferenceValidatorTest {
	
	private static final Logger log = LoggerFactory.getLogger(TitleSymbolRefOrderWithinRefPartValidatorTest.class);

	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private TitleGoldCopyDirectCircularSymbolReferenceValidator titleGoldCopyDirectCircularSymbolReferenceValidator;

	@Inject
	private ProposalValidationService proposalValidationService;

	@Inject
	private TitleService titleService;
	
	@Inject
	private ProposalDatasetTestingService proposalDatasetTestingService;

	@Resource(name = "proposalConsistencyValidator")
	private List<ProposalValidator> proposalValidators;
	
	@Test
	public void testVerifyConfig() {
		  boolean isIncluded = false;
	        for (ProposalValidator validator: proposalValidators) {
	            if (validator.getClass().getCanonicalName().equals(titleGoldCopyDirectCircularSymbolReferenceValidator.getClass().getCanonicalName())) {
	                isIncluded = true;
	                break;
	            }
	        }
	        Assert.assertTrue(isIncluded);
	}

	@Test
	public void testCreateReferenceContext() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N27/99", "0", 
				 " test ##SYMBOL##B01N##/SYMBOL##", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

//	        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "##SYMBOL##A01N01T/3002##/SYMBOL## This symbol should exist ##SYMBOL##A01N##/SYMBOL##", null));
//	        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "Test ##SYMBOL##D01N01/2001##/SYMBOL##", null));
//	        

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	     assertEquals(1, proposalValidationContext.getGoldCopyReferences().size());	        
	}

	
	@Test
	public void testValidateCPC() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "B21H7/12", "0", 
				 " test {##SYMBOL##A01L##/SYMBOL##}", null);
	     rows.add(item);
//		 item =ProposalValidationHelperTest.createRevisionChangeItem("M", "B01N", "0", 
//				 " test ##SYMBOL##A01N27/99##/SYMBOL##", null);
//	     rows.add(item);
//		 
	     proposalDatasetTestingService.pupulateDefaultsAsIfFromRequest(rows);
	     
//	        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "##SYMBOL##A01N01T/3002##/SYMBOL## This symbol should exist ##SYMBOL##A01N##/SYMBOL##", null));
//	        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "Test ##SYMBOL##D01N01/2001##/SYMBOL##", null));
//	        

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleGoldCopyDirectCircularSymbolReferenceValidator.validate(proposalValidationContext, rows);
	        for (ValidationMessage m: rows.get(0).getValidationMessages()) {
	        	log.error("{}", m.getMessageText());
	        }
	        assertEquals(1, rows.get(0).getValidationMessages().size());
	        assertEquals("Limiting references 'B21H7/12' (this proposal) and 'A01L' (current scheme) point to each other (in curly brackets). Verify scope of symbols!" , 
	        		rows.get(0).getValidationMessages().get(0).getMessageText());
	        
	        assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(0).getLevel());
	        
	        
	}

	@Test
	public void testValidateIPC() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A23C", "0", 
				 " test {##SYMBOL##A01J##/SYMBOL##}", null);
	     rows.add(item);
//		 item =ProposalValidationHelperTest.createRevisionChangeItem("M", "B01N", "0", 
//				 " test {##SYMBOL##A01N27/99##/SYMBOL##}", null);
//	     rows.add(item);
//		 
	     proposalDatasetTestingService.pupulateDefaultsAsIfFromRequest(rows);
	     
//	        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "##SYMBOL##A01N01T/3002##/SYMBOL## This symbol should exist ##SYMBOL##A01N##/SYMBOL##", null));
//	        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "Test ##SYMBOL##D01N01/2001##/SYMBOL##", null));
//	        

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleGoldCopyDirectCircularSymbolReferenceValidator.validate(proposalValidationContext, rows);
	        assertEquals(1, rows.get(0).getValidationMessages().size());
	        for (ValidationMessage m: rows.get(0).getValidationMessages()) {
	        	log.error("{}", m.getMessageText());
	        }
	        assertEquals("Limiting references 'A23C' (this proposal) and 'A01J' (current scheme) point to each other. Verify scope of symbols!" , 
	        		rows.get(0).getValidationMessages().get(0).getMessageText());
	         
	        		//"Limiting references 'A01N27/99' and 'B01N' (in this proposal) point to each other (in curly brackets). Verify scope of symbols!", rows.get(0).getValidationMessages().get(0).getMessageText());
	        
	        assertEquals(ValidationMessageLevel.ERROR, rows.get(0).getValidationMessages().get(0).getLevel());
	        
	        
	}
	
	@Test
	public void testValidateTransitiveCircDep() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N27/99", "0", 
				 " test {##SYMBOL##B01N##/SYMBOL##}", null);
	     rows.add(item);
		 item =ProposalValidationHelperTest.createRevisionChangeItem("M", "B01N", "0", 
				 " test {##SYMBOL##A01N##/SYMBOL##}", null);
	     rows.add(item);
		 item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N", "0", 
				 " test {##SYMBOL##A01N27/99##/SYMBOL##}", null);
	     rows.add(item);
		 
	     proposalDatasetTestingService.pupulateDefaultsAsIfFromRequest(rows);
	     
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleGoldCopyDirectCircularSymbolReferenceValidator.validate(proposalValidationContext, rows);
	        for (RevisionChangeItem row: rows) {
	        	assertEquals(0, row.getValidationMessages().size());
	        }
	}

	@Test
	public void testValidateNoError() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N27/99", "0", 
				 " test (test 123 ##SYMBOL##B01N##/SYMBOL##; test ##SYMBOL##C01N##/SYMBOL## test ##SYMBOL##C02N##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleGoldCopyDirectCircularSymbolReferenceValidator.validate(proposalValidationContext, rows);
	        assertEquals(0, rows.get(0).getValidationMessages().size());
	        
	}

	@Test
	public void testValidate2000SeriesNoError() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N27/99", "0", 
				 " test (test 123 ##SYMBOL##B01N##/SYMBOL##; test ##SYMBOL##C01N2001/00##/SYMBOL## test ##SYMBOL##C02N##/SYMBOL##; ##SYMBOL##A01N##/SYMBOL## )", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleGoldCopyDirectCircularSymbolReferenceValidator.validate(proposalValidationContext, rows);
	        assertEquals(0, rows.get(0).getValidationMessages().size());
	        
	}
	
	@Test
	public void testValidateNoRowsNoError() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        titleGoldCopyDirectCircularSymbolReferenceValidator.validate(proposalValidationContext, rows);
	        
	        assertEquals(0, rows.size());
	        
	}
	
	@Test
	public void testGetCost() {
		assertEquals(ValidationCost.MEDIUM, titleGoldCopyDirectCircularSymbolReferenceValidator.getCost());
	}

	@Before
	public void setUp() throws Exception {

		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		DateTimeZone.setDefault(DateTimeZone.UTC);
		
		datasetTestingService.loadOnce();

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(2L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		
	}

}
