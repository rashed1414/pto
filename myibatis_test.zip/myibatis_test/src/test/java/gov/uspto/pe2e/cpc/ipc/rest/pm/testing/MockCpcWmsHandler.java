/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.pm.testing;

import java.util.Date;
import java.util.UUID;

import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.commons.api.CpcWmsHandler;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ExternalServiceException;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.Input;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.TaskStateDetails;

/**
 * @author 2020 Development Team (myoung3)
 *
 */
@Service
public class MockCpcWmsHandler implements CpcWmsHandler {

   	@Override
	public TaskStateDetails getTaskDetailsByTaskId(String taskId) throws ExternalServiceException {
   		TaskStateDetails taskStateDetails = new TaskStateDetails();
   		
   		taskStateDetails.setTaskDefinitionKey(taskId);
   		taskStateDetails.setTaskName(taskId);
   		taskStateDetails.setCompleteTs(new Date());
   		taskStateDetails.setStartTs(new Date());
		return taskStateDetails;	
	}

	@Override
	public TaskStateDetails getTaskDetailsWithProposalId(UUID proposalId) throws ExternalServiceException {
		// TODO Auto-generated method stub
		TaskStateDetails taskStateDetails = new TaskStateDetails();
   		taskStateDetails.setCompleteTs(new Date());
   		taskStateDetails.setAssignee("WmsMock@TestUser.com");
   		Input taskComment = new Input();
   		taskComment.setName("wfForm_COMMENT");
   		taskComment.setValue("Task Submitted");
   		taskStateDetails.getInputs().add(taskComment);
		return taskStateDetails;	
	}

}
