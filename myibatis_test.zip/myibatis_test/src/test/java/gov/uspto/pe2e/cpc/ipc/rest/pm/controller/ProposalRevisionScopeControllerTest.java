package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.ByteArrayOutputStream;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.SchemeHierarchyRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.VersionSymbolRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalScopeMember;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
/**
 * Warning.  This is an unusual test.  it does not rely on normal sprint test bootstrapping.
 * This test mocks out everything except the controller and the service.  This means the 
 * db code is not tested at all.
 * 
 * @author 2020 Development Team (myoung3)
 *
 */
@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRevisionScopeControllerTest {
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject 
    private VersionSymbolRepository versionSymbolRepository;
    
    @Inject
    private SchemeHierarchyRepository schemeHierarchyRepository;
    
    @Inject
    private ProposalRevisionScopeController proposalRevisionScopeController;
    
    @Test
    public void testFindSymbolByRevsionExternalId() {
        List<String> symbols = versionSymbolRepository
                .findSymbolNamesByRevisionExternalId("080f8146bd4e4e349350c1b184db1b56");
        assertNotNull(symbols);
        assertEquals(10, symbols.size());
        
    }
    
    @Test 
    public void testFindParentSymbolsByChildren() throws ParseException {
        List<String> children = Arrays.asList("A01B1/02","A01B1/022", "A01B1/024","A01B1/026","A01B1/028","A01B1/04","A01B1/06");
        List<String> parents =   schemeHierarchyRepository
              .findParentSymbolNamesByChildren(children, DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        assertEquals(2, parents.size());
    }
    
    @Test 
    public void testFindDirectChildSymbolNames() throws ParseException {
        List<String> children = schemeHierarchyRepository.findDirectChildSymbolNames("A01B1/02", DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()) );
        assertNotNull(children);
        log.info("children found by parent ({}) : {}", "A01B1/02", children);
        assertEquals(5, children.size());
        
    }

    @Test
    public void testGetRevisionScopeByChangeProposalVersionId() throws Exception {
        UUID revision =  GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56");
        
        ResponseEntity<List<ProposalScopeMember>> resp = proposalRevisionScopeController.getRevisionScopeByChangeProposalVersionId(revision);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertNotEquals(0, resp.getBody().size());
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectMapper  m = new ObjectMapper();
        m.writeValue(baos, resp.getBody());
        log.info("Scope Members:  {}", baos.toString()); 
        
        assertEquals(6, resp.getBody().size());

        assertEquals(5, resp.getBody().get(0).getSymbols().size());
        
    }
    
    @Before
    public void setUp() throws Exception {
//        datasetTestingService.loadOnce();


        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
                "bkuppusamy", "Boops","Kuppusamy", "US");
            UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "boopathi.kuppusamy@uspto.gov", token,
                Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
                        new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
                        new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
        SecurityContextHolder.getContext().setAuthentication(springUser);        


        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }
}
