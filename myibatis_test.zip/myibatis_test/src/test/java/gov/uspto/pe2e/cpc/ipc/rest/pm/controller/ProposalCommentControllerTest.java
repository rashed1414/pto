 package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentPartCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CommentVisibility;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalComment;
import jakarta.inject.Inject;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalCommentControllerTest {

	@Inject
	private ProposalCommentController proposalCommentController;
	
	@Inject
	private DatasetTestingService datasetTestingService;


	@Test
	public void tesSaveComment() {
		
			UUID proposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
			ProposalComment proposalComment = new ProposalComment();
			
			String emailID = "user@testing.com";
	    	UUID commentID= UUID.randomUUID();
	    	Date now = new Date();
			
			proposalComment.setCommentText("Test Comment 1");
			proposalComment.setCreateTs(now);
			proposalComment.setCreateUserId(emailID);
			proposalComment.setId(commentID);
			proposalComment.setLastModifyTs(now);
			proposalComment.setLastModifyUserId(emailID);
			proposalComment.setProjectName("Test Project");
			proposalComment.setReferenceContext(ComponentPartCategory.APPLICATION_REFERENCES);
			proposalComment.setRevision(12);
			proposalComment.setSymbolName("A01B3/462");
			proposalComment.setVisibility(CommentVisibility.USERONLY);
			
			ResponseEntity<Void> resp = proposalCommentController.saveComment(
					proposalId, proposalComment);
			
			assertNotNull(resp);
			assertEquals(HttpStatus.CREATED, resp.getStatusCode());
	}
	@Test
	public void tesDeleteComment() {
    	UUID proposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
    	UUID commentId = GUIDUtils.fromDatabaseFormat("6d6634585b81488baee5bfb93d9583e3");
    	
    	ResponseEntity<Void> resp = proposalCommentController.deleteComment(proposalId, commentId);
    	
    	assertNotNull(resp);
    	assertEquals(HttpStatus.NO_CONTENT,resp.getStatusCode());
	}
	
	@Before
	public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.emptyTables(conn);
		datasetTestingService.loadAllDatasets(conn);

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamy@uspto.gov", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
	}


}