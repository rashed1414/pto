package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.jdom2.Element;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalVersionRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.VersionSymbolRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.XmlDomUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalRevisionServiceVolatileTest {
	  
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalRevisionService proposalRevisionService;
    
    @Inject
	private ChangeProposalVersionRepository changeProposalVersionRepository;  
    
    @Inject
    private VersionSymbolRepository versionSymbolRepository;
    
	
	@Test
	@Transactional
	public void testCleanDefinition() throws IOException {
		assertTrue(Pattern.matches("^[A-Za-z0-9]+\\-references$", "informative-references"));
		InputStream is = Thread.currentThread().getContextClassLoader()
				 .getResourceAsStream("data/xml/definition_section_edit_request_withmisplacedreferences.xml");
		String dirtyXml = IOUtils.toString(is);
		String clean = proposalRevisionService.cleanDefinition(dirtyXml);
		log.debug("XXXclean = {}",clean);
		List<Element> nodes = XmlDomUtils.findNodesByXpathExpression(clean, "/definition-item/informative-references");
		assertEquals(0, nodes.size());
		nodes = XmlDomUtils.findNodesByXpathExpression(clean, "/definition-item/references/informative-references");
		
		log.debug("clean {}", clean);
		//assertEquals(1, nodes.size());
		//TODO: Move this out to a volatile test class
	}
	
	@Before
	public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.emptyTables(conn);
		datasetTestingService.loadAllDatasets(conn);

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(2L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2021-09-27", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

//	        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("myoung3@uspto.gov", "myoung3@uspto.gov", Arrays
//	                .asList(new BasicTestingGrantedAuthority("test"), 
//	                		new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name())));
		//
//	        SecurityContextHolder.getContext().setAuthentication(token);

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamy@uspto.gov", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
	}


}
