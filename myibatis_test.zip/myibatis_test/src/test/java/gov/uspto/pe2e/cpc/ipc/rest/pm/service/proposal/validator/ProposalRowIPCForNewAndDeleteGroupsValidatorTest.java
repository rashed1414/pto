package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.TitleConverter;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageLevel;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import gov.uspto.pe2e.cpc.ipc.rest.pm.testingsupport.ProposalDatasetTestingService;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
/**
 * US117930 
 * 
 * @author 2020
 * @date Oct 2, 2019
 * @since __INSERT_VERSION__
 * @version __INSERT_VERSION__
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowIPCForNewAndDeleteGroupsValidatorTest {
	private static final Logger log = LoggerFactory.getLogger(ProposalRowIPCForNewAndDeleteGroupsValidatorTest.class);

	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private ProposalRowIPCForNewAndDeleteGroupsValidator proposalRowIPCForNewAndDeleteGroupsValidator;

	@Inject
	private ProposalValidationService proposalValidationService;

	@Inject
	private TitleService titleService;

	@Inject
	private ProposalDatasetTestingService proposalDatasetTestingService;

	@Resource(name = "proposalConsistencyValidator")
	private List<ProposalValidator> proposalValidators;
	
	@Test
	public void testValidateNoErrorCPCOnly() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("D", "A99N99/9999", "0", 
				 " test (takes precedence ##SYMBOL##D01N 1/00##/SYMBOL##; this is not part of the same subclass ##SYMBOL##A01N 1/21##/SYMBOL##; test ##SYMBOL##A01B1/21##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        proposalRowIPCForNewAndDeleteGroupsValidator.validate(proposalValidationContext, rows);
	        assertEquals(0, rows.get(0).getValidationMessages().size());
	}
	
	/**
	 * US132818 Validate Zombie IPC symbol
	 */
	@Test
	public void testValidateZombieIPC() {
		
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("N", "A01B63/116", "0", 
				 " test (takes precedence ##SYMBOL##D01N 1/00##/SYMBOL##; this is not part of the same subclass ##SYMBOL##A01N 1/21##/SYMBOL##; test ##SYMBOL##A01B1/21##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        proposalRowIPCForNewAndDeleteGroupsValidator.validate(proposalValidationContext, rows);
	        log.debug("{}", rows.get(0).getValidationMessages().get(0).getMessageText());
	        assertEquals(1, rows.get(0).getValidationMessages().size());
	        assertEquals(ValidationMessageLevel.WARNING, 
	        		rows.get(0).getValidationMessages().get(0).getLevel());
	        assertEquals("Symbol conflict: Previously used in IPC", rows.get(0).getValidationMessages().get(0).getMessageText());
	        
	}
	
	/**
	 * US132818
	 */
	@Test
	public void testValidateNoErrorDeadHorse() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("D", "A01B63/116", "0", 
				 " test (takes precedence ##SYMBOL##D01N 1/00##/SYMBOL##; this is not part of the same subclass ##SYMBOL##A01N 1/21##/SYMBOL##; test ##SYMBOL##A01B1/21##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        proposalRowIPCForNewAndDeleteGroupsValidator.validate(proposalValidationContext, rows);
	        
	        assertEquals(0, rows.get(0).getValidationMessages().size());
	}
	@Test
	public void testValidateNoErrorIPCError() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("D", "A01B63/116", "0", 
				 " test (takes precedence ##SYMBOL##D01N 1/00##/SYMBOL##; this is not part of the same subclass ##SYMBOL##A01N 1/21##/SYMBOL##; test ##SYMBOL##A01B1/21##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        proposalRowIPCForNewAndDeleteGroupsValidator.validate(proposalValidationContext, rows);
	        for (ValidationMessage msg : rows.get(0).getValidationMessages()) {
	        	log.debug("{}",msg.getMessageText());
	        }
	        assertEquals(0, rows.get(0).getValidationMessages().size());
	}
	
	/**
	 * US132818
	 */
	@Test
	public void testValidateOrphanAnnie() {
		 List<RevisionChangeItem> rows = new ArrayList<>();
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("D", "A01F25/20", "0", 
				 " test (takes precedence ##SYMBOL##D01N 1/00##/SYMBOL##; this is not part of the same subclass ##SYMBOL##A01N 1/21##/SYMBOL##; test ##SYMBOL##A01B1/21##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
	        rows.add(item);

	        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
	        proposalRowIPCForNewAndDeleteGroupsValidator.validate(proposalValidationContext, rows);
	        assertEquals(1, rows.get(0).getValidationMessages().size());
	        ValidationMessage val = rows.get(0).getValidationMessages().get(0);
	        
	        assertEquals("Cannot delete IPC group (unless intentional deviation)", val.getMessageText());
	        assertEquals(ValidationMessageLevel.ERROR, val.getLevel());
	        assertEquals(ValidationPhase.CONSISTENCY, val.getPhase());
	        
	        
	}

	@Test
	public void testVerifyConfig() {
		boolean isIncluded = false;
		for (ProposalValidator validator : proposalValidators) {
			if (validator.getClass().getCanonicalName()
					.equals(proposalRowIPCForNewAndDeleteGroupsValidator.getClass().getCanonicalName())) {
				isIncluded = true;
				break;
			}
		}
		Assert.assertTrue(isIncluded);
	}
	
	@Test
	public void testIsIpcDeleteViolation() {
		 RevisionChangeItem item =ProposalValidationHelperTest.createRevisionChangeItem("N", "A99N99/9999", "0", 
				 " test (takes precedence ##SYMBOL##D01N 1/00##/SYMBOL##; this is not part of the same subclass ##SYMBOL##A01N 1/21##/SYMBOL##; test ##SYMBOL##A01B1/21##/SYMBOL##)", null);
		 try {
	            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
	            item.setTitle(tree);
	            try {
	                tree = titleService.fromGrammar(TitleConverter.flattenTitleGrammar(item.getTitleGrammar()));
	                item.setFlattenedTitle(tree);
	            } catch (GrammarParseException gpe2) {
	                log.debug("GPE encountered, IPC title will be set to null");
	            }
	        } catch (GrammarParseException gpe) {
	            item.getValidationMessages().addAll(gpe.getValidationMessages());
	        }
		assertFalse(proposalRowIPCForNewAndDeleteGroupsValidator.isIpcDeleteViolation(item));
	
	}
	
	@Before
	public void setUp() throws Exception {

		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		DateTimeZone.setDefault(DateTimeZone.UTC);
		datasetTestingService.loadOnce();

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(2L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		
	}

}
