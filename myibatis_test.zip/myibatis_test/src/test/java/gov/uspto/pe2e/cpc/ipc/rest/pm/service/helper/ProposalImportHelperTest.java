package gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.dom4j.DocumentException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalVersion;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.VersionSymbol;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DirectoryUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.TitleConverter;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefinitionSectionType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.NAWItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassTransfer;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteParagraph;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteRawText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteType;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionContentNode;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionTitle;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalImportHelperTest {
	//private static final Logger log = LoggerFactory.getLogger(ProposalDocxImporterTest.class);
	
	private static final String XSLT_TITLE_PARSER_SCRIPT = "xslt/parse_title_docs_structure.xsl";
    private static final String XSLT_TITLE_STRIKED_TEXT_REMOVER_SCRIPT = "xslt/parse_title_remove_striked_text.xsl";

	 @Inject
	 private DatasetTestingService datasetTestingService;
	    
	@Inject
	private ProposalImportHelper proposalImportHelper;
	@Test
	public void testParseDocxXmlFragment() throws IOException, DocumentException {
//        String xml = IOUtils.toString(Thread.currentThread().getContextClassLoader().getResourceAsStream("data/xml/title_docx_fragment.xml"));
//		String xml = IOUtils.toString(Thread.currentThread().getContextClassLoader().getResourceAsStream("data/xml/full_docx_document.xml"));
	    String xml = IOUtils.toString(Thread.currentThread().getContextClassLoader().getResourceAsStream("data/xml/title_docx_fragment_1.xml"));
	            
		log.debug("Xml from fs {}", xml);		
		xml = proposalImportHelper.transformDocxXmlToTitleXml(xml, XSLT_TITLE_PARSER_SCRIPT);
		log.debug("Xml ={}", xml);
		Assert.assertTrue(xml.contains("<text>Testing Title H<sub>2</sub>O and A<sup>2</sup>and B<sup>2</sup> enclosed super script </text>"));
	}	
	
	@Test
	public void testParseDocxXmlFragmentWithStrikedText() throws IOException, DocumentException {
	    String xml = IOUtils.toString(Thread.currentThread().getContextClassLoader().getResourceAsStream("data/xml/title_fragment_striked_text.xml"));
	            
		log.debug("Xml from fs {}", xml);		
		String titlePartXML = proposalImportHelper.transformDocxXmlToTitleXml(xml, XSLT_TITLE_STRIKED_TEXT_REMOVER_SCRIPT);
		log.debug("titlePartXML ={}", titlePartXML);
		Assert.assertTrue(titlePartXML.equals("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
				+ "<class-title/>\n"
				+ ""));
	}	
	
	
	@Test
	public void testExportXmlForExample() {
	    InputStream is = null;
	    try {
	        is = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream("data/docx/sct_1row_complextitle.docx");
	        WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(is);
	        MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
	        log.debug("XML = {}", documentPart.getXML());
	        Assert.assertTrue(Boolean.TRUE);
	    } catch (Exception e) {
	        e.printStackTrace();
	        Assert.assertTrue(Boolean.FALSE);
	    } finally {
	        IOUtils.closeQuietly(is);
	    }
	    
	    
	}
	
	@Test
	public void testParseTitle1() {
	    String  classpathFile = "data/docx/sct_basic_parsetitle.docx";
	    classpathFile = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader()
                .getResource(classpathFile).getFile());

        List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File(classpathFile).getAbsolutePath());
        Assert.assertEquals(4, sctItems.size());
	}

	@Test
	public void testParseTitle_US334257() {
	    String  classpathFile = "data/docx/US334257.docx";
	    classpathFile = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader()
                .getResource(classpathFile).getFile());

        List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File(classpathFile).getAbsolutePath());
        Assert.assertEquals(18, sctItems.size());
  
      	log.debug("[{}] - first 15", StringUtils.substring(
      			TitleConverter.toGrammar(sctItems.get(0).getTitle()),0,15));
        String firstTitleFrag = StringUtils.substring(TitleConverter.toGrammar(sctItems.get(0).getTitle()),0,6);
        assertEquals("{Speci", firstTitleFrag); // this will detect if extra spaces are being introduced in the titles
        

	}

	
   @Test
    public void testParseTitle2() {
        String  classpathFile = "data/docx/sct_basic_parsetitle-badtitle.docx";
        classpathFile = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader()
                .getResource(classpathFile).getFile());

        List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File(classpathFile).getAbsolutePath());
       
        Assert.assertEquals(5, sctItems.size());
    }
   
   @Test
   public void testCarriageReturnReclass() {
       String  classpathFile = "data/docx/Carriage.docx";
       classpathFile = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader().getResource(classpathFile).getFile());

       List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File(classpathFile).getAbsolutePath());
       //List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File("C:\\CPC-IP-Trunk-STS3.5.1\\Trunk\\cpcipcrest\\cpcipcrestweb\\src\\test\\resources\\data\\docx\\Carriage.docx").getAbsolutePath());
       log.debug("Items-->"+sctItems.toString());
       Assert.assertEquals(1, sctItems.size());
       Assert.assertEquals(2, sctItems.get(0).getReclassTransfers().size());
       
       String[] reclass = new String[] {"G06Q20/308", "G06Q20/32"};
       for(ReclassTransfer rs : sctItems.get(0).getReclassTransfers()){
    	   Assert.assertTrue(ArrayUtils.contains(reclass,rs.getTargetSymbolName()));
       }
   }
   
   //Morethan50charinReclass
   @Test
   public void testMorethan50charinReclass() {
       String  classpathFile = "data/docx/Morethan50charinReclass.docx";
       classpathFile = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader().getResource(classpathFile).getFile());

       List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File(classpathFile).getAbsolutePath());
       //List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File("C:\\CPC-IP-Trunk-STS3.5.1\\Trunk\\cpcipcrest\\cpcipcrestweb\\src\\test\\resources\\data\\docx\\Morethan50charinReclass.docx").getAbsolutePath());
       
       Assert.assertEquals(1, sctItems.size());
       Assert.assertEquals(1, sctItems.get(0).getReclassTransfers().size());
       Assert.assertTrue("UNRECOGNIZED_SYMBOL".equalsIgnoreCase(sctItems.get(0).getReclassTransfers().get(0).getTargetSymbolName()));
   }
   
   @Test
   public void testOpticsInTitle() {
       String  classpathFile = "data/docx/opticsInTitle.docx";
       classpathFile = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader().getResource(classpathFile).getFile());

       List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File(classpathFile).getAbsolutePath());
       //List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File("C:\\CPC-IP-Trunk-STS3.5.1\\Trunk\\cpcipcrest\\cpcipcrestweb\\src\\test\\resources\\data\\docx\\opticsInTitle.docx").getAbsolutePath());   
       Assert.assertEquals(1, sctItems.size());
       Assert.assertTrue(sctItems.get(0).getTitle().getChildren().size()>0);
   }

   @Test
   public void testNoTransferReclass() {
       String  classpathFile = "data/docx/No_Transfer.docx";
       classpathFile = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader().getResource(classpathFile).getFile());
       List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File(classpathFile).getAbsolutePath());
       //List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File("C:\\CPC-IP-Trunk-STS3.5.1\\Trunk\\cpcipcrest\\cpcipcrestweb\\src\\test\\resources\\data\\docx\\No_Transfer.docx").getAbsolutePath());
       //log.debug("Items-->"+sctItems.toString());
       Assert.assertEquals(2, sctItems.size());
       Assert.assertEquals(0, sctItems.get(0).getReclassTransfers().size());
       Assert.assertEquals(0, sctItems.get(1).getReclassTransfers().size());       
   }
   
   //Space_in_middle_of_Symbol
   @Test
   public void testSpace_in_middle_of_Symbol() {
       String  classpathFile = "data/docx/Space_in_middle_of_Symbol.docx";
       classpathFile = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader().getResource(classpathFile).getFile());

       List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File(classpathFile).getAbsolutePath());
       //List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File("C:\\CPC-IP-Trunk-STS3.5.1\\Trunk\\cpcipcrest\\cpcipcrestweb\\src\\test\\resources\\data\\docx\\Space_in_middle_of_Symbol.docx").getAbsolutePath());
       //log.debug("Items-->"+sctItems.toString());
       Assert.assertEquals(1, sctItems.size());
       Assert.assertEquals(2, sctItems.get(0).getReclassTransfers().size());
       String[] reclass = new String[] {"G06A20/32", "G06Q20/308"};
       for(ReclassTransfer rs : sctItems.get(0).getReclassTransfers()){
    	   Assert.assertTrue(ArrayUtils.contains(reclass,rs.getTargetSymbolName()));
       }
   }
   
   @Test
   public void testEmDashInReclass() {
       String  classpathFile = "data/docx/EmDash.docx";
       classpathFile = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader().getResource(classpathFile).getFile());

       List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File(classpathFile).getAbsolutePath());
       //List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File("C:\\CPC-IP-Trunk-STS3.5.1\\Trunk\\cpcipcrest\\cpcipcrestweb\\src\\test\\resources\\data\\docx\\Space_in_middle_of_Symbol.docx").getAbsolutePath());
       //log.debug("Items-->"+sctItems.toString());
       Assert.assertEquals(1, sctItems.size());
       Assert.assertEquals(2, sctItems.get(0).getReclassTransfers().size());
       String[] reclass = new String[] {"G06Q20/308", "G06Q20/32"};
       for(ReclassTransfer rs : sctItems.get(0).getReclassTransfers()){
    	   Assert.assertTrue(ArrayUtils.contains(reclass,rs.getTargetSymbolName()));
       }
   }

   @Test
   public void testSemiColonInReclass() {
       String  classpathFile = "data/docx/SemiColonInReclass.docx";
       classpathFile = DirectoryUtils.cleanFileNameForJenkinsPath(Thread.currentThread().getContextClassLoader().getResource(classpathFile).getFile());

       List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File(classpathFile).getAbsolutePath());
       //List<RevisionChangeItemRequest> sctItems = proposalImportHelper.parseSchemeChangeTableDocx(new File("C:\\CPC-IP-Trunk-STS3.5.1\\Trunk\\cpcipcrest\\cpcipcrestweb\\src\\test\\resources\\data\\docx\\Space_in_middle_of_Symbol.docx").getAbsolutePath());
       log.debug("Items-->"+sctItems.toString());
       Assert.assertEquals(2, sctItems.size());
       Assert.assertEquals(2, sctItems.get(0).getReclassTransfers().size());
       Assert.assertEquals(2, sctItems.get(1).getReclassTransfers().size());
       String[] reclass1 = new String[] {"G06Q20/308", "G06Q20/32"};
       for(ReclassTransfer rs : sctItems.get(0).getReclassTransfers()){
    	   Assert.assertTrue(ArrayUtils.contains(reclass1,rs.getTargetSymbolName()));
       }
       String[] reclass2 = new String[] {"A01B1/02", "A01B3/08"};
       for(ReclassTransfer rs : sctItems.get(1).getReclassTransfers()){
    	   Assert.assertTrue(ArrayUtils.contains(reclass2,rs.getTargetSymbolName()));
       }
   }

      
   @Before
   public void setUp() throws Exception {
       IDatabaseConnection conn = datasetTestingService.getConnection();
       datasetTestingService.emptyTables(conn);
       datasetTestingService.loadAllDatasets(conn);
       SchemePublicationVersion version = new SchemePublicationVersion();
       version.setClassificationSchemeId(1L);
       version.setCpcXsdVersion("1.7");
       version.setDefinitionXsdVersion("1.0");
       version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
       version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
       SchemePublicationVersionContextHolder.setContext(version);

   }
   
   @Test
   public void testFetchAndSetSymbolName() {
	   ChangeProposalVersion cpv = new ChangeProposalVersion();
	   VersionSymbol vs = new VersionSymbol();
	   RevisionChangeItemRequest request = new RevisionChangeItemRequest();
	   request.setEntryType("D");
	   request.setSymbolName("A01N01/33333333324444444222222555555222226666222222222222");
	   request.setDotLevel("1");
	   request.setReclassTransferExpression("exp");
	   String classificationSymbol = proposalImportHelper.fetchAndSetSymbolName(cpv, vs, request, "user");
	   Assert.assertNotNull(classificationSymbol);
	   Assert.assertEquals(50, classificationSymbol.length());
   }
   // DE55414
   @Test 
   public void testBuildAndSetComponentRevisionForDefinition() {
	   
	   Date now = new Date();
	   VersionSymbol vs = new VersionSymbol();
	
	   
	   DefinitionContentNode content = new DefinitionContentNode();
	   content.setValue("TEST");
	   DefinitionTitle defTitle = new DefinitionTitle();
	   defTitle.getChildren().add(content);
	   
	   DefSectionItemEditRequest defEdit = new DefSectionItemEditRequest();
	   defEdit.setSectionType(DefinitionSectionType.DEFINITION_TITLE);
	   defEdit.setDefinitionTitle(defTitle);
	   RevisionChangeItemRequest row = new RevisionChangeItemRequest();
	   row.getDefinitionItems().add(defEdit);
	   proposalImportHelper.buildAndSetComponentRevisionForDefinition(vs, 
			   row, "testUser", now);
	   
	   assertNotNull(vs.getDefinitionXml());
	   
   }
   // DE55414
   @Test 
   public void testBuildAndSetComponentRevisionForNote() {
	   
	   Date now = new Date();
	   VersionSymbol vs = new VersionSymbol();
	
	   
	  
	   NoteRawText raw =  new NoteRawText();
	   raw.setContent("Test 123");
	   NoteParagraph p = new NoteParagraph();
	   p.getChildren().add(raw);
	   NAWItemEditRequest nawEdit = new NAWItemEditRequest();
	   nawEdit.setNoteCategory(NoteType.NOTE);
	   nawEdit.setNoteItem(p);
	   RevisionChangeItemRequest row = new RevisionChangeItemRequest();
	   row.getNoteItems().add(nawEdit);
	   
	   assertTrue(CollectionUtils.isNotEmpty(row.getNoteItems() ) );
	   proposalImportHelper.buildAndSetComponentRevisionForNote(vs, 
			    row, "testUser", now);
	   
	   assertNotNull(vs.getNoteXml());
	   
   }
}
