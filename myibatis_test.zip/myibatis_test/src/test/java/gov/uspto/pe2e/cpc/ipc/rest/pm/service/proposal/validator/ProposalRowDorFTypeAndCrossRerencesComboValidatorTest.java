package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentPartCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CrossReferenceModification;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowDorFTypeAndCrossRerencesComboValidatorTest {
    
    private static final Logger log = LoggerFactory.getLogger(ProposalRowDorFTypeAndCrossRerencesComboValidatorTest.class);    
    
    private static final String EXPECTED_MESSAGE = "All cross references to Type D and F row symbols in this proposal must be changed.";
    
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalRowDorFTypeAndCrossRerencesComboValidator proposalRowDorFTypeAndCrossRerencesComboValidator;

    @Inject
    private ProposalValidationService proposalValidationService;

    @Resource
    private List<ProposalValidator> proposalValidators;


    @Test
    @Transactional
    public void testValidate() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A01N27/99", "0", "Bold Error ##BOLD##", null));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("", "A01N27/99", "0", "Bold Error ##BOLD##", null));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowDorFTypeAndCrossRerencesComboValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
    }
    
    
    @Test
    @Transactional
    public void testValidateCrossReferenceModificationsForTypeDandF() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        
        RevisionChangeItem rcItem1 = ProposalValidationHelperTest.createRevisionChangeItem("D", "A01B1/02", "0", "Bold Error ##BOLD##", new String[] {"A01N"}); 
        rcItem1.getCrossReferenceModifications().add(createCrossReferenceModification("Y01N27/98", "Y01N27/99", ComponentPartCategory.TITLE, "A01B1/00"));        
        rows.add(rcItem1);
        
        RevisionChangeItem rcItem2 = ProposalValidationHelperTest.createRevisionChangeItem("D", "A01B1/022", "0", "Bold Error ##BOLD##", null);
        rcItem2.getCrossReferenceModifications().add(createCrossReferenceModification("Hello Y01N27/98", "Hello", ComponentPartCategory.WARNING_PARAGRAPH, "A01B1/00"));        
        rows.add(rcItem2); 
        
        RevisionChangeItem rcItem3 = ProposalValidationHelperTest.createRevisionChangeItem("D", "A01B3/462", "0", "Bold Error ##BOLD##", new String[] {});
        rcItem3.getCrossReferenceModifications().add(createCrossReferenceModification("a01B 3/462", "Hello", ComponentPartCategory.APPLICATION_REFERENCES, "A01B1/00"));        
        rcItem3.getCrossReferenceModifications().add(createCrossReferenceModification("Test A01B3/462", "Hello", ComponentPartCategory.APPLICATION_REFERENCES, "A01B33/02"));
        rows.add(rcItem3);
                
        RevisionChangeItem rcItem5 = ProposalValidationHelperTest.createRevisionChangeItem("D", "A01B3/462", "0", "Bold Error ##BOLD##", new String[] {}); 
        rcItem5.getCrossReferenceModifications().add(createCrossReferenceModification("", "Hello", ComponentPartCategory.NOTE_PARAGRAPH, "A01B1/00"));        
        rows.add(rcItem5);
        
        RevisionChangeItem rcItem4 = ProposalValidationHelperTest.createRevisionChangeItem("D", "A01B3/462", "0", "Bold Error ##BOLD##", new String[] {});
        rcItem4.getCrossReferenceModifications().add(createCrossReferenceModification("", "Hello", ComponentPartCategory.APPLICATION_REFERENCES, "A01B1/00")); 
        rcItem4.getCrossReferenceModifications().add(createCrossReferenceModification("", "Hello", ComponentPartCategory.DEFINITION_STATEMENT, "A01B33/02"));
        rows.add(rcItem4);
        
        RevisionChangeItem rcItem6 = ProposalValidationHelperTest.createRevisionChangeItem("N", "A01B3/462", "0", "Bold Error ##BOLD##", new String[] {}); 
        rcItem6.getCrossReferenceModifications().add(createCrossReferenceModification("A01B1/00", "Hello", ComponentPartCategory.APPLICATION_REFERENCES, "A01B1/00")); 
        rcItem4.getCrossReferenceModifications().add(createCrossReferenceModification("A01B1/00", "Hello", ComponentPartCategory.DEFINITION_STATEMENT, "A01B33/02"));
        rows.add(rcItem6);
        
        RevisionChangeItem rcItem7 = ProposalValidationHelperTest.createRevisionChangeItem("F", "", "0", "Bold Error ##BOLD##", new String[] {}); 
        rcItem7.getCrossReferenceModifications().add(createCrossReferenceModification("", "Hello", ComponentPartCategory.APPLICATION_REFERENCES, "Y01N27/22"));        
        rows.add(rcItem7);
        
        RevisionChangeItem rcItem8 = ProposalValidationHelperTest.createRevisionChangeItem("F", "A", "0", "Bold Error ##BOLD##", new String[] {}); 
        rcItem8.getCrossReferenceModifications().add(createCrossReferenceModification("test a", "Hello", ComponentPartCategory.APPLICATION_REFERENCES, "A01B1/00"));        
        rows.add(rcItem8);
        
        RevisionChangeItem rcItem9 = ProposalValidationHelperTest.createRevisionChangeItem("F", "A01", "0", "Bold Error ##BOLD##", new String[] {}); 
        rcItem9.getCrossReferenceModifications().add(createCrossReferenceModification("A01B, A01", "Hello", ComponentPartCategory.APPLICATION_REFERENCES, "A01B1/00"));        
        rows.add(rcItem9);
        
        RevisionChangeItem rcItem10 = ProposalValidationHelperTest.createRevisionChangeItem("D", "A01B3/462", "0", "Bold Error ##BOLD##", new String[] {}); 
        rcItem10.getCrossReferenceModifications().add(createCrossReferenceModification("", "Hello", ComponentPartCategory.NOTE_PARAGRAPH, "A01B1/00"));
        rcItem10.getCrossReferenceModifications().add(createCrossReferenceModification("", "Hello", ComponentPartCategory.WARNING_PARAGRAPH, "A01B33/02"));
        rows.add(rcItem10);
        
        RevisionChangeItem rcItem11 = ProposalValidationHelperTest.createRevisionChangeItem("F", "A01B3/462", "0", "Bold Error ##BOLD##", new String[] {}); 
        rcItem11.getCrossReferenceModifications().add(createCrossReferenceModification("A01B2/025", "", ComponentPartCategory.APPLICATION_REFERENCES, "A01B1/00")); 
        rcItem11.getCrossReferenceModifications().add(createCrossReferenceModification("A01N", "", ComponentPartCategory.DEFINITION_STATEMENT, "A01B33/02"));
        rows.add(rcItem11);
        
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowDorFTypeAndCrossRerencesComboValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(EXPECTED_MESSAGE, rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals(ValidationMessageField.CROSS_REFERENCES, rows.get(0).getValidationMessages().get(0).getTriggerField());      
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());        ;
        Assert.assertEquals(1, rows.get(2).getValidationMessages().size());
        Assert.assertEquals(EXPECTED_MESSAGE, rows.get(2).getValidationMessages().get(0).getMessageText());    
       
        Assert.assertEquals(1, rows.get(3).getValidationMessages().size());
        Assert.assertEquals(EXPECTED_MESSAGE, rows.get(3).getValidationMessages().get(0).getMessageText()); 
        
        Assert.assertEquals(1, rows.get(4).getValidationMessages().size());
        Assert.assertEquals(EXPECTED_MESSAGE, rows.get(4).getValidationMessages().get(0).getMessageText()); 
       
        Assert.assertTrue(rows.get(5).getValidationMessages().isEmpty());      
       
        Assert.assertTrue(rows.get(6).getValidationMessages().isEmpty());
       
        Assert.assertEquals(1, rows.get(7).getValidationMessages().size());
        Assert.assertEquals(1, rows.get(8).getValidationMessages().size());
        Assert.assertTrue(rows.get(9).getValidationMessages().isEmpty()); 
        Assert.assertTrue(rows.get(10).getValidationMessages().isEmpty());
    } 
    
    private CrossReferenceModification createCrossReferenceModification(String newText, String oldText,
            ComponentPartCategory category, String symbolName) {        
        CrossReferenceModification crm5 = new CrossReferenceModification();
        crm5.setNewText(newText);
        crm5.setOldText(oldText);
        crm5.setReferenceContext(category);
        crm5.setReferencingSymbolName(symbolName);        
        return crm5;
    }
    
    @Test
    public void testEmptyRows() {
        List<RevisionChangeItem> rows = new ArrayList<>();      
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowDorFTypeAndCrossRerencesComboValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.size());
    }   

    @Test
    public void testConfigCorrectlyIncludesGrammarValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(proposalRowDorFTypeAndCrossRerencesComboValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }

    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.MEDIUM, proposalRowDorFTypeAndCrossRerencesComboValidator.getCost());

    }

    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }

}
