package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.SchemeHierarchyRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.AdapterUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class GrammarParseRoundtripTest {
	
	@Inject
	private TitleService titleService;
	@Inject 
	private DatasetTestingService datasetTestingService;
	
	@Inject
	private SchemeHierarchyRepository schemeHierarchyRepository;

	@Before
	public void setup() throws Exception {
		System.setProperty("com.sun.xml.internal.stream.XMLInputFactoryImpl",
				"com.sun.xml.internal.stream.XMLInputFactoryImpl");
		System.setProperty("jakarta.xml.parsers.DocumentBuilderFactory",
				"com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");
		 IDatabaseConnection conn = datasetTestingService.getConnection();
	        datasetTestingService.emptyTables(conn);
	        datasetTestingService.loadAllDatasets(conn);

	        SchemePublicationVersion version = new SchemePublicationVersion();
	        version.setClassificationSchemeId(1L);
	        version.setCpcXsdVersion("1.7");
	        version.setDefinitionXsdVersion("1.0");
	        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
	        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
	        SchemePublicationVersionContextHolder.setContext(version);

	}

	
	@Test
    public void testSuggestionGrammar() throws Exception {
    	 Map<String, String> documentAdapterConfig = new HashMap<>();
         documentAdapterConfig.put("1.6", "gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter");
         documentAdapterConfig.put("1.7",
         "gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter" );
         DocumentAdapter adapter = (DocumentAdapter)AdapterUtils.latest(documentAdapterConfig);
    	String grammar = "Hoes;##SUGGESTIONSTART####SUGGESTIONSTARTNAME##deletion:edbf7261c271e9a0d64beb92388ae446a:KEVIN.CONVY@USPTO.GOV##/SUGGESTIONSTARTNAME####/SUGGESTIONSTART##Hand##SUGGESTIONEND####SUGGESTIONENDNAME##deletion:edbf7261c271e9a0d64beb92388ae446a:KEVIN.CONVY@USPTO.GOV##/SUGGESTIONENDNAME####/SUGGESTIONEND## cultivators {(rakes ##SYMBOL####SCHEME##cpc##/SCHEME##A01D7/00##/SYMBOL##; forks ##SYMBOL####SCHEME##cpc##/SCHEME##A01D9/00##/SYMBOL##; picks ##SYMBOL####SCHEME##cpc##/SCHEME##B25D##/SYMBOL##)}";
    	TitlePartTree tree  = titleService.fromGrammar(grammar);
    	log.debug("Found xml ={}" , JsonUtils.toJsonOrStacktrace(tree));
    	assertNotNull(tree);
    	
    	String xml = adapter.mapToGoldCopy(tree);
    	log.debug("xml ={}", xml);
    	assertNotNull(xml);
    	
    	
    }
	
//	@Test
//	public void testFromGold() {
//		 Map<String, String> documentAdapterConfig = new HashMap<>();
//         documentAdapterConfig.put("1.6", "gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter");
//         documentAdapterConfig.put("1.7",
//         "gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter" );
//
//         DocumentAdapter adapter = (DocumentAdapter)AdapterUtils.latest(documentAdapterConfig);
//         SchemeHierarchy symbol = schemeHierarchyRepository.findByNameFromLatestSchemeNotIncludingHeadingSymbols("A01N");
//         log.debug("\nsymbol {} \ntitle xml = {}  \ngrammar = {}", 
//        		 symbol.getClassificationSymbolCode(),
//        		 symbol.getTitle(),
//        		 TitleConverter.toGrammar(adapter.parseTitleXmlDocument(symbol.getTitle()))); 
//        
//	}
}
