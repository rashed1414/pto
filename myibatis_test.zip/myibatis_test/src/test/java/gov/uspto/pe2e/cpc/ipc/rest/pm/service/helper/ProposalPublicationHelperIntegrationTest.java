package gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.DotLevelType;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ClassificationScheme;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.SchemeHierarchy;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ClassificationSchemeRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.DefinitionHierarchyRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.SchemeHierarchyRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.AdapterUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.SymbolStatusCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DefSectionItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.NAWItemEditRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PrivateProposalTreeStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.PublicationTreeStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SCTComponentChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SchemeChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.Note;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteParagraph;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteRawText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePart;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartRawText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartText;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionTitle;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.Text;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test-oraclelocal.xml" })
@TestPropertySource("classpath:oracle.properties") // this allows the integration test to override oracle properties without affecting spring factory
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalPublicationHelperIntegrationTest {

	@Inject
	private DatasetTestingService datasetTestingService;

	@Inject
	private ProposalService proposalService;

	@Inject
	private ProposalPublicationHelper proposalPublicationHelper;

	@Inject
	public ProposalValidationService proposalValidationService;

	@Inject
	private SchemeHierarchyRepository schemeHierarchyRepository;
	@Inject
	private DefinitionHierarchyRepository definitionHierarchyRepository;
	
	@Inject
	private ClassificationSchemeRepository classificationSchemeRepository;
	
	@Inject
	private EntityManager entityManager;

	@Resource(name = "documentAdapterConfig")
	private Map<String, String> documentAdapterConfig;

	@BeforeClass
	public static void setupClass() {
		System.setProperty("com.sun.xml.internal.stream.XMLInputFactoryImpl",
				"com.sun.xml.internal.stream.XMLInputFactoryImpl");
		System.setProperty("jakarta.xml.parsers.DocumentBuilderFactory",
				"com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");

	}

	@Before
	public void setUp() throws Exception {

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.7");
		version.setDefinitionXsdVersion("1.0");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

	}

	@Test
	@Transactional
	public void testNewSymbolAtMainGroup(){
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		sctItems.add(createSctItem("D99Z1/00", DotLevelType.fromIndentLevel(6), SchemeChangeType.N));
		sctItems.add(createSctItem("D99Z1/00", DotLevelType.fromIndentLevel(7), SchemeChangeType.N));
		sctItems.add(createSctItem("D99Z1/02", DotLevelType.fromIndentLevel(8), SchemeChangeType.N));

		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"), 487L,
				sctItems, "test", new Date());

		SchemeHierarchy s1 = schemeHierarchyRepository.findByCompositeId(487L, "D99Z1/00",7);
		Assert.assertNotNull(s1);
		Assert.assertTrue(s1.getParent().getClassificationSymbolCode().equals("D99Z1/00"));
		Assert.assertTrue(s1.getParent().getParent().getClassificationSymbolCode().equals("D99Z"));
	}

	@Test
	@Transactional
	public void testBuildPublication() {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		sctItems.add(createSctItem("G06K9/00", DotLevelType.fromIndentLevel(7), SchemeChangeType.N));
		sctItems.add(createSctItem("G06K1/001", DotLevelType.fromIndentLevel(9), SchemeChangeType.N));
//		sctItems.add(createSctItem("A01N65/99", DotLevelType.fromIndentLevel(9), SchemeChangeType.D));
		//sctItems.add(createSctItem("A01B1/02", DotLevelType.fromIndentLevel(8), SchemeChangeType.M));

		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"), 487L,
				sctItems, "test", new Date());
		
		ClassificationScheme scheme = classificationSchemeRepository.findById(487L).get();
		assertEquals(PublicationTreeStatus.ERROR, scheme.getClassificationSchemeStatus().getStatus());
		log.debug("error = {}", scheme.getClassificationSchemeStatus().getFailure());
		assertEquals("failed to find parent for symbol/indent =G06K9/00/7", scheme.getClassificationSchemeStatus().getFailure());
			long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		assertNotEquals(count, afterCount);
		assertEquals(5783651, afterCount);
		entityManager.flush();
		entityManager.clear();
		List<SchemeHierarchy> symbols = new ArrayList<SchemeHierarchy>();
//		schemeHierarchyRepository.findAll().forEach(symbols::add);
//		Collections.sort(symbols, new BeanComparator<>("createTs"));
//		Collections.reverse(symbols);
//		List<SchemeHierarchy> symbols = schemeHierarchyRepository.findByName(3L,  "A01N65/99");
		SchemeHierarchy s1 = schemeHierarchyRepository.findByCompositeId(487L, "G06K9/00",9);
		if (s1 != null) {
			symbols.add(s1);
		}
		assertTrue(symbols.size() > 0);
		int i = 0;
		for (SchemeHierarchy symbol: symbols) {
			log.debug("id = {} name = {} status = {} scheme = {} indent = {}", symbol.getId(), 
					symbol.getClassificationSymbolCode(), symbol.getStatusCode(), 
					symbol.getClassificationScheme().getId(), symbol.getIndentLevel());
			i++;
			if (i > 30) {
				break;
			}
		}
		SchemeHierarchy symbol = symbols.get(0);
//		log.debug("definition content = {}", 
//				symbol.getDefinitionHierarchies().iterator().next().getDefinition());
		assertEquals(SymbolStatusCode.PROPOSED_DELETED, symbol.getStatusCode());
		
		PrivateProposalTreeStatus treeStatus =  proposalService.getPublicationTreeStatus(GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"));
		assertNotNull(treeStatus);
		assertEquals(PublicationTreeStatus.COMPLETE, treeStatus.getStatus());
	}

	@Test
	@Transactional
	public void testBuildPublication_verifyNotes() {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		RevisionChangeItemRequest item = createSctItem("G06K9/00", DotLevelType.fromIndentLevel(7), SchemeChangeType.N);
		item.getNoteItems().add(createNoteItem());
		sctItems.add(item);


		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"), 487L,
				sctItems, "test", new Date());
		
		ClassificationScheme scheme = classificationSchemeRepository.findById(487L).get();
		assertEquals(PublicationTreeStatus.COMPLETE, scheme.getClassificationSchemeStatus().getStatus());
		log.debug("error = {}", scheme.getClassificationSchemeStatus().getFailure());
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		assertNotEquals(count, afterCount);
		entityManager.flush();
		entityManager.clear();
		List<SchemeHierarchy> symbols = new ArrayList<SchemeHierarchy>();
//		schemeHierarchyRepository.findAll().forEach(symbols::add);
//		Collections.sort(symbols, new BeanComparator<>("createTs"));
//		Collections.reverse(symbols);
//		List<SchemeHierarchy> symbols = schemeHierarchyRepository.findByName(3L,  "A01N65/99");
		SchemeHierarchy s1 = schemeHierarchyRepository.findByCompositeId(487L, "G06K9/00",7);
		assertEquals("<notes-and-warnings dateRevised=\"\"><note><note-paragraph><text>This is test not text</text></note-paragraph></note></notes-and-warnings>", s1.getNotesAndWarnings());
		if (s1 != null) {
			symbols.add(s1);
		}
		assertTrue(symbols.size() > 0);
		int i = 0;
		for (SchemeHierarchy symbol: symbols) {
			log.debug("id = {} name = {} status = {} scheme = {} indent = {}", symbol.getId(), 
					symbol.getClassificationSymbolCode(), symbol.getStatusCode(), 
					symbol.getClassificationScheme().getId(), symbol.getIndentLevel());
			i++;
			if (i > 30) {
				break;
			}
		}
		
	}

	@Test
	@Transactional
	public void testBuildPublication_verifyNotes2() throws JsonParseException, JsonMappingException, IOException {
		long count = schemeHierarchyRepository.count();
		ObjectMapper mapper = new ObjectMapper();
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("data/json/publishme.json")) {
		List<RevisionChangeItemRequest> sctItems = mapper.readValue(is, new TypeReference<List<RevisionChangeItemRequest>>() {
		});
		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"), 487L,
				sctItems, "test", new Date());
		
		ClassificationScheme scheme = classificationSchemeRepository.findById(487L).get();
		assertEquals(PublicationTreeStatus.COMPLETE, scheme.getClassificationSchemeStatus().getStatus());
		log.debug("error = {}", scheme.getClassificationSchemeStatus().getFailure());
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		assertNotEquals(count, afterCount);
		entityManager.flush();
		entityManager.clear();
			System.exit(-1);
		}
		
	}
	
	@Rollback(false) 
	@Test
	@Transactional
	public void testBuildPublication_withNotesAndDefs() {
		
		Long classificationId = 492L;
		UUID proposalGUID = UUID.fromString("2380d855-5414-4c2b-80fb-0b98ff9be954");

    	int deleted = definitionHierarchyRepository.deleteByClassificationScheme(classificationId);
    	deleted = schemeHierarchyRepository.deleteByClassificationScheme(classificationId);
   
    	long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		RevisionChangeItemRequest item = createSctItem("A01N1/00", DotLevelType.fromIndentLevel(7), SchemeChangeType.N);
		item.getNoteItems().add(createNoteItem());
		item.getDefinitionItems().add(createDefinition());
		sctItems.add(item);

		proposalPublicationHelper.buildPublication(proposalGUID, classificationId,
				sctItems, "test", new Date());
		
		ClassificationScheme scheme = classificationSchemeRepository.findById(classificationId).get();
		assertEquals(PublicationTreeStatus.COMPLETE, scheme.getClassificationSchemeStatus().getStatus());
		log.debug("error = {}", scheme.getClassificationSchemeStatus().getFailure());
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		assertNotEquals(count, afterCount);
//		entityManager.flush();
//		entityManager.clear();
		List<SchemeHierarchy> symbols = new ArrayList<SchemeHierarchy>();
		SchemeHierarchy s1 = schemeHierarchyRepository.findByCompositeId(classificationId, item.getSymbolName(),7);
		assertEquals("<notes-and-warnings dateRevised=\"\"><note type=\"note\"><note-paragraph><text>This is test not text</text></note-paragraph></note></notes-and-warnings>", s1.getNotesAndWarnings());
		if (s1 != null) {
			symbols.add(s1);
		}
		log.debug("scheme hierarchy id = {}, symbolname = {} and indent = {}", 
				s1.getId(), s1.getClassificationSymbolCode(), s1.getIndentLevel());
		
		assertTrue(symbols.size() > 0);
		assertEquals("<definition-item><classification-symbol>A01N1/00</classification-symbol><definition-title><text>Test</text></definition-title><references><application-references/></references></definition-item>", 
				new ArrayList<>(s1.getDefinitionHierarchies()).get(0).getDefinition());
		
		
		
	}

	
	@Test
	@Transactional
	public void testBuildPublication_verifyDefinitions() {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		RevisionChangeItemRequest item = createSctItem("G06K9/00", DotLevelType.fromIndentLevel(7), SchemeChangeType.N);
		item.getDefinitionItems().add(createDefinition());
		
		sctItems.add(item);


		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"), 487L,
				sctItems, "test", new Date());
		
		ClassificationScheme scheme = classificationSchemeRepository.findById(487L).get();
		assertEquals(PublicationTreeStatus.COMPLETE, scheme.getClassificationSchemeStatus().getStatus());
		log.debug("error = {}", scheme.getClassificationSchemeStatus().getFailure());
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		assertNotEquals(count, afterCount);
		entityManager.flush();
		entityManager.clear();
		List<SchemeHierarchy> symbols = new ArrayList<SchemeHierarchy>();
//		schemeHierarchyRepository.findAll().forEach(symbols::add);
//		Collections.sort(symbols, new BeanComparator<>("createTs"));
//		Collections.reverse(symbols);
//		List<SchemeHierarchy> symbols = schemeHierarchyRepository.findByName(3L,  "A01N65/99");
		SchemeHierarchy s1 = schemeHierarchyRepository.findByCompositeId(487L, "G06K9/00",7);
		// <definition-item><classification-symbol>G06K9/00</classification-symbol><definition-title><media>Test</media></definition-title><references><application-references/></references></definition-item>
		String defXml = new ArrayList<>(s1.getDefinitionHierarchies()).get(0).getDefinition();
		assertTrue(!defXml.contains("<children>"));
		assertTrue(!defXml.contains("xmlns="));
		assertTrue(!defXml.contains("date-revised"));
		assertTrue(defXml.contains("Test"));
		assertEquals("<definition-item><classification-symbol>G06K9/00</classification-symbol><definition-title><text>Test</text></definition-title><references><application-references/></references></definition-item>", 
				defXml);
		
		if (s1 != null) {
			symbols.add(s1);
		}
		assertTrue(symbols.size() > 0);
		int i = 0;
		for (SchemeHierarchy symbol: symbols) {
			log.debug("id = {} name = {} status = {} scheme = {} indent = {}", symbol.getId(), 
					symbol.getClassificationSymbolCode(), symbol.getStatusCode(), 
					symbol.getClassificationScheme().getId(), symbol.getIndentLevel());
			i++;
			if (i > 30) {
				break;
			}
		}
		
	}

	private DefSectionItemEditRequest createDefinition() {
		Text node = new Text();
		node.setValue("Test");
		DefinitionTitle title = new DefinitionTitle();
		title.getChildren().add(node);
		DefSectionItemEditRequest def = new DefSectionItemEditRequest();
		def.setChangeType(SCTComponentChangeType.N);
		def.setDefinitionTitle(title);
		return def;
	}

	private NAWItemEditRequest createNoteItem() {
		
		StringWriter result = new StringWriter();
		
		NoteRawText raw = new NoteRawText();
		raw.setContent("This is test not text");
		Note n = new Note();
		n.setNoteOrWarningType(NoteType.WARNING.name());
	
		NoteText text = new NoteText();
		text.getChildren().add(raw);
		NoteParagraph p = new NoteParagraph();
		p.getChildren().add(text);
		n.getChildren().add(p);
		NAWItemEditRequest nawEdit = new NAWItemEditRequest();
		nawEdit.setChangeType(SCTComponentChangeType.N);
		nawEdit.setNoteCategory(NoteType.NOTE);
		nawEdit.setNoteItem(p);
		
//		try {
//			NotesAndWarnings naw  = new NotesAndWarnings();
//			naw.getChildren().add(n);
//			
//			NoteRawText raw2 = new NoteRawText();
//			raw2.setContent("This is the text for for the second note");
//			NoteText text2 = new NoteText();
//			text2.getChildren().add(raw2);
//			Note n2 = new Note();
//			n2.setNoteOrWarningType(NoteType.NOTE.name());
//			
//			NoteParagraph np2 = new NoteParagraph();
//			np2.getChildren().add(text2);
//			n2.getChildren().add(np2);
//			
//			
//			
//			naw.getChildren().add(n2);
//			
//			DocumentAdapter.CONTEXT.createMarshaller().marshal(naw, result);
//			} catch (Exception e) {
//				log.debug("EXC = ",e);
//			}
//			log.debug("Note json = {} / xml {}", JsonUtils.toJsonOrStacktrace(n), 
//					result.toString());
//		
		return nawEdit;
	}

	@Test
	@Transactional
	public void testDetermineParent() {
		SchemeHierarchy parent = proposalPublicationHelper.determineParentForNewSymbol("G06K9/00", DotLevelType.GUIDANCEHEADING.getIndentLevel(), 486L, 487L);
		assertNotNull(parent);
	}

	/**
	 * this case does not work because there is no A01B6/00 at level 7 (ostensibly 
	 * using A01B5/00 as its level 6 parent) for it to attach to
	 */
	@Test
	@Transactional
	public void testDetermineParent_A01B6_001() {
		
		
		SchemeHierarchy parent = proposalPublicationHelper.determineParentForNewSymbol("A01B6/001", DotLevelType.SUBGROUP.getIndentLevel(), 486L, 487L);
		// this is now returning null.  I am not sure if that is because of my code changes or bc the code was always in error
		log.debug("perent == {}", parent);
		assertNotNull(parent);
		assertEquals("A01B5/00", parent.getClassificationSymbolCode());
		assertEquals((Integer)7, parent.getIndentLevel());
	}
	
	private RevisionChangeItemRequest createSctItem(String symbolName, DotLevelType dotLevel, SchemeChangeType changeType) {
		RevisionChangeItemRequest item = new RevisionChangeItemRequest();
		item.setSymbolName(SymbolName.normalize(symbolName));
		String titleXmlFile = "data/xml/fragments/A01D_title_fragment.xml";
		TitlePartTree title = null;
		try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(titleXmlFile)) {
			assertNotNull("failed to find " + titleXmlFile+" for symbol "+symbolName, is);
			String baseTitle = IOUtils.toString(is);

			SchemeHierarchy dbSymbol = schemeHierarchyRepository
					.findByNameFromLatestSchemeNotIncludingHeadingSymbols(symbolName);

			if (dbSymbol != null) {
				String xml = dbSymbol.getTitle();
				title = (TitlePartTree) AdapterUtils.latest(documentAdapterConfig).mapTitleXmlDocument(xml);

			} else {
				title = (TitlePartTree) AdapterUtils.latest(documentAdapterConfig).mapTitleXmlDocument(baseTitle);
			}
			TitlePartRawText raw = new TitlePartRawText();
			raw.setContent("This is a minor edit forcing difference in case of testing publication");

			TitlePartText txt = new TitlePartText();
			txt.getChildren().add(raw);
			title.getChildren().add((TitlePart)txt);
		} catch (Exception e) {
			log.debug("exc = ", e);
		}
		item.setTitle(title);
		item.setDotLevel(dotLevel.getDisplayValue());
		item.setEntryType(changeType.name());
//		DefSectionItemEditRequest def =  new DefSectionItemEditRequest();
//		def.setApplicationReferences(new ApplicationReferences());
//		def.getApplicationReferences().setSuggestionStart("123");
//
//		def.getApplicationReferences().setSuggestionEnd("123");
//		item.getDefinitionItems().add(def);
		return item;
	}
	
	@Test
	public void testLevelMapping() {
		RevisionChangeItem sctItem = new RevisionChangeItem();
		sctItem.setDotLevel("Subclass");
		try {
			DotLevelType dot = DotLevelType.fromDisplay(sctItem.getDotLevel());
			assertNotNull(dot);
			assertEquals(5, dot.getIndentLevel());
		} catch (Exception e) {
			fail();
		}
	}
	
	
	@Transactional
	@Test
	@Rollback(false) 
	public void testExport_DE65846() throws IOException {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		//sctItems.add(createSctItem("A01N65/26", DotLevelType.fromIndentLevel(9), SchemeChangeType.C));
		//sctItems.add(createSctItem("A01B1/02", DotLevelType.fromIndentLevel(8), SchemeChangeType.M));

		
		
		sctItems.add(createSctItem("G01B19/00", 
				DotLevelType.fromIndentLevel(7), 
				SchemeChangeType.C));
//		sctItems.add(createSctItem("G06K9/00", 
//				DotLevelType.fromIndentLevel(8), 
//				SchemeChangeType.C));

//		GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"), 487L,
//		sctItems, "test", new Date()		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("84a711b7861544f7bd46904270087517"), 487L,
				sctItems, "test", new Date());
		
		
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		entityManager.flush();
		entityManager.clear();
		List<SchemeHierarchy> symbols = new ArrayList<SchemeHierarchy>();

		SchemeHierarchy sibling = schemeHierarchyRepository.findByCompositeId(487L, "G01B19/00",7);
		assertNotNull(sibling);
		assertEquals("G01B19/00", sibling.getClassificationSymbolCode());
		
		File directory =  new File("target/export_test_case");
		if (!directory.exists() ) {
			directory.mkdir();
		}
		
				
	}

	
	@Transactional
	@Test
	@Rollback(false) 
	public void testExport_orphanednode_exception() throws IOException {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		//sctItems.add(createSctItem("A01N65/26", DotLevelType.fromIndentLevel(9), SchemeChangeType.C));
		//sctItems.add(createSctItem("A01B1/02", DotLevelType.fromIndentLevel(8), SchemeChangeType.M));

		
		
		sctItems.add(createSctItem("A01B1/02", 
				DotLevelType.fromIndentLevel(10), 
				SchemeChangeType.C));
//		sctItems.add(createSctItem("G06K9/00", 
//				DotLevelType.fromIndentLevel(8), 
//				SchemeChangeType.C));

//		GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"), 487L,
//		sctItems, "test", new Date()		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("84a711b7861544f7bd46904270087517"), 487L,
				sctItems, "test", new Date());
		entityManager.flush();
		entityManager.clear();		
		
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);

	//	assertEquals(count, afterCount);
	}


	@Transactional
	@Test
	@Rollback(false) 
	public void testBuildPublicaiton_FQT_missingdefs() throws IOException {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		//sctItems.add(createSctItem("A01N65/26", DotLevelType.fromIndentLevel(9), SchemeChangeType.C));
		//sctItems.add(createSctItem("A01B1/02", DotLevelType.fromIndentLevel(8), SchemeChangeType.M));

		RevisionChangeItemRequest item = createSctItem("A61K6/35", 
				DotLevelType.fromIndentLevel(9), 
				SchemeChangeType.M);
		item.getDefinitionItems().add(this.createDefinition());
		sctItems.add(item);

//		sctItems.add(createSctItem("G06K9/00", 
//				DotLevelType.fromIndentLevel(8), 
//				SchemeChangeType.C));

//		GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"), 487L,
//		sctItems, "test", new Date()		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("84a711b7861544f7bd46904270087517"), 487L,
				sctItems, "test", new Date());
		entityManager.flush();
		entityManager.clear();
		
		ClassificationScheme scheme = classificationSchemeRepository.findById(487L).get();
		log.debug("found scheme {} status={} failureTx={}", scheme.getId(), 
				scheme.getClassificationSchemeStatus().getStatus(), 
				scheme.getClassificationSchemeStatus().getFailure() );

		SchemeHierarchy s1 = schemeHierarchyRepository.findByCompositeId(487L, "A61K6/35",9);
		assertNotNull(s1);
		assertThat(s1.getDefinitionHierarchies(), is(not(empty())));

		s1 = schemeHierarchyRepository.findByCompositeId(487L, "A61K6/30",8);
		assertNotNull(s1);
		assertThat(s1.getDefinitionHierarchies(), is(not(empty())));
		
		
		s1 = schemeHierarchyRepository.findByCompositeId(487L, "A61K",5);
		assertNotNull(s1);
		assertThat(s1.getDefinitionHierarchies(), is(not(empty())));

//		long afterCount = schemeHierarchyRepository.count();
//		log.debug("preCount={} / afterCount={}", count, afterCount);

	//	assertEquals(count, afterCount);
	}

	@Transactional
	@Test
	@Rollback(false) 
	public void testBuildPublicaiton_definition_constraint_violation() throws IOException {
		long count = schemeHierarchyRepository.count();
		ObjectMapper jsonMapper = new ObjectMapper();
		jsonMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("data/json/publishme_definition_constraint.json");
		
		List<RevisionChangeItemRequest> sctItems = jsonMapper.readValue(is, new TypeReference<List<RevisionChangeItemRequest>>() {});
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("84a711b7861544f7bd46904270087517"), 487L,
				sctItems, "test", new Date());
		entityManager.flush();
		entityManager.clear();
		
		ClassificationScheme scheme = classificationSchemeRepository.findById(487L).get();
		log.debug("found scheme {} status={} failureTx={}", scheme.getId(), 
				scheme.getClassificationSchemeStatus().getStatus(), 
				scheme.getClassificationSchemeStatus().getFailure() );
//		A01B22/00

		
//		SchemeHierarchy s1 = schemeHierarchyRepository.findByCompositeId(487L, "A61K6/35",9);
//		assertNotNull(s1);
//		assertThat(s1.getDefinitionHierarchies(), is(not(empty())));
//
//		s1 = schemeHierarchyRepository.findByCompositeId(487L, "A61K6/30",8);
//		assertNotNull(s1);
//		assertThat(s1.getDefinitionHierarchies(), is(not(empty())));
//		
//		
//		s1 = schemeHierarchyRepository.findByCompositeId(487L, "A61K",5);
//		assertNotNull(s1);
//		assertThat(s1.getDefinitionHierarchies(), is(not(empty())));
//
////		long afterCount = schemeHierarchyRepository.count();
////		log.debug("preCount={} / afterCount={}", count, afterCount);
//
//	//	assertEquals(count, afterCount);
	}

	@Transactional
	@Test
	@Rollback(false) 
	public void testBuildPublicaiton_neverreturnings() throws IOException {
		ObjectMapper jsonMapper = new ObjectMapper();
		jsonMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("data/json/publishme_sy.json");
		
		List<RevisionChangeItemRequest> sctItems = jsonMapper.readValue(is, new TypeReference<List<RevisionChangeItemRequest>>() {});
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("84a711b7861544f7bd46904270087517"), 487L,
				sctItems, "test", new Date());
		ClassificationScheme scheme = classificationSchemeRepository.findById(487L).get();
		log.debug("found scheme {} status={} failureTx={}", scheme.getId(), 
				scheme.getClassificationSchemeStatus().getStatus(), 
				scheme.getClassificationSchemeStatus().getFailure() );

		assertEquals(PublicationTreeStatus.COMPLETE, scheme.getClassificationSchemeStatus().getStatus());

		assertThat(scheme.getClassificationSchemeStatus().getFailure(), is(emptyOrNullString()));
	}

	
	@Transactional
	@Test
	@Rollback(false) 
	public void testBuildPublication_nonuniqueResults() throws IOException {
		ObjectMapper jsonMapper = new ObjectMapper();
		jsonMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("data/json/publishme_nonunique.json");
		
		List<RevisionChangeItemRequest> sctItems = jsonMapper.readValue(is, new TypeReference<List<RevisionChangeItemRequest>>() {});
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("84a711b7861544f7bd46904270087517"), 487L,
				sctItems, "test", new Date());
		entityManager.flush();
		entityManager.clear();
		ClassificationScheme scheme = classificationSchemeRepository.findById(487L).get();
		log.debug("found scheme {} status={} failureTx={}", scheme.getId(), 
				scheme.getClassificationSchemeStatus().getStatus(), 
				scheme.getClassificationSchemeStatus().getFailure() );

		assertEquals(PublicationTreeStatus.COMPLETE, scheme.getClassificationSchemeStatus().getStatus());

		log.debug("failure text {}", scheme.getClassificationSchemeStatus().getFailure());
		assertTrue(StringUtils.isEmpty(scheme.getClassificationSchemeStatus().getFailure()));
	}

	
	@Test
    public void testGetUIURL() {
		String revDbGuid = "674a3985fe354991a7ee36658e6022e5";
		String cpDbGuid ="84a711b7861544f7bd46904270087517";
		
		log.debug("found IDs = {} {}", GUIDUtils.fromDatabaseFormat(cpDbGuid), GUIDUtils.fromDatabaseFormat(revDbGuid));
		
		
	}

//	@Test
//	@Transactional
//	public void testDetermineParent() {
//		SchemeHierarchy parent = proposalPublicationHelper.determineParentForNewSymbol("G06K9/00",7, 486L, 487L);
//		// this is now returning null.  I am not sure if that is because of my code changes or bc the code was always in error
//		assertNotNull(parent);
//	}

	
	@Test
	@Transactional
	@Rollback(false)
	public void testBuildPublication_verifyDefinitions2() {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		RevisionChangeItemRequest item = createSctItem("A01B3/00", DotLevelType.fromIndentLevel(7), SchemeChangeType.N);
		item.getDefinitionItems().add(createDefinition());
		
		sctItems.add(item);


		
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"), 487L,
				sctItems, "test", new Date());
		
		ClassificationScheme scheme = classificationSchemeRepository.findById(487L).get();
		assertEquals(PublicationTreeStatus.COMPLETE, scheme.getClassificationSchemeStatus().getStatus());
		log.debug("error = {}", scheme.getClassificationSchemeStatus().getFailure());
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		List<SchemeHierarchy> symbols = new ArrayList<SchemeHierarchy>();
		SchemeHierarchy s1 = schemeHierarchyRepository.findByCompositeId(487L, "A01B3/00",7);
		assertNotNull(s1);
		
	
		s1 = schemeHierarchyRepository.findByCompositeId(487L, "A01B3/24",8);
		assertNotNull(s1);
		assertEquals("A01B3/24", s1.getClassificationSymbolCode());
		assertTrue(s1.getDefinitionExists());
		assertTrue(CollectionUtils.isNotEmpty(s1.getDefinitionHierarchies()));
		String defXml = new ArrayList<>(s1.getDefinitionHierarchies()).get(0).getDefinition();
		log.debug("xml found ", defXml);
//		assertTrue(!defXml.contains("<children>"));
//		assertTrue(!defXml.contains("xmlns="));
//		assertTrue(!defXml.contains("date-revised"));
//		assertTrue(defXml.contains("Test"));
		
		
	
		
	}

	@Test
	@Transactional
	@Rollback(false)
	public void testBuildPublication_withdefinitions3() {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		RevisionChangeItemRequest item = null;
		//createSctItem("B01B1/00", DotLevelType.fromIndentLevel(6), SchemeChangeType.N);
//		item.getDefinitionItems().add(createDefinition());
		
		//sctItems.add(item);
		item = createSctItem("B01B1/00", DotLevelType.fromIndentLevel(7), SchemeChangeType.N);
		sctItems.add(item);

		item = createSctItem("B01B1/005", DotLevelType.fromIndentLevel(8), SchemeChangeType.N);
		sctItems.add(item);

		item = createSctItem("B01B1/02", DotLevelType.fromIndentLevel(8), SchemeChangeType.N);
		sctItems.add(item);
	
		item = createSctItem("B01B1/04", DotLevelType.fromIndentLevel(9), SchemeChangeType.N);
		sctItems.add(item);

		item = createSctItem("B01B1/06", DotLevelType.fromIndentLevel(8), SchemeChangeType.N);
		sctItems.add(item);

		item = createSctItem("B01B1/08", DotLevelType.fromIndentLevel(8), SchemeChangeType.N);
		sctItems.add(item);

		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"), 487L,
				sctItems, "test", new Date());
		
		ClassificationScheme scheme = classificationSchemeRepository.findById(487L).get();
		assertEquals(PublicationTreeStatus.COMPLETE, scheme.getClassificationSchemeStatus().getStatus());
		log.debug("error = {}", scheme.getClassificationSchemeStatus().getFailure());
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		List<SchemeHierarchy> symbols = new ArrayList<SchemeHierarchy>();
		SchemeHierarchy s1 = null; 		
	
		s1 = schemeHierarchyRepository.findByCompositeId(487L, "B01B1/04",9);
		assertNotNull(s1);
		assertEquals("B01B1/04", s1.getClassificationSymbolCode());
		assertFalse(s1.getDefinitionExists());
		assertTrue(CollectionUtils.isEmpty(s1.getDefinitionHierarchies()));
//		String defXml = new ArrayList<>(s1.getDefinitionHierarchies()).get(0).getDefinition();
//		log.debug("xml found ", defXml);
//		assertTrue(!defXml.contains("<children>"));
//		assertTrue(!defXml.contains("xmlns="));
//		assertTrue(!defXml.contains("date-revised"));
//		assertTrue(defXml.contains("Test"));
		
		
	
		
	}

	@Test
	@Transactional
	@Rollback(false)
	public void testBuildPublication_withdefinitions4() {
		long count = schemeHierarchyRepository.count();
		List<RevisionChangeItemRequest> sctItems = new ArrayList<>();
		RevisionChangeItemRequest item = null;
		//createSctItem("B01B1/00", DotLevelType.fromIndentLevel(6), SchemeChangeType.N);
//		item.getDefinitionItems().add(createDefinition());
		
		//sctItems.add(item);
		item = createSctItem("A61K2035/11", DotLevelType.fromIndentLevel(8), SchemeChangeType.M);
		item.getDefinitionItems().add(createDefinition());
		sctItems.add(item);
		
		assertTrue(CollectionUtils.isNotEmpty(item.getDefinitionItems()));


		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("d12ccf4237324d08b7dcc28156875246"), 487L,
				sctItems, "test", new Date());
		
		ClassificationScheme scheme = classificationSchemeRepository.findById(487L).get();
		assertEquals(PublicationTreeStatus.COMPLETE, scheme.getClassificationSchemeStatus().getStatus());
		log.debug("error = {}", scheme.getClassificationSchemeStatus().getFailure());
		long afterCount = schemeHierarchyRepository.count();
		log.debug("preCount={} / afterCount={}", count, afterCount);
		List<SchemeHierarchy> symbols = new ArrayList<SchemeHierarchy>();
		SchemeHierarchy s1 = null; 		
	
		s1 = schemeHierarchyRepository.findByCompositeId(487L, "A61K2035/11",8);
		assertNotNull(s1);
		assertEquals("A61K2035/11", s1.getClassificationSymbolCode());
		assertTrue(s1.getDefinitionExists());
		assertTrue(CollectionUtils.isNotEmpty(s1.getDefinitionHierarchies()));
		
		
	
		
	}
	
	@Transactional
	@Test
	@Rollback(false) 
	public void testBuildPublicaiton_definition_definitionTitle() throws IOException {
		long count = schemeHierarchyRepository.count();
		ObjectMapper jsonMapper = new ObjectMapper();
		jsonMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("data/json/publishme_definition_with_title.json");
		
		List<RevisionChangeItemRequest> sctItems = jsonMapper.readValue(is, new TypeReference<List<RevisionChangeItemRequest>>() {});
		proposalPublicationHelper.buildPublication(GUIDUtils.fromDatabaseFormat("014d6dea73bf44b98db4097f74721828"), 534L,
				sctItems, "test", new Date());
		entityManager.flush();
		entityManager.clear();
		
		ClassificationScheme scheme = classificationSchemeRepository.findById(534L).get();
		log.debug("found scheme {} status={} failureTx={}", scheme.getId(), 
				scheme.getClassificationSchemeStatus().getStatus(), 
				scheme.getClassificationSchemeStatus().getFailure() );
	}
	
}
