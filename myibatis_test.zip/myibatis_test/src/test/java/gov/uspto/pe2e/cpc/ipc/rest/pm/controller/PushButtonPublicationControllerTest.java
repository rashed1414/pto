package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ProposalSourceMapping;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.GSDConflictStatistics;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.GlobalSubclassImpactedMaingroupsResponse;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.PBPLookupUserRole;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.PBPProjectRevisionStatisticsResponse;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.PBPProjectStatistics;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.PBPProjectType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.PBPProposalVersionDetails;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.PBPSDCTStatistics;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.PBPSubClassDetailsResponse;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.PBPSubclassItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.PBPSubclassProposal;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SchemeChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.pm.enumeration.ProjectTypes;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;


@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml"})
@NotThreadSafe
@Category(NotThreadSafe.class)
public class PushButtonPublicationControllerTest {
  //  private static final java.util.logging.Logger log = LoggerFactory.getLogger(PushButtonPublicationControllerTest.class);
    @Inject
	private PushButtonPublicationController pushButtonPublicationController;
    @Inject
    private DatasetTestingService datasetTestingService;

    @Test
    @Transactional
    public void testGetPbpSubclassList() throws ParseException {

        ResponseEntity<List<PBPSubclassItem>> resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, null, null, null);

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());

        List<PBPSubclassItem> list = resp.getBody();
        list = list.stream().filter(x -> x.getSubclassName().equals("A61K")).collect(Collectors.toList());

        List<PBPProposalVersionDetails> proposalList = list.get(0).getPbpProposalVersionDetails();
        assertNotNull(proposalList);
        assertEquals(2, proposalList.size());
        assertEquals("XX11002", proposalList.get(0).getProposalDisplayName());
        assertEquals("MP", proposalList.get(0).getProjectType());
        assertEquals("CPC", proposalList.get(0).getProjectSource());
        assertEquals("A", proposalList.get(0).getProjectPhase());
        assertEquals(1, proposalList.get(0).getVersionId());
        assertEquals("A61K31/00", proposalList.get(0).getReferenceSymbol());
        assertEquals("M", proposalList.get(0).getEntryType());

        assertEquals("Test Title", proposalList.get(0).getNewTitleText());
        assertEquals("Test Warning", proposalList.get(0).getNewWarningText());
        assertEquals("Test Note", proposalList.get(0).getNewNoteText());
        assertEquals("Test Definition", proposalList.get(0).getNewDefinitionText());

        assertEquals("May 2023", proposalList.get(0).getSchemeVersion());
        assertEquals(new SimpleDateFormat("yyyy-MM-dd").parse("2022-05-10"), proposalList.get(0).getSchemeReleaseDate());

        //Validate indicators
        Map<String, List<PBPSubclassItem>> map = resp.getBody().stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));
        PBPSubclassItem a61k = map.get("A61K").get(0);
        PBPSubclassItem b22f = map.get("B22F").get(0);
        PBPSubclassItem astb22 = map.get("*B22").get(0);
        PBPSubclassItem h05b = map.get("H05B").get(0);
        PBPSubclassItem h02b = map.get("H02B").get(0);

        assertTrue(a61k.isDefinitionChangeIndicator());
        assertTrue(a61k.isSchemeChangeIndicator());

        assertFalse(b22f.isDefinitionChangeIndicator());
        assertTrue(b22f.isSchemeChangeIndicator());

        assertTrue(astb22.isDefinitionChangeIndicator());
        assertFalse(astb22.isSchemeChangeIndicator());

        assertFalse(h05b.isDefinitionChangeIndicator());
        assertFalse(h05b.isSchemeChangeIndicator());

        assertFalse(h02b.isDefinitionChangeIndicator());
        assertFalse(h02b.isSchemeChangeIndicator());

    }

    @Test
    @Transactional
    public void testGetPbpSubclassList_filterBySchemeRelease() throws ParseException {

        ResponseEntity<List<PBPSubclassItem>> resp = pushButtonPublicationController
                .getPbpSubclassList(Collections.singletonList("May 2023"), null, null, null, null, null, null, null);

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());

        List<PBPSubclassItem> list = resp.getBody();
        //assertEquals("A", list.get(0).getSectionCode());
		PBPSubclassItem itemA61K = list.stream().filter(i -> i.getSubclassName().equals("A61K")).findFirst()
				.orElse(null);
		assertNotNull(itemA61K);

        List<PBPProposalVersionDetails> proposalList = itemA61K.getPbpProposalVersionDetails();
        assertNotNull(proposalList);
        assertEquals(1, proposalList.size());
        assertEquals("XX11002", proposalList.get(0).getProposalDisplayName());
        assertEquals("MP", proposalList.get(0).getProjectType());
        assertEquals("CPC", proposalList.get(0).getProjectSource());
        assertEquals("A", proposalList.get(0).getProjectPhase());
        assertEquals(1, proposalList.get(0).getVersionId());
        assertEquals("A61K31/00", proposalList.get(0).getReferenceSymbol());
        assertEquals("M", proposalList.get(0).getEntryType());

        assertEquals("Test Title", proposalList.get(0).getNewTitleText());
        assertEquals("Test Warning", proposalList.get(0).getNewWarningText());
        assertEquals("Test Note", proposalList.get(0).getNewNoteText());
        assertEquals("Test Definition", proposalList.get(0).getNewDefinitionText());

        assertEquals("May 2023", proposalList.get(0).getSchemeVersion());
        assertEquals(new SimpleDateFormat("yyyy-MM-dd").parse("2022-05-10"), proposalList.get(0).getSchemeReleaseDate());

    }

    @Test
    @Transactional
    public void testGetPbpSubclassList_filterByProjectType() {

        ResponseEntity<List<PBPSubclassItem>> resp = pushButtonPublicationController
                .getPbpSubclassList(null, ProposalTypeCode.RP, null, null, null, null, null, null);

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());

        Map<String, List<PBPSubclassItem>> map = resp.getBody().stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("*B22").get(0).getPbpProposalVersionDetails());
        assertNotNull(map.get("B22F").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("A61K").get(0).getPbpProposalVersionDetails()));


    }

    @Test
    @Transactional
    public void testGetPbpSubclassList_filterByProjectSource() {

        ResponseEntity<List<PBPSubclassItem>> resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, ProposalSourceMapping.IPC, null, null, null, null, null);

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());

        List<PBPSubclassItem> list = resp.getBody();
        Map<String, List<PBPSubclassItem>> map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("H02B").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("A61K").get(0).getPbpProposalVersionDetails()));

    }

    @Test
    @Transactional
    public void testGetPbpSubclassList_filterByIpcTech() {

        ResponseEntity<List<PBPSubclassItem>> resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, "Electrical", null, null, null, null);

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());

        List<PBPSubclassItem> list = resp.getBody();
        Map<String, List<PBPSubclassItem>> map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("B22F").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("A61K").get(0).getPbpProposalVersionDetails()));

    }

    @Test
    @Transactional
    public void testGetPbpSubclassList_filterByUSTech() {

        ResponseEntity<List<PBPSubclassItem>> resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, "Mechanical", null, null, null);

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());

        List<PBPSubclassItem> list = resp.getBody();
        Map<String, List<PBPSubclassItem>> map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("A61K").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));

    }

    @Test
    @Transactional
    public void testGetPbpSubclassList_filterByEPTech() {

        ResponseEntity<List<PBPSubclassItem>> resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, "Mechanical", null, null);

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());

        List<PBPSubclassItem> list = resp.getBody();

        Map<String, List<PBPSubclassItem>> map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("B22F").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("A61K").get(0).getPbpProposalVersionDetails()));

    }

    @Test
    @Transactional
    public void testGetPbpSubclassList_filterUserRoleAndEmail() {

        ResponseEntity<List<PBPSubclassItem>> resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, null, PBPLookupUserRole.EP_CPBM_NM, "testcpbm@epo.gov");

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());
        List<PBPSubclassItem> list = resp.getBody();
        Map<String, List<PBPSubclassItem>> map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("A61K").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));

        resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, null, PBPLookupUserRole.US_RECLASS_MGR_NM, "testreclassmgr@uspto.gov");

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());
        list = resp.getBody();

        map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("A61K").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));

        resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, null, PBPLookupUserRole.EP_RECLASS_MGR_NM, "testreclassmgr@epo.gov");

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());
        list = resp.getBody();
        map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("A61K").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));


        resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, null, PBPLookupUserRole.PUB_WRITER_EDITOR_NM, "testpubwriter@uspto.gov");

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());
        list = resp.getBody();
        map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("A61K").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));


        resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, null, PBPLookupUserRole.PUB_WRITER_EDITOR_NM, "testpubspecialist@uspto.gov");

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());
        list = resp.getBody();
        map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("A61K").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));


        resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, null, PBPLookupUserRole.PUB_WRITER_EDITOR_NM, "testpubmgr@uspto.gov");

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());
        list = resp.getBody();
        map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("A61K").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));


        resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, null, PBPLookupUserRole.US_SCE_NM, "msingh@uspto.gov");

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());
        list = resp.getBody();
        map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("A61K").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));

        resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, null, PBPLookupUserRole.US_QN, "examqn@uspto.gov");

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());
        list = resp.getBody();
        map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("A61K").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));

        resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, null, PBPLookupUserRole.US_QN, "examqn1@uspto.gov");

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());
        list = resp.getBody();
        map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("A61K").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));

        resp = pushButtonPublicationController
                .getPbpSubclassList(null, null, null, null, null, null, PBPLookupUserRole.US_QN, "examqn2@uspto.gov");

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());
        list = resp.getBody();
        map = list.stream()
                .collect(Collectors.groupingBy(PBPSubclassItem::getSubclassName));

        assertNotNull(map.get("A61K").get(0).getPbpProposalVersionDetails());
        assertTrue(CollectionUtils.isEmpty(map.get("H02B").get(0).getPbpProposalVersionDetails()));
        assertTrue(CollectionUtils.isEmpty(map.get("B22F").get(0).getPbpProposalVersionDetails()));

    }

    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1@uspto.gov", "myoung3@uspto.gov",
                Collections.singletonList(new BasicTestingGrantedAuthority("test@uspto.gov")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }

    @Test
    public void testGetProjectRevisionStatistics() {
        ResponseEntity<PBPProjectRevisionStatisticsResponse> resp = pushButtonPublicationController.getRevisionStatisticsResponse(Collections.singletonList("May 2023"), "F03D", ProposalTypeCode.MP, ProposalSourceMapping.CPC, "Chemistry", "Mechanical", "HBC- Healthcare, Biotech, Chemistry", PBPLookupUserRole.EP_CPBM_NM, "testcpbm@epo.gov");

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());

        List<PBPProjectStatistics> pbpProjectStatisticsList = resp.getBody().getProjectStatisticsList();
        Assert.assertEquals(pbpProjectStatisticsList.size(), 1);

        PBPProjectStatistics pbpProjectStatistics = pbpProjectStatisticsList.get(0);
        Assert.assertEquals(pbpProjectStatistics.getProjectSource(), "CPC");

        List<PBPProjectType> projectTypes = pbpProjectStatistics.getProjectTypes();
        Assert.assertEquals(projectTypes.size(), 1);

        PBPProjectType pbpProjectType = projectTypes.get(0);
        Assert.assertEquals(pbpProjectType.getName(), ProjectTypes.MP.name());
        Assert.assertEquals(pbpProjectType.getCount(), 2);
    }

    @Test
    public void testGetPbpSubclassSDCTStatistics_Test() {
        ResponseEntity<List<PBPSDCTStatistics>> resp = pushButtonPublicationController.getPbpSubclassSDCTStatistics("F03D", Collections.singletonList("May 2023"), ProposalTypeCode.MP, ProposalSourceMapping.CPC, "Chemistry", "Mechanical", "HBC- Healthcare, Biotech, Chemistry", PBPLookupUserRole.EP_CPBM_NM, null);

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        System.out.print("resp.getBody()" + resp.getBody());
        Assert.assertEquals(resp.getBody().size(), 9);
        List<PBPSDCTStatistics> pbpSDCTStatisticsList = resp.getBody();

        /* ChangeType: ALL */
        PBPSDCTStatistics pbpSDCTStatistics0 = pbpSDCTStatisticsList.get(0);
        Assert.assertEquals(pbpSDCTStatistics0.getChangesType(), "ALL");
        Assert.assertEquals(pbpSDCTStatistics0.getSymbolCount(), "6");
        Assert.assertEquals(pbpSDCTStatistics0.getNoteCount(), "4");
        Assert.assertEquals(pbpSDCTStatistics0.getWarningCount(), "4");
        Assert.assertEquals(pbpSDCTStatistics0.getDefinitionCount(), "4");

        /* ChangeType: U */
        PBPSDCTStatistics pbpSDCTStatistics1 = pbpSDCTStatisticsList.get(1);
        Assert.assertEquals(pbpSDCTStatistics1.getChangesType(), SchemeChangeType.U.value());
        Assert.assertEquals(pbpSDCTStatistics1.getSymbolCount(), "0");
        Assert.assertEquals(pbpSDCTStatistics1.getNoteCount(), "0");
        Assert.assertEquals(pbpSDCTStatistics1.getWarningCount(), "0");
        Assert.assertEquals(pbpSDCTStatistics1.getDefinitionCount(), "0");

        /* ChangeType: F */
        PBPSDCTStatistics pbpSDCTStatistics2 = pbpSDCTStatisticsList.get(2);
        Assert.assertEquals(pbpSDCTStatistics2.getChangesType(),  SchemeChangeType.F.value());
        Assert.assertEquals(pbpSDCTStatistics2.getSymbolCount(), "0");
        Assert.assertEquals(pbpSDCTStatistics2.getNoteCount(), "N/A");
        Assert.assertEquals(pbpSDCTStatistics2.getWarningCount(), "N/A");
        Assert.assertEquals(pbpSDCTStatistics2.getDefinitionCount(), "N/A");

        /* ChangeType: T */
        PBPSDCTStatistics pbpSDCTStatistics3 = pbpSDCTStatisticsList.get(3);
        Assert.assertEquals(pbpSDCTStatistics3.getChangesType(),  SchemeChangeType.T.value());
        Assert.assertEquals(pbpSDCTStatistics3.getSymbolCount(), "0");
        Assert.assertEquals(pbpSDCTStatistics3.getNoteCount(), "N/A");
        Assert.assertEquals(pbpSDCTStatistics3.getWarningCount(), "N/A");
        Assert.assertEquals(pbpSDCTStatistics3.getDefinitionCount(), "N/A");

        /* ChangeType: Q */
        PBPSDCTStatistics pbpSDCTStatistics4 = pbpSDCTStatisticsList.get(4);
        Assert.assertEquals(pbpSDCTStatistics4.getChangesType(),  SchemeChangeType.Q.value());
        Assert.assertEquals(pbpSDCTStatistics4.getSymbolCount(), "0");
        Assert.assertEquals(pbpSDCTStatistics4.getNoteCount(), "N/A");
        Assert.assertEquals(pbpSDCTStatistics4.getWarningCount(), "N/A");
        Assert.assertEquals(pbpSDCTStatistics4.getDefinitionCount(), "N/A");

        /* ChangeType: D */
        PBPSDCTStatistics pbpSDCTStatistics5 = pbpSDCTStatisticsList.get(5);
        Assert.assertEquals(pbpSDCTStatistics5.getChangesType(), SchemeChangeType.D.value());
        Assert.assertEquals(pbpSDCTStatistics5.getSymbolCount(), "0");
        Assert.assertEquals(pbpSDCTStatistics5.getNoteCount(), "0");
        Assert.assertEquals(pbpSDCTStatistics5.getWarningCount(), "0");
        Assert.assertEquals(pbpSDCTStatistics5.getDefinitionCount(), "0");

        /* ChangeType: C */
        PBPSDCTStatistics pbpSDCTStatistics6 = pbpSDCTStatisticsList.get(6);
        Assert.assertEquals(pbpSDCTStatistics6.getChangesType(), SchemeChangeType.C.value());
        Assert.assertEquals(pbpSDCTStatistics6.getSymbolCount(), "1");
        Assert.assertEquals(pbpSDCTStatistics6.getNoteCount(), "N/A");
        Assert.assertEquals(pbpSDCTStatistics6.getWarningCount(), "N/A");
        Assert.assertEquals(pbpSDCTStatistics6.getDefinitionCount(), "N/A");

        /* ChangeType: M */
        PBPSDCTStatistics pbpSDCTStatistics7 = pbpSDCTStatisticsList.get(7);
        Assert.assertEquals(pbpSDCTStatistics7.getChangesType(), SchemeChangeType.M.value());
        Assert.assertEquals(pbpSDCTStatistics7.getSymbolCount(), "2");
        Assert.assertEquals(pbpSDCTStatistics7.getNoteCount(), "2");
        Assert.assertEquals(pbpSDCTStatistics7.getWarningCount(), "2");
        Assert.assertEquals(pbpSDCTStatistics7.getDefinitionCount(), "2");

        /* ChangeType: N */
        PBPSDCTStatistics pbpSDCTStatistics8 = pbpSDCTStatisticsList.get(8);
        Assert.assertEquals(pbpSDCTStatistics8.getChangesType(), SchemeChangeType.N.value());
        Assert.assertEquals(pbpSDCTStatistics8.getSymbolCount(), "3");
        Assert.assertEquals(pbpSDCTStatistics8.getNoteCount(), "2");
        Assert.assertEquals(pbpSDCTStatistics8.getWarningCount(), "2");
        Assert.assertEquals(pbpSDCTStatistics8.getDefinitionCount(), "2");
    }
    
    @Test
	@Transactional
	public void testFindAllImpactedMainGroups() {

		ResponseEntity<GlobalSubclassImpactedMaingroupsResponse> resp = pushButtonPublicationController.findAllImpactedMainGroups("F03E", Collections.singletonList("May 2023"),
				ProposalTypeCode.MP, ProposalSourceMapping.CPC, "Chemistry", "Mechanical", "HBC- Healthcare, Biotech, Chemistry", PBPLookupUserRole.EP_CPBM_NM, null, false);
		assertNotNull(resp);
		assertEquals(HttpStatus.OK, resp.getStatusCode());
		List<String> definitions = resp.getBody().getDefinitions();
		List<String> scheme = resp.getBody().getScheme();
		assertEquals(1,  definitions.size());
		assertEquals(2,  scheme.size());
		assertEquals("H02B1/02", definitions.get(0));
		assertEquals("H02B1/02", scheme.get(0));

	}

    @Test
  	@Transactional
  	public void testFindAllImpactedMainGroups_isConflictFlagTrue() {

    	ResponseEntity<GlobalSubclassImpactedMaingroupsResponse> resp = pushButtonPublicationController.findAllImpactedMainGroups("F03F", Collections.singletonList("May 2023"),
				ProposalTypeCode.MP, ProposalSourceMapping.CPC, "Chemistry", "Mechanical", "HBC- Healthcare, Biotech, Chemistry", PBPLookupUserRole.EP_CPBM_NM, null, true);
		assertNotNull(resp);
		assertEquals(HttpStatus.OK, resp.getStatusCode());
		List<String> definitions = resp.getBody().getDefinitions();
		List<String> scheme = resp.getBody().getScheme();		
		assertEquals(2,  definitions.size());
		assertEquals(2,  scheme.size());
		assertEquals("H02B1/01", definitions.get(0));
		assertEquals("H02B1/01", scheme.get(0));
  	}


    @Test
	@Transactional
	public void testGetProposalsListForSubclass_isConflictFlagFalse() {

    	 ResponseEntity<Set<PBPSubclassProposal>> resp = pushButtonPublicationController
                 .getProposalListForSubclass(null, null, null, null, null, null, null, null, "A61K", false);

    	assertNotNull(resp);
		assertEquals(HttpStatus.OK, resp.getStatusCode());

		Set<PBPSubclassProposal> projects = resp.getBody();
		//This will only include distinct project list
		assertEquals(1,  projects.size());
	}

    @Test
    @Transactional
    public void testGetProposalsListForSubclass_isConflictFlagNull() {

        ResponseEntity<Set<PBPSubclassProposal>> resp = pushButtonPublicationController
                .getProposalListForSubclass(null, null, null, null, null, null, null, null, "A61K", null);

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());

        Set<PBPSubclassProposal> projects = resp.getBody();
        //This will only include distinct project list
        assertEquals(1,  projects.size());
    }

    @Test
    @Transactional
    public void testGetPbpSubclassConflictStatistics() {
        ResponseEntity<GSDConflictStatistics> resp = pushButtonPublicationController.getPbpSubclassConflictStatistics("B14J", Collections.singletonList("May 2023"), ProposalTypeCode.MP, ProposalSourceMapping.CPC, "Chemistry", "Mechanical", "HBC- Healthcare, Biotech, Chemistry", PBPLookupUserRole.EP_CPBM_NM, null);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertNotNull(resp.getBody());
        GSDConflictStatistics gsdConflictStatistics = resp.getBody();
        assertEquals(2,  gsdConflictStatistics.getDefinitionsConflictCount());
        assertEquals(2,  gsdConflictStatistics.getSymbolsConflictCount());
        assertEquals(2,  gsdConflictStatistics.getProjectsConflictCount());
    }
    
    
    @Test
    @Transactional
    public void testGetPbpSubclassDetails() {
       // ResponseEntity<PBPSubClassDetailsResponse> resp = pushButtonPublicationController.getPbpSubclassDetails("A01B", Collections.singletonList("May 2023"), ProposalTypeCode.MP, ProposalSourceMapping.CPC, "Chemistry", "Mechanical", "HBC- Healthcare, Biotech, Chemistry", PBPLookupUserRole.EP_CPBM_NM, null);
        ResponseEntity<PBPSubClassDetailsResponse> resp = pushButtonPublicationController.getPbpSubclassDetails("C01B", null, null, null, null, null, null, null, null);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertNotNull(resp.getBody());
        PBPSubClassDetailsResponse pbpSubClassDetailsResponse = resp.getBody();
        assertEquals("C01B", pbpSubClassDetailsResponse.getSubclass());
        assertEquals("24,3", pbpSubClassDetailsResponse.getMainGroups());
        assertEquals("1173,4", pbpSubClassDetailsResponse.getSymbols());
        assertEquals("253,0", pbpSubClassDetailsResponse.getDefinitions());
        assertEquals("4", pbpSubClassDetailsResponse.getProjectCount());
        assertEquals("2023.08", pbpSubClassDetailsResponse.getSchemeRelease());
        assertEquals("2023.12", pbpSubClassDetailsResponse.getLatestSchemeDef());
        assertEquals(true, pbpSubClassDetailsResponse.isLatestSchemeDistCopy());
        assertEquals(false, pbpSubClassDetailsResponse.isLatestSchemeGoldCopy());
        
    }
    @Test
    @Transactional
    public void testGetProposalListForSubclass() {
        ResponseEntity<Set<PBPSubclassProposal>> resp = pushButtonPublicationController.getProposalListForSubclass(null, null, null, null, null, null, null, null, "B14C", true);
        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertNotNull(resp.getBody());
        Set<PBPSubclassProposal> projects = resp.getBody();
        assertEquals(2,  projects.size());
    }
    
    @Test
    @Transactional
    public void testGetPbpSubclassList_filterBySchemeReleaseNotAvailable() throws ParseException {

        ResponseEntity<List<PBPSubclassItem>> resp = pushButtonPublicationController
                .getPbpSubclassList(Collections.singletonList("Feb 2025"), null, null, null, null, null, null, null);

        assertNotNull(resp);
        assertEquals(HttpStatus.OK, resp.getStatusCode());
        assertEquals(16, resp.getBody().size());

    }

}
