package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;
/**
 * US412692 - disabled the following validation message
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowEntryTypeAndTransferToComboValidatorTest {
    private static final Logger log = LoggerFactory.getLogger(ProposalRowEntryTypeAndTransferToComboValidatorTest.class);
    
    
    private static final String EXPECTED_MESSAGE = "Type D requires Transfer-To target symbol.";
    
    private static final String EXPECTED_N_TYPE_MESSAGE = "Type N does not allow Transfer-To target symbol. N groups receive documents. Convert to 'Q' if transferring any documents out.";
    
    private static final String EXPECTED_T_TYPE_MESSAGE = "Type T does not allow Transfer-To target symbol. T groups receive documents. Convert to 'C' if transferring any documents out.";
    
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalRowEntryTypeAndTransferToComboValidator proposalRowEntryTypeAndTransferToComboValidator;

    @Inject
    private ProposalValidationService proposalValidationService;

    @Resource
    private List<ProposalValidator> proposalValidators;


    @Test
    public void testValidate() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A01N27/99", "0", "Bold Error ##BOLD##", null));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowEntryTypeAndTransferToComboValidator.validate(proposalValidationContext, rows);
        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
        for (RevisionChangeItem row : rows) {
            Assert.assertEquals(1, row.getValidationMessages().size());
            for (ValidationMessage msg : row.getValidationMessages()) {
                Assert.assertEquals(ValidationMessageField.CHANGE_TYPE, msg.getTriggerField());
                log.debug(msg.getMessageText());
                Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));

            }
        }
        Assert.assertTrue(proposalValidationContext.isSymbolExistsInProposal("A01N27/99"));
        Assert.assertEquals(2L, proposalValidationContext.getClassificationSchemneId().longValue());
        proposalValidationContext.setClassificationSchemneId(3L);
        Assert.assertEquals(3L, proposalValidationContext.getClassificationSchemneId().longValue());

    }
    
    @Test
    public void testValidateTypeNandE() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("T", "A01N28/99", "0", "Bold Error ##BOLD##", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("T", "A01N27/99", "0", "Bold Error ##BOLD##", new String[] {}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("N", "A01N28/99", "0", "Bold Error ##BOLD##", new String[] {}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("M", "A01N28/99", "0", "Bold Error ##BOLD##", new String[] {"A01N"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowEntryTypeAndTransferToComboValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(EXPECTED_N_TYPE_MESSAGE, rows.get(0).getValidationMessages().get(0).getMessageText());
        Assert.assertEquals(EXPECTED_T_TYPE_MESSAGE, rows.get(1).getValidationMessages().get(0).getMessageText());
        Assert.assertTrue(rows.get(2).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(3).getValidationMessages().isEmpty());
        Assert.assertFalse(rows.get(4).getValidationMessages().isEmpty());
    }
    
    
    @Test
    public void testValidateTypeDWithYSeriesSymbol() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "Y01N27/99", "0", "Bold Error ##BOLD##", new String[] {"A01N"}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "Y01N27", "0", "Bold Error ##BOLD##", null));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowEntryTypeAndTransferToComboValidator.validate(proposalValidationContext, rows);
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
    }
    
//    @Test
//    public void testValidateTypeDNonYSeriesSymbol() {
//        List<RevisionChangeItem> rows = new ArrayList<>();
//        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A01N27/99", "0", "Bold Error ##BOLD##", new String[] {}));
//        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A01N", "0", "Bold Error ##BOLD##", null));
//        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
//        proposalRowEntryTypeAndTransferToComboValidator.validate(proposalValidationContext, rows);
//        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
//        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
//        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());        
//        Assert.assertEquals(EXPECTED_MESSAGE, rows.get(0).getValidationMessages().get(0).getMessageText());       
//        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, rows.get(0).getValidationMessages().get(0).getTriggerField());                
//        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(0).getValidationMessages().get(0).getLevel());
//        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(0).getValidationMessages().get(0).getMessageType());
//        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
//    }
    
    @Test
    public void testValidateTypeDSymbolWith2ThousandSeries() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A01N2700/99", "0", "Bold Error ##BOLD##", new String[] {}));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A01N", "0", "Bold Error ##BOLD##", null));
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A01N 20/20", "0", "Bold Error ##BOLD##", null));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowEntryTypeAndTransferToComboValidator.validate(proposalValidationContext, rows);      
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
        Assert.assertTrue(rows.get(1).getValidationMessages().isEmpty());
        Assert.assertEquals(0, rows.get(2).getValidationMessages().size());        
//        Assert.assertEquals(EXPECTED_MESSAGE, rows.get(2).getValidationMessages().get(0).getMessageText());       
//        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, rows.get(2).getValidationMessages().get(0).getTriggerField());                
//        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(2).getValidationMessages().get(0).getLevel());
//        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(2).getValidationMessages().get(0).getMessageType());
//        Assert.assertTrue(StringUtils.isNotBlank(rows.get(2).getValidationMessages().get(0).getMessageText()));       
    }

    
    @Test
    public void testValidateTypeFSymbolsWithNoReclass() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("F", "A61M1/0001", "0", "Bold Error ##BOLD##", null));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowEntryTypeAndTransferToComboValidator.validate(proposalValidationContext, rows);      
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
//        Assert.assertEquals(EXPECTED_MESSAGE, rows.get(2).getValidationMessages().get(0).getMessageText());       
//        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, rows.get(2).getValidationMessages().get(0).getTriggerField());                
//        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(2).getValidationMessages().get(0).getLevel());
//        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(2).getValidationMessages().get(0).getMessageType());
//        Assert.assertTrue(StringUtils.isNotBlank(rows.get(2).getValidationMessages().get(0).getMessageText()));       
    }

    @Test
    public void testValidateTypeFSymbolsWithReclass() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("F", "A61M1/0001", "0", "Bold Error ##BOLD##", new String[] {"A01N1/10"}));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
        proposalRowEntryTypeAndTransferToComboValidator.validate(proposalValidationContext, rows);      
        for (ValidationMessage msg: rows.get(0).getValidationMessages()) {
        	log.debug("Validation Message = {}", JsonUtils.toJsonOrStacktrace(msg) );
        }
        Assert.assertTrue(rows.get(0).getValidationMessages().isEmpty());
//        Assert.assertEquals(EXPECTED_MESSAGE, rows.get(2).getValidationMessages().get(0).getMessageText());       
//        Assert.assertEquals(ValidationMessageField.RECLASS_TRANSFER, rows.get(2).getValidationMessages().get(0).getTriggerField());                
//        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(2).getValidationMessages().get(0).getLevel());
//        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(2).getValidationMessages().get(0).getMessageType());
//        Assert.assertTrue(StringUtils.isNotBlank(rows.get(2).getValidationMessages().get(0).getMessageText()));       
    }

    
//    @Test
//    public void testValidateTypeDandOtherType() {
//        List<RevisionChangeItem> rows = new ArrayList<>();
//        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("D", "A01N27/99", "0", "Bold Error ##BOLD##", null));
//        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("Q", "A01N27/99", "0", "Bold Error ##BOLD##", null));
//        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows);
//        proposalRowEntryTypeAndTransferToComboValidator.validate(proposalValidationContext, rows);
//        Assert.assertNotNull(rows.get(0).getValidationMessages().get(0).getMessageText());
//        Assert.assertFalse(rows.get(0).getValidationMessages().isEmpty());
//        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());        
//        Assert.assertEquals(EXPECTED_MESSAGE, rows.get(0).getValidationMessages().get(0).getMessageText());       
//        Assert.assertNotNull(rows.get(1).getValidationMessages().get(0).getMessageText());
//        Assert.assertFalse(rows.get(1).getValidationMessages().isEmpty());
//        Assert.assertEquals(1, rows.get(1).getValidationMessages().size());        
//        Assert.assertEquals("Type Q requires Transfer-To target symbol.", rows.get(1).getValidationMessages().get(0).getMessageText());       
//        Assert.assertEquals(ValidationMessageField.CHANGE_TYPE, rows.get(1).getValidationMessages().get(0).getTriggerField());                
//        Assert.assertEquals(ValidationMessageLevel.CRITICAL, rows.get(1).getValidationMessages().get(0).getLevel());
//        Assert.assertEquals(ValidationMessageType.RECORD, rows.get(1).getValidationMessages().get(0).getMessageType());
//        Assert.assertTrue(StringUtils.isNotBlank(rows.get(1).getValidationMessages().get(0).getMessageText())); 
//    }   
    

    @Test
    public void testConfigCorrectlyIncludesGrammarValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(proposalRowEntryTypeAndTransferToComboValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }

    @Test
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.LOW, proposalRowEntryTypeAndTransferToComboValidator.getCost());

    }

    @Before
    public void setUp() throws Exception {
    	datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

    }

}
