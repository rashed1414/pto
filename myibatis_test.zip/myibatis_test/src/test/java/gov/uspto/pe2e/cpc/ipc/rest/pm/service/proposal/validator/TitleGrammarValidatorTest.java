package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationCost;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessageField;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalValidationService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelper;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class TitleGrammarValidatorTest {

    @Inject
    private TitleGrammarValidator titleGrammarValidator;
    
    @Inject 
    private ProposalValidationHelper proposalValidationHelper;
    
    @Inject 
    private ProposalValidationService proposalValidationService;

    @Inject
    private TitleService titleService;
    
    @Resource(name="proposalCompletenessValidator")
    private List<ProposalValidator> proposalValidators;

    
    @Test
    public void testConfigCorrectlyIncludesGrammarValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator: proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(titleGrammarValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }
    
    @Test 
    public void testGetCost() {
        Assert.assertEquals(ValidationCost.LOW, titleGrammarValidator.getCost());
        
    }
    
    @Test 
    public void testValidationSourceFields() {
    	List<ValidationMessageField> msgFieldList = titleGrammarValidator.getValidationSourceFields();
        Assert.assertNotNull(msgFieldList);
        Assert.assertEquals(ValidationMessageField.TITLE, msgFieldList.get(0));
    }
    
    @Test
    public void testValidate() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "Bold Error ##BOLD##", null));

        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "BoldEND Error ##/BOLD##", null));
        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "BoldEND Error{##BOLD## missing boldend }", null));
        

        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "({)}", null));

        rows.add(createRevisionChangeItemAndValidateTitleGrammar("M", "A01N27/99", "0", "superscripts cannot contain bold ##SUPERSCRIPT####BOLD##bold##/BOLD####/SUPERSCRIPT##", null));
        ProposalValidationContext proposalValidationContext = proposalValidationService.createProposalValidationContext(rows); 
        titleGrammarValidator.validate(proposalValidationContext, rows);
        for (RevisionChangeItem row: rows) {
            for (ValidationMessage msg: row.getValidationMessages()) {
                Assert.assertEquals(ValidationMessageField.TITLE, msg.getTriggerField());
                Assert.assertTrue(StringUtils.isNotBlank(msg.getMessageText()));
            }
        }        
    }
    
    public RevisionChangeItem createRevisionChangeItemAndValidateTitleGrammar(String entryType, String symbolName, String dotLevel, String titleGrammar, String[] reclassTargets) {
        RevisionChangeItem item = ProposalValidationHelperTest.createRevisionChangeItem(entryType, symbolName, dotLevel, titleGrammar, reclassTargets); 
        try {
            TitlePartTree tree = titleService.fromGrammar(item.getTitleGrammar());
            item.setTitle(tree);
        } catch (GrammarParseException gpe) {
            item.getValidationMessages().addAll(gpe.getValidationMessages());
        }
        return item;
    }

}
