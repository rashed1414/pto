package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class CrossReferenceToolControllerVolatileTest {
    private static final Logger log = LoggerFactory.getLogger(CrossReferenceToolControllerVolatileTest.class);
    @Inject
    private CrossReferenceToolController crossReferenceToolController;
    @Inject
    private DatasetTestingService datasetTestingService;    

	@Test
	@Transactional
	public void saveCurrentProjectCrlSymbols() throws IOException {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("msingh4@uspto.gov", "msingh4", "Manpreet",
				"Singh", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("msingh4@uspto.gov",
				token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		UUID sourceProposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		UUID versionSymbolGuid = GUIDUtils.fromDatabaseFormat("e0569b67a5a643ca8dd5ccff5b6e5387");
		String sourceSymbol = "A01B3/462";
		String crlSymbol = "A01B63/114";
		RevisionChangeItemRequest req = mapJsonStringToRevisionChangeItemRequest(
				"data/json/crt/CrossReferenceListChangeRequest.json");

		ResponseEntity<List<Void>> resp = crossReferenceToolController.saveProjectCrlSymbols(sourceProposalId, null,
				versionSymbolGuid, sourceSymbol, crlSymbol, req);

		assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
		assertNotNull(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER));
	}
	
	@Test
	@Transactional
	public void saveOtherProjectCrlSymbols() throws IOException {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("msingh4@uspto.gov", "msingh4", "Manpreet",
				"Singh", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("msingh4@uspto.gov",
				token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		UUID sourceProposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		UUID otherProposalId = GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7");
		UUID versionSymbolGuid = GUIDUtils.fromDatabaseFormat("e0569b67a5a643ca8dd5ccff5b6e5387");
		String sourceSymbol = "A01B3/462";
		String crlSymbol = "A01B63/114";
		RevisionChangeItemRequest req = mapJsonStringToRevisionChangeItemRequest(
				"data/json/crt/CrossReferenceListChangeRequest.json");

		ResponseEntity<List<Void>> resp = crossReferenceToolController.saveProjectCrlSymbols(sourceProposalId, otherProposalId,
				versionSymbolGuid, sourceSymbol, crlSymbol, req);

		assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
		assertNotNull(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER));
	}
	
	@Test
	@Transactional
	public void saveCurrentProjectCrlSymbols_validateNullTitleAndChangeTypes() throws IOException {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("msingh4@uspto.gov", "msingh4", "Manpreet",
				"Singh", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken("msingh4@uspto.gov",
				token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		UUID sourceProposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		UUID versionSymbolGuid = GUIDUtils.fromDatabaseFormat("e0569b67a5a643ca8dd5ccff5b6e5387");
		String sourceSymbol = "A01B3/462";
		String crlSymbol = "A01B63/114";
		RevisionChangeItemRequest req = mapJsonStringToRevisionChangeItemRequest(
				"data/json/crt/CrossReferenceListChangeRequest_withChangeTypeValidation.json");

		ResponseEntity<List<Void>> resp = crossReferenceToolController.saveProjectCrlSymbols(sourceProposalId, null,
				versionSymbolGuid, sourceSymbol, crlSymbol, req);

		assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
		assertNotNull(resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER));
	}
	
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1@uspto.gov", "myoung3@uspto.gov", Arrays
                .asList(new BasicTestingGrantedAuthority("test@uspto.gov")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }
    
    private RevisionChangeItemRequest mapJsonStringToRevisionChangeItemRequest(String filePath) throws IOException {
    	InputStream is = Thread.currentThread().getContextClassLoader()
				 .getResourceAsStream("data/json/crt/CrossReferenceListChangeRequest.json");
    	String jsonString =  IOUtils.toString(is);
    	return new ObjectMapper().readValue(jsonString, RevisionChangeItemRequest.class);
    }
}
