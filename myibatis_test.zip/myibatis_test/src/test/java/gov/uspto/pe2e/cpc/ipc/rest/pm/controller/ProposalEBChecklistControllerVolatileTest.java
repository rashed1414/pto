package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalDetail;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalDetailRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalFormType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposerAction;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposerTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.CheckListItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.CheckListItemDecision;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.ChecklistName;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.EbCheckList;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposalebcl.v1_0.EbclApproverRole;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalEBChecklistService;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;


/**
 * Test for class ProposalEBChecklistController
 * @author msingh4
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalEBChecklistControllerVolatileTest {
    private static final Logger log = LoggerFactory.getLogger(ProposalEBChecklistControllerVolatileTest.class);
    
    @Inject
    private DatasetTestingService datasetTestingService;    
    
    @Inject
    private ProposalEBChecklistController proposalEBChecklistController;
    
    @Inject
    private EntityManager entityManager;
    
    @Inject
    private ChangeProposalDetailRepository changeProposalDetailRepository;
          
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);
        
		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1000L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setPublicationDate(DateUtils.parseDate("2015-09-01", 
				DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);
        
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("boopathi.kuppusamy@uspto.gov", "boopathi.kuppusamy@uspto.gov", 
                Arrays.asList(new BasicTestingGrantedAuthority("test")));
        SecurityContextHolder.getContext().setAuthentication(token);        
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/resources/images/cpc-sch-A01N-0937.gif")));
    }
	
	@Test
	@Transactional
	public void testSaveAndVerifySync() {

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boopathi", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamyy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));

		SecurityContextHolder.getContext().setAuthentication(springUser);

		List<EbCheckList> request = new ArrayList<>();
		request.add(createCheckList());
		UUID cpGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");

		ResponseEntity<Void> response = proposalEBChecklistController
				.saveChecklistItems(cpGuid, request);
		entityManager.flush();
		entityManager.clear();
		
		List<ChangeProposalDetail> details =changeProposalDetailRepository.findAllProposalDetails(GUIDUtils.toDatabaseFormat(cpGuid), 
				ProposalFormType.PROJECT_DETAIL);
		List<ChangeProposalDetail> decisions = details.stream().filter(it -> Arrays.asList(
				"USEBAPPROVAL_PD","EPEBAPPROVAL_PD","USJBAPPROVAL_PD","EPJBAPPROVAL_PD").contains(it.getItemName()))
				.collect(Collectors.toList());
		assertEquals(4, decisions.size());

	}

	private EbCheckList createCheckList() {
	
		EbCheckList checkList = new EbCheckList();
		checkList.setChecklistName(ChecklistName.EBJB_REVIEW);
		checkList.getItems().add(createCheckListItem());
		checkList.setType("test 123");
		checkList.setProposalStatus(ProposalStatus.ACTIVE);
		return checkList;
	}



	private CheckListItem createCheckListItem() {
		CheckListItem item = new CheckListItem();
		item.setItemName(ProposalEBChecklistService.SYNCD_CHECKLIST_NAME);
		item.getDecisions().add(createDescision(StandardIpOfficeCode.US, 
				EbclApproverRole.EDITORIAL_BOARD, ProposerAction.APPROVED));
		item.getDecisions().add(createDescision(StandardIpOfficeCode.US, 
				EbclApproverRole.JOINT_BOARD, ProposerAction.NA));
		item.getDecisions().add(createDescision(StandardIpOfficeCode.EP, 
				EbclApproverRole.EDITORIAL_BOARD, ProposerAction.APPROVED));
		item.getDecisions().add(createDescision(StandardIpOfficeCode.EP, 
				EbclApproverRole.JOINT_BOARD, ProposerAction.NO));
		item.setItemId(1000);
		item.setSrNo(999);
		return item;
	}



	private CheckListItemDecision createDescision(StandardIpOfficeCode officeCode, 
			EbclApproverRole role, ProposerAction action) {
		CheckListItemDecision d = new CheckListItemDecision();
		d.setDecisionType(action);
		d.setOfficeCode(officeCode);
		d.setOfficeType(ProposerTypeCode.RO);
		d.setRole(role);
	
		return d;
	}

}
