package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.PBPLookupUserRole;
import gov.uspto.pe2e.cpc.ipc.rest.contract.pbp.v1_0.PBPSubclassItem;
import jakarta.inject.Inject;
import net.jcip.annotations.NotThreadSafe;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test-oraclelocal.xml"})
@NotThreadSafe
@Category(NotThreadSafe.class)
@TestPropertySource("classpath:oracle.properties") // this allows the integration test to override oracle properties without affecting spring factory
public class PushButtonPublicationIntegrationTest {
	 private static final Logger log = LoggerFactory.getLogger(PushButtonPublicationControllerTest.class);
	    @Inject
	    private PushButtonPublicationController pushButtonPublicationController;
	    @Inject
	    private DatasetTestingService datasetTestingService;    
    
    
  
    @Before
    public void setUp() throws Exception {
        //IDatabaseConnection conn = datasetTestingService.getConnection();
       // datasetTestingService.emptyTables(conn);
       // datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1@uspto.gov", "myoung3@uspto.gov", Arrays
                .asList(new BasicTestingGrantedAuthority("test@uspto.gov")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }
    
    @Test
	@Transactional
	public void testGetPbpSubclassList_filterUserRoleAndEmail_USEbRole() throws ParseException {
		ResponseEntity<List<PBPSubclassItem>> resp = pushButtonPublicationController
				.getPbpSubclassList(null, null, null, null, null, null, PBPLookupUserRole.US_EB_NM, "partha.barua@USPTO.GOV");
		
		assertNotNull(resp);
		assertEquals(HttpStatus.OK, resp.getStatusCode());
	}
}
