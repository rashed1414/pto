package gov.uspto.pe2e.cpc.ipc.rest.pm.service;

import static org.hamcrest.Matchers.matchesPattern;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.dbunit.database.IDatabaseConnection;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.wml.Tbl;
import org.docx4j.wml.Tc;
import org.docx4j.wml.Tr;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.opencsv.CSVReader;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ExportDocxReportType;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.S3CloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.DocxUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.CloudResource;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.KeyValuePairEntry;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalExportRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalRevisionDetail;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalSummary;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SchemeChangeType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.TaskStateSummary;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalExportServiceTest {

    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private ProposalExportService proposalExportService;


    @Inject
    private ProposalRevisionService proposalRevisionService;


    @Inject
    private SecurityService securityService;



	@Test
	@Transactional
	public void testExportAndSendProposalData() throws IOException {
		ProposalExportRequest req = new ProposalExportRequest();
		 UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(SecurityContextHolder.getContext()
	                .getAuthentication());
		 int recordsFound = 0;
		byte[] bytes = proposalExportService.exportAndSendProposalData(req, authToken, false);
		try (ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
			    Reader targetReader = new InputStreamReader(bais);){
			CSVReader csvReader = new CSVReader(targetReader);
			String[] rec = null;
			String[] header = csvReader.readNext(); // skip header TODO: validate header too
			
			while ((rec = csvReader.readNext()) != null) {
				log.debug("{}", rec);
				if (rec.length == 48) {
					if (recordsFound == 0) {
						assertEquals("A01A", rec[5]);
					}
					if (rec[0].equalsIgnoreCase("MP0028")) {
						//assertEquals("CEF1000", rec[3]);
						assertEquals("TC99", rec[27]);
						assertEquals("", rec[18]); // EPPC_PD
						assertEquals("Q - Bilateral Request Phase", rec[19]);
						assertEquals("EP_TECH_TEST", rec[14]);
						assertEquals("EP:COORDINATOR, US:COORDINATOR", rec[22]);
						assertEquals("15", rec[37]);
						assertEquals("Completed", rec[45]);
						assertEquals("Ongoing_O", rec[47]);
					}
					assertTrue(rec[0].matches("[A-Z]{2,2}\\d+")); // project alias
					assertTrue(StringUtils.isNotEmpty(rec[24])); // createTs
					recordsFound ++;
				}
			}
		}
		//assertEquals((Integer)7, (Integer)recordsFound );
	}

	
	@Test
	public void testWithCannedData() throws IOException {
		File f = new File("target/gpl.csv");
		List<ProposalSummary> proposals = new ArrayList<>();
		
		ProposalSummary summary  = new ProposalSummary();
		summary.setId(UUID.fromString("bd5d0f7c-cff4-410b-af4f-7761ed979963"));
		summary.setCreateUserId("Swarén, Peter; pswaren@epo.org");
		summary.setPhase(ProposalPhase.A);
		TaskStateSummary task1 = new TaskStateSummary();
		task1.setAssignee("matt@uspto.gov");
		task1.setTaskName("test 1234");
		task1.setTaskDefinitionKey("BAT01");
		
		
		summary.getActiveTasks().add(task1);
		
		proposals.add(summary);
		
		ProposalSummary summary1  = new ProposalSummary();
		summary1.setId(UUID.fromString("9e1c8ab4-5b3c-408e-8ff3-e7b69a883105"));
		summary1.setDisplayName("test1");
		KeyValuePairEntry kvp = new KeyValuePairEntry();
		kvp.setKey("PROJECT_DETAIL.projectSource_PD");
		summary1.getProposalDetails().add(kvp);
		
		proposals.add(summary1);
		
		ProposalSummary summary2  = new ProposalSummary();
		summary2.setId(UUID.fromString("9e1c8ab4-5b3c-408e-8ff3-e7b69a883106"));
		summary2.setDisplayName("PI-Scheme Publication Date (Estimated)");
		KeyValuePairEntry kvp1 = new KeyValuePairEntry();
		kvp1.setKey("PROJECT_DETAIL.PF_releaseDateEstimated_PD");
		summary2.getProposalDetails().add(kvp1);
		
		proposals.add(summary2);
		
		ProposalSummary summary3  = new ProposalSummary();
		summary3.setId(UUID.fromString("9e1c8ab4-5b3c-408e-8ff3-e7b69a883106"));
		summary3.setDisplayName("PF-Scheme Publication Date (Estimated)");
		KeyValuePairEntry kvp3 = new KeyValuePairEntry();
		kvp3.setKey("PROJECT_DETAIL.releaseDateEstimated_PD");
		summary3.getProposalDetails().add(kvp3);
		
		proposals.add(summary3);
		byte[] sample = proposalExportService.exportProposalsToCSV(proposals, new Date());
	    IOUtils.write(sample, new FileOutputStream(f));
	    
	    assertTrue(f.exists());
	    InputStreamReader isReader = new InputStreamReader(
	            new ByteArrayInputStream(sample));
	    CSVReader reader = new CSVReader(isReader, ',');
	    reader.readNext();
	    String[] fields = reader.readNext();
	    assertEquals("4", fields[19]);
	    assertEquals("4.01", fields[21]);
	    
	    
	    reader.close();
	    isReader.close();
	   
	}
	
	/**
	 * US448501 - added numeric sorts
	 * @throws IOException
	 */
	@Test
	@Transactional
	public void testExportAndSendTimeAndHistoryCSV() throws IOException {
		ProposalExportRequest req = new ProposalExportRequest();
		 UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(SecurityContextHolder.getContext()
	                .getAuthentication());
		 int recordsFound = 0;
		 int taskSortIdFound = 0;
		 int phaseSortFound = 0;
		byte[] bytes = proposalExportService.exportAndUploadProposalTaskHistory(req, authToken);
		IOUtils.write(bytes, new FileOutputStream("target/tnh.csv"));
		try (ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
			    Reader targetReader = new InputStreamReader(bais);){
			CSVReader csvReader = new CSVReader(targetReader);
			String[] rec = null;
			String[] header = csvReader.readNext(); // skip header TODO: validate header too
			
			while ((rec = csvReader.readNext()) != null) {
				log.debug("ROW: {}", Arrays.asList(rec));
				if (rec.length >= 16) {
					if (recordsFound == 0 || recordsFound == 1) {
						assertEquals("DP0027", rec[0]);
					}
					assertEquals("test 123", rec[19]);
					assertNotNull(rec[1]);
					assertTrue("field 3 does not allow "+rec[3], 
							Arrays.asList("BAT02", "BAT03", "BAT01" , "BAT04").contains(rec[3]));
					if (StringUtils.isNotEmpty(rec[4])) {
						assertThat(rec[4], matchesPattern("^\\d*\\.\\d+$"));
						taskSortIdFound++;
					}
					if (StringUtils.isNotEmpty(rec[1])) {
						assertThat(rec[1], matchesPattern("^\\d+$"));
						phaseSortFound++;
					}
//					if (rec[0].equalsIgnoreCase("MP0028")) {
//						//assertEquals("CEF1000", rec[3]);
//						assertEquals("TC99", rec[27]);
//						assertEquals("", rec[18]); // EPPC_PD
//						assertEquals("Q - Bilateral Request Phase", rec[19]);
//						assertEquals("EP_TECH_TEST", rec[14]);
//						assertEquals("EP:COORDINATOR, US:COORDINATOR", rec[22]);
//						assertEquals("15", rec[37]);
//						assertEquals("Completed", rec[45]);
//						assertEquals("Ongoing_O", rec[47]);
//					}
//					if (rec[0].equalsIgnoreCase("DP11337")) {
//						assertEquals("BAT03", rec[3]);
//						assertEquals("Name_BAT03", rec[5]);
////						assertEquals("TC99", rec[27]);
////						assertEquals("", rec[18]); // EPPC_PD
////						assertEquals("Q - Bilateral Request Phase", rec[19]);
////						assertEquals("EP_TECH_TEST", rec[14]);
////						assertEquals("EP:COORDINATOR, US:COORDINATOR", rec[22]);
////						assertEquals("15", rec[37]);
////						assertEquals("Completed", rec[45]);
////						assertEquals("Ongoing_O", rec[47]);
//					}					
					
//					assertTrue(rec[0].matches("[A-Z]{2,2}\\d+")); // project alias
//					assertTrue(StringUtils.isNotEmpty(rec[24])); // createTs
					recordsFound ++;
				}
			}
		}
		assertEquals((Integer)60, (Integer)recordsFound );
		// US448501
		assertEquals((Integer)60, (Integer)taskSortIdFound );
		assertEquals((Integer)60, (Integer)phaseSortFound );

	}

	
	@Test
	public void testSCTExportSortWithCannedData() throws Exception {
		String filename = "target/sct_cascading_sort_test.docx";
		File f = new File(filename);
		
		RequestContextHolder
		.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
				"/cpcipcrestweb", "/proposalrevisions/44c4f7b8b78e4c07aa5d37432db56260/statistics.docx")));

		ProposalRevisionDetail proposalRevisionDetail = builSCTforSortTest();
        byte[] dataForDisplay = proposalRevisionService.prepareProposalRevisionInfoIntoDocx(ExportDocxReportType.SCT.name(), null, 
        		proposalRevisionDetail);	    
        IOUtils.write(dataForDisplay, new FileOutputStream(f));
        assertTrue(f.exists());
 	      
	    
		
		
		
	    WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new java.io.File(filename));
	    List<Pair<String,String>> entries =  readSCTEntries(wordMLPackage);
	    assertEquals(Pair.of("D","A01N1/2011"), entries.get(1));
	    assertEquals(Pair.of("N","A01N1/11"), entries.get(2));
	    assertEquals(Pair.of("M","A01N1/2011"), entries.get(3));
	    assertEquals(Pair.of("C","A01N1/2011"), entries.get(4));
	    assertEquals(Pair.of("D","A01N1/111"), entries.get(5));
	    assertEquals(Pair.of("M","A01N1/111"), entries.get(6));
	}
	
	@Test
	public void testExtractProposalNameFromFileName() {
		List<CloudResource> crList = new ArrayList<>();
		CloudResource cr = new CloudResource();
		cr.setId("/test/extract/proosal/name/MP12345_definition_1234.zip");
		crList.add(cr);

		List<CloudResource> crListWithMetadata = proposalExportService.extractProposalNameFromFileName(crList);
		
		assertNotNull(crListWithMetadata);
		assertEquals(crListWithMetadata.get(0).getId(), cr.getId());
		assertEquals(crListWithMetadata.get(0).getMetadata().get(0).getValue(), "MP12345");
	}


    private List<Pair<String, String>> readSCTEntries(WordprocessingMLPackage wordMLPackage) {
    	  List<Pair<String,String>> foundRows = new ArrayList<>();
		  MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
          List<Tbl> tables = DocxUtils.search(documentPart, Tbl.class);
          for (Tbl docPart : tables) {
   //           if (docPart.getTblGrid().getGridCol().size() == SCT_COLUMN_COUNT) {
                  List<Tr> rows = DocxUtils.search(docPart, Tr.class);
                  for (Tr row : rows) {
                      List<Tc> cells = DocxUtils.search(row, Tc.class);
                      
                      String changeType = DocxUtils.coalesceText(cells.get(0));
                      log.debug("changeType text = {} ", changeType);
                      String symbolName = DocxUtils.coalesceText(cells.get(1));
                      log.debug("Found in column 1 (zero based) = {}", symbolName);
                       	
                      foundRows.add(Pair.of(changeType, symbolName));
                  } // end row for loop
//              }
          }

			return foundRows;
	}


	private ProposalRevisionDetail builSCTforSortTest() {
		ProposalRevisionDetail rev = new ProposalRevisionDetail();
		rev.setId(GUIDUtils.fromDatabaseFormat("080f8146bd4e4e349350c1b184db1b56"));
		
		rev.setProposalId(GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"));
		rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.C,"A01N1/2011"));
		rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.M,"A01N1/2011"));
		rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.N,"A01N1/11"));
		rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.M,"A01N1/111"));
		rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.D,"A01N1/111"));

		rev.getRevisionChangeItems().add(createRevisionChangeItem(SchemeChangeType.D,"A01N1/2011"));
		return rev;
	}


	private RevisionChangeItem createRevisionChangeItem(SchemeChangeType changeType, String symbolName) {
		RevisionChangeItem item =  new RevisionChangeItem();
		item.setEntryType(changeType.name());
		item.setSymbolName(symbolName);
		item.setSymbolSortKey(convert2KSymbolIfNecessary(symbolName));
		return item;
	}


	private String convert2KSymbolIfNecessary(String symbolName) {
		String sortKey = symbolName;
		if (StringUtils.indexOf(symbolName,"/") >= 0) {
			String twoThouPart = StringUtils.trim(StringUtils.substringAfterLast(symbolName, "/"));
			if (Integer.parseInt(twoThouPart) >= 2000) {
				twoThouPart = (Integer.parseInt(twoThouPart) - 2000)+"";
			}
			sortKey = StringUtils.substring(symbolName,0, StringUtils.indexOf(symbolName, "/"))+ "/"+twoThouPart;
			log.debug("symbolName ={} -> sorkey = {}", symbolName, sortKey);
		}
		return sortKey;
	}


	@Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);
        
        proposalExportService.setS3CloudResourcePersistenceService(mock(S3CloudResourcePersistenceService.class));

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
//        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("matthew.young@uspto.gov", "myoung3",
//                "Matt", "Young", "US");
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("manpreet.singh@uspto.gov", "msingh4",
                "Manpreet", "Singh", "US");
        UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "matthew.young@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority(
                        ApplicationPermission.WMS_INSTANCE_START.name()), new BasicTestingGrantedAuthority(
                                ApplicationPermission.EDITORIAL_BOARD.name()), new BasicTestingGrantedAuthority(
                                        ApplicationPermission.COORDINATOR.name())));
        SecurityContextHolder.getContext().setAuthentication(springUser);

    }

}
