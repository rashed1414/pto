package gov.uspto.pe2e.cpc.ipc.rest.pm.service.proposal.validator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_1.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassTransfer;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassificationTypeCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import gov.uspto.pe2e.cpc.ipc.rest.pm.model.validator.ProposalValidationContext;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper.ProposalValidationHelperTest;
import jakarta.annotation.Resource;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
public class ProposalRowFrozenTypeReclassValidatorTest {
    private static final Logger log = LoggerFactory.getLogger(TitleReferencePartValidatorTest.class);
    
    @Inject
    private DatasetTestingService datasetTestingService;

    @Inject
    private  ProposalRowFrozenTypeReclassValidator  proposalRowFrozenTypeReclassValidator;

    @Resource
    private List<ProposalValidator> proposalValidators;

    @Test
    public void testConfigCorrectlyIncludesGrammarValidator() {
        boolean isIncluded = false;
        for (ProposalValidator validator : proposalValidators) {
            if (validator.getClass().getCanonicalName().equals(proposalRowFrozenTypeReclassValidator.getClass().getCanonicalName())) {
                isIncluded = true;
                break;
            }
        }
        Assert.assertTrue(isIncluded);
    }

    @Test
    public void testValidate() {
        List<RevisionChangeItem> rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItem("F",  "A01B63/00", "0",
                "Testing", new String[]{"A01N", "A01N99/2001"}));

        ProposalValidationContext proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenTypeReclassValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Frozen groups require intellectual reclass to multiple groups. (No Administrative transfers.)",
                rows.get(0).getValidationMessages().get(0).getMessageText());
        
        
        RevisionChangeItem row = ProposalValidationHelperTest.createRevisionChangeItem("F",  "A01B63/00", "0",
                "Testing", new String[]{"A01N","A01M99/2001"});
        for (ReclassTransfer reclass: row.getReclassTransfers()) {
            reclass.setReclassificationTypeCategory(ReclassificationTypeCategory.INTELLECTUAL);
        }
        rows = Arrays.asList(row);

        proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenTypeReclassValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(0, rows.get(0).getValidationMessages().size());

        rows = new ArrayList<>();
        rows.add(ProposalValidationHelperTest.createRevisionChangeItemWithBothReclassCategory("F",  "A01B63/00", "0",
                "Testing", new String[]{"A01N", "A01N99/2001","A01B", "A01D"}));

        proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenTypeReclassValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Frozen groups require intellectual reclass to multiple groups. (No Administrative transfers.)",
                rows.get(0).getValidationMessages().get(0).getMessageText());
        
        row = ProposalValidationHelperTest.createRevisionChangeItem("F",  "A01B63/00", "0",
                "Testing", new String[]{"A01N"});
        for (ReclassTransfer reclass: row.getReclassTransfers()) {
            reclass.setReclassificationTypeCategory(ReclassificationTypeCategory.INTELLECTUAL);
        }
        rows = Arrays.asList(row);

        proposalValidationContext = new ProposalValidationContext();
        proposalRowFrozenTypeReclassValidator.validate(proposalValidationContext, rows);
        Assert.assertEquals(1, rows.get(0).getValidationMessages().size());
        Assert.assertEquals("Frozen groups require intellectual reclass to multiple groups. (No Administrative transfers.)",
                rows.get(0).getValidationMessages().get(0).getMessageText());
    
        
    }      
    
    @Before
    public void setUp() throws Exception {

        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        DateTimeZone.setDefault(DateTimeZone.UTC);
        datasetTestingService.loadOnce();

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(2L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2016-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        // UsernamePasswordAuthenticationToken token = new
        // UsernamePasswordAuthenticationToken("user1", "user@user.com",
        // Arrays.asList(new BasicTestingGrantedAuthority("test")));
        //
        // SecurityContextHolder.getContext().setAuthentication(token);
        //
        // RequestContextHolder.setRequestAttributes(
        // new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
        // "/cpcipcrestweb", "/symbols")));
    }
}
