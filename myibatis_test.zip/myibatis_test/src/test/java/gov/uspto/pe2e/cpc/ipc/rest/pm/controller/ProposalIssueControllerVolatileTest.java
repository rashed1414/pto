package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalIssue;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalIssueRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ChangeProposalIssueStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentReference;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalIssue;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import net.jcip.annotations.NotThreadSafe;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
@Slf4j
public class ProposalIssueControllerVolatileTest {
	

    @Inject
    private ChangeProposalIssueRepository changeProposalIssueRepository;    
    @Inject
    private ProposalIssueController proposalIssueController;
    
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private EntityManager entityManager;
   
    
    @Before
    public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.emptyTables(conn);
		datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.7");
        version.setDefinitionXsdVersion("1.0");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);
        
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", 
    			"bkuppusamy", "Boops","Kuppusamy", "US");
    		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
    			"boopathi.kuppusamy@uspto.gov", token,
    			Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
    					new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
    	SecurityContextHolder.getContext().setAuthentication(springUser);  

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }

	@Test
	public void testGetProposalIssues() {
		UUID proposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		ResponseEntity<List<ProposalIssue>> resp =proposalIssueController.getProposalIssues(proposalId);
		assertNotNull(resp);
		assertEquals(HttpStatus.OK, resp.getStatusCode());
		assertEquals(2, resp.getBody().size());
		assertEquals(1, resp.getBody().get(0).getDocuments().size());
	}

	@Test
	public void testAddDocumentToMeetingProposalIssue() {
		UUID proposalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		ResponseEntity<Void> resp =proposalIssueController.addDocumentToMeetingProposalIssue(proposalId, 
				GUIDUtils.fromDatabaseFormat("7945e2cf4f1644cea1b4766502d0dd8b"), 
				GUIDUtils.fromDatabaseFormat("c960d30a52a852ac8c51b64dfcc0ea99"));
		assertNotNull(resp);
		assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
		
		assertEquals(1, resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).size());
	}

	@Transactional
	@Test
	public void testSaveProposalIssue() {
		
		ProposalIssue iss = new ProposalIssue();
		iss.setCategory("Test");
		iss.setPriority(9);
		iss.setIpOfficeCode(StandardIpOfficeCode.US.name());
		iss.setStatus(ChangeProposalIssueStatus.DONE);
		iss.setDescription("Test 1234");
		iss.setSortOrderNumber(9);
		iss.getDocuments().add(createDocument(
				GUIDUtils.fromDatabaseFormat("e9a0d3ab81004702ae11086eb215a050"), 
				"test.txt"));
		
		ResponseEntity<Void> resp = proposalIssueController.saveProposalIssue(
				GUIDUtils.fromDatabaseFormat("d153f9bf804848aa8ba202db9f844d41"), iss);
		
		assertNotNull(resp);
		assertEquals(HttpStatus.CREATED, resp.getStatusCode());
		
		assertEquals(1, resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).size());
		
		entityManager.flush();
		entityManager.clear();
		
		ChangeProposalIssue dbiss = changeProposalIssueRepository.findByGuid(
				GUIDUtils.toDatabaseFormat(
						UUID.fromString(
								resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0))));
		assertEquals(1,dbiss.getReferencedDocuments().size());
		assertEquals("e9a0d3ab81004702ae11086eb215a050",
				dbiss.getReferencedDocuments().iterator().next().getDocument().getExternalId());
		
		
	}

	private ProposalDocumentReference createDocument(UUID documentRepositoryId, String docName) {
		ProposalDocumentReference ref = new ProposalDocumentReference();
		ref.setDocumentName(docName);
		ref.setDocumentId(documentRepositoryId);
		return ref;
	}

}
