package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Arrays;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.ValidatedList;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDetail;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalFormType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalPageDetail;
import jakarta.inject.Inject;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
		"classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalDetailsControllerTest {
	private static final Logger log = LoggerFactory.getLogger(ProposalDetailsControllerTest.class);

	@Inject
	private ProposalDetailsController proposalDetailsController;

	@Inject
	private DatasetTestingService datasetTestingService;

	@Transactional
	@Test
	public void testGetProposalDetails() throws JsonGenerationException, JsonMappingException, IOException {

		log.info("inside testGetProposalDetails");
		UUID uuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		ProposalFormType formType = ProposalFormType.INTERNAL_REQUEST;

		ResponseEntity<ProposalPageDetail> resp = proposalDetailsController.getProposalDetailsByExternalId(uuid,
				formType, true);

		Assert.assertNotNull(resp);
		Assert.assertNotNull(resp.getBody());
		log.debug("resp = {} ", JsonUtils.toJson(resp.getBody()));
	}

	@Transactional
	@Test
	public void testGetProposalDetails_verifyAliases() throws JsonGenerationException, JsonMappingException, IOException {

		log.info("inside testGetProposalDetails");
		UUID uuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		ProposalFormType formType = ProposalFormType.PROJECT_DETAIL;

		ResponseEntity<ProposalPageDetail> resp = proposalDetailsController.getProposalDetailsByExternalId(uuid,
				formType, true);

		Assert.assertNotNull(resp);
		Assert.assertNotNull(resp.getBody());
		log.debug("resp = {} ", JsonUtils.toJson(resp.getBody()));
		ProposalDetail dtl = resp.getBody().getProposalDetails().stream()
				.filter( it-> it.getItemName().equalsIgnoreCase("cefProject_PD"))
				.findFirst().get();
		assertEquals("CEF0026", dtl.getDetails());
		dtl = resp.getBody().getProposalDetails().stream()
				.filter( it-> it.getItemName().equalsIgnoreCase("projectAlias_PD"))
				.findFirst().get();
		assertEquals("UD99999", dtl.getDetails());
	}

	@Transactional
	@Test
	public void testGetProposalDetails_updateExisting() throws JsonGenerationException, JsonMappingException, IOException {
		
		UUID uuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		ProposalFormType formType = ProposalFormType.PROJECT_DETAIL;

		ValidatedList<ProposalDetail> kvps = new ValidatedList<>();
		kvps.add(createKVP("cefProject_PD", "CEF99999", formType));
		kvps.add(createKVP("projectAlias_PD", "UD99900", formType));
		
		proposalDetailsController.saveForFormType(uuid, formType, kvps);
		ResponseEntity<ProposalPageDetail> resp = proposalDetailsController.getProposalDetailsByExternalId(uuid,
				formType, true);

		Assert.assertNotNull(resp);
		Assert.assertNotNull(resp.getBody());
		log.debug("resp = {} ", JsonUtils.toJson(resp.getBody()));
		ProposalDetail dtl = resp.getBody().getProposalDetails().stream()
				.filter( it-> it.getItemName().equalsIgnoreCase("cefProject_PD"))
				.findFirst().get();
		assertEquals("CEF99999", dtl.getDetails());
		dtl = resp.getBody().getProposalDetails().stream()
				.filter( it-> it.getItemName().equalsIgnoreCase("projectAlias_PD"))
				.findFirst().get();
		assertEquals("UD99900", dtl.getDetails());
	}

	
	private ProposalDetail createKVP(String key, String value, ProposalFormType formType) {
		ProposalDetail kvp = new ProposalDetail();
		kvp.setFormType(formType);
		kvp.setDetails(value);
		kvp.setItemName(key);
		return kvp;
	}

	@Before
	public void setUp() throws Exception {
		IDatabaseConnection conn = datasetTestingService.getConnection();
		datasetTestingService.emptyTables(conn);
		datasetTestingService.loadAllDatasets(conn);

		SchemePublicationVersion version = new SchemePublicationVersion();
		version.setClassificationSchemeId(1L);
		version.setCpcXsdVersion("1.6");
		version.setDefinitionXsdVersion("0.9");
		version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
		version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
		SchemePublicationVersionContextHolder.setContext(version);

		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
				"Boops", "Kuppusamy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"boopathi.kuppusamy@uspto.gov", token,
				Arrays.asList(new BasicTestingGrantedAuthority(ApplicationPermission.WMS_INSTANCE_START.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.EDITORIAL_BOARD.name()),
						new BasicTestingGrantedAuthority(ApplicationPermission.COORDINATOR.name())));
		SecurityContextHolder.getContext().setAuthentication(springUser);

		RequestContextHolder.setRequestAttributes(
				new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost", "/cpcipcrestweb", "/symbols")));
	}

}