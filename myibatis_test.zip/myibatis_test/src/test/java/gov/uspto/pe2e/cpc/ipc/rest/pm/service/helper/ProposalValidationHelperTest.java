package gov.uspto.pe2e.cpc.ipc.rest.pm.service.helper;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassTransfer;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassificationTypeCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ReclassificationTypeTargetClassifiationCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItem;
import jakarta.inject.Inject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"classpath:META-INF/spring/applicationContext.xml", "classpath:META-INF/spring/applicationContext-test.xml"})
public class ProposalValidationHelperTest {
	
	@Inject
	private DatasetTestingService datasetTestingService;
    
    public static RevisionChangeItem createRevisionChangeItem(String entryType, String symbolName, String dotLevel, String tileGrammar, String[] reclassTargets) {
        RevisionChangeItem item = new RevisionChangeItem();
        //item.setId(UUID.randomUUID());
        item.setDotLevel(dotLevel);
        item.setEntryType(entryType);
        item.setSymbolName(symbolName);
        item.setTitleGrammar(tileGrammar);
        if (reclassTargets != null && reclassTargets.length > 0) {
        	//RevisionChangeItem reclass = new ReclassTransfer();
            for (String targSymbol: reclassTargets) {
                ReclassTransfer xfer = new ReclassTransfer();
                xfer.setReclassificationTypeCategory(ReclassificationTypeCategory.ADMIN);
                xfer.setTargetSymbolName(targSymbol);
                //xfer.setSourceSymbolName(item.getSymbolName());                
                
                item.getReclassTransfers().add(xfer);
            }
            
        }
         return item;
    }
    
    public static RevisionChangeItem createRevisionChangeItemAdminInventive(String entryType, String symbolName, String dotLevel, String tileGrammar, String[] reclassTargets) {
        RevisionChangeItem item = new RevisionChangeItem();
        //item.setId(UUID.randomUUID());
        item.setDotLevel(dotLevel);
        item.setEntryType(entryType);
        item.setSymbolName(symbolName);
        item.setTitleGrammar(tileGrammar);
        if (reclassTargets != null && reclassTargets.length > 0) {
        	//RevisionChangeItem reclass = new ReclassTransfer();
            for (String targSymbol: reclassTargets) {
                ReclassTransfer xfer = new ReclassTransfer();
                xfer.setReclassificationTypeCategory(ReclassificationTypeCategory.ADMIN);
                xfer.setReclassificationTypeTargetClassifiationCategory(ReclassificationTypeTargetClassifiationCategory.I);
                xfer.setTargetSymbolName(targSymbol);
                //xfer.setSourceSymbolName(item.getSymbolName());                
                
                item.getReclassTransfers().add(xfer);
            }
            
        }
         return item;
    }
    
    
    public static RevisionChangeItem createRevisionChangeItemWithIntelluctualReclassCategory(String entryType, String symbolName, String dotLevel, String tileGrammar, String[] reclassTargets) {
        RevisionChangeItem item = new RevisionChangeItem();
        //item.setId(UUID.randomUUID());
        item.setDotLevel(dotLevel);
        item.setEntryType(entryType);
        item.setSymbolName(symbolName);
        item.setTitleGrammar(tileGrammar);
        if (reclassTargets != null && reclassTargets.length > 0) {
        	//RevisionChangeItem reclass = new ReclassTransfer();
            for (String targSymbol: reclassTargets) {
                ReclassTransfer xfer = new ReclassTransfer();
                xfer.setReclassificationTypeCategory(ReclassificationTypeCategory.INTELLECTUAL);
                xfer.setTargetSymbolName(targSymbol);
                //xfer.setSourceSymbolName(item.getSymbolName());                
                
                item.getReclassTransfers().add(xfer);
            }
            
        }
         return item;
    }
    
    // Make sure, you have two re-class targets for this
    public static RevisionChangeItem createRevisionChangeItemWithBothReclassCategory(String entryType, String symbolName, String dotLevel, String tileGrammar, String[] reclassTargets) {
        RevisionChangeItem item = new RevisionChangeItem();
        //item.setId(UUID.randomUUID());
        item.setDotLevel(dotLevel);
        item.setEntryType(entryType);
        item.setSymbolName(symbolName);
        item.setTitleGrammar(tileGrammar);
        if (reclassTargets != null && reclassTargets.length > 0) {
        	int i=1;
            for (String targSymbol: reclassTargets) {
                ReclassTransfer xfer = new ReclassTransfer();
                if ( i % 2 == 0 ){
                	xfer.setReclassificationTypeCategory(ReclassificationTypeCategory.ADMIN);
                }else{
                	xfer.setReclassificationTypeCategory(ReclassificationTypeCategory.INTELLECTUAL);
                }
                
                xfer.setTargetSymbolName(targSymbol);
                //xfer.setSourceSymbolName(item.getSymbolName());                
                
                item.getReclassTransfers().add(xfer);
                i++;
            }
            
        }
         return item;
    }
    
    @Test
    public void testCreateRevisionChangeItemWithBothReclassCategory() {    	
    	 RevisionChangeItem rci = ProposalValidationHelperTest.createRevisionChangeItemWithBothReclassCategory("D", "A01B", "2", "dfstitle", null);
    	 Assert.assertEquals("2", rci.getDotLevel());
    }
    
    @Before
    public void setUp() throws Exception {
        datasetTestingService.loadOnce();
        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", 
                DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);          
    }
}
