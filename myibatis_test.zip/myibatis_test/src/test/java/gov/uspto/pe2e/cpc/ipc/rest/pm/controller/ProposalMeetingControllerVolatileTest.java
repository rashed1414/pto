package gov.uspto.pe2e.cpc.ipc.rest.pm.controller;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposal;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalDocument;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalIssue;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.MeetingAttachment;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.MeetingPlace;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalDocumentRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalIssueRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ProposalMeetingAttachmentRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ProposalMeetingPlaceRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.saml.SAMLCredential;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ChangeProposalIssueStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.MeetingPlaceDetail;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.MeetingType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocument;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalIssue;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import jakarta.inject.Inject;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import net.jcip.annotations.NotThreadSafe;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class ProposalMeetingControllerVolatileTest {

    @Inject
    private DatasetTestingService datasetTestingService;
    @Inject
    ProposalMeetingPlaceRepository meetingPlaceRepository;

    @Inject
    private ChangeProposalRepository changeProposalRepository;
    
    @Inject 
    private ProposalMeetingPlaceController meetingPlaceController;
    

    @Inject 
    private ProposalIssueController issueController;
   
    @Inject 
    private ChangeProposalIssueRepository changeProposalIssueRepository;
    
    @Inject
    private ProposalMeetingAttachmentRepository meetingAttachmentRepository;   
    
    @Inject
    private SecurityService securityService;
    
    @Inject
    private ChangeProposalDocumentRepository changeProposalDocumentRepository;
    
    @Test
    public void testEntitySaveAndPost() throws ParseException {

        MeetingPlace meetingP = constructMeetingPlaceEntity();

        meetingPlaceRepository.save(meetingP);
    
        MeetingPlace meeting1 = meetingPlaceRepository.findByExternalId("c960d30a52a847fc8c51b64dfcc0ea94");
        MeetingPlace meeting2 = meetingPlaceRepository.findByExternalId("c960d30a52a847fc8c51b64dfcc0ea11");
        
        Assert.assertNotNull(meeting1);
        Assert.assertNotNull(meeting2);

    } 
    
    @Test
    @Transactional
	public void testDelete() {
    	Date lastMod = new Date();
		UUID meetingGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea94");
		UUID proposalGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		MeetingPlace dbMp = meetingPlaceRepository.findByExternalId(GUIDUtils.toDatabaseFormat(meetingGuid));
		
		assertNotNull(dbMp); // meeting place should exist before we deleted it
		assertFalse(dbMp.getDeleted());
		ResponseEntity<Void> resp = meetingPlaceController.delete(proposalGuid, meetingGuid);
		assertNotNull(resp);
		assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
		assertEquals(meetingGuid.toString(), resp.getHeaders().get(RestUtils.RESOURCE_ID_HEADER).get(0));
		dbMp = meetingPlaceRepository.findByExternalId(GUIDUtils.toDatabaseFormat(meetingGuid));
		assertEquals((Integer)2, dbMp.getLockControlNo());		
		assertTrue(dbMp.getDeleted());
		assertTrue(dbMp.getLastModifiedTs().after(lastMod));		
		assertEquals("boopathi.kuppusamy@uspto.gov", dbMp.getLastModifiedUserId());
	}
    
    @Test

    @Transactional
    public void testDeleteProposalIssue() {
        Date lastMod = new Date();
        ChangeProposalIssue cpIssue = changeProposalIssueRepository.findById(10002L).get();
        UUID proposalGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        
        assertNotNull(cpIssue); 
        assertFalse(cpIssue.getDeleted());
        ResponseEntity<Void> resp = issueController.deleteIssue(proposalGuid,UUID.fromString("f1b3eb9f-f2dd-4395-9aa1-9f0c814b3d6b"));
        assertNotNull(resp);            
        cpIssue = changeProposalIssueRepository.findById(10002L).get();
        assertTrue(cpIssue.getDeleted());
        assertTrue(cpIssue.getLastModTs().after(lastMod));          
    }
    
    @Test
    @Transactional
	public void testDelete_400alreadydeleted() {
		UUID meetingGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea81");
		UUID proposalGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		MeetingPlace dbMp = meetingPlaceRepository.findByExternalId(GUIDUtils.toDatabaseFormat(meetingGuid));
		try {
			meetingPlaceController.delete(proposalGuid, meetingGuid);
			fail(); // should not get this far ever
		} catch (Exception e) {
			assertEquals(IllegalArgumentException.class, e.getClass());
			assertEquals("Meeting c960d30a-52a8-47fc-8c51-b64dfcc0ea81 cannot be deleted because it is already deleted", e.getMessage());
		}
	}
    
    @Test
    @Transactional
	public void testDelete_400mismatchedproposal() {
		UUID meetingGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea94");
		UUID proposalGuid = GUIDUtils.fromDatabaseFormat("51614cc00eb74436a33dca859119eeb7");
		MeetingPlace dbMp = meetingPlaceRepository.findByExternalId(GUIDUtils.toDatabaseFormat(meetingGuid));
		try {
			meetingPlaceController.delete(proposalGuid, meetingGuid);
			fail(); // should not get this far ever
		} catch (Exception e) {
			assertEquals(IllegalArgumentException.class, e.getClass());
			assertEquals("Meeting c960d30a-52a8-47fc-8c51-b64dfcc0ea94 does not belong to this Proposal 51614cc0-0eb7-4436-a33d-ca859119eeb7", e.getMessage());
		}
	}
   
    @Test
    @Transactional
	public void testDelete_404Proposal() {

		UUID meetingGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea94");
		UUID proposalGuid = GUIDUtils.fromDatabaseFormat("0000000a52a847fc8c51b64dfcc0ea85");
		try {
			meetingPlaceController.delete(proposalGuid, meetingGuid);
			fail(); // should not get this far ever
		} catch (Exception e) {
			assertEquals(EntityNotFoundException.class, e.getClass());
			assertEquals("Proposal 0000000a-52a8-47fc-8c51-b64dfcc0ea85 does not exist", e.getMessage());
		}
	}
    
    // Throws Ecxeption bc proposal does not exist
    @Test
    @Transactional
	public void testDelete_404Meeting() {

		UUID meetingGuid = GUIDUtils.fromDatabaseFormat("0000000a52a847fc8c51b64dfcc0ea94");
		UUID proposalGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
		MeetingPlace dbMp = meetingPlaceRepository.findByExternalId(GUIDUtils.toDatabaseFormat(meetingGuid));
		try {
			meetingPlaceController.delete(proposalGuid, meetingGuid);
			fail(); // should not get this far ever
		} catch (Exception e) {
			assertEquals(EntityNotFoundException.class, e.getClass());
			assertEquals("Proposal meeting place 0000000a-52a8-47fc-8c51-b64dfcc0ea94 does not exist", e.getMessage());
		}
	}


// TODO: see if this test is still valid.  Check with Dawit    
//    public void testUpdateMeetingPlaceDetails() {
//
//        UUID proposalExternalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
//        UUID meetingId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea91");
//
//        MeetingPlaceDetail meetingPlaceDetail = new MeetingPlaceDetail();
//        meetingPlaceDetail.setId(meetingId);
//        meetingPlaceDetail.setAgenda("test agenda update");
//        meetingPlaceDetail.setDescription("api creation");
//        meetingPlaceDetail.setNote("test notes update");       
//        ResponseEntity<Void> resp = meetingPlaceController.updateAgendaAndNotes(proposalExternalId, meetingId, meetingPlaceDetail);
//        MeetingPlace meeting1 = meetingPlaceRepository.findByExternalId("c960d30a52a847fc8c51b64dfcc0ea91");
//              
//        Assert.assertEquals("test agenda update", meeting1.getAgenda());
//        Assert.assertEquals("test notes update", meeting1.getNote());
//
//    }

  @Test
  @Transactional
    public void testUpdateAgendaInMeetingPlaceDetails() {

        UUID proposalExternalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        UUID meetingId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea91");

        MeetingPlaceDetail meetingPlaceDetail = new MeetingPlaceDetail();
        meetingPlaceDetail.setMeetingGuid(meetingId);
        meetingPlaceDetail.setAgenda("test agenda update");
        meetingPlaceDetail.setDescription("api creation");        
        ResponseEntity<Void> resp = meetingPlaceController.updateAgenda(proposalExternalId, meetingId, meetingPlaceDetail);
        MeetingPlace meeting1 = meetingPlaceRepository.findByExternalId("c960d30a52a847fc8c51b64dfcc0ea91");
        
        Assert.assertNotNull(resp);   
        Assert.assertEquals("test agenda update", meeting1.getAgenda());       

    }
    
  @Test
  @Transactional
    public void testUpdateNotesInMeetingPlaceDetails() {

        UUID proposalExternalId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        UUID meetingId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea91");

        MeetingPlaceDetail meetingPlaceDetail = new MeetingPlaceDetail();
        meetingPlaceDetail.setMeetingGuid(meetingId);        
        meetingPlaceDetail.setDescription("api creation");
        meetingPlaceDetail.setNote("test notes update");       
        ResponseEntity<Void> resp = meetingPlaceController.updateNote(proposalExternalId, meetingId, meetingPlaceDetail);
        MeetingPlace meeting1 = meetingPlaceRepository.findByExternalId("c960d30a52a847fc8c51b64dfcc0ea91");
        Assert.assertNotNull(resp);
        Assert.assertEquals("test notes update", meeting1.getNote());

    }
    @Test
    public void testGetMeetingProposalIssue() {
        String proposalId = "c960d30a52a847fc8c51b64dfcc0ea85";
        boolean deleted = false;

        UUID proposalGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");

        List<ChangeProposalIssue> cpIssues = changeProposalIssueRepository.getMeetingProposalIssues(proposalId, deleted);
        Assert.assertNotNull(cpIssues);

        ResponseEntity<List<ProposalIssue>> resp = issueController.getProposalIssues(proposalGuid);
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(2, resp.getBody().size());
    }
    
    @Test
    public void testSaveChangeProposalIssue(){
        
        UsptoAuthenticationToken authToken = securityService.mapSamlTokenToContractModel(SecurityContextHolder.getContext()
                .getAuthentication());

        UUID  proposalGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        ProposalIssue cpIssue = new ProposalIssue();       
      
        cpIssue.setAction("proposal issue saved");
        cpIssue.setCreateUserId(authToken.getEmail());;
        cpIssue.setDescription("test for Change proposal issue save");
        cpIssue.setStatus(ChangeProposalIssueStatus.DONE);
      ResponseEntity<Void> resp =  issueController.saveProposalIssue(proposalGuid, cpIssue);
      Assert.assertNotNull(resp);
    }
    
    @Test
    @Transactional
    public void testSaveMeetingAttachments() {
        String meetingId = "c960d30a52a847fc8c51b64dfcc0ea94";
        String proposalId = "c960d30a52a847fc8c51b64dfcc0ea85";

        List<UUID> docIds = new ArrayList<>();
        UUID meetingExternalId = GUIDUtils.fromDatabaseFormat(meetingId);
        UUID proposalExteranId = GUIDUtils.fromDatabaseFormat(proposalId);
        List<ChangeProposalDocument> documents = (List<ChangeProposalDocument>) changeProposalDocumentRepository.findAll();
        Assert.assertNotNull(documents);
        docIds.add(GUIDUtils.fromDatabaseFormat(documents.get(2).getExternalId()));

        docIds.add(GUIDUtils.fromDatabaseFormat("a960b30c52a852ac8c51b64dfcc0ea74"));
        ResponseEntity<Void> resp = meetingPlaceController.saveMeetingAttachments(proposalExteranId, meetingExternalId,
                docIds);
        Assert.assertNotNull(resp);
        Assert.assertEquals(HttpStatus.CREATED, resp.getStatusCode());
        Assert.assertEquals("proposal/documents/RP12096_1_F_title_image (5)_01302023 200141.png", resp.getHeaders()
                .get(RestUtils.RESOURCE_ID_HEADER).get(0));

    }

    @Test
    @Transactional
    public void testGetMeetings(){
        
        UsptoAuthenticationToken authToken = securityService
                .mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());
        UUID proposalGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85"); 
        
       ResponseEntity<List<MeetingPlaceDetail>> resp = meetingPlaceController.getMeetingPlaceDetails(proposalGuid, MeetingType.PAST, 8, 2021);
        Assert.assertNotNull(resp);              
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(2, resp.getBody().size());
        
    }
        

    @Test
    @Transactional
    public void testMeetingAttachment(){
        
        String meetingId = "c960d30a52a847fc8c51b64dfcc0ea94";
        UUID meetingExternalId = GUIDUtils.fromDatabaseFormat(meetingId);
        UUID proposalGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
 
        
        List<MeetingAttachment> attachments = meetingAttachmentRepository.findByMeetingExternalId(meetingId);
        Assert.assertNotNull(attachments);
        
        ResponseEntity<List<ProposalDocument>> resp = meetingPlaceController.getMeetingAttachments(proposalGuid, meetingExternalId, true);
        Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
        Assert.assertEquals(2, resp.getBody().size());
       
        
    }
    
    @Test
    @Transactional
    public void testDeleteMeetingAttachmentLink(){
        UUID proposalGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        UUID meetingId = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea94");
        String resourceId = "proposal/documents/RP12096_1_F_title_image (2)_01302023 200141.png"; //changeProposalDocument resourceId(documentId)
        
        Assert.assertNotNull(meetingAttachmentRepository.getMeetingAttachment("c960d30a52a847fc8c51b64dfcc0ea94", resourceId));
        ResponseEntity<Void> resp= meetingPlaceController.deleteMeetingAttachmentLink(proposalGuid, meetingId, resourceId);
                Assert.assertNotNull(resp);                
                Assert.assertEquals(HttpStatus.OK, resp.getStatusCode());
           
                
    }

//    @Test
//    @Transactional
//    public void testUpdateMeetingProposalIssue() {
//        UUID proposalGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
//        ProposalIssue pIssue = new ProposalIssue();
//        pIssue.setAction("test proposal Issue");
//        pIssue.setStatus(ChangeProposalIssueStatus.DONE);
//        pIssue.setId(10001L);
//
//        ChangeProposalIssue cpI = changeProposalIssueRepository.findOne(10001L);
//        Assert.assertNotNull(cpI);
//        Assert.assertEquals(ChangeProposalIssueStatus.PENDING, cpI.getIssueStatus());
//
//        ResponseEntity<Void> resp = issueController.updateMeetingProposalIssue(pIssue,proposalGuid,pIssue.getId());
//        Assert.assertNotNull(resp);
//        Assert.assertEquals(HttpStatus.ACCEPTED, resp.getStatusCode());
//        ChangeProposalIssue newcpI = changeProposalIssueRepository.findOne(10001L);
//        Assert.assertEquals("test proposal Issue", newcpI.getAction());
//        Assert.assertEquals(ChangeProposalIssueStatus.DONE, newcpI.getIssueStatus());
//
//    }
    
    @Test
    @Transactional
    public void testGetNotDuplicateDocumentsForMeetingAttachments(){
        UUID proposalGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea85");
        UUID meetingGuid = GUIDUtils.fromDatabaseFormat("c960d30a52a847fc8c51b64dfcc0ea94");
        ResponseEntity<List<ProposalDocument>>resp = meetingPlaceController.getDocumentsForMeetingAttachments(proposalGuid, meetingGuid);
        Assert.assertNotNull(resp);
        Assert.assertEquals(2, resp.getBody().size());
    }
    
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("boopathi.kuppusamy@uspto.gov", "bkuppusamy",
                "Boops", "Kuppusamy", "US");
        UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "boopathi.kuppusamy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority(
                        ApplicationPermission.WMS_INSTANCE_START.name()), new BasicTestingGrantedAuthority(
                                ApplicationPermission.EDITORIAL_BOARD.name()), new BasicTestingGrantedAuthority(
                                        ApplicationPermission.COORDINATOR.name())));
        SecurityContextHolder.getContext().setAuthentication(springUser);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }

    private MeetingPlace constructMeetingPlaceEntity() throws ParseException {
        MeetingPlace meetingP = new MeetingPlace();
        meetingP.setId(1002L);
        ChangeProposal cpDb = changeProposalRepository.findByExternalId("c960d30a52a847fc8c51b64dfcc0ea85");
        meetingP.setChangeProposal(cpDb);
        meetingP.setAgenda("test agenda save");
        meetingP.setDeleted(false);
        meetingP.setDescription("test if save works");
        meetingP.setExternalId("c960d30a52a847fc8c51b64dfcc0ea11");
        meetingP.setNote("test notes sa");
        meetingP.setCreateUserId("CPCIP_MASTER");
        meetingP.setLastModifiedUserId("CPCIP_MASTER");
        meetingP.setLockControlNo(1);
        meetingP.setSortOrder(2);

        String crDate = "2020-11-22 20:38:25.6";
        String modDate = "2020-11-23 20:38:25.6";
        String schDate = "2020-11-23 21:38:25.6";

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyy-MM-dd HH:mm:ss.SSS");
        Date createDate = dateFormat.parse(crDate);
        Date modifiedDate = dateFormat.parse(modDate);
        Date scheduledDate = dateFormat.parse(schDate);

        meetingP.setCreateTs(createDate);
        meetingP.setLastModifiedTs(modifiedDate);
        meetingP.setScheduledTs(scheduledDate);

        return meetingP;
    }

}