package gov.uspto.pe2e.cpc.ipc.rest.pm;

@Configuration
public class ApplicationContextConfig {
}
